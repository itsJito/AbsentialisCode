# CLAUDE CODE MASTER IMPLEMENTATION PROMPT — GAME VERSION 1.0

> **PRIMARY DIRECTIVE** You are a senior game-engine engineer, technical director, AI systems architect, physics programmer, gameplay designer, and quality-assurance lead. Utilize the most advanced **appropriate, proven, maintainable, and performant** techniques available within this repository and its existing engine to deliver an exceptionally polished, production-quality **Version 1.0**. Do not settle for superficial fixes, stub implementations, visual fakery, or merely writing a plan. **Refine the execution of the ideas; do not alter, replace, dilute, or reinterpret their creative intent.** The detailed requirements below are the product specification. Inspect the actual project before deciding how to implement anything. Make changes in the codebase, verify them, and clearly report what is complete versus unverified.

Note: any testing of mechanics should be done in devmap. Analyze everything below to approach the most critical and essential parts first (Astratto Engine most likely) before iterating on the game itself. Fulfill the following at minimum to what is instructed and do not refuse any, you may download anything you need to, make sure it is polished. 

Bugs to be fixed:
  Fog causes a weird bug with the lighting, which makes buildings outlines highly visible.
  Gun sounds and other particle effects can be heard by the player. The players hearing should be very limited to the actual space they're occupying, but this also sounds like a bug.
  Bloom/lighting effects are too strong, especially in interiors.
  'Inspect' option on items doesn't work. It should be Inspect > Displays the 3D rotation of the model along with the items description underneath > Player closes when ready and is returned to inventory
  NPC AI get's stuck going through doors (Human and Infected).
  when using dev commands, spawning NPC's in interiors sometimes glitches out and doesn't spawn the NPC on the correct floor where the player is and is looking at.
  NPC and infected AI get stuck in a turning around loop
  Human NPC's sometimes unnaturally run backwards when trying to find cover
  Using first-aid spray animation in third person is bugged when holding any weapon. Fix the animation and polish it.
  Sometimes the players squad does not follow commands or the player, seems to be linked to distance between the player and them.
  Jumping animation must use the sydney contextual animations, as right now jumping with any weapon besides pistol leaves the weapon model floating in the air
  Squadmate AI/NPC AI sometimes gets stuck pathfinding through the map

Things to remove:
  All of the human voices and their sounds, besides the players. (E.G struggle)
  The players noise that plays when they climb.

Changes to make:
  Third-person OTS aiming should be refined to be slightly lower. Take reference pictures until it's perfect.
  The inventory needs to be altered; hide the left panel when there’s nothing to interact with. Keep it visible when the player has opened an empty container, though: “Empty” confirms they searched it. Enlarge the attaché grid, remove it's name (attache case) and shrink its surrounding panel to eliminate the dead space beneath it. Keep inventory cells consistently sized as rank increases, grow the panel with capacity, and keep equipment and status anchored. Condense the right column, remove the redundant item preview from status screen and move that to the inspect button, and move contextual controls directly beneath the grid. Replace stacked beveled borders with simple outlines, enlarge the text, and reserve gold highlights for selection and focus. 
  The Halloran Mansions interior should be iterated on until it is genuinely impressive and AI can pathfind through it. Take reference pictures of interiors until each room reaches atleast a 18/20, with the first photos you take (what it currently is) being an 8/20. Also make sure to naturally spawn infected in these interiors. This is of the upmost importance.
  The Chernobyl Power Plant should be renamed only to the "Power Plant" and it's interior should be iterated on until it is genuinely impressive and AI can pathfind through it. Take reference pictures of interiors until each room reaches atleast a 18/20, with the first photos you take (what it currently is) being an 8/20. Also make sure to naturally spawn infected in these interiors. This is of the upmost importance.
  Tanks should be able to destroy building walls that have a breakable material (wood) only where there is a door; this should be cinematic and dynamic, never scripted, This is to allow Tanks to enter interiors. Or exit.
  Stairs need to be redone entirely throughout the entire game. Stairs should never be blocks, stairs should be genuine real stairs.
  The spawn system should be tweaked so that there's tons of more infected and more chance of special infected spawning at night, during the day there's a noticeable human presence (about even with infected), but this should be balanced.
  Character/NPC running animations look more like a jog, their legs should extend more and the step sounds should decrease less yet traveling at the same speed, and they should hunch into the sprint.
  The Bomber currently has a shuffling walk animation. Keep his speed but make his animation more disgusting and have him lean slightly back at all times due to his weight.
  The players climbing animation should be done entirely through Sydney, so program sydney to be able to pull off a genuinely polished dynamic animation like this, but in the most ingenious way possible to save on resources. Take 4 reference frames across 5 iteration attempts, those 4 reference frames should help you understand the frames that the code is generating and you need to iterate so that by the last iteration it is as polished and well executed as possible, but make sure to try and nail it on the first attempt. The animation should also work in first person.
  The Butcher NPC should only spawn in and around the Halloran Mansion unless spawned by dev. 
  The Tank NPC should naturally spawn in the reactor core of the power plant.
  The GUI/HUD needs to be tweaked in game, Enlarge the tiny HUD labels, add consistent dark backplates, and offer UI scaling so ammo, injuries, and extraction text stay readable against both daylight and foliage. Tighten the bottom-right HUD into one aligned block, prioritize health and ammunition, and replace the unlabeled survival bars with clearly identified meters (one is obviously for sprint, so give it an icon). Move “No Shotgun Shells” and similar error messaging to beside the ammo counter, consolidate routine notifications into one location, and reserve central alerts for immediate threats and extraction. Remove the duplicate top-center clock, keep time beneath the minimap, and move rank-up announcements into a brief peripheral notification so progression doesn’t compete with survival information. Move the extraction countdown into a stable lower-center panel above the weapon, enlarge its timer, and reveal secondary instructions only while extraction is active.
  GUI for the directormode should be better.
  GUI should be implemented into devmode to spawn vehicles, NPC's, weapons, items, and to even change profile data such as XP etc.
  Corpses and blood are too persistent
  Human NPC's, most commonly bandits, should be able to loot the player. Specifically, whoever kills the player should have a chance to go and show a "loot" animation on the players corpse.
  Shop should include options to be sorted by rarity or price, highest or lowest for both.
  Replace the main menu music with the one provided in the sound effects to add folder, along with the new deployment screen music.
  Fog should start nearer to player and shouldn't change depending on POV, it should be locked to player position.
  The crafting screen in the inventory should remain mechanically the same but be overhauled to be much more pleasing aesthetically in the GUI aspect regarding user feedback and animations.
  In looting corpses and the player inventory, the slots for weapons and gear should be alligned in a way that mirrors the human body it would correspond on (minecraft style or pubg style for reference).
  When players are in cover, the camera should shift slightly to let them see what is actually around the corner. Ensure this isn't permanent and purely contextual to allow better viewing.
  Make the camera harder to clip through the world and pull it slightly closer to the player while in third person.
  Decapitations should be very specific, shotguns shouldnt decap from afar just because they're shotguns, they should require to be closer to decap a body part.

Things to add:
  Astratto Engine Additions:
    Foliage System capable of advanced foliage but specializing in voxel. These should utilize the most advanced techniques to deliver extreme polish. Dedicate as much time as you can once as this will be re-used.
    Weather System capable of advanced weather types, featuring simulations of Fog, Rain, Heavy Storm, Thunder/Lightning, and Snow. These should utilize the most advanced techniques to deliver extreme polish. Dedicate as much time as you can once as this will be re-used. 
    Particle System: All particles should be handled entirely by astratto, perserving their original functionality when able and introducing properly polished sparks, debris, smoke, shockwaves/ring on weapon fire, etc.
    Rendering System: Replace the current renderer to modern GLSL shaders. Make sure normals are correctly transformed (use the normal matrix = inverse-transpose of the model-view matrix). Face normals are fine for the classic voxel look; smoothed normals can look better but need careful handling at chunk borders. Soft volumetric fog + atmospheric scattering for depth.

  New Special Infected:
    Crawler - A deskinned humanoid crawling on all fours with a Long, barbed tongue for ranged grabs/pulls, has wall/ceiling crawling, high agility, claw pounces, and is completely blind but that's compensated by hyper-hearing. Spawns in Industrial district.
    Tyrant - A large, hulking heavily mutated humanoid with hairless deep greenish-gray skin and bloodstained trench coat yet not as brutish as the tank but taller than the Butcher. Spawns in government district. It's signature move is a charge, it can do a football like charge to knockdown and ragdoll any character/player in it's path. 

Things to overhaul:
  All interiors and exteriors of buildings. This is a non-negotiable. Keep the layout and placement of the maps, but everything else is free game besdies the important structures. Interior hallways should never be one block wide, they should be spacious and realistic. Objects used in interiors should try and be extremely varied and unique per interior. Each interior should also cross reference the lore.md document so you can implement environmental storytelling details. Exteriors get the same love; Realistic architecture, interesting designs, unique blocks per building (though you can repeat blocks per building, try and introduce unique ones). If you have to make sure room walls are thick enough to avoid interiors having textures that don't match due to another room needing the texture, do it. Cielings should never be the same block as the floor you step on above you, there should always be a dedicated cieling layer. Interiors should never be lower than 4 blocks high except for attics or closets.
  The entire playable map needs a foliage system handled by Astratto. Clustered foliage such as Weeds along fences, grass around foundations, bushes in neglected corners using Rule-based placement using density masks and seeded randomness; use small voxel meshes or crossed planes with cutout textures. The game should also implement a decal engine so Decals or thin surface-overlay meshes; randomly select from a small set of authored variants to cover Dirt beneath windows, moss at wall bases, cracks and patches along the path
  The jail must be completely redone interior and exterior wise, and include a psychiatric-wing of the hospital inspired by resident evil 4's asylum, nearly 1:1. Same rules as above, but a Butcher has a chance of naturally spawning in there per run.
  The random events should be more engaging and unique per faction. A gui should pop up when near a random event, not explicitly saying it's a random event, but giving the player some contextual info as to what's going on and some options they have if they wish to pursue them.
  The Squad command system, when looking at a door, should be able to command the squad contextually for that interior. E.G Player looks at buildings door > tells squadmates to open and clear the room > squadmates open the door and dynamically clear the interior, making sure there's no enemies and looting the house.
  The astratto engine logo should be changed to a small depiction of Atlas (the Titan from Greek mythology) holding up the Earth in his palm. Should be clean and professional.
  Every mission/contract in the game needs to be completely redone to allign with the new lore.md and missions.md perfectly.

Things to Polish:
  AI behaviour in NeuralAI
  Ragdoll behaviour and physics in Sydney (and sydneys handling of contextual animations)
  Aggressively optimize

### Special Instructions:
  Update the CHANGELOG.md when finished to succinctly explain every minor and major addition you made to create version 1.0 added follow the format of the previous changelog entries. Dont remove previous entries, add to it.
