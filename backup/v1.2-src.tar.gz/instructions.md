# CLAUDE CODE MASTER IMPLEMENTATION PROMPT — GAME VERSION 1.2

> **PRIMARY DIRECTIVE** You are a senior expert level game-engine engineer, technical director, AI systems architect, physics programmer, gameplay designer, and quality-assurance lead. Utilize the most advanced **appropriate, proven, maintainable, and performant** techniques available within this repository and its existing engine to deliver an exceptionally polished, production-quality **Version 1.2**. Do not settle for superficial fixes, stub implementations, visual fakery, or merely writing a plan. **Refine the execution of the ideas; do not alter, replace, dilute, or reinterpret their creative intent.** The detailed requirements below are the product specification. Inspect the actual project before deciding how to implement anything. Make changes in the codebase, verify them, and clearly report what is complete versus unverified.

Note: any testing of mechanics should be done in devmap

Bugs to be fixed:
  Spider hitbox is bugged. Hitmarkers don't work on them.
  Dog/Infected dog hitbox is bugged. Hitmarkers don't work on them.
  Chicken/Crow hitbox is bugged. Hitmarkers don't work on them.
  Crows don't properly fly, they run to and climb up walls.
  devspawn doesnt properly account for all NPC's
  devspawn doesnt properly spawn crows or npc's at the exact cursor location.
  The entrance to the police station is completely bugged and blocked.
  Dogs/Infected dogs still wag tail on death.
  The Halloran Mansion interior has a lot of bugs, such as paintings blocking doors, backwards beds, objects that look weird. They need to be refined.
  Spiders currently target infected such as tyrants when they shouldn't
  The Police Station interior also has a lot of bugs, such as paintings blocking doors, backwards beds, objects that look weird. They need to be refined.
  The Power Plant interior also has a ton of weird bugs, such as paintings blocking doors, backwards beds, objects that look weird. They need to be refined.
  Devmode still can not pick up objects, entities or npc's with a click.
  Animals do not get hit by vehicles.
  Doors don't always move against bodies
  the stacked-glass bug appears when there are two glass blocks placed ontop of eachother and the top is broken first so the glass particles float in the air when the bottom is shot
  the truncated "valve at 556,24,286" item.

Things to remove:

Changes to make:
  The animation system should be entirely overhauled to be able to handle dynamic, polished animations on the fly. The stress test for this should be human aiming of weapons to appear way more natural, along with their body positioning and transitional animations.
  Human AI needs to be polished to behave way more convincingly
  Infected walk animation needs to be tweaked and polished
  When players/npc's grab onto a ledge to pull themselves up, it should actually be broken into 2 phases to allow the character/npc to actually stay held onto the ledge and sydney can handle the dangling of the legs while they are holding on. Pressing the jump button should continue and let them pull themselves onto the ledge, and pressing the button assigned to open doors should let them drop from the ledge. Keep this baked into the Sydney or Astratto engine.
  Fall animations should be present, polished, and dynamic. Sydney should ragdoll the NPC/Player if falling for more than 3 seconds AND ALSO play a small kicking/falling animation.
  The Med Cabinet texture should be redone completely and polished to look like an actual voxel med cabinet.
  The Tool Box texture should be redone entirely to be an actual tool box.
  All objects/blocks that let the player open them should be converted into an object form to allow for dynamic animations. Animations should show the players hand actually interacting with the container and the container opening/closing while in the screen. Make sure to ensure the new models won't conflict with where they currently exist in the world in many interiors.
  Humans/entities/NPCs/infected should all cast a shadow from vehicle lights.
  All special infected should carry at least 1 jewelry item, and randomize it so theres always a chance for valuable loot.
  The leaderboard in the deployment screen should be redone to be more visually appealing, and only include the top 20 on the leaderboard (always show players position, but if they're outside the top 20 put that at the very bottom after the 20th place with their actual spot listed instead of 21) with their #, Name (their rank should be the ranks insignia put next to their name, do the same for the players profile card by placing the insignia next to the name and rank name somewhere neat, and display the faction they belong too next to their name, not in its own tab), kills and standins
  All of the profile card background should be high-quality vectors and not ASCII looking art.
  Astratto Engine ASCII logo art needs to be something like the following but more professional like the Rage engine or the RE engine; styilized "A"
  Search online and replace the current chicken SFX for better ones. Also replace spider and Crow SFX with better ones.
  When the player presses the aim button while unarmed, they should be able to block and show an animation in both first and third person for blocking.
  When the player has a knife equipped, they should be able to block. Blocking with no knife does 3% less damage to the player vs 5% with a knife.
  Human AI should have much more realistic perception and shouldn't engage the player if they are more than 12 blocks away.
  Animals should be rigged to ragdoll on death via the Sydney engine.
  Quest givers, such as Nika Berdize/their equivalent, should be placed/moved in interiors or placed in more logical locations.
  Sydneys handling of recovering from ragdolls seems pre-animated, and it shouldn't be.

Things to add:
  Normal dog non-jumping bite animation
  There should be bloody mist that varies and is dynamic depending on what part of the character you shoot and how bad.
  Various dynamic and contextual animations that can be naturally simulated and transitioned between
  Inventory Discard:
    Add a 9x6 style attache menu in the inventory that contextually appears when an item is being rotated or moved, and stays when an item is placed in it and doesn't appear when the player isnt moving or rotating something. This is to allow the player to discard/drop multiple things at once. Shouldn't interfere with any existing GUI and should appear outside of it instead of integrated.

Things to overhaul:
  Any code that needs to be rewritten in c++ due to the new engine requirements.

Things to Polish:
  Procedural and contextual animation
  The faction system needs polish, look over it.
  NeuralAI needs to be polished so that Human AI actually implement and use tactics, E.G surrounding the player on multiple sides, blocking off exits to interiors if they suspect a player is in there so one member of an NPC team will wait by a door while the other searches the building ETC.
  Doors physically interacting with bodies should be more realistic and pleasing.
  Infected need to have a contextual dynamic animation for crawling through windows.
  NPC pathfinding on the map and in interiors needs to be refined. This is important.
  Dog walking/running and other animations need to be polished and smooth
  Spider walking/various animations need to be polished and smooth
  all Crow animations need to be polished and smooth
  all Chicken animations need to be polished and smooth
  Infected dog jumping bite animation needs to be scarier and more polished
  Third Person aiming animations should be better and more polished per weapon
  Characters naturally returning back to normal position from ragdoll
  Character idle animations have the entire body swaying
  Silent takedown stealth kill animations need to be polished in both third and first person
  NPC characters should be able to go crouch and prone through NeuralAI.
  Spiders combat is too overpowered and animations should be staggered instead of spammed.
  Spider death animations need way more polish. No canned deaths, all death ragdolls go through sydney.
  Infected walk, window-crawl and 1x1 crawl animations; crawler gait.
  Encounters 
  Ammo box, med cabinet and toolbox must be redesigned and polished; containers and wooden planks covering windows should be displayed as voxel objects instead of blocks.
  There should be a small Inventory discard case that only shows when the player is moving or rotating an object so they can discard multiple items at once. Shift clicking equipment and weapons from the stash in deployment should auto-equip, leaderboard should only show top 10 people with player always displayed at the bottom, profile cards should be completely redesigned but keeping the original what it was (e.g snowman stays snowman just redesigned) into vector graphics instead of voxel art.
  Doors don't always move against bodies, the stacked-glass bug appears when there are two glass blocks placed ontop of eachother and the top is broken first so the glass particles float in the air when the bottom is shot, and the truncated "valve at 556,24,286" item.
  Optimize aggressively and ingeniusly

Side objective:
  Astratto Engine:
    We need to turn the technology behind Absentialis into a proper, reusable **Astratto Engine**, preserving everything that can serve future games. This is more of the primary objective than the side for this session, as everything else will depend on it. Organize and architect it all as smart as you can.

    1. Preserve and extract all reusable technology. Audit every system, tool, shader, and asset pipeline. Move reusable capabilities into Astratto. Preserve their functionality, quality, and accumulated work even where implementation must be rewritten. 

    2. Establish a hard Java/C++ boundary:
       - C++ owns engine execution: world state, resource management, rendering, physics and physical animation through Sydney, NeuralAI’s perception/pathfinding/planning execution, and UltraEngine’s audio processing. GPU shaders remain shader code managed by the renderer.
       - Java owns gameplay and authoring: game rules, inventory behavior, HUD composition, missions, character goals, AI policies, and editor workflows. Java configures and requests engine services; C++ executes them.
       - One documented bridge connects them: a versioned C-compatible API with Java bindings, batched commands, events, and read-only state snapshots. C++ owns native memory and authoritative simulation state. No duplicated simulation, per-object cross-language calls, or Java callbacks inside rendering, physics, or audio processing loops.

    3. Separate engine capability from game content. Astratto provides reusable UI, persistence, simulation, and AI services. Absentialis supplies its specific interfaces, certain textures, some items, rules, behaviors, and content. The engine must build and run without depending on Absentialis, though we do not require the engine to be built, we just need you to start the ground work around the already existing game of absentialis

    4. Restructure whatever is necessary. Refactor individual systems or rebuild substantial portions of the game where required to achieve this architecture. Preserve working behavior and migrate in verified stages; retaining existing code must not compromise the boundary. All functionality must be properly translated if moving from java to c++.

    The objective is to preserve the value of everything already built to eventually produce a genuine engine that future Astratto games can use independently.

  Animation system overhaul, vehicle animation overhaul, 

  Human AI tactics and factions need polish. Human AI sometimes runs backwards, they should move their bodies realistically aswell as behave realistically.


### Special Instructions:
  Update the CHANGELOG.md when finished to succinctly explain every minor and major addition you made to create version 1.2 added follow the format of the previous changelog entries. Dont remove previous entries, add to it.
