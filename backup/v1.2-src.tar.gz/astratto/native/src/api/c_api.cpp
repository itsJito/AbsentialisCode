// Astratto Engine - the C interface: the one door in the wall. Nothing C++ crosses it, in either direction.
#include <cstddef>
#include <exception>
#include <new>

#include "astratto/astratto.h"
#include "core/engine.h"

using astratto::Engine;

// The layouts the other side of the bridge writes by hand: if one of these moves, so must every binding.
static_assert(sizeof(astratto_record) == 8, "record header");
static_assert(sizeof(astratto_block_def) == 8, "block def");
static_assert(sizeof(astratto_cmd_block_set) == 24, "block set");
static_assert(sizeof(astratto_cmd_door_seal) == 24, "door seal");
static_assert(sizeof(astratto_cmd_nav_tuning) == 24, "nav tuning");
static_assert(sizeof(astratto_cmd_path_request) == 48, "path request");
static_assert(sizeof(astratto_cmd_sight_request) == 40, "sight request");
static_assert(sizeof(astratto_evt_path_result) == 24, "path result");
static_assert(sizeof(astratto_evt_sight_result) == 16, "sight result");
static_assert(sizeof(astratto_frame_io) == 40 && offsetof(astratto_frame_io, commands) == 8 && offsetof(astratto_frame_io, events) == 24, "frame");
static_assert(sizeof(astratto_world_desc) == 40 && offsetof(astratto_world_desc, blocks) == 24, "world desc");
static_assert(sizeof(astratto_block_table) == 16, "block table");
static_assert(sizeof(astratto_snapshot_io) == 24, "snapshot");
static_assert(sizeof(astratto_stats) == 96, "stats");

struct astratto_engine { Engine impl; explicit astratto_engine(unsigned workers) : impl(workers) {} };

namespace {

thread_local int32_t createStatus = ASTRATTO_OK;

/** Runs a call's body; whatever it throws stays on this side of the boundary. */
template <typename F> int32_t guarded(astratto_engine* e, F&& body) {
    if (e == nullptr) return ASTRATTO_ERR_ARGUMENT;
    try { return body(e->impl); }
    catch (const std::bad_alloc&) { e->impl.fail("out of memory"); return ASTRATTO_ERR_MEMORY; }
    catch (const std::exception& x) { e->impl.fail(x.what()); return ASTRATTO_ERR_INTERNAL; }
    catch (...) { e->impl.fail("unknown failure"); return ASTRATTO_ERR_INTERNAL; }
}

}  // namespace

extern "C" {

uint32_t astratto_api_version(void) { return ASTRATTO_API_VERSION; }

const char* astratto_build_info(void) {
    return "Astratto Engine native core, API 1.0, built " __DATE__ " " __TIME__
#if defined(_MSC_VER)
           " (MSVC)"
#elif defined(__clang__)
           " (Clang)"
#elif defined(__GNUC__)
           " (GCC)"
#endif
        ;
}

int32_t astratto_create_status(void) { return createStatus; }

astratto_engine* astratto_create(const astratto_config* config) {
    createStatus = ASTRATTO_OK;
    if (config == nullptr || config->struct_size < sizeof(astratto_config)) { createStatus = ASTRATTO_ERR_ARGUMENT; return nullptr; }
    // a caller built for another major version would misread what it is given; one built for a later minor of this
    // major asks for things this engine has not got
    if ((config->api_version >> 16) != ASTRATTO_API_MAJOR || (config->api_version & 0xFFFFu) > ASTRATTO_API_MINOR) { createStatus = ASTRATTO_ERR_VERSION; return nullptr; }
    try { return new astratto_engine(config->worker_threads); }
    catch (const std::bad_alloc&) { createStatus = ASTRATTO_ERR_MEMORY; }
    catch (...) { createStatus = ASTRATTO_ERR_INTERNAL; }
    return nullptr;
}

void astratto_destroy(astratto_engine* engine) { delete engine; }

const char* astratto_last_error(astratto_engine* engine) { return engine == nullptr ? "no engine" : engine->impl.error(); }

int32_t astratto_world_block_table(astratto_engine* engine, const astratto_block_table* table) {
    return guarded(engine, [&](Engine& e) -> int32_t {
        if (table == nullptr || table->struct_size < sizeof(astratto_block_table) || table->count > 256 || (table->count > 0 && table->defs == nullptr)) { e.fail("bad block table"); return ASTRATTO_ERR_ARGUMENT; }
        e.world().setTable(table->defs, table->count);
        return ASTRATTO_OK;
    });
}

int32_t astratto_world_load(astratto_engine* engine, const astratto_world_desc* world) {
    return guarded(engine, [&](Engine& e) -> int32_t {
        if (world == nullptr || world->struct_size < sizeof(astratto_world_desc)) { e.fail("bad world description"); return ASTRATTO_ERR_ARGUMENT; }
        if (!e.world().load(world->size_x, world->size_y, world->size_z, world->below_floor_block, world->blocks, world->block_bytes)) { e.fail("world sizes out of range, or not the number of cells given"); return ASTRATTO_ERR_ARGUMENT; }
        return ASTRATTO_OK;
    });
}

int32_t astratto_frame(astratto_engine* engine, astratto_frame_io* io) {
    return guarded(engine, [&](Engine& e) -> int32_t {
        if (io == nullptr || io->struct_size < sizeof(astratto_frame_io) || (io->command_bytes > 0 && io->commands == nullptr)) { e.fail("bad frame"); return ASTRATTO_ERR_ARGUMENT; }
        const int32_t status = e.frame(io->commands, io->command_bytes, io->dt);
        io->events = e.events().empty() ? nullptr : e.events().data();
        io->event_bytes = static_cast<uint32_t>(e.events().size());
        io->event_count = e.eventCount();
        return status;
    });
}

int32_t astratto_snapshot(astratto_engine* engine, astratto_snapshot_io* io) {
    return guarded(engine, [&](Engine& e) -> int32_t {
        if (io == nullptr || io->struct_size < sizeof(astratto_snapshot_io)) { e.fail("bad snapshot request"); return ASTRATTO_ERR_ARGUMENT; }
        switch (io->kind) {
            case ASTRATTO_SNAPSHOT_STATS: { const astratto_stats& s = e.stats(); io->data = &s; io->bytes = sizeof(s); return ASTRATTO_OK; }
            default: e.fail("unknown snapshot kind"); io->data = nullptr; io->bytes = 0; return ASTRATTO_ERR_ARGUMENT;
        }
    });
}

}  // extern "C"
