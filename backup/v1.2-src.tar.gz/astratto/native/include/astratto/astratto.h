/*
 * Astratto Engine - the native core's public interface.
 *
 * This header is the whole of the bridge between the engine (C++) and whatever is built on it (Absentialis' gameplay
 * is Java; a future game need not be). It is plain C, so that any language with a foreign-function interface can bind
 * it, and it is versioned, so that a game built against one engine refuses to run on another instead of misreading it.
 *
 * The rules of the boundary - they are what this file is shaped by:
 *
 *   1. The engine owns native memory and the authoritative state of what it simulates. The caller never frees or
 *      writes anything the engine hands out; pointers returned by the engine are read-only and stay valid until the
 *      next call of the function that returned them.
 *   2. Nothing is asked of the engine one object at a time. The caller writes a batch of COMMANDS into a buffer and
 *      hands the whole batch over once a tick (astratto_frame). The engine answers with a batch of EVENTS.
 *   3. State is read back as SNAPSHOTS: immutable blocks of plain data (astratto_snapshot), never live objects.
 *   4. The engine never calls back into the caller. Not from the frame, not from a worker thread, not ever.
 *   5. Every structure starts with its own size, and every function takes pointers only and returns a status. That
 *      is what lets a structure grow in a later minor version without breaking a caller built against an older one.
 *
 * Byte order is the machine's (little-endian on every platform the engine builds for). All records in command and
 * event streams are aligned to four bytes.
 *
 * Copyright (c) Astratto North of LudusValley Recreations, under VEIN Enterprises.
 */
#ifndef ASTRATTO_H
#define ASTRATTO_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#if defined(_WIN32)
#  if defined(ASTRATTO_BUILD)
#    define ASTRATTO_API __declspec(dllexport)
#  elif defined(ASTRATTO_STATIC)
#    define ASTRATTO_API
#  else
#    define ASTRATTO_API __declspec(dllimport)
#  endif
#else
#  define ASTRATTO_API __attribute__((visibility("default")))
#endif

/* ------------------------------------------------------------------ version */
/* MAJOR moves when a caller built against the old header would misbehave; MINOR when something was only added. */
#define ASTRATTO_API_MAJOR 1
#define ASTRATTO_API_MINOR 0
#define ASTRATTO_API_VERSION ((uint32_t)((ASTRATTO_API_MAJOR << 16) | ASTRATTO_API_MINOR))

/* ------------------------------------------------------------------ status */
enum {
    ASTRATTO_OK = 0,
    ASTRATTO_ERR_ARGUMENT = -1,   /* a null pointer, a structure too small, a value out of range */
    ASTRATTO_ERR_VERSION = -2,    /* the caller was built against an incompatible major version */
    ASTRATTO_ERR_STATE = -3,      /* asked for before what it needs exists (a path before a world) */
    ASTRATTO_ERR_MEMORY = -4,
    ASTRATTO_ERR_STREAM = -5,     /* a malformed command stream; nothing after the bad record was run */
    ASTRATTO_ERR_INTERNAL = -6
};

typedef struct astratto_engine astratto_engine;

/* ------------------------------------------------------------------ making and ending an engine */
typedef struct astratto_config {
    uint32_t struct_size;
    uint32_t api_version;      /* ASTRATTO_API_VERSION the caller was compiled against */
    uint32_t worker_threads;   /* 0 = one per hardware thread, less one (the caller's own thread works too) */
    uint32_t reserved;
} astratto_config;

ASTRATTO_API uint32_t astratto_api_version(void);
ASTRATTO_API const char* astratto_build_info(void);
/* Returns null on failure; astratto_create_status says why. */
ASTRATTO_API astratto_engine* astratto_create(const astratto_config* config);
ASTRATTO_API int32_t astratto_create_status(void);
ASTRATTO_API void astratto_destroy(astratto_engine* engine);
/* The text of the last error on this engine (never null; empty when there has been none). */
ASTRATTO_API const char* astratto_last_error(astratto_engine* engine);

/* ------------------------------------------------------------------ the world: voxels */
/*
 * Block kinds are the game's, not the engine's: the engine is told only what it needs to know about each of the 256
 * possible ids. Flags the engine understands:
 */
enum {
    ASTRATTO_BLOCK_SOLID = 1u << 0,    /* a body cannot be where it is */
    ASTRATTO_BLOCK_OPAQUE = 1u << 1,   /* nothing is seen through it */
    ASTRATTO_BLOCK_CUTOUT = 1u << 2,   /* mesh or grating: solid, but seen through */
    ASTRATTO_BLOCK_CLIMB = 1u << 3,    /* something to hold (a ladder) */
    ASTRATTO_BLOCK_STEP = 1u << 4,     /* a stair tread: a step up onto it is walked, not jumped */
    ASTRATTO_BLOCK_LIQUID = 1u << 5,   /* waded through, slowly */
    ASTRATTO_BLOCK_HAZARD = 1u << 6,   /* never routed over or through */
    ASTRATTO_BLOCK_DOOR = 1u << 7      /* a door leaf: passable to those who open doors unless it is sealed */
};
enum { ASTRATTO_MATERIAL_OTHER = 0, ASTRATTO_MATERIAL_GLASS = 1, ASTRATTO_MATERIAL_FOLIAGE = 2 };

typedef struct astratto_block_def {
    uint32_t flags;
    uint16_t hide_mask;   /* for shaped blocks: bit n set = the shape hides a line crossing sixteenth n of its height */
    uint8_t material;     /* ASTRATTO_MATERIAL_* */
    uint8_t shape;        /* 0 = a full cube; anything else = furniture or a fitting (see hide_mask) */
} astratto_block_def;

typedef struct astratto_block_table {
    uint32_t struct_size;
    uint32_t count;                    /* at most 256; ids not given are air */
    const astratto_block_def* defs;
} astratto_block_table;

/*
 * A whole world at once. Cells are one byte each, laid out column by column: index = (x * size_z + z) * size_y + y.
 * The engine copies them; from then on its copy is changed only by ASTRATTO_CMD_BLOCK_SET.
 * Limits: size_x and size_z at most 1024, size_y at most 2048.
 */
typedef struct astratto_world_desc {
    uint32_t struct_size;
    uint32_t size_x, size_y, size_z;
    uint32_t below_floor_block;        /* the id reported for any cell under y = 0 */
    uint32_t reserved;
    const uint8_t* blocks;             /* size_x * size_y * size_z bytes */
    uint64_t block_bytes;
} astratto_world_desc;

ASTRATTO_API int32_t astratto_world_block_table(astratto_engine* engine, const astratto_block_table* table);
ASTRATTO_API int32_t astratto_world_load(astratto_engine* engine, const astratto_world_desc* world);

/* ------------------------------------------------------------------ commands (caller -> engine) */
/*
 * A command stream is a run of records. Each begins with this header; 'bytes' is the size of the whole record,
 * header included, and is a multiple of four. Unknown commands from a newer minor version are skipped.
 */
typedef struct astratto_record {
    uint32_t type;
    uint32_t bytes;
} astratto_record;

enum {
    ASTRATTO_CMD_BLOCK_SET = 1,       /* astratto_cmd_block_set */
    ASTRATTO_CMD_DOOR_SEAL = 2,       /* astratto_cmd_door_seal */
    ASTRATTO_CMD_NAV_TUNING = 3,      /* astratto_cmd_nav_tuning */
    ASTRATTO_CMD_DOORS_UNSEAL = 4,    /* a bare astratto_record: every door is unsealed (a new set of doors follows) */
    ASTRATTO_CMD_PATH_REQUEST = 16,   /* astratto_cmd_path_request -> ASTRATTO_EVT_PATH_RESULT */
    ASTRATTO_CMD_SIGHT_REQUEST = 17   /* astratto_cmd_sight_request -> ASTRATTO_EVT_SIGHT_RESULT */
};

typedef struct astratto_cmd_block_set { astratto_record head; int32_t x, y, z; uint32_t block; } astratto_cmd_block_set;
/* A door cell that may not simply be opened (locked and still latched), or may again. */
typedef struct astratto_cmd_door_seal { astratto_record head; int32_t x, y, z; uint32_t sealed; } astratto_cmd_door_seal;
typedef struct astratto_cmd_nav_tuning { astratto_record head; float jump_cost, ladder_cost, mantle_cost; uint32_t reserved; } astratto_cmd_nav_tuning;

enum {
    ASTRATTO_PATH_DOORS = 1u << 0,     /* the walker opens doors (and pulls itself up ledges, with MANTLE) */
    ASTRATTO_PATH_GOAL_Y = 1u << 1,    /* the goal is on a particular floor (ty is meaningful) */
    ASTRATTO_PATH_MANTLE = 1u << 2
};
typedef struct astratto_cmd_path_request {
    astratto_record head;
    uint32_t request;                  /* the caller's own number for it; comes back with the result */
    uint32_t flags;
    float sx, sy, sz;
    float tx, ty, tz;
    uint32_t max_expand;
    uint32_t reserved;
} astratto_cmd_path_request;

enum {
    ASTRATTO_SIGHT_LIGHT = 0,          /* stops at opaque blocks only */
    ASTRATTO_SIGHT_EYE = 1             /* what an eye sees through: walls, shut doors, furniture and canopy stop it */
};
typedef struct astratto_cmd_sight_request {
    astratto_record head;
    uint32_t request;
    uint32_t mode;
    float ax, ay, az;
    float bx, by, bz;
} astratto_cmd_sight_request;

/* ------------------------------------------------------------------ events (engine -> caller) */
enum {
    ASTRATTO_EVT_PATH_RESULT = 16,    /* astratto_evt_path_result, then cell_count * 3 int32 (x, y, z) */
    ASTRATTO_EVT_SIGHT_RESULT = 17    /* astratto_evt_sight_result */
};
enum { ASTRATTO_PATH_FOUND = 0, ASTRATTO_PATH_NONE = 1 };

typedef struct astratto_evt_path_result {
    astratto_record head;
    uint32_t request;
    uint32_t status;                   /* ASTRATTO_PATH_FOUND (cells follow; may stop short of the goal) or _NONE */
    uint32_t expansions;
    uint32_t cell_count;
} astratto_evt_path_result;

typedef struct astratto_evt_sight_result {
    astratto_record head;
    uint32_t request;
    uint32_t clear;                    /* 1 = nothing in the way */
} astratto_evt_sight_result;

/* ------------------------------------------------------------------ one tick */
/*
 * Hands over a batch of commands and runs the engine for dt seconds. Commands that change the world are applied in
 * the order written; requests are then answered against the world as the batch left it. On return 'events' points at
 * the engine's own memory - the answers, in the order the requests were written - and stays valid until the next
 * call of astratto_frame on this engine.
 */
typedef struct astratto_frame_io {
    uint32_t struct_size;
    float dt;
    const uint8_t* commands;
    uint32_t command_bytes;
    uint32_t reserved;
    const uint8_t* events;             /* out */
    uint32_t event_bytes;              /* out */
    uint32_t event_count;              /* out */
} astratto_frame_io;

ASTRATTO_API int32_t astratto_frame(astratto_engine* engine, astratto_frame_io* io);

/* ------------------------------------------------------------------ snapshots */
enum { ASTRATTO_SNAPSHOT_STATS = 1 };

typedef struct astratto_stats {
    uint32_t struct_size;
    uint32_t workers;
    uint64_t frames;
    uint64_t commands;
    uint64_t block_edits;
    uint64_t path_requests;
    uint64_t path_expansions;
    uint64_t paths_found;
    uint64_t sight_requests;
    uint32_t nav_version;              /* moves whenever a change could open or close a way through */
    uint32_t sealed_doors;
    float last_frame_ms;
    float worst_frame_ms;
    uint32_t world_x, world_y, world_z;
    uint32_t reserved;
} astratto_stats;

typedef struct astratto_snapshot_io {
    uint32_t struct_size;
    uint32_t kind;                     /* ASTRATTO_SNAPSHOT_* */
    const void* data;                  /* out: the engine's memory, valid until the next astratto_snapshot */
    uint64_t bytes;                    /* out */
} astratto_snapshot_io;

ASTRATTO_API int32_t astratto_snapshot(astratto_engine* engine, astratto_snapshot_io* io);

#ifdef __cplusplus
}
#endif
#endif
