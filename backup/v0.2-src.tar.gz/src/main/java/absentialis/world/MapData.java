package absentialis.world;

import java.util.ArrayList;
import java.util.List;

/**
 * Authored/seeded map metadata produced by the city generator: loot hotspots, extraction points,
 * insertion points, landmarks, the street waypoint graph, faction posts, nests and
 * infrastructure sites. Separate from voxel data so gameplay can reason about the city.
 */
public final class MapData {

    public static final class LootSpot {
        public final int x, y, z;
        public final String table;
        public final District district;
        public final long id;
        public boolean named;      // hand-placed named stash (persistently looted)
        public String tag;         // optional quest/document tag
        public LootSpot(int x, int y, int z, String table, District d) {
            this.x = x; this.y = y; this.z = z; this.table = table; this.district = d;
            this.id = ((long) x << 40) ^ ((long) y << 20) ^ z;
        }
    }

    public enum ExitType { PERMANENT, CONDITIONAL, TIME_WINDOW, SIGNALED, EMERGENCY }

    public static final class Exit {
        public final String id, name;
        public final int x, y, z;
        public final ExitType type;
        public final District district;
        public String condition = "";   // e.g. "rep:military:0", "pay:400", "item:key.metro", "power", "window:8-18", "item:flare"
        public String faction = "";     // faction controlling the exit (checkpoints)
        public float radius = 4.5f;
        public Exit(String id, String name, int x, int y, int z, ExitType t, District d) {
            this.id = id; this.name = name; this.x = x; this.y = y; this.z = z; this.type = t; this.district = d;
        }
    }

    public static final class Point {
        public final String name, kind;
        public final int x, y, z;
        public final District district;
        public String faction = "";
        public Point(String name, String kind, int x, int y, int z, District d) {
            this.name = name; this.kind = kind; this.x = x; this.y = y; this.z = z; this.district = d;
        }
    }

    public static final class Node {
        public final int id, x, y, z;
        public final District district;
        public final List<Integer> links = new ArrayList<>();
        public Node(int id, int x, int y, int z, District d) { this.id = id; this.x = x; this.y = y; this.z = z; this.district = d; }
    }

    public final List<LootSpot> loot = new ArrayList<>();
    public final List<Exit> exits = new ArrayList<>();
    public final List<Point> insertions = new ArrayList<>();
    public final List<Point> landmarks = new ArrayList<>();
    public final List<Point> posts = new ArrayList<>();       // faction guard posts / camps / shrines / checkpoints
    public final List<Point> nests = new ArrayList<>();       // infected nests
    public final List<Point> sites = new ArrayList<>();       // infrastructure / mission sites (substation, purifier ...)
    public final List<Point> documents = new ArrayList<>();   // document / signal spots
    public final List<Point> lampsOnPower = new ArrayList<>(); // street/interior lamps that depend on district power
    public final List<Point> barricades = new ArrayList<>();  // persistent barricade spots (breakable shortcuts)
    public final List<Node> nodes = new ArrayList<>();
    /** Placement audit results (world.gen.Validation): props lowered onto support / removed / still floating, nav nodes repaired / unusable. */
    public int propsGrounded, propsRemoved, propsFloating, nodesFixed, nodesBlocked, lootPruned;

    public void clear() {
        loot.clear(); exits.clear(); insertions.clear(); landmarks.clear(); posts.clear(); nests.clear();
        sites.clear(); documents.clear(); lampsOnPower.clear(); barricades.clear(); nodes.clear();
    }

    public Node addNode(int x, int y, int z, District d) {
        for (Node n : nodes) if (Math.abs(n.x - x) < 6 && Math.abs(n.z - z) < 6) return n;
        Node n = new Node(nodes.size(), x, y, z, d);
        nodes.add(n);
        return n;
    }

    public void link(Node a, Node b) {
        if (a == b) return;
        if (!a.links.contains(b.id)) a.links.add(b.id);
        if (!b.links.contains(a.id)) b.links.add(a.id);
    }

    public Node nearestNode(float x, float z) {
        Node best = null; float bd = Float.MAX_VALUE;
        for (Node n : nodes) { float d = (n.x - x) * (n.x - x) + (n.z - z) * (n.z - z); if (d < bd) { bd = d; best = n; } }
        return best;
    }

    public Point site(String name) { for (Point p : sites) if (p.name.equals(name)) return p; return null; }
    public Exit exit(String id) { for (Exit e : exits) if (e.id.equals(id)) return e; return null; }
    public LootSpot lootAt(int x, int y, int z) { for (LootSpot l : loot) if (l.x == x && l.y == y && l.z == z) return l; return null; }
}
