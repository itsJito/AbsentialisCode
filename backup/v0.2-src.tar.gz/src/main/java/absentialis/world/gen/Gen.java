package absentialis.world.gen;

import absentialis.engine.util.Rng;
import absentialis.world.Block;
import absentialis.world.District;
import absentialis.world.MapData;
import absentialis.world.World;

/** Shared generation context and voxel construction helpers. */
public final class Gen {
    public final World w;
    public final MapData map;
    public final Rng rng;
    public final long seed;
    public static final int G = World.GROUND;        // feet level on streets; street surface block is G-1
    public static final int FLOOR_H = 4;

    public Gen(World w, long seed) {
        this.w = w; this.map = w.map; this.seed = seed; this.rng = new Rng(seed);
    }

    public Rng rng(String salt) { return new Rng(Rng.mix(seed, salt.hashCode())); }
    public Rng rng(int a, int b) { return new Rng(Rng.mix(seed, a * 92821L + b * 7L)); }

    // ------------------------------------------------------------------ district layout
    /**
     * District plan. The power plant sits at the centre of the city on the north bank of the canal
     * and belongs to the Industrial district, which wraps round to the rail yard and the terminal;
     * the Government quarter faces it across the water. Downtown is north-west, the Residential
     * microdistricts fill the west, the Untamed blocks the south-east.
     */
    public static District planDistrict(int x, int z) {
        if (x < World.CITY_MIN || z < World.CITY_MIN || x >= World.CITY_MAX || z >= World.CITY_MAX) return District.WILDERNESS;
        if (x >= 256 && x < 448 && z >= 256 && z < 352) return District.INDUSTRIAL;
        if (x >= 256 && x < 448 && z >= 352 && z < 448) return District.CIVIC;
        if (z < 256 && x < 352) return District.OLD_QUARTER;
        if (x >= 352 && z < 344) return District.INDUSTRIAL;
        if (x < 256) return District.MARKET;
        return District.REDLINE;
    }

    public District district(int x, int z) { return w.district(x, z); }

    // ------------------------------------------------------------------ voxel helpers
    public void set(int x, int y, int z, int id) { w.setRaw(x, y, z, id); }
    public int get(int x, int y, int z) { return w.get(x, y, z); }
    public boolean air(int x, int y, int z) { return w.get(x, y, z) == Block.AIR; }

    public void setIfAir(int x, int y, int z, int id) { if (World.inBounds(x, y, z) && w.get(x, y, z) == 0) w.setRaw(x, y, z, id); }

    /** Fill inclusive box. */
    public void fill(int x0, int y0, int z0, int x1, int y1, int z1, int id) {
        int ax = Math.min(x0, x1), bx = Math.max(x0, x1), ay = Math.min(y0, y1), by = Math.max(y0, y1), az = Math.min(z0, z1), bz = Math.max(z0, z1);
        ax = Math.max(0, ax); az = Math.max(0, az); ay = Math.max(0, ay);
        bx = Math.min(World.W - 1, bx); bz = Math.min(World.D - 1, bz); by = Math.min(World.H - 1, by);
        for (int x = ax; x <= bx; x++) for (int z = az; z <= bz; z++) {
            int base = World.idx(x, 0, z);
            for (int y = ay; y <= by; y++) w.blocks[base + y] = (byte) id;
        }
    }

    /** Replace only blocks of id 'from' (or any non-air if from<0) inside the box. */
    public void replace(int x0, int y0, int z0, int x1, int y1, int z1, int from, int to) {
        for (int x = Math.min(x0, x1); x <= Math.max(x0, x1); x++)
            for (int y = Math.min(y0, y1); y <= Math.max(y0, y1); y++)
                for (int z = Math.min(z0, z1); z <= Math.max(z0, z1); z++) {
                    int c = w.get(x, y, z);
                    if ((from < 0 && c != 0) || c == from) set(x, y, z, to);
                }
    }

    /** Hollow walls of a box (no floor/roof). */
    public void walls(int x0, int y0, int z0, int x1, int y1, int z1, int id) {
        fill(x0, y0, z0, x1, y1, z0, id);
        fill(x0, y0, z1, x1, y1, z1, id);
        fill(x0, y0, z0, x0, y1, z1, id);
        fill(x1, y0, z0, x1, y1, z1, id);
    }

    /** Sphere of id (air for damage carving), optionally sparing ids in 'keep'. */
    public void sphere(float cx, float cy, float cz, float r, int id, boolean ragged) {
        for (int x = (int) (cx - r - 1); x <= cx + r + 1; x++) for (int y = (int) (cy - r - 1); y <= cy + r + 1; y++) for (int z = (int) (cz - r - 1); z <= cz + r + 1; z++) {
            float d = (float) Math.sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy) + (z - cz) * (z - cz));
            float rr = ragged ? r * (0.75f + 0.5f * Rng.hash(x, y, z, (int) seed)) : r;
            if (d <= rr && y > 1) set(x, y, z, id);
        }
    }

    /** Pile of rubble with a rough cone shape. */
    public void rubblePile(int cx, int cz, int r, int h, int id) {
        for (int x = cx - r; x <= cx + r; x++) for (int z = cz - r; z <= cz + r; z++) {
            float d = (float) Math.hypot(x - cx, z - cz) / (r + 0.5f);
            if (d > 1) continue;
            int top = (int) ((1 - d) * h + Rng.hash(x, 0, z, (int) seed) * 1.5f);
            int base = groundY(x, z);
            for (int y = base; y < base + top; y++) if (air(x, y, z)) set(x, y, z, Rng.hash(x, y, z, 7) < 0.25f ? Block.RUBBLE_BRICK : id);
        }
    }

    /** First air y above the highest solid at street level region (scans down from y0). */
    public int groundY(int x, int z) {
        for (int y = Math.min(World.H - 2, G + 40); y > 0; y--) {
            int id = w.get(x, y - 1, z);
            if (id != 0 && Block.ALL[id].solid()) {
                if (y <= G + 6 || true) return y;
            }
        }
        return G;
    }

    /** Lowest air at or above G scanning up from street level (inside lots). */
    public int surfaceY(int x, int z) {
        int y = G;
        while (y < World.H - 1 && w.get(x, y, z) != 0 && Block.ALL[w.get(x, y, z)].solid()) y++;
        return y;
    }

    // ------------------------------------------------------------------ gameplay markers
    public void container(int x, int y, int z, int blockId, String table) {
        set(x, y, z, blockId);
        String t = table != null ? table : Block.ALL[blockId].containerType;
        if (t == null) t = "crate";
        map.loot.add(new MapData.LootSpot(x, y, z, t, district(x, z)));
    }

    public MapData.LootSpot namedCache(int x, int y, int z, String table, String tag) {
        set(x, y, z, Block.STASH_CACHE);
        MapData.LootSpot l = new MapData.LootSpot(x, y, z, table, district(x, z));
        l.named = true;
        l.tag = tag;
        map.loot.add(l);
        return l;
    }

    /** Power-dependent lamp (switched by district power state at raid start). */
    public void lamp(int x, int y, int z) {
        set(x, y, z, Block.LAMP);
        map.lampsOnPower.add(new MapData.Point("lamp", "lamp", x, y, z, district(x, z)));
    }

    public void post(String name, String kind, String faction, int x, int y, int z) {
        MapData.Point p = new MapData.Point(name, kind, x, y, z, district(x, z));
        p.faction = faction;
        map.posts.add(p);
    }

    public void landmark(String name, String kind, int x, int y, int z) {
        map.landmarks.add(new MapData.Point(name, kind, x, y, z, district(x, z)));
    }

    public void site(String name, int x, int y, int z) {
        map.sites.add(new MapData.Point(name, "site", x, y, z, district(x, z)));
    }

    public void document(String docId, int x, int y, int z) {
        map.documents.add(new MapData.Point(docId, "document", x, y, z, district(x, z)));
    }

    public void nest(int x, int y, int z) {
        map.nests.add(new MapData.Point("nest", "nest", x, y, z, district(x, z)));
    }

    // ------------------------------------------------------------------ small props
    public void car(int x, int z, boolean alongX, int color, boolean wrecked) {
        int y = G;
        int len = 4, wid = 2;
        int dx = alongX ? len : wid, dz = alongX ? wid : len;
        if (wrecked && rng.chance(0.3)) color = Block.CAR_RUST;
        // body
        fill(x, y, z, x + dx - 1, y, z + dz - 1, color);
        // cabin
        if (alongX) {
            fill(x + 1, y + 1, z, x + 2, y + 1, z + dz - 1, Block.CAR_WINDOW);
            if (!wrecked || rng.chance(0.5)) { set(x + 1, y + 1, z, color); set(x + 1, y + 1, z + dz - 1, color); }
        } else {
            fill(x, y + 1, z + 1, x + dx - 1, y + 1, z + 2, Block.CAR_WINDOW);
            if (!wrecked || rng.chance(0.5)) { set(x, y + 1, z + 1, color); set(x + dx - 1, y + 1, z + 1, color); }
        }
        if (wrecked && rng.chance(0.4)) { // smashed windows
            replace(x, y + 1, z, x + dx - 1, y + 1, z + dz - 1, Block.CAR_WINDOW, Block.AIR);
        }
        if (wrecked && rng.chance(0.15)) set(x + dx / 2, y + (rng.chance(0.5) ? 1 : 0), z + dz / 2, Block.ASH);
    }

    public void truck(int x, int z, boolean alongX, int color) {
        int y = G, len = 7, wid = 3;
        int dx = alongX ? len : wid, dz = alongX ? wid : len;
        fill(x, y, z, x + dx - 1, y + 2, z + dz - 1, color);
        if (alongX) { fill(x, y + 1, z, x, y + 1, z + dz - 1, Block.CAR_WINDOW); fill(x + 2, y, z, x + dx - 1, y + 2, z + dz - 1, Block.CANVAS_OLIVE); }
        else { fill(x, y + 1, z, x + dx - 1, y + 1, z, Block.CAR_WINDOW); fill(x, y, z + 2, x + dx - 1, y + 2, z + dz - 1, Block.CANVAS_OLIVE); }
    }

    public void tree(int x, int y, int z, int h, boolean dead) {
        for (int i = 0; i < h; i++) set(x, y + i, z, Block.LOG);
        if (dead) {
            for (int b = 0; b < 3; b++) {
                int dx = rng.range(-1, 1), dz = rng.range(-1, 1);
                setIfAir(x + dx, y + h - 1 - b, z + dz, Block.LOG);
            }
            for (int i = 0; i < 6; i++) setIfAir(x + rng.range(-2, 2), y + h - rng.range(0, 2), z + rng.range(-2, 2), Block.DEAD_LEAVES);
            return;
        }
        int r = 2 + (h > 6 ? 1 : 0);
        for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) for (int dy = -1; dy <= 2; dy++) {
            float d = (float) Math.sqrt(dx * dx + dz * dz + (dy - 0.5f) * (dy - 0.5f) * 1.6f);
            if (d <= r + 0.3f && Rng.hash(x + dx, y + dy, z + dz, 3) > 0.12f) setIfAir(x + dx, y + h - 1 + dy, z + dz, Block.LEAVES);
        }
    }

    public void streetLamp(int x, int z, int dirX, int dirZ) {
        for (int y = G; y < G + 5; y++) set(x, y, z, Block.STEEL_BEAM);
        set(x + dirX, G + 5, z + dirZ, Block.STEEL_BEAM);
        set(x, G + 5, z, Block.STEEL_BEAM);
        lamp(x + dirX * 2, G + 5, z + dirZ * 2);
    }

    public void barrelFire(int x, int z) {
        set(x, G, z, Block.BARREL_FIRE);
        setIfAir(x, G + 1, z, Block.FIRE);
    }

    public void sandbagWall(int x0, int z0, int x1, int z1, int h) {
        fill(x0, G, z0, x1, G + h - 1, z1, Block.SANDBAG);
    }
}
