package absentialis.world.gen;

import static absentialis.world.gen.Gen.G;

import absentialis.engine.util.Noise;
import absentialis.engine.util.Rng;
import absentialis.world.Block;
import absentialis.world.World;
import absentialis.world.gen.Buildings.Roof;
import absentialis.world.gen.Buildings.Spec;
import absentialis.world.gen.Buildings.Style;

/**
 * The irradiated Wilderness beyond the quarantine wall: rolling terrain that grows more desolate
 * with distance, forests, farmsteads, the eastern highway, pylons and the cordon wall itself.
 * Radiation damage increases with distance from the city, so the playable edge feels like the
 * border of a much larger world rather than an invisible wall.
 */
public final class WildernessGen {
    private final Gen g;
    private final int[] height = new int[World.W * World.D];
    public static final int HWY_Z0 = 174, HWY_Z1 = 187;

    public WildernessGen(Gen g) { this.g = g; }

    private int h(int x, int z) { return height[x * World.D + z]; }

    public void terrain() {
        int seed = (int) g.seed;
        for (int x = 0; x < World.W; x++) for (int z = 0; z < World.D; z++) {
            float dist = World.outsideDistance(x, z);
            if (dist <= 0) { height[x * World.D + z] = G - 1; continue; }
            float t = smooth(Math.min(1, dist / 26f));
            float n = Noise.fbm(x / 70f, z / 70f, 4, seed) * 22 - 9 + Noise.fbm(x / 17f, z / 17f, 2, seed + 5) * 4;
            int hh = (int) (G - 1 + n * t);
            // flatten the highway corridor
            if (x >= World.CITY_MAX && z >= HWY_Z0 - 3 && z < HWY_Z1 + 3) hh = G - 1;
            hh = Math.max(8, Math.min(G + 22, hh));
            height[x * World.D + z] = hh;
            float desolation = Math.min(1, dist / 90f);
            // ground cover changes in broad drifts (fbm), so fields, burnt ground and ash read as places
            float r = Noise.fbm(x / 21f, z / 21f, 3, seed + 31);
            g.set(x, 0, z, Block.BEDROCK);
            g.fill(x, 1, z, x, hh - 4, z, Block.STONE_DARK);
            g.fill(x, hh - 3, z, x, hh - 1, z, Block.DIRT);
            int top;
            if (hh < G - 6) top = r < 0.5f ? Block.MUD : Block.GRAVEL;
            else if (r < 0.22f + desolation * 0.30f) top = Block.DEAD_GRASS;
            else if (r > 0.86f - desolation * 0.12f) top = Block.ASH;
            else top = Block.GRASS;
            g.set(x, hh, z, top);
            // standing water in hollows
            if (hh < G - 5) g.fill(x, hh + 1, z, x, G - 5, z, Block.WATER);
        }
        // highway
        for (int x = World.CITY_MAX; x < World.W; x++) for (int z = HWY_Z0; z < HWY_Z1; z++) {
            int across = z - HWY_Z0;
            int id = across == 0 || across == HWY_Z1 - HWY_Z0 - 1 ? Block.CURB : (across == 6 && (x / 3) % 3 != 0 ? Block.ROAD_LINE : (Rng.hash(x, 3, z, 3) < 0.12f ? Block.ASPHALT_CRACKED : Block.ASPHALT));
            g.set(x, G - 1, z, id);
            g.fill(x, G, z, x, World.H - 1, z, Block.AIR);
        }
    }

    private static float smooth(float t) { return t * t * (3 - 2 * t); }

    public void quarantineWall(Streets st) {
        Rng r = g.rng("wall");
        int lo = World.CITY_MIN - 4, hi = World.CITY_MAX + 2; // wall occupies [lo, lo+1] and [hi, hi+1]
        for (int i = lo; i <= hi + 1; i++) {
            wallColumn(i, lo, r); wallColumn(i, lo + 1, r);
            wallColumn(i, hi, r); wallColumn(i, hi + 1, r);
            wallColumn(lo, i, r); wallColumn(lo + 1, i, r);
            wallColumn(hi, i, r); wallColumn(hi + 1, i, r);
        }
        // fill the gap between the wall and the perimeter road
        for (int i = lo; i <= hi + 1; i++) for (int k = lo + 2; k < World.CITY_MIN; k++) {
            gapGround(i, k); gapGround(k, i); gapGround(i, World.CITY_MAX + (k - lo - 2)); gapGround(World.CITY_MAX + (k - lo - 2), i);
        }
        // watchtowers
        for (int i = lo + 24; i < hi; i += 56) {
            tower(i, lo - 3); tower(i, hi - 1); tower(lo - 3, i); tower(hi - 1, i);
        }
        // gates and breaches
        opening(hi, HWY_Z0 + 1, HWY_Z1 - 2, false, true, r);              // eastern highway gate (open)
        g.post("East Gate", "checkpoint", "military", World.CITY_MAX - 6, G, (HWY_Z0 + HWY_Z1) / 2);
        opening(lo, 414, 426, false, false, r);                             // fringe breach (west)
        breachRubble(lo - 2, 420, r);
        opening(lo, 300, 304, false, false, r);                             // market west gate
        for (int x = 414; x <= 426; x++) for (int y = G; y < G + 7; y++) { g.set(x, y, hi, Block.GATE_METAL); g.set(x, y, hi + 1, Block.GATE_METAL); } // cordon gate (closed)
        // random collapsed sections let the player wander into the wilderness
        int[][] breaches = {{0, 160}, {0, 520}, {1, 250}, {1, 470}, {2, 140}, {2, 560}, {3, 330}, {3, 520}};
        for (int[] b : breaches) {
            int side = b[0], p = b[1];
            boolean alongX = side == 0 || side == 2;
            int fixed = (side == 0 || side == 3) ? lo : hi;
            if (side == 3) fixed = lo;
            if (alongX) { opening(p, fixed, fixed, true, false, r); } else opening(fixed, p, p + 4, false, false, r);
        }
        // radiation warnings outside the wall
        for (int i = lo + 10; i < hi; i += 40) {
            sign(i, lo - 5); sign(i, hi + 6); sign(lo - 5, i); sign(hi + 6, i);
        }
    }

    private void gapGround(int x, int z) {
        if (x < 0 || z < 0 || x >= World.W || z >= World.D) return;
        if (World.outsideDistance(x, z) <= 0) return;
        g.fill(x, 1, z, x, G - 2, z, Block.DIRT);
        g.set(x, G - 1, z, Block.GRAVEL);
        g.fill(x, G, z, x, G + 25, z, Block.AIR);
    }

    private void wallColumn(int x, int z, Rng r) {
        if (x < 0 || z < 0 || x >= World.W || z >= World.D) return;
        g.fill(x, G - 5, z, x, G + 6, z, Rng.hash(x, 1, z, 3) < 0.1f ? Block.CONCRETE_STAINED : Block.CONCRETE);
        g.set(x, G + 7, z, Block.BARBED);
        if ((x + z) % 16 == 0) g.set(x, G + 3, z, Block.HAZARD_STRIPE);
        if (Rng.hash(x, 2, z, 3) < 0.02f) g.set(x, G + 2, z, Block.GRAFFITI);
    }

    /** Clears a wall section. alongX: wall runs along x at z=b0 (clears x in [a,a+4]); else wall at x=a, clears z in [b0,b1]. */
    private void opening(int a, int b0, int b1, boolean alongX, boolean gate, Rng r) {
        for (int y = G; y <= G + 7; y++) for (int t = 0; t < 2; t++) {
            if (alongX) for (int x = a; x <= a + 4; x++) g.set(x, y, b0 + t, Block.AIR);
            else for (int z = b0; z <= b1; z++) g.set(a + t, y, z, Block.AIR);
        }
        if (alongX) g.rubblePile(a + 2, b0 + (b0 < 300 ? -3 : 4), 3, 2, Block.RUBBLE);
        if (gate) for (int b = b0; b <= b1; b++) g.set(a - 1, G, b, (b - b0) % 3 == 0 ? Block.BARRIER : Block.AIR);
    }

    private void breachRubble(int x, int z, Rng r) {
        g.rubblePile(x, z, 5, 3, Block.RUBBLE);
        for (int i = 0; i < 6; i++) g.setIfAir(x + r.range(-4, 4), G, z + r.range(-6, 6), Block.CONCRETE);
        g.landmark("Fringe Breach", "breach", x, G, z);
    }

    private void tower(int x, int z) {
        if (x < 2 || z < 2 || x > World.W - 6 || z > World.D - 6) return;
        for (int y = G - 1; y < G + 10; y++) { g.set(x, y, z, Block.STEEL_BEAM); g.set(x + 3, y, z, Block.STEEL_BEAM); g.set(x, y, z + 3, Block.STEEL_BEAM); g.set(x + 3, y, z + 3, Block.STEEL_BEAM); }
        g.fill(x, G + 10, z, x + 3, G + 10, z + 3, Block.GRATE);
        g.walls(x, G + 11, z, x + 3, G + 11, z + 3, Block.SANDBAG);
        g.fill(x, G + 13, z, x + 3, G + 13, z + 3, Block.CANVAS_OLIVE);
        g.set(x + 1, G + 12, z + 1, Block.RED_LIGHT);
    }

    private void sign(int x, int z) {
        if (x < 1 || z < 1 || x >= World.W - 1 || z >= World.D - 1) return;
        int y = h(x, z) + 1;
        if (y < 4 || y > World.H - 5) return;
        g.set(x, y, z, Block.STEEL_BEAM); g.set(x, y + 1, z, Block.STEEL_BEAM); g.set(x, y + 2, z, Block.BIOHAZARD);
    }

    /** Forests, farmsteads, pylons, wrecks along the highway and scattered camps. */
    public void outskirts() {
        Rng r = g.rng("outskirts");
        int seed = (int) g.seed;
        for (int x = 2; x < World.W - 2; x++) for (int z = 2; z < World.D - 2; z++) {
            float dist = World.outsideDistance(x, z);
            if (dist < 8) continue;
            if (x >= World.CITY_MAX && z >= HWY_Z0 - 4 && z < HWY_Z1 + 4) continue;
            float forest = Noise.fbm(x / 45f, z / 45f, 3, seed + 99);
            float hh = Rng.hash(x, 7, z, seed);
            int y = h(x, z) + 1;
            if (y >= World.H - 12 || g.get(x, y - 1, z) == Block.WATER || g.get(x, y, z) != 0) continue;
            boolean dead = dist > 55 || hh < 0.2f;
            // woods grow in stands; open ground stays open (no lone trees, no stray boulders)
            if (forest > 0.55f && hh < 0.05f) g.tree(x, y, z, 5 + r.nextInt(4), dead && dist > 40);
            else if (forest > 0.42f && hh > 0.95f && g.get(x, y - 1, z) == Block.GRASS) g.set(x, y, z, Block.TALL_GRASS);
        }
        // farmsteads on level ground
        int placed = 0;
        for (int tries = 0; tries < 400 && placed < 7; tries++) {
            int x = r.nextInt(World.W - 30) + 4, z = r.nextInt(World.D - 30) + 4;
            if (World.outsideDistance(x, z) < 20 || World.outsideDistance(x + 20, z + 20) < 20) continue;
            if (z + 20 >= HWY_Z0 - 4 && z <= HWY_Z1 + 4 && x > World.CITY_MAX) continue;
            if (!flatEnough(x, z, 18, 16)) continue;
            farmstead(x, z, r);
            placed++;
        }
        // pylons marching away from the city
        for (int x = World.CITY_MAX + 14; x < World.W - 4; x += 30) { int z = 230; if (flatEnough(x - 2, z - 2, 6, 6)) pad(x - 2, z - 2, 6, 6); new Landmarks(g).pylon(x, z, 20); }
        for (int z = World.CITY_MAX + 14; z < World.D - 4; z += 30) { int x = 470; pad(x - 2, z - 2, 6, 6); new Landmarks(g).pylon(x, z, 20); }
        // highway wrecks + jackknifed convoy
        for (int x = World.CITY_MAX + 8; x < World.W - 6; x += 9 + r.nextInt(8)) {
            int z = HWY_Z0 + 2 + r.nextInt(7);
            if (r.chance(0.7)) g.car(x, z, true, r.pick(new int[]{Block.CAR_RUST, Block.CAR_WHITE, Block.CAR_BLUE, Block.CAR_RED}), true);
            else g.truck(x, HWY_Z0 + 3, true, Block.CAR_OLIVE);
        }
        g.container(660, G, HWY_Z0 + 2, Block.CRATE_MIL, "military");
        g.landmark("Eastern Highway", "highway", 660, G, 180);
        // a handful of hunter camps, each a known place a good walk from the next - not a tent in every field
        java.util.List<int[]> camps = new java.util.ArrayList<>();
        for (int i = 0; i < 400 && camps.size() < 10; i++) {
            int x = r.nextInt(World.W - 10) + 5, z = r.nextInt(World.D - 10) + 5;
            if (World.outsideDistance(x, z) < 15) continue;
            int y = h(x, z) + 1;
            if (y != G || g.get(x, y, z) != 0 || !flatEnough(x - 3, z - 2, 7, 8)) continue;
            boolean crowded = false;
            for (int[] c : camps) if (Math.abs(c[0] - x) + Math.abs(c[1] - z) < 110) crowded = true;
            if (crowded) continue;
            camps.add(new int[]{x, z});
            g.landmark("Hunter Camp", "camp", x, G, z);
            new Landmarks(g).tent(x, z, Block.TARP, r);
            g.container(x + 2, y, z - 1, Block.STASH_CACHE, "cache");
            g.set(x - 2, y, z - 1, Block.EMBER);
        }
    }

    private boolean flatEnough(int x0, int z0, int w, int d) {
        for (int x = x0; x < x0 + w; x += 2) for (int z = z0; z < z0 + d; z += 2) {
            if (x < 0 || z < 0 || x >= World.W || z >= World.D) return false;
            if (Math.abs(h(x, z) - (G - 1)) > 3) return false;
        }
        return true;
    }

    private void pad(int x0, int z0, int w, int d) {
        for (int x = x0; x < x0 + w; x++) for (int z = z0; z < z0 + d; z++) {
            if (x < 0 || z < 0 || x >= World.W || z >= World.D) continue;
            g.fill(x, 1, z, x, G - 2, z, Block.DIRT);
            g.set(x, G - 1, z, Block.DEAD_GRASS);
            g.fill(x, G, z, x, G + 30, z, Block.AIR);
        }
    }

    private void farmstead(int x, int z, Rng r) {
        pad(x - 2, z - 2, 22, 20);
        Spec house = new Spec(x, z, 9, 8);
        house.floors = 2; house.style = Style.HOUSE; house.wall = r.chance(0.5) ? Block.WOOD_PLANKS : Block.PLASTER; house.trim = Block.WOOD_DARK;
        house.roofType = Roof.PITCHED; house.roof = Block.ROOF_TILES; house.street[2] = true; house.damage = r.range(0.1f, 0.5f); house.lit = false; house.basement = r.chance(0.4);
        new Buildings(g).build(house);
        Spec barn = new Spec(x + 11, z, 8, 12);
        barn.floors = 1; barn.style = Style.WAREHOUSE; barn.wall = Block.WOOD_GREEN; barn.trim = Block.WOOD_DARK; barn.roofType = Roof.PITCHED; barn.roof = Block.ROOF_METAL; barn.street[3] = true; barn.lootBias = "farm";
        new Buildings(g).build(barn);
        for (int k = 0; k < 16; k++) g.set(x - 2 + k, G, z + 16, Block.WOOD_DARK);
        g.container(x + 4, G, z + 10, Block.CRATE, "farm");
        g.landmark("Abandoned Farmstead", "farm", x + 5, G, z + 5);
    }
}
