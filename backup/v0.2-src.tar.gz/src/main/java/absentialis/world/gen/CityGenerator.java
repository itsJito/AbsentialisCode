package absentialis.world.gen;

import static absentialis.world.gen.Gen.G;

import absentialis.engine.util.Rng;
import absentialis.world.Block;
import absentialis.world.District;
import absentialis.world.MapData;
import absentialis.world.MapData.ExitType;
import absentialis.world.World;
import absentialis.world.gen.Streets.Rect;
import absentialis.world.gen.Streets.Style;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Deterministic generation of the whole Zone from a seed: five districts around the Civic Core,
 * the canal, arterial avenues, sewers, metro, the quarantine wall and the irradiated wilderness.
 * Mission-critical landmarks are authored placements; clutter, weathering and loot are seeded.
 */
public final class CityGenerator {
    private final World w;
    private final Gen g;
    public final Streets streets;
    private final Consumer<String> progress;

    // district sub-areas (between arterial roads)
    public static final Rect OQ = new Rect(104, 104, 346, 244);
    public static final Rect IND_N = new Rect(358, 104, 600, 244);
    public static final Rect IND_SE = new Rect(460, 256, 600, 344);
    public static final Rect MKT_N = new Rect(104, 256, 244, 344);
    public static final Rect MKT_S = new Rect(104, 360, 244, 600);
    public static final Rect CIV_N = new Rect(256, 256, 448, 344);
    public static final Rect CIV_S = new Rect(256, 360, 448, 448);
    public static final Rect RED_E = new Rect(460, 360, 600, 448);
    public static final Rect RED_S = new Rect(256, 460, 600, 600);

    public CityGenerator(World w, long seed, Consumer<String> progress) {
        this.w = w;
        this.g = new Gen(w, seed);
        this.streets = new Streets(g);
        this.progress = progress == null ? s -> {} : progress;
        w.seed = seed;
    }

    public void generate() {
        long t0 = System.currentTimeMillis();
        w.map.clear();
        java.util.Arrays.fill(w.blocks, (byte) 0);
        progress.accept("Surveying district boundaries");
        for (int x = 0; x < World.W; x++) for (int z = 0; z < World.D; z++) w.districtMap[x * World.D + z] = (byte) Gen.planDistrict(x, z).ordinal();

        progress.accept("Shaping terrain and wilderness");
        WildernessGen wild = new WildernessGen(g);
        wild.terrain();
        // city bedrock & fill
        for (int x = World.CITY_MIN; x < World.CITY_MAX; x++) for (int z = World.CITY_MIN; z < World.CITY_MAX; z++) {
            g.set(x, 0, z, Block.BEDROCK);
            g.fill(x, 1, z, x, G - 2, z, Block.DIRT);
            g.set(x, G - 1, z, groundFor(w.district(x, z), x, z));
            g.fill(x, G, z, x, World.H - 1, z, Block.AIR);
        }

        progress.accept("Laying arterial avenues");
        Rng r = g.rng("arterial");
        arterials();

        progress.accept("Digging canal, sewers and metro");
        streets.canal(r);
        streets.bridge(244, 256, false, false, r);           // west ring bridge
        streets.bridge(448, 460, false, true, r);            // east ring: military checkpoint
        streets.bridge(96, 104, false, false, r);
        streets.bridge(600, 608, false, false, r);
        streets.bridge(166, 174, false, false, r);           // market footbridge
        streets.bridge(318, 330, false, true, r);            // civic checkpoint bridge
        streets.bridge(398, 410, true, false, r);            // collapsed bridge
        streets.bridge(526, 536, false, false, r);           // industrial/redline crossing
        for (Streets.Road rd : new ArrayList<>(streets.roads)) if (rd.style() == Style.AVENUE) streets.sewerAlong(rd.r(), rd.alongX(), r);
        streets.metro(150, 590, 300, r);

        progress.accept("Building Downtown");
        Districts dist = new Districts(g, streets);
        dist.oldQuarter(OQ);
        progress.accept("Building the Industrial district and the power plant");
        dist.industrial(IND_N, IND_SE);
        progress.accept("Building the Residential microdistricts");
        dist.market(MKT_N, MKT_S);
        progress.accept("Building the Government quarter");
        dist.civic(CIV_N, CIV_S);
        progress.accept("Building the Untamed blocks");
        dist.redline(RED_E, RED_S);
        streets.metroStation(330, 378, 300, 338, 324, r);

        progress.accept("Dressing streets");
        streets.crosswalks();
        streets.furnish(g.rng("furnish"));
        streets.buildNodes();

        progress.accept("Raising the quarantine wall");
        wild.quarantineWall(streets);
        wild.outskirts();

        progress.accept("Marking extraction routes");
        exitsAndInsertions();
        w.computeHeights();
        progress.accept("Auditing prop placement and the street graph");
        Validation.run(w);
        w.computeHeights();
        System.out.printf("[Gen] City generated in %d ms: %d loot spots, %d exits, %d nodes, %d lamps%n",
                System.currentTimeMillis() - t0, w.map.loot.size(), w.map.exits.size(), w.map.nodes.size(), w.map.lampsOnPower.size());
    }

    /** Ground finish per district. Surfaces change in broad patches (yards, stains, verges), never per-voxel speckle. */
    private int groundFor(District d, int x, int z) {
        float n = absentialis.engine.util.Noise.fbm(x / 13f, z / 13f, 2, 41);
        switch (d) {
            case OLD_QUARTER: return Block.SIDEWALK;
            case INDUSTRIAL: return n < 0.36f ? Block.GRAVEL : (n > 0.74f ? Block.OIL_FLOOR : Block.CONCRETE_FLOOR);
            case REDLINE: return n < 0.32f ? Block.ASH : (n < 0.5f ? Block.DEAD_GRASS : Block.SIDEWALK);
            case CIVIC: return Block.SIDEWALK;
            case MARKET: return n < 0.3f ? Block.DIRT : Block.SIDEWALK;
            default: return Block.GRASS;
        }
    }

    private void arterials() {
        // perimeter ring just inside the wall
        streets.road(new Rect(96, 96, 608, 104), true, Style.STREET);
        streets.road(new Rect(96, 600, 608, 608), true, Style.STREET);
        streets.road(new Rect(96, 96, 104, 608), false, Style.STREET);
        streets.road(new Rect(600, 96, 608, 608), false, Style.STREET);
        // avenues
        streets.road(new Rect(96, 244, 608, 256), true, Style.AVENUE);   // north avenue
        streets.road(new Rect(244, 448, 608, 460), true, Style.AVENUE);  // south avenue
        streets.road(new Rect(244, 244, 256, 608), false, Style.AVENUE); // west ring
        streets.road(new Rect(448, 244, 460, 608), false, Style.AVENUE); // east ring
        streets.road(new Rect(346, 96, 358, 244), false, Style.AVENUE);  // quarter / industry divide
    }

    // ------------------------------------------------------------------ extraction & insertion
    private void exitsAndInsertions() {
        MapData m = w.map;
        // Permanent: the western breach in the quarantine wall (Market)
        exit("fringe_breach", "Fringe Breach", 98, G, 420, ExitType.PERMANENT, "", "");
        // Permanent: pedestrian underpass beneath the north wall (Downtown)
        exit("north_underpass", "North Underpass", 200, G, 99, ExitType.PERMANENT, "", "");
        // Time window: the ministry's daytime convoy out of the Government quarter
        exit("ministry_convoy", "Ministry Convoy", 300, G, 405, ExitType.TIME_WINDOW, "window:7-19", "military");
        // Permanent: forester's track through the western wilderness (long, irradiated walk)
        exit("west_track", "Forester's Track", 40, Math.max(G, surfaceTop(40, 420) + 1), 420, ExitType.PERMANENT, "", "");
        // Conditional: crypt tunnel under the cathedral (key) — placed by Districts as site "crypt_exit"
        MapData.Point crypt = m.site("crypt_exit");
        if (crypt != null) exit("crypt_exit", "Cathedral Crypt Tunnel", crypt.x, crypt.y, crypt.z, ExitType.CONDITIONAL, "item:key.crypt", "mercenaries");
        // Time window: rail yard freight train
        MapData.Point rail = m.site("rail_exit");
        if (rail != null) exit("rail_freight", "Rail Yard Freight", rail.x, rail.y, rail.z, ExitType.TIME_WINDOW, "window:6-22", "");
        // Conditional: civic bridge checkpoint (military standing or toll)
        exit("bridge_checkpoint", "Reactor Bridge Checkpoint", 324, G, 336, ExitType.CONDITIONAL, "rep:military:0|pay:450", "military");
        // Conditional: metro line east end (needs power restored)
        exit("metro_line", "Metro Line 2 Tunnel", 586, 5, 300, ExitType.CONDITIONAL, "power", "");
        // Signaled: helipad on the tower roof (flare)
        MapData.Point heli = m.site("helipad");
        if (heli != null) exit("helipad", "Rooftop Helipad", heli.x, heli.y, heli.z, ExitType.SIGNALED, "item:signal.flare", "");
        // Permanent: hospital ambulance bay
        MapData.Point amb = m.site("ambulance_bay");
        if (amb != null) exit("ambulance_bay", "Ambulance Bay", amb.x, amb.y, amb.z, ExitType.PERMANENT, "", "");
        // Time window: canal boat
        exit("canal_boat", "Canal Boat", 590, 19, 352, ExitType.TIME_WINDOW, "window:12-32", "");
        // Permanent: sewer outfall (west canal end)
        exit("sewer_outfall", "Sewer Outfall", 108, 19, 346, ExitType.PERMANENT, "", "");
        // Emergency: cordon gate (offered only after the window closes, at a cost)
        exit("cordon_gate", "Emergency Cordon Gate", 420, G, 604, ExitType.EMERGENCY, "emergency", "military");
        // Permanent but exposed: wilderness road far east (radiation)
        exit("east_road", "Eastern Highway", 690, G, 180, ExitType.PERMANENT, "", "");
        for (MapData.Exit e : m.exits) {
            // landing marker: hazard-stripe pad
            if (e.y >= G - 1 && e.type != ExitType.SIGNALED) {
                for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) {
                    int x = e.x + dx, z = e.z + dz;
                    int top = surfaceTop(x, z);
                    if (top >= 0 && Math.abs(dx) + Math.abs(dz) >= 3) w.setRaw(x, top, z, Block.HAZARD_STRIPE);
                }
            }
            int py = e.y;
            for (int y = py + 3; y < py + 7 && e.type != ExitType.SIGNALED && e.y > 10; y++) if (w.get(e.x, y, e.z) == 0) w.setRaw(e.x, y, e.z, y == py + 6 ? Block.RED_LIGHT : Block.IRON_FENCE);
        }
        // insertion points per district
        insertion("Residential West Gate", 110, G, 300);
        insertion("Residential South Lot", 150, G, 590);
        insertion("Downtown North Gate", 200, G, 110);
        insertion("Downtown Arcades", 300, G, 110);
        insertion("Industrial North Siding", 470, G, 110);
        insertion("Industrial East Dock", 594, G, 300);
        insertion("Plant North Avenue", 350, G, 250);
        insertion("Government South Avenue", 380, G, 454);
        insertion("Untamed East", 594, G, 400);
        insertion("Untamed South Wall", 300, G, 594);
    }

    private int surfaceTop(int x, int z) {
        for (int y = G + 12; y > 1; y--) if (Block.ALL[w.get(x, y, z)].solid()) return y;
        return -1;
    }

    private void exit(String id, String name, int x, int y, int z, ExitType t, String cond, String faction) {
        MapData.Exit e = new MapData.Exit(id, name, x, y, z, t, w.district(x, z));
        e.condition = cond;
        e.faction = faction;
        // make sure the exit volume is walkable
        for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) for (int yy = y; yy < y + 2; yy++) {
            int c = w.get(x + dx, yy, z + dz);
            if (c != 0 && Block.ALL[c].solid() && !Block.ALL[c].is(Block.STEP)) w.setRaw(x + dx, yy, z + dz, Block.AIR);
        }
        w.map.exits.add(e);
    }

    private void insertion(String name, int x, int y, int z) {
        for (int yy = y; yy < y + 3; yy++) for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) {
            int c = w.get(x + dx, yy, z + dz);
            if (c != 0 && Block.ALL[c].solid()) w.setRaw(x + dx, yy, z + dz, Block.AIR);
        }
        w.map.insertions.add(new MapData.Point(name, "insertion", x, y, z, w.district(x, z)));
    }

    public static List<Rect> grid(Gen g, Streets st, Rect area, int streetW, int minB, int maxB, Style style, Rng r) {
        List<Integer> xs = cuts(area.x0(), area.x1(), streetW, minB, maxB, r);
        List<Integer> zs = cuts(area.z0(), area.z1(), streetW, minB, maxB, r);
        // streets
        for (int i = 1; i < xs.size() - 1; i += 2) st.road(new Rect(xs.get(i), area.z0(), xs.get(i + 1), area.z1()), false, style);
        for (int i = 1; i < zs.size() - 1; i += 2) st.road(new Rect(area.x0(), zs.get(i), area.x1(), zs.get(i + 1)), true, style);
        List<Rect> blocks = new ArrayList<>();
        for (int i = 0; i < xs.size(); i += 2) for (int j = 0; j < zs.size(); j += 2) blocks.add(new Rect(xs.get(i), zs.get(j), xs.get(i + 1), zs.get(j + 1)));
        return blocks;
    }

    /** Returns [b0start, b0end(=s0start), s0end, b1end, ...] alternating block/street boundaries. */
    private static List<Integer> cuts(int a, int b, int sw, int minB, int maxB, Rng r) {
        List<Integer> l = new ArrayList<>();
        l.add(a);
        int cur = a;
        while (b - cur > maxB + sw + minB) {
            int blk = r.range(minB, maxB);
            l.add(cur + blk);
            l.add(cur + blk + sw);
            cur = cur + blk + sw;
        }
        l.add(b);
        return l;
    }
}
