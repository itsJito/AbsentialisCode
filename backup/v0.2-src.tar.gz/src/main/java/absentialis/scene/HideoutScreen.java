package absentialis.scene;

import absentialis.gameplay.economy.Economy;
import absentialis.gameplay.inventory.Container;
import absentialis.gameplay.inventory.InventoryService;
import absentialis.gameplay.inventory.Loadout;
import absentialis.gameplay.items.Content;
import absentialis.gameplay.items.ItemDef;
import absentialis.gameplay.items.ItemInstance;
import absentialis.gameplay.missions.Contracts;
import absentialis.gameplay.progression.Challenges;
import absentialis.gameplay.progression.Progression;
import absentialis.gameplay.weapons.Gunsmith;
import absentialis.gameplay.weapons.WeaponService;
import absentialis.persistence.Profile;
import absentialis.persistence.SaveSystem;
import absentialis.sim.ZoneState;
import absentialis.ui.InventoryUi;
import absentialis.ui.Ui;
import absentialis.world.District;
import absentialis.world.MapData;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Hideout menu (addendum P2.4): STAT (rank / challenges / prestige) - INV (stash + case, traders)
 * - MAP (influence) - WORKBENCH (gunsmith + clean, facilities) - CONTRACTS. Screens slide/fade in
 * over 120 ms; the same item instances appear identically in every view.
 */
public final class HideoutScreen {
    public static final String[] TABS = {"STAT", "INV", "MAP", "WORKBENCH", "CONTRACTS", "OPERATOR"};
    private static final String[] GLYPHS = {"stat", "inv", "map", "bench", "contracts", "star"};
    private CharacterCreator creator;
    private final Ctx c;
    private final LoadoutPanel panel;
    public int tab;
    private float tabAnim = 1, stashScroll;
    private boolean trade, deployOpen, prestigeOpen, upgradesOpen;
    private String traderId = "mara";
    private ItemInstance benchWeapon;
    private int insertion, minutes = 30;
    public String action;           // "deploy", "settings", "title" for GameApp
    public int deployInsertion;
    public float deployMinutes;

    public HideoutScreen(Ctx c) { this.c = c; this.panel = new LoadoutPanel(c); }

    private Profile p() { return c.profile; }

    public void enter() {
        tabAnim = 0;
        c.win.setCursorLocked(false);
        p().applyCapacity();
        p().contracts.refill(p().seed ^ p().stat("raids"), p().prog.rank());
        if (c.map.ready()) c.map.rebuildHatch(p().zone);
    }

    public void render(float dt) {
        Ui ui = c.ui;
        int W = c.win.width, H = c.win.height;
        org.lwjgl.opengl.GL11.glViewport(0, 0, W, H);
        org.lwjgl.opengl.GL11.glClearColor(0.05f, 0.055f, 0.05f, 1);
        org.lwjgl.opengl.GL11.glClear(org.lwjgl.opengl.GL11.GL_COLOR_BUFFER_BIT | org.lwjgl.opengl.GL11.GL_DEPTH_BUFFER_BIT);
        ui.b.begin(W, H);
        ui.begin(dt, W, H);
        backdrop(ui);
        tabAnim = Math.min(1, tabAnim + dt / Ui.EASE);
        float ease = 1 - (1 - tabAnim) * (1 - tabAnim);
        boolean modal = deployOpen || prestigeOpen || p().prog.tokens > 0 || upgradesOpen;
        ui.block = modal;
        header(ui);
        float top = ui.s(118) + (1 - ease) * ui.s(14);
        switch (tab) {
            case 0 -> stat(ui, top);
            case 1 -> inventory(ui, top);
            case 2 -> map(ui, top);
            case 3 -> bench(ui, top);
            case 4 -> contracts(ui, top);
            default -> operator(ui, top);
        }
        if (tabAnim < 1) ui.b.rect(0, top - ui.s(10), W, H, Ui.alpha(0xFF0A0B0A, 1 - ease));
        ui.block = false;
        if (p().prog.tokens > 0) tokenModal(ui);
        else if (prestigeOpen) prestigeModal(ui);
        else if (deployOpen) deployModal(ui);
        else if (upgradesOpen) upgradesModal(ui);
        c.console.draw(ui, dt);
        ui.end();
        ui.b.end();
    }

    private void backdrop(Ui ui) {
        // dim bunker: concrete panels and a hanging lamp glow, pixel-snapped bands
        for (int y = 0; y < ui.h; y += ui.s(48)) ui.b.rect(0, y, ui.w, ui.s(47), (y / ui.s(48)) % 2 == 0 ? 0xFF101210 : 0xFF0E100E);
        ui.b.rect(0, 0, ui.w, ui.s(100), 0xFF161816);
        ui.b.rect(0, ui.s(100), ui.w, ui.s(3), 0xFF8A6420);
    }

    private void header(Ui ui) {
        Profile p = p();
        ui.text("ABSENTIALIS", ui.s(24), ui.s(14), 26, Ui.TXT_HI);
        ui.text("HIDEOUT  -  Day " + p.zone.day + String.format("  %02d:00", (int) p.zone.hour % 24) + (p.zone.weatherRain > 0.5f ? "  -  Rain" : ""), ui.s(26), ui.s(48), 12, Ui.TXT_DIM);
        // rank chip
        float rx = ui.s(270);
        int g = Math.max(2, ui.s(2));
        ui.glyph(p.prog.master() ? "star" : "chevron", rx, ui.s(16), g, 0xFFFFFFFF);
        ui.text(p.name + "  -  " + p.prog.title(), rx + ui.s(32), ui.s(14), 16, Ui.TXT_HI);
        ui.bar(rx + ui.s(32), ui.s(38), ui.s(200), ui.s(8), p.prog.rankProgress(), 0xFFE2A034);
        ui.glyph("coin", rx + ui.s(250), ui.s(30), g, 0xFFFFFFFF);
        ui.text(p.scrip + " scrip", rx + ui.s(282), ui.s(31), 16, Ui.AMBER);
        ui.glyph("heart", rx + ui.s(420), ui.s(30), g, 0xFFFFFFFF);
        ui.text(Math.round(p.health) + "%", rx + ui.s(452), ui.s(31), 16, p.health < 60 ? Ui.RED : Ui.TXT);
        // tabs
        float tw = ui.s(138), tx = ui.s(24);
        for (int i = 0; i < TABS.length; i++) if (ui.tab("ht" + i, tx + i * (tw + ui.s(4)), ui.s(62), tw, ui.s(34), TABS[i], GLYPHS[i], tab == i) && tab != i) { tab = i; tabAnim = 0; }
        float bx = ui.w - ui.s(24);
        if (ui.button("deploy", bx - ui.s(170), ui.s(54), ui.s(170), ui.s(42), "DEPLOY", "flag", c.world != null)) { deployOpen = true; }
        if (ui.button("settings", bx - ui.s(170) - ui.s(56), ui.s(54), ui.s(48), ui.s(42), null, "cog", true)) action = "settings";
        if (ui.button("title", bx - ui.s(170) - ui.s(112), ui.s(54), ui.s(48), ui.s(42), null, "arrow", true)) { SaveSystem.save(p()); action = "title"; }
        if (c.world == null) ui.textR("Surveying the Zone...", bx, ui.s(20), 12, Ui.TXT_DIM);
    }

    // ================================================================== OPERATOR (customization)
    private void operator(Ui ui, float top) {
        if (creator == null) creator = new CharacterCreator(c);
        float x = ui.s(24), w = ui.w - ui.s(48), h = ui.h - top - ui.s(24);
        float cy = ui.window("Operator  -  " + p().name, "star", x, top, w, h);
        ui.text("Your look is a set of definition ids: head, hair, facial hair, torso, sleeves, legs, hands, feet and colours. Equipment you wear changes the silhouette on top of it.", x + ui.s(20), cy, 12, Ui.TXT_DIM);
        if (creator.draw(ui, p().appearance, p(), x + ui.s(20), cy + ui.s(30), w - ui.s(40), h - (cy - top) - ui.s(60))) SaveSystem.save(p());
    }

    // ================================================================== STAT
    private void stat(Ui ui, float top) {
        Profile p = p();
        Progression pr = p.prog;
        float x = ui.s(24), w = ui.s(520), h = ui.h - top - ui.s(24);
        float cy = ui.window("Rank & Prestige", "chevron", x, top, w, h);
        ui.text(pr.master() ? "MASTER" : "PRESTIGE " + pr.prestige + "  -  RANK " + pr.rank() + " / " + Progression.RANKS + "  -  " + Progression.rankName(pr.rank()).toUpperCase(), x + ui.s(18), cy, 20, Ui.TXT_HI);
        for (int i = 0; i < Progression.MAX_PRESTIGE; i++) ui.glyph("star", x + ui.s(18) + i * ui.s(30), cy + ui.s(30), Math.max(2, ui.s(2)), i < pr.prestige ? 0xFFFFFFFF : 0x30FFFFFF);
        cy += ui.s(66);
        ui.text("Next rank", x + ui.s(18), cy, 13, Ui.TXT);
        ui.bar(x + ui.s(130), cy + ui.s(3), w - ui.s(160), ui.s(12), pr.rankProgress(), 0xFFE2A034);
        cy += ui.s(22);
        ui.text("Cycle", x + ui.s(18), cy, 13, Ui.TXT);
        ui.bar(x + ui.s(130), cy + ui.s(3), w - ui.s(160), ui.s(12), pr.cycleXp / (float) Progression.CYCLE_XP, 0xFF8A6420);
        ui.text(String.format("%,d / %,d XP   (lifetime %,d / %,d to Master)", pr.cycleXp, Progression.CYCLE_XP, pr.lifetimeXp, Progression.totalToMaster()), x + ui.s(18), cy + ui.s(20), 11, Ui.TXT_DIM);
        cy += ui.s(48);
        if (ui.button("prestige", x + ui.s(18), cy, w - ui.s(36), ui.s(42), pr.master() ? "MASTER ACHIEVED" : pr.cycleComplete() ? "PRESTIGE NOW" : "PRESTIGE (complete rank 50)", "star", pr.canPrestige())) prestigeOpen = true;
        cy += ui.s(56);
        // the next rungs of the ladder: what the next ranks actually open
        ui.text("NEXT UNLOCKS", x + ui.s(18), cy, 13, Ui.TXT_HI);
        cy += ui.s(20);
        for (String[] e : pr.nextUnlocks(4)) {
            String label = e[1].startsWith("Weapon platform: ") ? "Weapon platform: " + absentialis.gameplay.items.Content.def(e[1].substring(17)).name : e[1];
            ui.text("Rank " + e[0], x + ui.s(18), cy, 12, Ui.AMBER); ui.text(label, x + ui.s(92), cy, 12, Ui.TXT); cy += ui.s(17);
        }
        cy += ui.s(8);
        ui.text("ENLISTED ACCESS (resets on prestige)", x + ui.s(18), cy, 13, Ui.TXT_HI);
        cy += ui.s(22);
        String[][] rows = {{"Trader tier", "T" + pr.traderTier()}, {"Carry capacity", String.format("%.1f kg", pr.carryCapacityKg())},
                {"Stash rows", "+" + pr.stashRows() + " (" + pr.prestigeStashRows() + " permanent)"}, {"Loadout presets", String.valueOf(pr.presets())}, {"Banner layers", String.valueOf(pr.bannerLayers())}};
        for (String[] r : rows) { ui.text(r[0], x + ui.s(18), cy, 13, Ui.TXT); ui.textR(r[1], x + w - ui.s(18), cy, 13, Ui.AMBER); cy += ui.s(19); }
        cy += ui.s(6);
        ui.text("PLATFORMS", x + ui.s(18), cy, 13, Ui.TXT_HI);
        cy += ui.s(20);
        for (String id : Progression.platforms()) {
            boolean un = pr.platformUnlocked(id);
            boolean tok = pr.tokenUnlocks.contains("platform:" + id);
            ui.glyph(un ? "check" : "lock", x + ui.s(18), cy - ui.s(2), Math.max(1, ui.s(1)), 0xFFFFFFFF);
            ui.text(Content.def(id).name, x + ui.s(38), cy, 12, un ? Ui.TXT : Ui.TXT_DIM);
            ui.textR(tok ? "TOKEN (permanent)" : "Rank " + Progression.platformRank(id) + "  -  mastery " + pr.masteryLevel(id), x + w - ui.s(18), cy, 12, tok ? Ui.AMBER : Ui.TXT_DIM);
            cy += ui.s(18);
        }
        // middle column: prestige rewards ladder
        float x2 = x + w + ui.s(18), w2 = ui.s(420);
        float cy2 = ui.window("Prestige Rewards", "star", x2, top, w2, h);
        for (int i = 1; i <= Progression.MAX_PRESTIGE; i++) {
            boolean got = pr.prestige >= i;
            ui.glyph(got ? "check" : "lock", x2 + ui.s(16), cy2, Math.max(1, ui.s(1)), 0xFFFFFFFF);
            ui.text("P" + i, x2 + ui.s(38), cy2, 13, got ? Ui.AMBER : Ui.TXT_DIM);
            ui.text(Progression.rewardText(i) + "  + token", x2 + ui.s(76), cy2, 12, got ? Ui.TXT : Ui.TXT_DIM);
            cy2 += ui.s(22);
        }
        cy2 += ui.s(10);
        ui.wrap("Prestige forfeits enlisted unlocks, trader access and your deployed loadout. You keep cosmetics, banners, emblems, weapon mastery and token unlocks. Rank never adds damage.", x2 + ui.s(16), cy2, w2 - ui.s(32), 12, Ui.TXT_DIM);
        cy2 += ui.s(70);
        ui.text("TOKEN UNLOCKS", x2 + ui.s(16), cy2, 13, Ui.TXT_HI);
        cy2 += ui.s(20);
        if (pr.tokenUnlocks.isEmpty()) { ui.text("None yet", x2 + ui.s(16), cy2, 12, Ui.TXT_DIM); cy2 += ui.s(18); }
        for (String t : pr.tokenUnlocks) { ui.text(tokenLabel(t), x2 + ui.s(16), cy2, 12, Ui.AMBER); cy2 += ui.s(18); }
        cy2 += ui.s(14);
        ui.text("CHALLENGES", x2 + ui.s(16), cy2, 13, Ui.TXT_HI);
        cy2 += ui.s(22);
        for (Challenges.Challenge ch : Challenges.ALL) {
            if (cy2 > top + h - ui.s(30)) break;
            boolean done = Challenges.claimed(p, ch);
            int prog = Challenges.progress(p, ch);
            ui.text(ch.label(), x2 + ui.s(16), cy2, 12, done ? Ui.TXT_DIM : Ui.TXT);
            if (Challenges.claimable(p, ch)) {
                if (ui.button("ch" + ch.id(), x2 + w2 - ui.s(126), cy2 - ui.s(4), ui.s(110), ui.s(22), "CLAIM +" + ch.xp() / 1000 + "k", null, true)) {
                    int xp = Challenges.claim(p, ch);
                    c.inv.say("Challenge complete: +" + xp + " XP", Ui.GREEN);
                    c.sfx("ui_buy", 0.6f);
                    SaveSystem.save(p);
                }
            } else if (done) ui.glyph("check", x2 + w2 - ui.s(32), cy2 - ui.s(2), Math.max(1, ui.s(1)), 0xFFFFFFFF);
            else {
                ui.bar(x2 + w2 * 0.55f, cy2 + ui.s(3), w2 * 0.3f, ui.s(8), prog / (float) ch.goal(), 0xFF8A6420);
                ui.textR(prog + "/" + ch.goal(), x2 + w2 - ui.s(16), cy2, 11, Ui.TXT_DIM);
            }
            cy2 += ui.s(22);
        }
        // right column: standing & record
        float x3 = x2 + w2 + ui.s(18), w3 = ui.w - x3 - ui.s(24);
        if (w3 < ui.s(240)) return;
        float cy3 = ui.window("Standing", "radio", x3, top, w3, h);
        for (String f : ZoneState.FACTIONS) {
            float r = p.rep(f);
            ui.text(ZoneState.cap(f), x3 + ui.s(16), cy3, 13, Ui.TXT);
            float bw = w3 - ui.s(150), bx = x3 + ui.s(120);
            ui.b.rect(bx, cy3 + ui.s(4), bw, ui.s(10), 0xFF141615);
            float mid = bx + bw / 2;
            ui.b.rect(Math.min(mid, mid + bw / 2 * r / 100f), cy3 + ui.s(5), Math.abs(bw / 2 * r / 100f), ui.s(8), r >= 0 ? 0xFF7DBA5C : 0xFFC0402E);
            ui.b.rect(mid, cy3 + ui.s(2), 1, ui.s(14), 0xFF8E897A);
            ui.textR(String.format("%+.0f", r), x3 + w3 - ui.s(12), cy3, 12, Ui.TXT_DIM);
            cy3 += ui.s(24);
        }
        cy3 += ui.s(14);
        ui.text("SERVICE RECORD", x3 + ui.s(16), cy3, 13, Ui.TXT_HI);
        cy3 += ui.s(22);
        for (String k : new String[]{"raids", "extracts", "deaths"}) { ui.text(ZoneState.cap(k), x3 + ui.s(16), cy3, 12, Ui.TXT); ui.textR(String.valueOf(p.stat(k)), x3 + w3 - ui.s(16), cy3, 12, Ui.AMBER); cy3 += ui.s(18); }
        for (Map.Entry<String, Integer> e : p.stats.entrySet()) if (e.getKey().startsWith("kills_")) { ui.text("Kills: " + e.getKey().substring(6), x3 + ui.s(16), cy3, 12, Ui.TXT_DIM); ui.textR(String.valueOf(e.getValue()), x3 + w3 - ui.s(16), cy3, 12, Ui.TXT); cy3 += ui.s(17); }
        cy3 += ui.s(14);
        ui.text("WEAPON MASTERY (persists)", x3 + ui.s(16), cy3, 13, Ui.TXT_HI);
        cy3 += ui.s(22);
        for (Map.Entry<String, Long> e : pr.mastery.entrySet()) {
            if (Content.def(e.getKey()) == null) continue;
            ui.text(Content.def(e.getKey()).name, x3 + ui.s(16), cy3, 12, Ui.TXT);
            ui.textR("Lv " + Progression.masteryLevel(e.getValue()), x3 + w3 - ui.s(16), cy3, 12, Ui.AMBER);
            cy3 += ui.s(17);
        }
        // medical treatment
        if (p.health < 100 && cy3 < top + h - ui.s(70)) {
            int cost = Math.round((100 - p.health) * 6 / Math.max(1, p.level("medical")));
            cy3 = top + h - ui.s(60);
            if (ui.button("heal", x3 + ui.s(16), cy3, w3 - ui.s(32), ui.s(40), "TREATMENT  (" + cost + " scrip)", "heart", p.scrip >= cost)) { p.scrip -= cost; p.health = 100; c.sfx("bandage", 0.6f); SaveSystem.save(p); }
        }
    }

    private static String tokenLabel(String t) {
        String[] s = t.split(":");
        return switch (s[0]) {
            case "platform" -> "Platform: " + (Content.def(s[1]) != null ? Content.def(s[1]).name : s[1]);
            case "trader" -> "Trader tier floor: T" + s[1];
            default -> "Hideout: +1 " + ZoneState.cap(s[1]) + " level";
        };
    }

    private void prestigeModal(Ui ui) {
        ui.b.rect(0, 0, ui.w, ui.h, 0xC0000000);
        float w = ui.s(560), h = ui.s(380), x = (ui.w - w) / 2, y = (ui.h - h) / 2;
        float cy = ui.window("Prestige " + (p().prog.prestige + 1), "star", x, y, w, h);
        String[] lines = {"^rYou will lose:", "  - Rank (back to 1) and every enlisted unlock", "  - Trader access beyond tier 1", "  - Your deployed loadout (equipped gear + case)",
                "^gYou keep:", "  - Stash, scrip, cosmetics, banners, emblems", "  - Weapon mastery and all token unlocks", "^aReward: " + Progression.rewardText(p().prog.prestige + 1) + " + 1 token"};
        for (String l : lines) {
            int col = l.startsWith("^r") ? Ui.RED : l.startsWith("^g") ? Ui.GREEN : l.startsWith("^a") ? Ui.AMBER : Ui.TXT;
            ui.text(l.replaceFirst("^\\^.", ""), x + ui.s(24), cy, 14, col);
            cy += ui.s(24);
        }
        if (ui.button("pconfirm", x + ui.s(24), y + h - ui.s(64), ui.s(240), ui.s(44), "PRESTIGE", "star", true)) {
            String err = p().prog.prestige();
            if (err == null) {
                p().loadout.strip(true);
                p().applyCapacity();
                c.sfx("ui_buy", 0.8f);
                SaveSystem.save(p());
            } else c.inv.say(err, Ui.RED);
            prestigeOpen = false;
        }
        if (ui.button("pcancel", x + w - ui.s(264), y + h - ui.s(64), ui.s(240), ui.s(44), "CANCEL", "cross", true)) prestigeOpen = false;
    }

    private void tokenModal(Ui ui) {
        ui.b.rect(0, 0, ui.w, ui.h, 0xC8000000);
        List<String> opts = p().prog.tokenOptions();
        float w = ui.s(560), h = ui.s(120) + opts.size() * ui.s(42), x = (ui.w - w) / 2, y = Math.max(ui.s(20), (ui.h - h) / 2);
        float cy = ui.window("Spend your prestige token", "token", x, y, w, h);
        ui.text("One permanent unlock that survives every future prestige. Tokens do not stack.", x + ui.s(20), cy, 12, Ui.TXT_DIM);
        cy += ui.s(26);
        for (String o : opts) {
            if (ui.button("tok" + o, x + ui.s(20), cy, w - ui.s(40), ui.s(36), tokenLabel(o), "token", true)) {
                String err = p().prog.spendToken(o);
                if (err == null) { p().applyCapacity(); SaveSystem.save(p()); c.sfx("ui_buy", 0.7f); } else c.inv.say(err, Ui.RED);
            }
            cy += ui.s(42);
        }
    }

    // ================================================================== INV
    private void inventory(Ui ui, float top) {
        Profile p = p();
        var inv = c.inv;
        inv.begin(34);
        inv.fit(ui.h - top - ui.s(24) - ui.s(44) - ui.s(160), p.loadout.caseGrid.h + (p.loadout.packGrid() == null ? 0 : p.loadout.packGrid().h + 2));
        inv.quickA = trade ? null : p.stash;
        inv.quickB = p.loadout.caseGrid;
        inv.owner = p.loadout;
        inv.allowDrop = false;
        inv.extraActions.clear();
        inv.extraActions.add("quick");
        if (trade) inv.extraActions.add("sell");
        inv.onAction = (it, act) -> {
            if ("sell".equals(act)) { sell(it); return; }
            String r = panel.act(p, it, act, p.stash);
            if (r != null) inv.say(r, Ui.TXT);
        };
        float h = ui.h - top - ui.s(24);
        float leftW = p.stash.w * inv.cell + ui.s(40);
        float x0 = ui.s(24);
        float cy = ui.window(trade ? "Traders" : "Stash  " + p.stash.w + "x" + p.stash.h, trade ? "coin" : "inv", x0, top, leftW, h);
        if (ui.button("tradeToggle", x0 + leftW - ui.s(150), top + ui.s(8), ui.s(136), ui.s(28), trade ? "STASH" : "TRADE", trade ? "inv" : "coin", true)) { trade = !trade; c.sfx("ui_click", 0.4f); }
        if (trade) trader(ui, x0 + ui.s(14), cy, leftW - ui.s(28), h - (cy - top) - ui.s(14));
        else {
            float gh = h - (cy - top) - ui.s(96);
            int visRows = Math.max(4, (int) (gh / inv.cell));
            stashScroll = Math.max(0, Math.min(p.stash.h - visRows, stashScroll - (float) c.in.scroll * 2));
            float gy = cy + ui.s(26);
            ui.b.scissor((int) x0, (int) gy - 2, (int) leftW, (int) (visRows * inv.cell) + 4);
            inv.grid(p.stash, x0 + ui.s(18), gy - (int) stashScroll * inv.cell, null);
            ui.b.noScissor();
            ui.text("STASH  (scroll)  rows " + (int) stashScroll + "-" + Math.min(p.stash.h, (int) stashScroll + visRows) + " of " + p.stash.h, x0 + ui.s(18), cy, 12, Ui.TXT_DIM);
            float by = gy + visRows * inv.cell + ui.s(10);
            if (ui.button("sortStash", x0 + ui.s(18), by, ui.s(120), ui.s(30), "SORT", "sort", true)) { InventoryService.Result r = InventoryService.autoSort(p.stash); inv.say(r.ok() ? "Stash sorted" : r.msg(), r.ok() ? Ui.GREEN : Ui.RED); }
            boolean broke = p.scrip < 500 && !hasWeapon(p);
            if (ui.button("fallback", x0 + ui.s(146), by, leftW - ui.s(164), ui.s(30), "FALLBACK KIT", "radio", broke && p.lastFallbackDay != p.zone.day)) {
                for (ItemInstance i : Economy.fallbackKit()) InventoryService.add(i, p.stash);
                p.lastFallbackDay = p.zone.day;
                inv.say("Quartermaster issued a fallback kit (no resale value)", Ui.GREEN);
            }
            presets(ui, x0 + ui.s(18), by + ui.s(36), leftW - ui.s(36));
        }
        float rx = x0 + leftW + ui.s(16);
        float rw = panel.width(p.loadout);
        float ry = ui.window("Loadout", "inv", rx, top, rw + ui.s(24), h);
        panel.draw(p, rx + ui.s(12), ry, rw, h - (ry - top) - ui.s(16), p.stash);
        float ix = rx + rw + ui.s(40);
        if (ix + ui.s(260) < ui.w) inv.inspectPanel(ix, top, Math.min(ui.s(320), ui.w - ix - ui.s(24)), h);
        if (c.in.pressed("sort")) InventoryService.autoSort(p.loadout.caseGrid);
        inv.end();
        if (c.in.keyDown(org.lwjgl.glfw.GLFW.GLFW_KEY_F) && inv.inspected != null) inv.fullInspect(inv.spin, 0.45f);
    }

    private static boolean hasWeapon(Profile p) {
        for (ItemInstance i : p.allItems()) if (i.def().weapon != null && !i.def().weapon.melee()) return true;
        return false;
    }

    /** Loadout presets: save equipped/case defs; apply pulls matching instances from the stash. */
    private void presets(Ui ui, float x, float y, float w) {
        Profile p = p();
        int n = p.prog.presets();
        float bw = Math.min(ui.s(110), (w - ui.s(8)) / Math.max(1, n));
        for (int i = 0; i < n; i++) {
            boolean has = i < p.presets.size() && p.presets.get(i) != null;
            if (ui.button("preset" + i, x + i * (bw + ui.s(4)), y, bw, ui.s(30), (has ? "LOAD " : "SAVE ") + (i + 1), null, true)) {
                if (ui.shift || !has) { savePreset(i); c.inv.say("Preset " + (i + 1) + " saved (shift+click to overwrite)", Ui.GREEN); }
                else c.inv.say(applyPreset(i), Ui.TXT);
            }
        }
    }

    private void savePreset(int i) {
        Profile p = p();
        Map<String, Object> m = new LinkedHashMap<>();
        for (String s : Loadout.SLOTS) if (p.loadout.slot(s) != null) m.put(s, p.loadout.slot(s).defId);
        List<Object> cs = new ArrayList<>();
        for (ItemInstance it : p.loadout.caseGrid.items) cs.add(it.defId);
        m.put("case", cs);
        while (p.presets.size() <= i) p.presets.add(null);
        p.presets.set(i, m);
    }

    private String applyPreset(int i) {
        Profile p = p();
        Map<String, Object> m = p.presets.get(i);
        int got = 0, miss = 0;
        for (String s : Loadout.SLOTS) {
            Object id = m.get(s);
            if (id == null || p.loadout.slot(s) != null && p.loadout.slot(s).defId.equals(id)) continue;
            ItemInstance found = null;
            for (ItemInstance it : p.stash.items) if (it.defId.equals(id)) { found = it; break; }
            if (found != null && InventoryService.equip(found, p.loadout, s).ok()) got++; else miss++;
        }
        @SuppressWarnings("unchecked") List<Object> cs = (List<Object>) m.getOrDefault("case", List.of());
        List<String> want = new ArrayList<>();
        for (Object o : cs) want.add(String.valueOf(o));
        for (ItemInstance it : p.loadout.caseGrid.items) want.remove(it.defId);
        for (String id : want) {
            ItemInstance found = null;
            for (ItemInstance it : p.stash.items) if (it.defId.equals(id)) { found = it; break; }
            if (found != null && InventoryService.store(found, p.loadout).ok()) got++; else miss++;
        }
        return "Preset applied: " + got + " moved" + (miss > 0 ? ", " + miss + " missing from stash" : "");
    }

    private void trader(Ui ui, float x, float y, float w, float h) {
        Profile p = p();
        float tw = (w - ui.s(8)) / Economy.TRADERS.size();
        for (int i = 0; i < Economy.TRADERS.size(); i++) {
            Economy.Trader t = Economy.TRADERS.get(i);
            if (ui.tab("tr" + t.id(), x + i * (tw + ui.s(4)), y, tw, ui.s(30), t.name().split(" ")[0], null, traderId.equals(t.id()))) traderId = t.id();
        }
        Economy.Trader t = Economy.trader(traderId);
        float rep = p.rep(t.faction());
        ui.text(t.name() + "  -  " + ZoneState.cap(t.faction()) + String.format(" standing %+.0f  -  tier %d", rep, p.prog.traderTier()), x, y + ui.s(40), 13, Ui.TXT_HI);
        ui.wrap(t.blurb() + "  Right-click your items -> Sell, or shift+click to sell.", x, y + ui.s(58), w, 11, Ui.TXT_DIM);
        List<ItemDef> stock = Economy.stock(t, p.prog, rep);
        float ly = y + ui.s(100), lh = ui.s(30);
        if (stock.isEmpty()) ui.text("Nothing for you. Improve your standing with the " + t.faction() + ".", x, ly, 13, Ui.RED);
        int col = 0;
        float cw = (w - ui.s(8)) / 2;
        for (ItemDef d : stock) {
            float ix = x + col * (cw + ui.s(8));
            if (ly > y + h - lh) break;
            int price = Economy.buyPrice(d, t, p.zone, rep);
            boolean can = p.scrip >= price;
            boolean hov = ui.hover(ix, ly, cw, lh - ui.s(2));
            ui.b.rect(ix, ly, cw, lh - ui.s(2), hov ? 0xFF2A2820 : 0xFF181A18);
            ItemInstance probe = new ItemInstance(-50, d.id);
            c.icons.draw(ui.b, probe, ix + ui.s(2), ly + ui.s(2), ui.s(44), lh - ui.s(6), 0xFFFFFFFF);
            ui.text(d.name, ix + ui.s(52), ly + ui.s(6), 12, can ? Ui.TXT : Ui.TXT_DIM);
            ui.textR(price + (d.stackable() ? "/u" : ""), ix + cw - ui.s(8), ly + ui.s(6), 12, can ? Ui.AMBER : Ui.RED);
            if (hov) { c.inv.inspected = probe; c.inv.hover = probe; }
            if (hov && ui.click && !ui.consumed) {
                ui.consumed = true;
                buy(d, price, d.stackable() ? Math.min(d.maxStack, ui.shift ? d.maxStack : Math.max(1, d.maxStack / 3)) : 1);
            }
            col++;
            if (col == 2) { col = 0; ly += lh; }
        }
        // selling via shift+click on case/stash items
        if (c.inv.hover != null && c.inv.hover.uid > 0 && ui.shift && ui.click) sell(c.inv.hover);
    }

    private void buy(ItemDef d, int unitPrice, int qty) {
        Profile p = p();
        int total = unitPrice * qty;
        if (p.scrip < total) { qty = (int) (p.scrip / unitPrice); total = unitPrice * qty; }
        if (qty <= 0) { c.inv.say("Not enough scrip", Ui.RED); c.sfx("ui_error", 0.5f); return; }
        ItemInstance it = new ItemInstance(d.id);
        it.qty = qty;
        it.origin = "trader:" + traderId;
        if (d.magazine != null) { it.rounds = 0; }
        if (!InventoryService.add(it, p.stash).ok()) { c.inv.say("Stash is full", Ui.RED); c.sfx("ui_error", 0.5f); return; }
        p.scrip -= total;
        c.inv.say("Bought " + qty + "x " + d.name + " for " + total, Ui.GREEN);
        c.sfx("ui_buy", 0.6f);
        SaveSystem.save(p);
    }

    private void sell(ItemInstance it) {
        Profile p = p();
        Economy.Trader t = Economy.trader(traderId);
        if (it.slot != null && !it.slot.startsWith("pouch")) { c.inv.say("Unequip it first", Ui.RED); return; }
        if (!Economy.accepts(t, it.def())) { c.inv.say(t.name() + " doesn't buy " + it.def().category, Ui.RED); return; }
        int price = Economy.sellPrice(it, t, p.zone, p.rep(t.faction()), p.recentSales.getOrDefault(it.defId, 0));
        if (price <= 0) { c.inv.say(it.fallback ? "Fallback kit has no resale value" : "Worthless to this trader", Ui.RED); return; }
        List<ItemInstance> nested = new ArrayList<>();
        it.collect(nested);
        if (nested.size() > 1) { c.inv.say("Strip magazines/parts before selling", Ui.RED); return; }
        InventoryService.release(it);
        p.scrip += price;
        p.recentSales.merge(it.defId, 1, Integer::sum);
        // evidence: selling faction gear to a rival is noticed
        if (it.ownerFaction != null && !it.ownerFaction.equals(t.faction())) { p.addRep(it.ownerFaction, -1); c.inv.say("Sold " + it.name() + " for " + price + " - the " + it.ownerFaction + " will hear of it", Ui.AMBER); }
        else c.inv.say("Sold " + it.name() + " for " + price, Ui.GREEN);
        c.sfx("ui_buy", 0.6f);
    }

    // ================================================================== MAP
    private void map(Ui ui, float top) {
        Profile p = p();
        float h = ui.h - top - ui.s(24), s = Math.min(h - ui.s(60), ui.w * 0.55f);
        float x = ui.s(24);
        float cy = ui.window("Zone Map  -  Influence", "map", x, top, s + ui.s(28), h);
        if (!c.map.ready()) { ui.text("Map is being drawn...", x + ui.s(20), cy, 14, Ui.TXT_DIM); return; }
        c.map.draw(ui, p, x + ui.s(14), cy, s, s, 0, 0, absentialis.world.World.W, null, Float.NaN, 0, 0, true);
        float x2 = x + s + ui.s(46), w2 = ui.w - x2 - ui.s(24);
        float cy2 = ui.window("District Intel", "radio", x2, top, w2, h);
        String[] fn = {"MIL", "RAI", "SUR", "CUL"};
        int[] fc = {0xFF7A8A5A, 0xFFB0503A, 0xFF5A80B0, 0xFF9A3A6A};
        for (District d : District.CITY) {
            String ctl = p.zone.controller(d);
            ui.text(d.display.toUpperCase(), x2 + ui.s(16), cy2, 14, Ui.TXT_HI);
            ui.textR(ctl == null ? "CONTESTED" : ctl.toUpperCase(), x2 + w2 - ui.s(16), cy2, 12, ctl == null ? Ui.AMBER : Ui.TXT);
            cy2 += ui.s(20);
            float bw = w2 - ui.s(32);
            float bx = x2 + ui.s(16);
            float tot = 0;
            for (int f = 0; f < 4; f++) tot += p.zone.influence[d.ordinal()][f];
            for (int f = 0; f < 4; f++) {
                float fw = bw * p.zone.influence[d.ordinal()][f] / Math.max(0.01f, tot);
                ui.b.rect(bx, cy2, fw, ui.s(10), fc[f]);
                if (fw > ui.s(30)) ui.text(fn[f], bx + ui.s(3), cy2 - ui.s(1), 9, 0xFF0A0A0A);
                bx += fw;
            }
            cy2 += ui.s(14);
            ui.text(String.format("Infected %d%%   Food %d%%   Medicine %d%%   Ammo %d%%   %s", Math.round(p.zone.infected[d.ordinal()] * 100),
                    Math.round(p.zone.supply[d.ordinal()][0] * 100), Math.round(p.zone.supply[d.ordinal()][2] * 100), Math.round(p.zone.supply[d.ordinal()][3] * 100),
                    p.zone.power[d.ordinal()] ? "POWER ON" : "no power"), x2 + ui.s(16), cy2, 11, Ui.TXT_DIM);
            cy2 += ui.s(26);
        }
        ui.text("NEWS", x2 + ui.s(16), cy2, 14, Ui.TXT_HI);
        cy2 += ui.s(22);
        if (p.zone.news.isEmpty()) ui.text("Quiet. For now.", x2 + ui.s(16), cy2, 12, Ui.TXT_DIM);
        for (String n : p.zone.news) { if (cy2 > top + h - ui.s(30)) break; ui.text(n, x2 + ui.s(16), cy2, 11, Ui.TXT); cy2 += ui.s(17); }
    }

    // ================================================================== WORKBENCH
    private void bench(Ui ui, float top) {
        Profile p = p();
        float h = ui.h - top - ui.s(24);
        float x = ui.s(24), w = ui.s(300);
        float cy = ui.window("Weapons", "bench", x, top, w, h);
        List<ItemInstance> guns = new ArrayList<>();
        for (ItemInstance i : p.allItems()) if (i.def().weapon != null && !i.def().weapon.melee() && i.parent == null) guns.add(i);
        if (benchWeapon != null && !guns.contains(benchWeapon)) benchWeapon = null;
        if (benchWeapon == null && !guns.isEmpty()) benchWeapon = guns.get(0);
        for (ItemInstance g : guns) {
            if (cy > top + h - ui.s(60)) break;
            boolean sel = g == benchWeapon;
            if (ui.hover(x + ui.s(12), cy, w - ui.s(24), ui.s(52)) && ui.click) benchWeapon = g;
            ui.nine(sel ? "slot_hi" : "slot", x + ui.s(12), cy, w - ui.s(24), ui.s(52), 0xFFFFFFFF);
            c.icons.draw(ui.b, g, x + ui.s(16), cy + ui.s(4), ui.s(120), ui.s(44), 0xFFFFFFFF);
            ui.text(g.def().name, x + ui.s(142), cy + ui.s(6), 12, Ui.TXT_HI);
            float cond = g.condition() / 100f;
            ui.b.rect(x + ui.s(142), cy + ui.s(30), (w - ui.s(170)) * cond, ui.s(4), cond < 0.25f ? Ui.RED : cond < 0.5f ? Ui.AMBER : Ui.GREEN);
            ui.text(Math.round(g.condition()) + "/" + Math.round(g.maxDurability * 100) + (g.slot != null ? "  equipped" : ""), x + ui.s(142), cy + ui.s(36), 10, Ui.TXT_DIM);
            cy += ui.s(58);
        }
        if (ui.button("upgrades", x + ui.s(12), top + h - ui.s(52), w - ui.s(24), ui.s(40), "HIDEOUT FACILITIES", "cog", true)) upgradesOpen = true;
        float x2 = x + w + ui.s(16), w2 = ui.w - x2 - ui.s(24);
        float cy2 = ui.window("Gunsmith", "bench", x2, top, w2, h);
        if (benchWeapon == null) { ui.text("No firearms owned.", x2 + ui.s(16), cy2, 14, Ui.TXT_DIM); return; }
        ItemInstance g = benchWeapon;
        float vs = Math.min(ui.s(300), h * 0.45f);
        ui.b.rect(x2 + ui.s(16), cy2, vs * 1.6f, vs, 0xFF0B0C0B);
        c.icons.drawInspect(ui.b, g, x2 + ui.s(16) + vs * 0.3f, cy2, vs, c.time * 0.6f, 0.3f);
        // stats
        float sx = x2 + vs * 1.6f + ui.s(36), sw = w2 - vs * 1.6f - ui.s(60);
        float sy = cy2;
        ui.text(g.def().name.toUpperCase(), sx, sy, 18, Ui.TXT_HI);
        sy += ui.s(28);
        for (String[] s : InventoryUi.stats(g)) {
            if (sy > cy2 + vs) break;
            ui.text(s[0], sx, sy, 12, Ui.TXT);
            if (s.length > 2) ui.bar(sx + sw * 0.4f, sy + ui.s(3), sw * 0.6f, ui.s(9), Float.parseFloat(s[2]), s.length > 3 && "bad".equals(s[3]) ? 0xFFC0402E : 0xFFB0A070);
            else ui.textR(s[1], sx + sw, sy, 12, Ui.AMBER);
            sy += ui.s(17);
        }
        // service buttons
        float by = cy2 + vs + ui.s(14);
        ItemInstance oil = findOwned("mat.gun_oil"), kit = findOwned("kit.repair");
        if (ui.button("clean", x2 + ui.s(16), by, ui.s(210), ui.s(38), "CLEAN (+25) " + (oil == null ? "- no oil" : ""), "bench", oil != null)) { String r = WeaponService.clean(g, oil, true); c.inv.say(r == null ? "Cleaned: condition " + Math.round(g.condition()) : r, r == null ? Ui.GREEN : Ui.RED); c.icons.invalidate(g); }
        if (ui.button("repair", x2 + ui.s(234), by, ui.s(230), ui.s(38), "REPAIR (max -5) " + (kit == null ? "- no kit" : ""), "bench", kit != null)) { String r = WeaponService.repair(g, kit); c.inv.say(r == null ? "Repaired to " + Math.round(g.condition()) : r, r == null ? Ui.GREEN : Ui.RED); }
        boolean gold = p.prog.cosmetics.contains("gold_finish");
        if (gold && ui.button("gold", x2 + ui.s(472), by, ui.s(240), ui.s(38), "GOLD FINISH (25,000)", "star", p.scrip >= 25000)) applyGold(g);
        // slots
        by += ui.s(52);
        List<String> slots = Gunsmith.slotsFor(g.def());
        ui.text("PLATFORM SLOTS (" + slots.size() + ")  -  drag parts onto the weapon in INV, or fit from your stash here", x2 + ui.s(16), by, 12, Ui.TXT_DIM);
        by += ui.s(22);
        float colW = (w2 - ui.s(48)) / 3;
        for (int i = 0; i < slots.size(); i++) {
            String s = slots.get(i);
            float sx2 = x2 + ui.s(16) + (i % 3) * (colW + ui.s(8)), sy2 = by + (i / 3) * ui.s(74);
            if (sy2 > top + h - ui.s(70)) break;
            ui.nine("slot", sx2, sy2, colW, ui.s(68), 0xFFFFFFFF);
            ui.text(s.toUpperCase(), sx2 + ui.s(8), sy2 + ui.s(4), 11, Ui.AMBER);
            String cur;
            if (s.equals("mag")) cur = g.mag == null ? "-" : g.mag.def().name.replaceAll(" \\(\\d+\\)", "") + "  " + g.mag.rounds + "/" + g.mag.capacity() + " rds";
            else if (s.equals("ammo")) cur = g.loadedAmmoId() == null ? "-" : Content.def(g.loadedAmmoId()).name;
            else cur = g.attachment(s) == null ? "Factory" : g.attachment(s).def().name;
            ui.text(cur, sx2 + ui.s(8), sy2 + ui.s(22), 12, Ui.TXT);
            if (!s.equals("mag") && !s.equals("ammo")) {
                ItemInstance part = firstPart(g, s);
                if (g.attachment(s) != null && ui.button("rm" + s, sx2 + colW - ui.s(84), sy2 + ui.s(36), ui.s(76), ui.s(26), "REMOVE", null, true)) {
                    InventoryService.Result r = InventoryService.detachPart(g, s, p.stash);
                    c.inv.say(r.ok() ? "Removed" : r.msg(), r.ok() ? Ui.GREEN : Ui.RED);
                }
                if (part != null && ui.button("fit" + s, sx2 + ui.s(8), sy2 + ui.s(36), colW - ui.s(100), ui.s(26), "FIT " + part.def().name, null, true)) {
                    InventoryService.Result r = InventoryService.attach(g, part);
                    c.inv.say(r.ok() ? "Fitted " + part.def().name : r.msg(), r.ok() ? Ui.GREEN : Ui.RED);
                }
            }
        }
    }

    private ItemInstance findOwned(String id) {
        for (ItemInstance i : p().allItems()) if (i.defId.equals(id) && i.parent == null) return i;
        return null;
    }

    private ItemInstance firstPart(ItemInstance g, String socket) {
        for (ItemInstance i : p().stash.items) if (i.def().attachment != null && socket.equals(i.def().attachment.socket) && Gunsmith.incompatibility(g, i) == null) return i;
        for (ItemInstance i : p().loadout.caseGrid.items) if (i.def().attachment != null && socket.equals(i.def().attachment.socket) && Gunsmith.incompatibility(g, i) == null) return i;
        return null;
    }

    private void applyGold(ItemInstance g) {
        Profile p = p();
        if (p.scrip < 25000) return;
        ItemInstance fin = new ItemInstance("finish.gold");
        fin.origin = "prestige14";
        if (!InventoryService.add(fin, p.stash).ok()) { c.inv.say("Stash full", Ui.RED); return; }
        InventoryService.Result r = InventoryService.attach(g, fin);
        if (!r.ok()) { InventoryService.release(fin); c.inv.say(r.msg(), Ui.RED); return; }
        p.scrip -= 25000;
        c.inv.say("Gold voxel finish applied", Ui.AMBER);
    }

    private static final String[][] FACILITIES = {
            {"workbench", "Workbench", "3", "Unlocks crafting tiers (ammo, repair kits, flares)"},
            {"medical", "Medical Bay", "3", "Cheaper treatment, medical crafting"},
            {"kitchen", "Kitchen", "2", "Water purification and cooking"},
            {"radio", "Radio Room", "2", "L1: exits on the map  L2: known infected nests"},
            {"case", "Case Workshop", "4", "Attaché case +1x1 per level (up to 16x20)"},
            {"stash", "Stash Racks", "3", "+4 stash rows per level"}};

    public static int upgradeCost(int nextLevel) { return (int) (1500 * Math.pow(nextLevel, 1.6)); }

    private void upgradesModal(Ui ui) {
        Profile p = p();
        ui.b.rect(0, 0, ui.w, ui.h, 0xC0000000);
        float w = ui.s(680), h = ui.s(120) + FACILITIES.length * ui.s(62), x = (ui.w - w) / 2, y = (ui.h - h) / 2;
        float cy = ui.window("Hideout Facilities", "cog", x, y, w, h);
        for (String[] f : FACILITIES) {
            int lvl = p.hideout.getOrDefault(f[0], 0), max = Integer.parseInt(f[2]);
            ui.text(f[1] + "  -  level " + p.level(f[0]) + (p.level(f[0]) != lvl ? " (token +1)" : ""), x + ui.s(20), cy, 14, Ui.TXT_HI);
            ui.text(f[3], x + ui.s(20), cy + ui.s(19), 11, Ui.TXT_DIM);
            int cost = upgradeCost(lvl + 1);
            boolean can = lvl < max && p.scrip >= cost;
            if (ui.button("up" + f[0], x + w - ui.s(210), cy, ui.s(190), ui.s(38), lvl >= max ? "MAXED" : "UPGRADE " + cost, null, can)) {
                p.scrip -= cost;
                p.hideout.put(f[0], lvl + 1);
                p.applyCapacity();
                c.sfx("ui_buy", 0.7f);
                SaveSystem.save(p);
            }
            cy += ui.s(62);
        }
        // facility crafting
        if (ui.button("upclose", x + w - ui.s(150), y + h - ui.s(52), ui.s(130), ui.s(38), "CLOSE", "cross", true)) upgradesOpen = false;
        if (ui.button("upcraft", x + ui.s(20), y + h - ui.s(52), ui.s(300), ui.s(38), "CRAFT AT FACILITIES", "bench", true)) { upgradesOpen = false; craftOpen = !craftOpen; }
        if (c.in.keyPressed(org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE)) upgradesOpen = false;
    }

    private boolean craftOpen;

    // ================================================================== CONTRACTS
    private void contracts(Ui ui, float top) {
        Profile p = p();
        float h = ui.h - top - ui.s(24), w = (ui.w - ui.s(64)) / 2;
        float x = ui.s(24);
        float cy = ui.window("Contract Board", "contracts", x, top, w, h);
        for (Contracts.Contract k : new ArrayList<>(p.contracts.board)) {
            if (cy > top + h - ui.s(110)) break;
            contractCard(ui, k, x + ui.s(14), cy, w - ui.s(28), false);
            cy += ui.s(104);
        }
        float x2 = x + w + ui.s(16);
        float cy2 = ui.window("Active (" + p.contracts.active.size() + "/" + Contracts.MAX_ACTIVE + ")", "check", x2, top, w, h);
        if (p.contracts.active.isEmpty()) ui.text("No active contracts. Pay comes on extraction.", x2 + ui.s(16), cy2, 13, Ui.TXT_DIM);
        for (Contracts.Contract k : new ArrayList<>(p.contracts.active)) { contractCard(ui, k, x2 + ui.s(14), cy2, w - ui.s(28), true); cy2 += ui.s(104); }
        if (craftOpen) facilityCraft(ui, x2 + ui.s(14), cy2 + ui.s(10), w - ui.s(28));
    }

    private void contractCard(Ui ui, Contracts.Contract k, float x, float y, float w, boolean active) {
        ui.nine("slot", x, y, w, ui.s(96), 0xFFFFFFFF);
        ui.text(k.title, x + ui.s(12), y + ui.s(8), 15, Ui.TXT_HI);
        ui.textR(ZoneState.cap(k.giver), x + w - ui.s(12), y + ui.s(8), 12, Ui.AMBER);
        ui.text(k.desc, x + ui.s(12), y + ui.s(30), 12, Ui.TXT);
        ui.text("+" + k.scrip + " scrip   +" + k.xp + " XP   +" + (int) k.rep + " rep", x + ui.s(12), y + ui.s(50), 12, Ui.GREEN);
        if (active) {
            ui.bar(x + ui.s(12), y + ui.s(74), w - ui.s(150), ui.s(10), k.have / (float) Math.max(1, k.need), 0xFFE2A034);
            ui.text(k.have + "/" + k.need, x + w - ui.s(132), y + ui.s(70), 12, Ui.TXT);
            if (ui.button("ab" + k.id, x + w - ui.s(90), y + ui.s(62), ui.s(80), ui.s(28), "DROP", null, true)) p().contracts.abandon(k.id);
        } else if (ui.button("ac" + k.id, x + w - ui.s(110), y + ui.s(58), ui.s(100), ui.s(30), "ACCEPT", "check", p().contracts.active.size() < Contracts.MAX_ACTIVE)) {
            String e = p().contracts.accept(k.id);
            if (e != null) c.inv.say(e, Ui.RED); else c.sfx("ui_click", 0.5f);
        }
    }

    private void facilityCraft(Ui ui, float x, float y, float w) {
        Profile p = p();
        ui.text("FACILITY CRAFTING (uses carried + stash materials moved to your case)", x, y, 13, Ui.TXT_HI);
        float ry = y + ui.s(22);
        for (Content.Recipe r : Content.RECIPES) {
            if (r.where.equals("field") || r.where.equals("treasure")) continue;
            if (ry > ui.h - ui.s(60)) break;
            boolean lvl = p.level(r.facility()) >= r.level();
            boolean can = lvl && LoadoutPanel.canCraft(p, r);
            ui.text(r.name + "  (" + r.facility() + " " + r.level() + ")", x, ry, 12, can ? Ui.TXT_HI : Ui.TXT_DIM);
            if (ui.button("fc" + r.id, x + w - ui.s(90), ry - ui.s(4), ui.s(86), ui.s(26), "CRAFT", null, can)) { String e = LoadoutPanel.craft(p, r); c.inv.say(e == null ? "Crafted " + r.name : e, e == null ? Ui.GREEN : Ui.RED); }
            ry += ui.s(30);
        }
    }

    // ================================================================== DEPLOY
    private void deployModal(Ui ui) {
        Profile p = p();
        ui.b.rect(0, 0, ui.w, ui.h, 0xC0000000);
        List<MapData.Point> ins = c.world.map.insertions;
        float w = ui.s(760), h = ui.s(170) + ins.size() * ui.s(32), x = (ui.w - w) / 2, y = Math.max(ui.s(10), (ui.h - h) / 2);
        float cy = ui.window("Deploy", "flag", x, y, w, h);
        ui.text("INSERTION POINT", x + ui.s(20), cy, 13, Ui.TXT_HI);
        cy += ui.s(22);
        for (int i = 0; i < ins.size(); i++) {
            MapData.Point pt = ins.get(i);
            String ctl = p.zone.controller(pt.district);
            String info = pt.district.display + "  -  " + (ctl == null ? "contested" : ctl + " held") + String.format("  -  infected %d%%", Math.round(p.zone.infected[pt.district.ordinal()] * 100));
            if (ui.tab("ins" + i, x + ui.s(20), cy, w - ui.s(40), ui.s(28), pt.name + "    " + info, null, insertion == i)) insertion = i;
            cy += ui.s(32);
        }
        cy += ui.s(6);
        ui.text("OPERATION LENGTH", x + ui.s(20), cy, 13, Ui.TXT_HI);
        int[] lens = {25, 30, 35, 45};
        for (int i = 0; i < lens.length; i++) if (ui.tab("len" + i, x + ui.s(200) + i * ui.s(90), cy - ui.s(6), ui.s(84), ui.s(28), lens[i] + " min", "clock", minutes == lens[i])) minutes = lens[i];
        cy += ui.s(34);
        boolean armed = p.loadout.slot("primary") != null || p.loadout.slot("sidearm") != null;
        String warn = !armed ? "^No firearm equipped." : p.health < 50 ? "^Deploying injured (" + Math.round(p.health) + "%)." : "";
        if (!warn.isEmpty()) ui.text(warn.substring(1), x + ui.s(20), cy, 12, Ui.RED);
        if (ui.button("go", x + ui.s(20), y + h - ui.s(56), ui.s(260), ui.s(42), "DEPLOY NOW", "flag", true)) {
            deployOpen = false;
            action = "deploy";
            deployInsertion = insertion;
            deployMinutes = minutes;
            SaveSystem.save(p);
        }
        if (ui.button("dcancel", x + w - ui.s(200), y + h - ui.s(56), ui.s(180), ui.s(42), "CANCEL", "cross", true) || c.in.keyPressed(org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE)) deployOpen = false;
    }
}
