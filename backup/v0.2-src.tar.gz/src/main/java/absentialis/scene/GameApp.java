package absentialis.scene;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;

import absentialis.engine.Window;
import absentialis.engine.audio.AudioEngine;
import absentialis.engine.audio.SoundBank;
import absentialis.engine.render.Atlas;
import absentialis.engine.render.Batch2D;
import absentialis.engine.render.Font;
import absentialis.engine.render.ModelRenderer;
import absentialis.engine.render.Screenshot;
import absentialis.engine.render.WorldRenderer;
import absentialis.entity.Actor;
import absentialis.gameplay.economy.Economy;
import absentialis.gameplay.inventory.InventoryService;
import absentialis.gameplay.items.Content;
import absentialis.gameplay.items.ItemInstance;
import absentialis.persistence.Profile;
import absentialis.persistence.SaveSystem;
import absentialis.persistence.Settings;
import absentialis.sim.ZoneState;
import absentialis.ui.InventoryUi;
import absentialis.ui.ItemIcons;
import absentialis.ui.MapView;
import absentialis.ui.Ui;
import absentialis.world.Block;
import absentialis.world.District;
import absentialis.world.MapData;
import absentialis.world.World;
import absentialis.world.gen.CityGenerator;
import java.util.ArrayList;
import java.util.List;

/**
 * Application shell: boots every service, generates the Zone in the background while the menus
 * run, and drives the TITLE -> PROFILES -> HIDEOUT <-> RAID -> DEBRIEF state machine with 120 ms
 * screen transitions. Also hosts the developer console and the ABS_AUTOSHOT capture script.
 */
public final class GameApp {
    private enum State { TITLE, PROFILES, CREATE, HIDEOUT, LOADING, RAID, DEBRIEF }

    private final Window win;
    private final Ctx c = new Ctx();
    private State state = State.TITLE;
    private HideoutScreen hideout;
    private RaidScreen raidScreen;
    private SettingsScreen settings;
    private boolean settingsOpen;
    private volatile String genStatus = "Waiting";
    private volatile boolean worldGenerated, worldDirty;
    private volatile Thread prepThread;
    private boolean renderReady;
    private float fade = 1;
    private List<String> debriefLines = new ArrayList<>();
    private Raid lastRaid;
    private final StringBuilder nameField = new StringBuilder();
    private int createSlot, createArm = 4, createSkin = 1, createOutfit;
    private final String autoshot = System.getenv("ABS_AUTOSHOT");
    private int shotFrame;

    public GameApp(Window w) { this.win = w; }

    public void run() {
        init();
        long last = System.nanoTime();
        while (!win.shouldClose()) {
            long now = System.nanoTime();
            float dt = Math.min(0.05f, (now - last) / 1e9f);
            last = now;
            c.time += dt;
            win.poll();
            frame(dt);
            if (autoshot != null) autoshotStep();
            win.swap();
            c.in.endFrame();
        }
        if (c.profile != null && state != State.RAID) SaveSystem.save(c.profile);
        if (c.wr != null) c.wr.shutdown();
        if (c.audio != null) c.audio.stop();
    }

    // ------------------------------------------------------------------ boot
    private void init() {
        c.win = win;
        c.in = win.input;
        Content.load();
        c.settings = Settings.load(c.in);
        Batch2D b = new Batch2D();
        b.init();
        Font font = new Font(48);
        font.init();
        c.ui = new Ui(b, font, c.in);
        c.ui.init();
        c.icons = new ItemIcons();
        c.icons.init();
        c.inv = new InventoryUi(c.ui, c.icons);
        c.map = new MapView();
        c.console = new Console();
        c.mr = new ModelRenderer();
        c.mr.init();
        c.ar = new ActorRenderer(c.mr);
        c.audio = new AudioEngine();
        new SoundBank().build(c.audio.samples);
        c.audio.start();
        c.settings.applyAudio(c.audio);
        c.ui.sound = c::ui;
        menuMusic(true);
        c.atlas = new Atlas();
        c.atlas.paintAll();
        c.atlas.upload();
        settings = new SettingsScreen(c);
        registerCommands();
        win.setCursorLocked(false);
        glfwSetInputMode(win.handle, GLFW_CURSOR, GLFW_CURSOR_HIDDEN);
        startWorldGeneration();
        if (autoshot != null) autoProfile();
    }

    private void startWorldGeneration() {
        Thread t = new Thread(() -> {
            try {
                World w = new World();
                new CityGenerator(w, 1337L, s -> genStatus = s).generate();
                genStatus = "Lighting the Zone";
                w.lighting.computeAll();
                w.snapshotPristine();
                c.world = w;
                worldGenerated = true;
                genStatus = "Ready";
            } catch (Throwable e) {
                e.printStackTrace();
                genStatus = "World generation failed: " + e;
            }
        }, "worldgen");
        t.setDaemon(true);
        t.start();
    }

    /** GL-side setup once the voxel data exists (main thread). */
    private void ensureRenderer() {
        if (renderReady || !worldGenerated) return;
        c.wr = new WorldRenderer(c.world, c.atlas);
        c.wr.init();
        java.util.Arrays.fill(c.world.dirtyColumns, true);
        c.world.anyDirty = true;
        c.wr.scheduleDirty();
        c.map.build(c.world);
        if (c.profile != null) c.map.rebuildHatch(c.profile.zone);
        renderReady = true;
    }

    /** Restores the pristine city and re-applies persistent world state before a deployment. */
    private void prepareWorldForRaid() {
        Profile p = c.profile;
        prepThread = new Thread(() -> {
            if (worldDirty) {
                genStatus = "Resetting the operational slice";
                c.world.restorePristine();
            }
            for (MapData.Point lp : c.world.map.lampsOnPower) {
                District d = c.world.district(lp.x, lp.z);
                int want = p.zone.power[d.ordinal()] || d == District.CIVIC ? Block.LAMP : Block.LAMP_OFF;
                int cur = c.world.get(lp.x, lp.y, lp.z);
                if (cur == Block.LAMP || cur == Block.LAMP_OFF) c.world.setRaw(lp.x, lp.y, lp.z, want);
            }
            genStatus = "Relighting";
            c.world.lighting.computeAll();
            java.util.Arrays.fill(c.world.dirtyColumns, true);
            c.world.anyDirty = true;
            worldDirty = true;
            genStatus = "Meshing";
        }, "raid-prep");
        prepThread.setDaemon(true);
        prepThread.start();
    }

    // ------------------------------------------------------------------ frame
    private void frame(float dt) {
        ensureRenderer();
        if (c.wr != null && state != State.RAID) { c.wr.scheduleDirty(); c.wr.uploadResults(48); }
        c.ui.scale = c.settings.uiScale;
        if (c.in.keyPressed(GLFW_KEY_F12)) Screenshot.save(win.width, win.height, "screenshots/shot_" + System.currentTimeMillis() + ".png");
        if (state != State.RAID && c.in.keyPressed(GLFW_KEY_GRAVE_ACCENT)) c.console.toggle();
        if (state != State.RAID && c.console.open) c.console.input(c.in);
        switch (state) {
            case TITLE -> menuFrame(dt, this::title);
            case PROFILES -> menuFrame(dt, this::profiles);
            case CREATE -> menuFrame(dt, this::create);
            case HIDEOUT -> hideoutFrame(dt);
            case LOADING -> loadingFrame(dt);
            case RAID -> raidFrame(dt);
            case DEBRIEF -> menuFrame(dt, this::debrief);
        }
        fade = Math.max(0, fade - dt / Ui.EASE);
        if (fade > 0) {
            c.ui.b.begin(win.width, win.height);
            c.ui.b.rect(0, 0, win.width, win.height, Ui.alpha(0xFF000000, fade));
            c.ui.b.end();
        }
    }

    private void go(State s) { state = s; fade = 1; c.inv.drag = null; c.inv.menu.clear(); }

    private void menuFrame(float dt, Runnable body) {
        glViewport(0, 0, win.width, win.height);
        glClearColor(0.04f, 0.045f, 0.04f, 1);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        Ui ui = c.ui;
        ui.b.begin(win.width, win.height);
        ui.begin(dt, win.width, win.height);
        menuBackdrop(ui);
        if (settingsOpen) ui.block = true;
        body.run();
        ui.block = false;
        if (settingsOpen) { settings.draw(ui); if (settings.close) { settings.close = false; settingsOpen = false; } }
        c.console.draw(ui, dt);
        ui.end();
        ui.b.end();
    }

    private void menuBackdrop(Ui ui) {
        // slow drifting voxel skyline silhouette in pixel blocks
        int px = Math.max(4, ui.s(6));
        for (int x = 0; x < ui.w; x += px) {
            int hgt = (int) (ui.h * 0.18f + Math.abs(Math.sin(x * 0.013 + 1) * 90 + Math.sin(x * 0.051) * 40) * ui.scale);
            hgt = hgt / px * px;
            ui.b.rect(x, ui.h - hgt, px, hgt, 0xFF0C0E0C);
            if (((x / px) * 7 + (int) (c.time * 0.2)) % 23 == 0) ui.b.rect(x, ui.h - hgt + px * 3, px, px, 0xFF6A5420);
        }
        ui.b.rect(0, ui.h - ui.s(3), ui.w, ui.s(3), 0xFF8A6420);
    }

    // ------------------------------------------------------------------ title & profiles
    private void title() {
        Ui ui = c.ui;
        float cx = ui.w / 2f;
        ui.textC("ABSENTIALIS", cx, ui.h * 0.16f, 64, Ui.TXT_HI);
        ui.textC("A PERSISTENT VOXEL EXTRACTION SURVIVAL", cx, ui.h * 0.16f + ui.s(76), 14, Ui.AMBER);
        float bw = ui.s(320), bh = ui.s(48), y = ui.h * 0.42f;
        int last = lastProfile();
        if (ui.button("t_continue", cx - bw / 2, y, bw, bh, last >= 0 ? "CONTINUE  (" + SaveSystem.summary(last)[0] + ")" : "CONTINUE", "arrow", last >= 0)) { loadProfile(last); }
        if (ui.button("t_profiles", cx - bw / 2, y + bh + ui.s(10), bw, bh, "SURVIVOR PROFILES", "inv", true)) go(State.PROFILES);
        if (ui.button("t_settings", cx - bw / 2, y + (bh + ui.s(10)) * 2, bw, bh, "SETTINGS", "cog", true)) settingsOpen = true;
        if (ui.button("t_quit", cx - bw / 2, y + (bh + ui.s(10)) * 3, bw, bh, "QUIT", "cross", true)) win.requestClose();
        ui.textC(worldGenerated ? (renderReady && c.wr.busy() ? "Meshing the city... " + c.wr.pending.get() : "The Zone is ready.") : "Generating the Zone: " + genStatus + "...", cx, ui.h - ui.s(48), 12, Ui.TXT_DIM);
    }

    private int lastProfile() { for (int i = 0; i < SaveSystem.SLOTS; i++) if (SaveSystem.exists(i)) return i; return -1; }

    private final String[][] summaries = new String[SaveSystem.SLOTS][];
    private float summaryAge = 99;

    private void profiles() {
        Ui ui = c.ui;
        summaryAge += ui.dt;
        if (summaryAge > 2) { for (int i = 0; i < SaveSystem.SLOTS; i++) summaries[i] = SaveSystem.summary(i); summaryAge = 0; }
        float w = ui.s(860), h = ui.s(520), x = (ui.w - w) / 2, y = (ui.h - h) / 2;
        float cy = ui.window("Survivor Profiles  (4 isolated slots)", "inv", x, y, w, h);
        for (int i = 0; i < SaveSystem.SLOTS; i++) {
            float ry = cy + i * ui.s(96);
            ui.nine("slot", x + ui.s(20), ry, w - ui.s(40), ui.s(86), 0xFFFFFFFF);
            String[] s = summaries[i];
            if (s == null) {
                ui.text("SLOT " + (i + 1) + "  -  empty", x + ui.s(40), ry + ui.s(30), 16, Ui.TXT_DIM);
                if (ui.button("p_new" + i, x + w - ui.s(220), ry + ui.s(22), ui.s(180), ui.s(42), "NEW SURVIVOR", "star", true)) { createSlot = i; nameField.setLength(0); go(State.CREATE); }
            } else {
                ui.text(s[0], x + ui.s(40), ry + ui.s(14), 20, Ui.TXT_HI);
                ui.text(s[1] + "   -   " + s[2] + "   -   " + s[3], x + ui.s(40), ry + ui.s(46), 13, Ui.TXT);
                if (ui.button("p_load" + i, x + w - ui.s(330), ry + ui.s(22), ui.s(150), ui.s(42), "PLAY", "arrow", true)) loadProfile(i);
                if (ui.button("p_del" + i, x + w - ui.s(170), ry + ui.s(22), ui.s(130), ui.s(42), ui.shift ? "CONFIRM" : "DELETE", "cross", true)) {
                    if (ui.shift) { SaveSystem.delete(i); summaryAge = 99; } else c.inv.say("Hold Shift and click DELETE to erase this profile", Ui.AMBER);
                }
            }
        }
        if (ui.button("p_back", x + ui.s(20), y + h - ui.s(60), ui.s(160), ui.s(42), "BACK", "arrow", true) || c.in.keyPressed(GLFW_KEY_ESCAPE)) go(State.TITLE);
        c.inv.flashTime -= ui.dt;
        if (c.inv.flashTime > 0) ui.textC(c.inv.flash, ui.w / 2f, y + h + ui.s(12), 14, c.inv.flashColor);
    }

    private CharacterCreator creator;
    private absentialis.character.Appearance createApp = absentialis.character.Appearance.legacy(1, 0);
    private AudioEngine.Voice menuMusic;

    private void menuMusic(boolean on) {
        if (c.audio == null) return;
        if (on && menuMusic == null) menuMusic = c.audio.loop("music_hideout", 0.5f, AudioEngine.MUSIC);
        if (!on && menuMusic != null) { menuMusic.fadeTo(0, 2.5f); menuMusic = null; }
    }

    private void create() {
        Ui ui = c.ui;
        while (!c.in.typed.isEmpty()) { char ch = c.in.typed.poll(); if (nameField.length() < 18 && ch >= 32 && ch < 127) nameField.append(ch); }
        if (c.in.keyPressed(GLFW_KEY_BACKSPACE) && nameField.length() > 0) nameField.setLength(nameField.length() - 1);
        float w = Math.min(ui.w - ui.s(40), ui.s(1100)), h = Math.min(ui.h - ui.s(40), ui.s(760)), x = (ui.w - w) / 2, y = (ui.h - h) / 2;
        float cy = ui.window("New Survivor  -  Slot " + (createSlot + 1), "star", x, y, w, h);
        ui.text("CALLSIGN", x + ui.s(24), cy, 13, Ui.TXT_HI);
        ui.nine("slot", x + ui.s(24), cy + ui.s(20), ui.s(360), ui.s(40), 0xFFFFFFFF);
        ui.text(nameField + ((System.currentTimeMillis() / 450) % 2 == 0 ? "_" : ""), x + ui.s(36), cy + ui.s(30), 18, Ui.AMBER);
        cy += ui.s(80);
        if (creator == null) creator = new CharacterCreator(c);
        creator.draw(ui, createApp, null, x + ui.s(24), cy, w - ui.s(48), h - (cy - y) - ui.s(84));
        boolean ok = nameField.toString().trim().length() >= 2;
        if (ui.button("c_go", x + ui.s(24), y + h - ui.s(64), ui.s(260), ui.s(44), "ENTER THE ZONE", "arrow", ok) || ok && c.in.keyPressed(GLFW_KEY_ENTER)) {
            Profile p = new Profile();
            p.slot = createSlot;
            p.name = nameField.toString().trim();
            p.appearance = createApp.copy();
            p.seed = 1337L;
            p.starterKit();
            p.contracts.refill(p.seed, 1);
            SaveSystem.save(p);
            loadProfile(createSlot);
        }
        if (ui.button("c_back", x + w - ui.s(184), y + h - ui.s(64), ui.s(160), ui.s(44), "BACK", "cross", true) || c.in.keyPressed(GLFW_KEY_ESCAPE)) go(State.PROFILES);
    }

    private void loadProfile(int slot) {
        Profile p = SaveSystem.load(slot);
        if (p == null) return;
        c.profile = p;
        String err = p.verify();
        if (err != null) System.err.println("[Profile] integrity warning: " + err);
        InventoryService.listener = null;
        hideout = new HideoutScreen(c);
        hideout.enter();
        go(State.HIDEOUT);
    }

    // ------------------------------------------------------------------ hideout
    private void hideoutFrame(float dt) {
        if (settingsOpen) { menuFrame(dt, () -> {}); return; }
        hideout.render(dt);
        String a = hideout.action;
        hideout.action = null;
        if ("settings".equals(a)) settingsOpen = true;
        else if ("title".equals(a)) go(State.TITLE);
        else if ("deploy".equals(a)) deploy(hideout.deployInsertion, hideout.deployMinutes);
    }

    private int pendingInsertion;
    private float pendingMinutes;

    private void deploy(int insertion, float minutes) {
        if (!worldGenerated) return;
        pendingInsertion = insertion;
        pendingMinutes = minutes;
        prepareWorldForRaid();
        go(State.LOADING);
    }

    private void loadingFrame(float dt) {
        boolean prepDone = prepThread == null || !prepThread.isAlive();
        if (prepDone && c.wr != null) { c.wr.scheduleDirty(); c.wr.uploadResults(0); }
        menuFrame(dt, () -> {
            Ui ui = c.ui;
            ui.textC("DEPLOYING", ui.w / 2f, ui.h * 0.38f, 36, Ui.TXT_HI);
            String s = prepDone ? "Meshing the city (" + (c.wr == null ? "?" : c.wr.pending.get()) + " columns left)" : genStatus;
            ui.textC(s, ui.w / 2f, ui.h * 0.38f + ui.s(56), 14, Ui.TXT_DIM);
            String[] tips = {"Sound carries. Sprinting on metal is heard a block away; crouching on carpet is not.", "A tactical reload keeps the chambered round. Double-tap R to drop the magazine and go faster.",
                    "Weapons under 50 condition jam. Under 25 they need a workbench.", "Faction hostility needs evidence. Unwitnessed is not forgiven - only unknown.",
                    "Treasures and keys take no case space. Combine treasures for value.", "Missing extraction is a failed raid. Watch the clock: amber at 10:00, red at 3:00."};
            ui.textC(tips[(int) (c.time / 6) % tips.length], ui.w / 2f, ui.h * 0.62f, 14, Ui.AMBER);
        });
        if (prepDone && c.wr != null && !c.wr.busy()) startRaid();
    }

    private void startRaid() {
        Profile p = c.profile;
        c.bus.clear();
        Raid r = new Raid(c.world, p, c.settings, c.bus, pendingInsertion, pendingMinutes);
        c.map.rebuildHatch(p.zone);
        raidScreen = new RaidScreen(c, r);
        lastRaid = r;
        menuMusic(false);
        go(State.RAID);
    }

    private void raidFrame(float dt) {
        if (settingsOpen) { win.setCursorLocked(false); menuFrame(dt, () -> {}); if (!settingsOpen) raidScreen.paused = true; return; }
        raidScreen.update(dt);
        raidScreen.render(dt);
        if ("settings".equals(raidScreen.pauseAction)) { raidScreen.pauseAction = null; settingsOpen = true; }
        if ("quit".equals(raidScreen.pauseAction)) { raidScreen.raid.debrief.outcome = Raid.Debrief.Outcome.MIA; raidScreen.raid.debrief.reason = "Left the Zone (quit)"; endRaid(); win.requestClose(); return; }
        if (raidScreen.done) endRaid();
    }

    private void endRaid() {
        raidScreen.stopAudio();
        win.setCursorLocked(false);
        Raid r = raidScreen.raid;
        debriefLines = RaidResolver.resolve(r);
        SaveSystem.save(c.profile);
        menuMusic(true);
        if (r.debrief.outcome == Raid.Debrief.Outcome.EXTRACTED) c.sfx("extract_done", 0.6f);
        go(State.DEBRIEF);
    }

    private void debrief() {
        Ui ui = c.ui;
        Raid.Debrief d = lastRaid.debrief;
        boolean ok = d.outcome == Raid.Debrief.Outcome.EXTRACTED;
        float w = Math.min(ui.w - ui.s(40), ui.s(980)), h = ui.h - ui.s(80), x = (ui.w - w) / 2, y = ui.s(40);
        float cy = ui.window("Debrief", ok ? "flag" : "skull", x, y, w, h);
        int col = ok ? Ui.GREEN : d.outcome == Raid.Debrief.Outcome.MIA ? Ui.AMBER : Ui.RED;
        ui.text(ok ? "EXTRACTED" : d.outcome == Raid.Debrief.Outcome.MIA ? "MISSING IN ACTION" : "KILLED IN ACTION", x + ui.s(24), cy, 32, col);
        ui.text(d.reason + String.format("   -   %d:%02d in the Zone", (int) lastRaid.time / 60, (int) lastRaid.time % 60), x + ui.s(24), cy + ui.s(42), 14, Ui.TXT);
        cy += ui.s(80);
        float colW = (w - ui.s(72)) / 2;
        ui.text("EXPERIENCE", x + ui.s(24), cy, 14, Ui.TXT_HI);
        float ly = cy + ui.s(24);
        for (String[] xp : d.xp) { ui.text(xp[0], x + ui.s(24), ly, 13, Ui.TXT); ui.textR("+" + xp[1], x + ui.s(24) + colW, ly, 13, Ui.AMBER); ly += ui.s(20); }
        ly += ui.s(8);
        ui.text(String.format("Shots %d  -  hits %d  -  containers %d  -  noise %.0f", d.shotsFired, d.hits, d.containersSearched, d.noise), x + ui.s(24), ly, 12, Ui.TXT_DIM);
        ly += ui.s(26);
        ui.text(c.profile.prog.title() + "  -  " + c.profile.scrip + " scrip", x + ui.s(24), ly, 16, Ui.TXT_HI);
        ui.bar(x + ui.s(24), ly + ui.s(26), colW, ui.s(10), c.profile.prog.rankProgress(), 0xFFE2A034);
        float rx = x + ui.s(48) + colW;
        ui.text("CONSEQUENCES", rx, cy, 14, Ui.TXT_HI);
        float ry = cy + ui.s(24);
        for (String l : debriefLines) {
            if (ry > y + h - ui.s(90)) break;
            ry += ui.wrap("- " + l, rx, ry, colW, 13, l.startsWith("NEWS") ? Ui.AMBER : l.startsWith("Lost") ? Ui.RED : Ui.TXT) + ui.s(4);
        }
        if (ui.button("d_cont", x + w - ui.s(260), y + h - ui.s(64), ui.s(236), ui.s(44), "RETURN TO HIDEOUT", "arrow", true) || c.in.keyPressed(GLFW_KEY_ENTER)) {
            hideout.enter();
            go(State.HIDEOUT);
        }
    }

    // ------------------------------------------------------------------ console
    private Raid raid() { return state == State.RAID && raidScreen != null ? raidScreen.raid : null; }

    private void registerCommands() {
        Console k = c.console;
        k.register("help", "list commands", a -> k.help(), null);
        k.register("god", "toggle invulnerability", a -> { Raid r = raid(); if (r == null) return "Only in a raid"; r.god = !r.god; return "god " + (r.god ? "ON" : "OFF"); }, null);
        k.register("noclip", "toggle noclip flight", a -> { Raid r = raid(); if (r == null) return "Only in a raid"; r.noclip = !r.noclip; return "noclip " + (r.noclip ? "ON" : "OFF"); }, null);
        k.register("thirdperson", "toggle third-person camera", a -> { if (raidScreen == null) return "Only in a raid"; raidScreen.thirdPerson = !raidScreen.thirdPerson; return "third person " + raidScreen.thirdPerson; }, null);
        k.register("give", "give <itemId> [qty] - creates a new instance in your case (or stash)", a -> {
            if (c.profile == null) return "No profile loaded";
            if (a.length < 2 || Content.def(a[1]) == null) return "Unknown item. Tab completes ids.";
            ItemInstance it = new ItemInstance(a[1]);
            it.qty = a.length > 2 ? Math.max(1, Math.min(it.def().maxStack, Integer.parseInt(a[2]))) : 1;
            it.origin = "console";
            if (it.def().magazine != null) { it.rounds = it.capacity(); it.ammoId = Content.ammoFor(it.def().magazine.caliber).id; }
            var res = state == State.RAID ? InventoryService.store(it, c.profile.loadout) : InventoryService.add(it, c.profile.stash);
            return res.ok() ? "Gave " + it : res.msg();
        }, i -> i == 0 ? new ArrayList<>(Content.ITEMS.keySet()) : null);
        k.register("tp", "tp <district|exit id> - teleport", a -> {
            Raid r = raid();
            if (r == null || a.length < 2) return "Usage in raid: tp <district|exit>";
            for (MapData.Exit e : c.world.map.exits) if (e.id.equalsIgnoreCase(a[1])) { place(r, e.x + 0.5f, e.y, e.z + 2.5f); return "Teleported to " + e.name; }
            District d = District.byName(a[1]);
            if (d == null) return "Unknown destination";
            for (MapData.Point p : c.world.map.insertions) if (p.district == d) { place(r, p.x + 0.5f, p.y, p.z + 0.5f); return "Teleported to " + p.name; }
            for (MapData.Node n : c.world.map.nodes) if (n.district == d) { place(r, n.x + 0.5f, n.y, n.z + 0.5f); return "Teleported to " + d.display; }
            return "No spot found";
        }, i -> { List<String> l = new ArrayList<>(); for (District d : District.values()) l.add(d.name().toLowerCase()); if (c.world != null) for (MapData.Exit e : c.world.map.exits) l.add(e.id); return l; });
        k.register("setrep", "setrep <faction> <value>", a -> { if (c.profile == null || a.length < 3) return "Usage: setrep <faction> <value>"; c.profile.rep.put(a[1], Float.parseFloat(a[2])); return a[1] + " = " + a[2]; }, i -> i == 0 ? List.of(ZoneState.FACTIONS) : null);
        k.register("econ", "econ audit [graph] - verify no buy/sell loop, show price curves", a -> {
            if (c.profile == null) return "No profile";
            StringBuilder b = new StringBuilder(Economy.audit(c.profile.zone, c.profile.rep));
            if (a.length > 2 && "graph".equals(a[2])) {
                b.append("\nSale saturation (repeated sales of one item):");
                ItemInstance probe = new ItemInstance(-1, "val.watch");
                for (int s = 0; s <= 10; s += 2) {
                    int v = Economy.sellPrice(probe, Economy.trader("mara"), c.profile.zone, 0, s);
                    b.append("\n  sale ").append(s).append(": ").append(v).append(" ").append("#".repeat(Math.max(1, v / 4)));
                }
            }
            return b.toString();
        }, i -> i == 0 ? List.of("audit") : i == 1 ? List.of("graph") : null);
        k.register("skip", "skip hour [n] - advance the strategic world clock", a -> {
            if (c.profile == null) return "No profile";
            int n = a.length > 2 ? Integer.parseInt(a[2]) : 1;
            String[] before = c.profile.zone.controllers();
            c.profile.zone.advance(n, c.profile.seed);
            c.profile.zone.announceFlips(before);
            if (c.map.ready()) c.map.rebuildHatch(c.profile.zone);
            return "Advanced " + n + "h -> day " + c.profile.zone.day + " " + (int) c.profile.zone.hour + ":00";
        }, i -> i == 0 ? List.of("hour") : null);
        k.register("ai", "ai debug - toggle AI state overlay", a -> { Raid r = raid(); if (r == null) return "Only in a raid"; r.aiDebug = !r.aiDebug; return "AI debug " + r.aiDebug; }, i -> i == 0 ? List.of("debug") : null);
        k.register("noise", "noise debug - show sound propagation rings", a -> { Raid r = raid(); if (r == null) return "Only in a raid"; r.noiseDebug = !r.noiseDebug; return "noise debug " + r.noiseDebug; }, i -> i == 0 ? List.of("debug") : null);
        k.register("save", "save the profile now", a -> { if (c.profile == null) return "No profile"; if (state == State.RAID) return "Saving is disabled mid-raid (raid state resolves on exit)"; SaveSystem.save(c.profile); return "Saved slot " + c.profile.slot; }, null);
        k.register("load", "reload the profile from disk", a -> { if (c.profile == null || state == State.RAID) return "Not available"; loadProfile(c.profile.slot); return "Loaded"; }, null);
        k.register("xp", "xp <amount> - grant XP", a -> { if (c.profile == null) return "No profile"; int r = c.profile.prog.addXp(Long.parseLong(a[1])); return "Rank " + c.profile.prog.rank() + (r > 0 ? " (+" + r + ")" : ""); }, null);
        k.register("heal", "full heal (raid) / health (hideout)", a -> { Raid r = raid(); if (r != null) { r.player.hp = 100; r.body.bleedHeavy = r.body.bleedLight = r.body.fracture = false; } else if (c.profile != null) c.profile.health = 100; return "Healed"; }, null);
        k.register("extract", "force a successful extraction", a -> { Raid r = raid(); if (r == null) return "Only in a raid"; r.debrief.outcome = Raid.Debrief.Outcome.EXTRACTED; r.debrief.exitName = "Console"; r.debrief.reason = "Extracted (console)"; return "Extracting"; }, null);
        k.register("time", "time <minutesLeft> - set the raid clock", a -> { Raid r = raid(); if (r == null) return "Only in a raid"; r.duration = r.time + Float.parseFloat(a[1]) * 60; return "Clock set"; }, null);
        k.register("spawn", "spawn <archetype|faction> - spawn an infected archetype or a faction member 12m ahead", a -> {
            Raid r = raid();
            if (r == null || a.length < 2) return "Only in a raid";
            float x = r.player.x - (float) Math.sin(r.player.yaw) * 12, z = r.player.z - (float) Math.cos(r.player.yaw) * 12;
            Actor sp = r.debugSpawn(a[1], x, z, r.player.y);
            return "Spawned " + (sp.infected() ? absentialis.ai.Brain.displayName(sp.archetype) + " infected" : ZoneState.cap(sp.faction) + " " + sp.archetype);
        }, i -> { List<String> l = new ArrayList<>(); for (var ar : absentialis.ai.Brain.ARCHS) if (ar.infected()) l.add(ar.id()); l.addAll(List.of(ZoneState.FACTIONS)); return l; });
        k.register("freeze", "toggle AI decisions (bodies and animation keep running)", a -> { Raid r = raid(); if (r == null) return "Only in a raid"; r.freezeAI = !r.freezeAI; return "AI " + (r.freezeAI ? "frozen" : "running"); }, null);
        k.register("alife", "alife [log] - strategic squads and the off-screen event log", a -> {
            if (c.profile == null) return "No profile";
            StringBuilder sb = new StringBuilder();
            for (var sq : c.profile.zone.squads) sb.append(String.format("#%d %s x%d in %s -> %s%n", sq.id, ZoneState.cap(sq.faction), sq.size, District.values()[sq.district].display, District.values()[sq.goal].display));
            for (int i = 0; i < Math.min(10, c.profile.zone.log.size()); i++) { var e = c.profile.zone.log.get(i); sb.append(String.format("  d%d %02d:00 [%s] %s%n", e.day(), e.hour(), e.type(), e.text())); }
            Raid r = raid();
            if (r != null) sb.append("raid: noise events ").append(r.noiseEvents).append(", migrations ").append(r.migrations).append(", dispatches ").append(r.dispatches).append(", evidence ").append(r.evidence.size());
            return sb.length() == 0 ? "No strategic state yet - skip hour to advance" : sb.toString().trim();
        }, i -> i == 0 ? List.of("log") : null);
        k.register("selftest", "run the quality gates now", a -> { int f = absentialis.tools.SelfTests.runHeadless("all"); return f == 0 ? "All gates passed" : f + " gate(s) FAILED - see stdout"; }, null);
        k.print("ABSENTIALIS console. Type 'help'. Tab autocompletes.");
    }

    private static void place(Raid r, float x, float y, float z) { r.player.x = x; r.player.y = y + 0.1f; r.player.z = z; r.player.vy = 0; }

    // ------------------------------------------------------------------ autoshot (scripted visual verification)
    private void autoProfile() {
        Profile p = new Profile();
        p.slot = 3;
        p.name = "Autoshot";
        p.starterKit();
        p.contracts.refill(p.seed, 1);
        SaveSystem.save(p);
    }

    private void autoshotStep() {
        shotFrame++;
        String dir = autoshot;
        switch (state) {
            case TITLE -> { if (shotFrame == 20) shot(dir, "01_title"); if (shotFrame > 25 && worldGenerated) loadProfile(3); }
            case HIDEOUT -> {
                int f = shotFrame;
                if (hideoutT == 0) { hideoutT = f; equipForAuto(); }
                int rel = f - hideoutT;
                int nt = HideoutScreen.TABS.length;
                for (int t = 0; t < nt; t++) if (rel == 10 + t * 12) { hideout.tab = t; }
                for (int t = 0; t < nt; t++) if (rel == 20 + t * 12) shot(dir, "02_hideout_" + HideoutScreen.TABS[t].toLowerCase());
                if (rel >= 30 + nt * 12 && renderReady && raidT == 0 && state == State.HIDEOUT && !deployed) { deployed = true; deploy(0, 30); }
            }
            case RAID -> {
                if (raidT == 0) raidT = shotFrame;
                int rel = shotFrame - raidT;
                Raid r = raidScreen.raid;
                var in = c.in;
                int fire = absentialis.engine.Input.MOUSE_OFFSET + GLFW_MOUSE_BUTTON_LEFT;
                // staged on the west ring avenue: one of everyone in a line-up, AI frozen so they hold the pose
                if (rel == 3) { r.freezeAI = true; r.god = true; place(r, 250.5f, World.GROUND, 300.5f); r.player.yaw = 0; r.player.pitch = 0; }
                if (rel == 6) {
                    String[] cast = {"military", "mercenaries", "raiders", "survivors", "walker", "sprinter", "boomer", "tank"};
                    for (int i = 0; i < cast.length; i++) { Actor a = r.debugSpawn(cast[i], 243.5f + i * 2f, 292.5f - (i >= 4 ? 2 : 0), World.GROUND); a.yaw = (float) Math.PI; a.homeX = a.x; a.homeZ = a.z; lineup.add(a); }
                }
                if (rel == 40) shot(dir, "03_raid_start");
                if (rel == 44) r.player.pitch = -1.25f;
                if (rel == 56) shot(dir, "03b_first_person_legs");
                if (rel == 58) { r.player.pitch = 0; raidScreen.thirdPerson = true; }
                if (rel == 80) shot(dir, "06_raid_thirdperson");
                if (rel == 82) in.inject(GLFW_KEY_W, true);
                if (rel == 104) shot(dir, "06b_thirdperson_walk");
                if (rel == 106) { in.inject(GLFW_KEY_W, false); raidScreen.thirdPerson = false; place(r, 250.5f, World.GROUND, 300.5f); }
                if (rel >= 112 && rel < 116) in.inject(fire, rel % 2 == 1);
                if (rel == 116) { shot(dir, "05_firing"); in.inject(fire, false); }
                if (rel == 120) in.inject(GLFW_KEY_R, true);
                if (rel == 121) in.inject(GLFW_KEY_R, false);
                if (rel == 150) shot(dir, "05b_reload");
                if (rel == 200) { for (int i = 0; i < 4 && i < lineup.size(); i++) r.damageActor(lineup.get(i), r.player, 500, absentialis.gameplay.items.Content.def("ammo.556"), i % 2 == 0 ? "torso" : "head", lineup.get(i).x, lineup.get(i).y + 1, lineup.get(i).z); }
                if (rel == 212) shot(dir, "10a_ragdoll_falling");
                if (rel == 290) shot(dir, "10b_ragdoll_settled");
                if (rel == 292) in.inject(GLFW_KEY_TAB, true);
                if (rel == 312) shot(dir, "07_weapon_wheel");
                if (rel == 313) in.inject(GLFW_KEY_TAB, false);
                if (rel == 320) { if (!raidScreen.debugOpenNearestContainer(25)) raidScreen.invOpen = true; }
                if (rel == 340) shot(dir, "08_inventory_loot");
                if (rel == 345) { in.inject(GLFW_KEY_I, true); }
                if (rel == 346) { in.inject(GLFW_KEY_I, false); raidScreen.invOpen = false; raidScreen.mapOpen = true; }
                if (rel == 365) shot(dir, "09_map");
                if (rel == 370) { raidScreen.mapOpen = false; place(r, 380.5f, World.GROUND, 339.5f); r.player.yaw = 0.12f; r.player.pitch = 0.42f; }
                if (rel == 400) shot(dir, "10_power_plant");
                if (rel == 405) { c.console.exec("time 2.5"); r.player.pitch = 0; r.player.hp = 60; r.body.healthChanged = r.time; r.body.staminaChanged = r.time; r.body.stamina = 40; }
                if (rel == 425) shot(dir, "11_hud_red_timer");
                if (rel == 430) c.console.exec("extract");
            }
            case DEBRIEF -> { if (debriefT == 0) debriefT = shotFrame; if (shotFrame - debriefT == 20) { shot(dir, "12_debrief"); win.requestClose(); } }
            default -> {}
        }
        if (shotFrame > 20000) win.requestClose();
    }

    private final List<Actor> lineup = new ArrayList<>();
    private int hideoutT, raidT, debriefT;
    private boolean deployed;

    private void equipForAuto() {
        Profile p = c.profile;
        for (ItemInstance i : new ArrayList<>(p.stash.items)) {
            if (i.def().slot != null && p.loadout.slot(i.def().slot) == null) InventoryService.equip(i, p.loadout, i.def().slot);
        }
        for (ItemInstance i : new ArrayList<>(p.stash.items)) if (i.def().magazine != null || i.def().medical != null || i.def().ammo != null || i.def().food != null) InventoryService.store(i, p.loadout);
        ItemInstance akr = p.loadout.slot("primary");
        for (ItemInstance i : new ArrayList<>(p.loadout.caseGrid.items)) if (akr != null && i.def().magazine != null && akr.mag == null) { InventoryService.insertMag(akr, i); absentialis.gameplay.weapons.WeaponService.chamberFromMag(akr); }
        for (ItemInstance i : new ArrayList<>(p.stash.items)) if (akr != null && i.def().attachment != null) InventoryService.attach(akr, i);
    }

    private void shot(String dir, String name) { Screenshot.save(win.width, win.height, dir + "/" + name + ".png"); }
}
