package absentialis.scene;

import absentialis.engine.Input;
import absentialis.persistence.Settings;
import absentialis.ui.Ui;
import java.util.ArrayList;
import java.util.List;

/**
 * Options (GDD 18.3/18.4, addendum polish checklist): UI scale slider, camera shake, sensitivity,
 * FOV, volumes, subtitles with directional tags, hit direction, hold/toggle actions, difficulty
 * presets and fully rebindable keys.
 */
public final class SettingsScreen {
    private final Ctx c;
    private String rebinding;
    private float scroll;
    public boolean close;

    public SettingsScreen(Ctx c) { this.c = c; }

    public void draw(Ui ui) {
        Settings s = c.settings;
        Input in = c.in;
        ui.b.rect(0, 0, ui.w, ui.h, 0xD0060706);
        float w = Math.min(ui.w - ui.s(40), ui.s(1000)), h = ui.h - ui.s(80), x = (ui.w - w) / 2, y = ui.s(40);
        float cy = ui.window("Settings", "cog", x, y, w, h);
        float colW = (w - ui.s(72)) / 2, lx = x + ui.s(24), rx = lx + colW + ui.s(24);
        float ly = cy + ui.s(4);
        ui.text("DISPLAY & ACCESSIBILITY", lx, ly, 14, Ui.TXT_HI); ly += ui.s(28);
        // the scale applies on mouse release so the layout does not reflow under the cursor mid-drag
        if (draggingScale && !ui.down) { s.uiScale = pendingScale; draggingScale = false; }
        if (!draggingScale) pendingScale = s.uiScale;
        float v = Math.round(ui.slider("uiscale", lx, ly, colW, "UI scale", pendingScale, 0.75f, 1.75f, "%.2fx") * 20) / 20f;
        if (ui.down && v != pendingScale) draggingScale = true;
        pendingScale = v;
        ly += ui.s(52);
        s.shake = ui.slider("shake", lx, ly, colW, "Camera shake", s.shake, 0, 1, "%.2f"); ly += ui.s(52);
        s.fov = ui.slider("fov", lx, ly, colW, "Field of view", s.fov, 60, 100, "%.0f"); ly += ui.s(52);
        s.sensitivity = ui.slider("sens", lx, ly, colW, "Mouse sensitivity", s.sensitivity, 0.03f, 0.4f, "%.2f"); ly += ui.s(52);
        s.subtitles = ui.toggle("subs", lx, ly, colW, "Subtitles with directional sound tags", s.subtitles); ly += ui.s(32);
        s.hitDirection = ui.toggle("hitdir", lx, ly, colW, "Directional hit indicators", s.hitDirection); ly += ui.s(32);
        s.toggleAim = ui.toggle("tAim", lx, ly, colW, "Aim: toggle instead of hold", s.toggleAim); ly += ui.s(32);
        s.toggleCrouch = ui.toggle("tCrouch", lx, ly, colW, "Crouch: toggle instead of hold", s.toggleCrouch); ly += ui.s(32);
        s.showFps = ui.toggle("fps", lx, ly, colW, "Show FPS / perf", s.showFps); ly += ui.s(40);
        ui.text("DIFFICULTY PRESET", lx, ly, 14, Ui.TXT_HI); ly += ui.s(24);
        for (int i = 0; i < 3; i++) if (ui.tab("diff" + i, lx + i * (colW / 3), ly, colW / 3 - ui.s(4), ui.s(30), Settings.DIFFICULTY[i], null, s.difficulty == i)) s.difficulty = i;
        ly += ui.s(36);
        ui.text(new String[]{"Slower AI awareness, gentler survival drain.", "The intended balance.", "Sharper AI, harsher survival. Same extraction stakes."}[s.difficulty], lx, ly, 11, Ui.TXT_DIM);
        // audio: one master, four buses, each with a mute
        float ry = cy + ui.s(4);
        float sw = colW - ui.s(96);
        ui.text("AUDIO", rx, ry, 14, Ui.TXT_HI); ry += ui.s(26);
        s.master = ui.slider("vmaster", rx, ry, sw, "Master", s.master, 0, 1, "%.2f"); s.muteAll = ui.toggle("mAll", rx + sw + ui.s(10), ry + ui.s(14), ui.s(86), "Mute", s.muteAll); ry += ui.s(46);
        s.music = ui.slider("vmusic", rx, ry, sw, "Music", s.music, 0, 1, "%.2f"); s.muteMusic = ui.toggle("mMus", rx + sw + ui.s(10), ry + ui.s(14), ui.s(86), "Mute", s.muteMusic); ry += ui.s(46);
        s.sfx = ui.slider("vsfx", rx, ry, sw, "Effects", s.sfx, 0, 1, "%.2f"); s.muteSfx = ui.toggle("mSfx", rx + sw + ui.s(10), ry + ui.s(14), ui.s(86), "Mute", s.muteSfx); ry += ui.s(46);
        s.voice = ui.slider("vvoice", rx, ry, sw, "Voice", s.voice, 0, 1, "%.2f"); s.muteVoice = ui.toggle("mVoi", rx + sw + ui.s(10), ry + ui.s(14), ui.s(86), "Mute", s.muteVoice); ry += ui.s(46);
        s.ambience = ui.slider("vamb", rx, ry, sw, "Ambience", s.ambience, 0, 1, "%.2f"); ry += ui.s(46);
        s.uiVolume = ui.slider("vui", rx, ry, sw, "Interface", s.uiVolume, 0, 1, "%.2f"); ry += ui.s(52);
        s.applyAudio(c.audio);
        // key bindings
        float bindTop = ry;
        ui.text("CONTROLS  (click to rebind, Esc cancels)", rx, ry, 14, Ui.TXT_HI); ry += ui.s(28);
        List<String> acts = new ArrayList<>(in.bindings.keySet());
        float rowH = ui.s(27);
        int vis = (int) ((y + h - ui.s(90) - ry) / rowH);
        scroll = Math.max(0, Math.min(Math.max(0, acts.size() - vis), scroll - (float) in.scroll));
        for (int i = (int) scroll; i < Math.min(acts.size(), (int) scroll + vis); i++) {
            String a = acts.get(i);
            ui.text(a.replace('_', ' '), rx, ry + ui.s(4), 13, Ui.TXT);
            boolean wait = a.equals(rebinding);
            String key = wait ? "press a key..." : Input.keyName(in.bindings.get(a));
            if (ui.button("bind" + a, rx + colW - ui.s(150), ry, ui.s(150), ui.s(24), key, null, true)) rebinding = a;
            ry += rowH;
        }
        if (rebinding != null) {
            if (in.keyPressed(org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE)) rebinding = null;
            else if (in.lastKeyPressed >= 0 && !(in.lastKeyPressed == Input.MOUSE_OFFSET && ui.consumed)) {
                int k = in.lastKeyPressed;
                if (k != Input.MOUSE_OFFSET || !ui.hover(rx, bindTop, colW, h)) { in.bindings.put(rebinding, k); rebinding = null; }
            }
        }
        if (ui.button("defaults", rx, y + h - ui.s(60), ui.s(180), ui.s(40), "DEFAULT KEYS", null, true)) in.resetBindings();
        if (ui.button("sclose", x + w - ui.s(200), y + h - ui.s(60), ui.s(176), ui.s(40), "DONE", "check", true) || (rebinding == null && in.keyPressed(org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE))) {
            s.save(in);
            close = true;
        }
    }

    private float pendingScale = 1;
    private boolean draggingScale;
}
