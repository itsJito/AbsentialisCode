package absentialis.scene;

import static absentialis.character.Rig.*;

import absentialis.character.Animator;
import absentialis.character.Appearance;
import absentialis.character.CharBuilder;
import absentialis.character.CharModel;
import absentialis.character.Pose;
import absentialis.character.Rig;
import absentialis.engine.math.Mat4;
import absentialis.engine.render.ModelRenderer;
import absentialis.engine.render.Tex;
import absentialis.engine.voxel.VoxModel;
import absentialis.entity.Actor;
import absentialis.gameplay.inventory.Loadout;
import absentialis.gameplay.items.ItemInstance;
import absentialis.persistence.Profile;
import absentialis.ui.ItemModels;
import absentialis.world.World;
import java.util.HashMap;
import java.util.Map;

/**
 * Draws characters as twelve skinned voxel parts on the shared rig. A character is a look
 * (definition-table indices) plus visible gear; the assembled part meshes are cached by that key
 * and posed every frame by the {@link Animator} - or by the ragdoll once the actor is dead. The
 * same model is used in third person, as the first-person body and for the viewmodel arms.
 */
public final class ActorRenderer {
    public static final float VOX = Rig.VOX;
    /** Held weapons are modelled at 1/40 m per voxel; in character voxels that is this scale. */
    public static final float WEAPON_SCALE = (1f / 40f) / VOX;
    private final ModelRenderer mr;
    private final Map<String, CharModel> models = new HashMap<>();
    private final Mat4[] bones = new Mat4[GROUPS];
    private final Mat4 base = new Mat4(), hips = new Mat4(), aim = new Mat4(), wpn = new Mat4(), m = new Mat4();
    private final Pose pose = new Pose();
    private final float[] v = new float[3];
    /** SKIN groups hidden on the first-person body: the head (the camera is inside it) and the arms the viewmodel draws. Legs stay. */
    public static final int FP_HIDE = bit(HEAD) | ARMS_MASK;
    /** Whole-character opacity (third-person camera pulled in close to the player). */
    public float alpha = 1;

    public ActorRenderer(ModelRenderer mr) { this.mr = mr; for (int g = 0; g < GROUPS; g++) bones[g] = new Mat4(); }

    /** Appearance + gear resolved for an actor, with the cache key of its assembled model. */
    public static final class Look {
        public Appearance app;
        public final CharBuilder.Gear gear = new CharBuilder.Gear();
        public String key;
        public float scale = 1;
    }

    // ------------------------------------------------------------------ looks
    /** The player's look: profile definition ids plus whatever is actually equipped. */
    public static Look playerLook(Profile p, Look reuse) {
        Look l = reuse != null ? reuse : new Look();
        l.app = p.appearance;
        Loadout lo = p.loadout;
        ItemInstance head = lo.slot("head"), face = lo.slot("face"), vest = lo.slot("armor"), pack = lo.slot("backpack");
        l.gear.head = head == null ? "" : head.def().armor != null && head.def().armor.armorClass > 0 ? "helmet" : "cap";
        l.gear.face = face == null ? "" : face.def().armor != null && face.def().armor.gasMask ? "gasmask" : "balaclava";
        l.gear.vest = vest == null || vest.def().armor == null ? "" : vest.def().armor.armorClass >= 4 ? "plate" : vest.def().armor.armorClass >= 3 ? "mil" : "soft";
        l.gear.pack = pack == null ? "case" : pack.def().backpack != null && pack.def().backpack.gw >= 8 ? "large" : "small";
        l.gear.facePaint = p.prog.cosmetics.contains("face_paint") && p.facePaint;
        l.gear.helmetMarks = p.prog.cosmetics.contains("helmet_marks");
        l.key = CharBuilder.key(l.app, l.gear);
        return l;
    }

    /** Seeded faction look for an NPC, cached on the actor. */
    public static Look lookFor(Actor a) {
        if (a.visual instanceof Look l) return l;
        Look l = new Look();
        if (a.infected()) {
            l.gear.infected = a.archetype;
            l.scale = "tank".equals(a.archetype) ? 1.45f : "boomer".equals(a.archetype) ? 1.08f : 1f;
        } else {
            l.gear.vest = a.armorClass >= 4 ? "plate" : a.armorClass >= 3 ? "mil" : a.armorClass > 0 ? "soft" : "";
            l.gear.head = a.helmet ? "helmet" : a.look.contains("head:helmet.cap") ? "cap" : "";
        }
        l.app = CharBuilder.factionLook(a.infected() ? "infected" : a.faction, a.id * 7919L + 13, l.gear);
        l.key = CharBuilder.key(l.app, l.gear);
        a.visual = l;
        return l;
    }

    private CharModel model(Look l) {
        CharModel cm = models.get(l.key);
        if (cm == null) {
            if (models.size() > 400) models.clear();
            cm = CharBuilder.build(l.app, l.gear);
            models.put(l.key, cm);
        }
        return cm;
    }

    private Animator animator(Actor a, Look l) {
        if (a.anim == null) a.anim = new Animator();
        a.anim.scale = l.scale;
        a.anim.family = Animator.familyOf(a.archetype, a.infected());
        return a.anim;
    }

    /** Grip geometry of a held weapon: sets the animator's two-handed flag and support-hand distance. */
    private static void grips(Animator an, ItemInstance w) {
        if (w == null) return;
        VoxModel wm = ItemModels.of(w);
        boolean melee = w.def().weapon != null && w.def().weapon.melee();
        an.twoHanded = !melee && wm.sx >= 26;
        an.gripSep = Math.max(0.6f, Math.min(8.5f, wm.sx * WEAPON_SCALE * 0.34f));
    }

    private void basis(Actor a, Animator an, float scale, float backOff) {
        float s = VOX * scale;
        base.identity().translate(a.x + (float) Math.sin(a.yaw) * backOff, a.y + an.visY, a.z + (float) Math.cos(a.yaw) * backOff).rotateY(a.yaw).scale(s, s, s);
    }

    // ------------------------------------------------------------------ drawing
    /** Draws one actor in the world. hideMask removes SKIN groups (first-person body hides head and arms). */
    public void draw(Actor a, Look l, float light, float aimPitch, Animator.Ground ground, int hideMask, boolean firstPerson) {
        CharModel cm = model(l);
        int tint = ((int) (alpha * 255) << 24) | (a.hurtFlash > 0 ? 0xFF9090 : 0xFFFFFF);
        boolean rag = a.ragdoll != null;
        Animator an = animator(a, l);
        if (rag) a.ragdoll.bones(bones);
        else {
            grips(an, a.weapon);
            an.pose(a, pose, aimPitch, ground, firstPerson);
            float back = 0;
            if (firstPerson) {
                // the body hangs from the head: shift it so the head bone sits on the capsule axis
                basis(a, an, l.scale, 0);
                fk(pose, base, hips, bones);
                // the eye is at the front of the skull, so looking down shows the legs and feet, not the inside of the chest
                bones[HEAD].transformPoint(0, 5.3f, -6.5f, v);
                float ox = v[0] - a.x, oz = v[2] - a.z;
                base.identity().translate(a.x - ox, a.y + an.visY, a.z - oz).rotateY(a.yaw).scale(VOX * l.scale, VOX * l.scale, VOX * l.scale);
            } else basis(a, an, l.scale, back);
            fk(pose, base, hips, bones);
        }
        for (int g = 0; g < GROUPS; g++) {
            if ((hideMask & (1 << g)) != 0) continue;
            mr.draw(mr.meshAt(l.key + "#" + g, cm.groups[g], ORIGIN[g][0], ORIGIN[g][1], ORIGIN[g][2]), bones[g], light, tint, 0);
        }
        if (a.weapon != null && !rag && (hideMask & bit(R_HAND)) == 0) {
            an.aimFrame(pose, aimPitch, hips, aim);
            Animator.weaponFrame(pose, aim, wpn);
            VoxModel wm = ItemModels.of(a.weapon);
            boolean melee = a.weapon.def().weapon != null && a.weapon.def().weapon.melee();
            // weapon models point +x; the firing grip sits behind the centre, low on the model
            m.set(wpn).rotateY((float) Math.PI / 2f).scale(WEAPON_SCALE, WEAPON_SCALE, WEAPON_SCALE).translate(melee ? wm.sx * 0.32f : wm.sx * 0.16f, -wm.sy * 0.38f, 0);
            mr.draw(mr.mesh("w:" + a.weapon.visualKey(), wm, 1), m, light, 0xFFFFFFFF, 0);
        }
    }

    /**
     * Eye position for the first-person camera: the head bone of the evaluated pose (so the view
     * rides the real gait, crouch and step-ups) kept on the capsule axis. Writes {x, y, z}.
     */
    public void eye(Actor a, Look l, float aimPitch, float[] out) {
        Animator an = animator(a, l);
        an.pose(a, pose, aimPitch, null, true);
        basis(a, an, l.scale, 0);
        fk(pose, base, hips, bones);
        bones[HEAD].transformPoint(0, 5.3f, 0, v);
        out[0] = a.x;
        out[1] = Math.min(v[1], a.y + a.height() - 0.10f);
        out[2] = a.z;
    }

    /** World position of the muzzle of the held weapon for the last drawn/evaluated pose of this actor. */
    public void muzzle(Actor a, Look l, float aimPitch, float[] out) {
        Animator an = animator(a, l);
        grips(an, a.weapon);
        an.pose(a, pose, aimPitch, null, false);
        basis(a, an, l.scale, 0);
        fk(pose, base, hips, bones);
        an.aimFrame(pose, aimPitch, hips, aim);
        Animator.weaponFrame(pose, aim, wpn);
        float len = a.weapon == null ? 6 : ItemModels.of(a.weapon).sx * WEAPON_SCALE * 0.84f;
        wpn.transformPoint(0, 1, -len, out);
    }

    /** One arm part of a look, for the first-person viewmodel (same meshes as the body). */
    public void drawPart(Look l, int group, Mat4 model, float light) {
        CharModel cm = model(l);
        mr.draw(mr.meshAt(l.key + "#" + group, cm.groups[group], ORIGIN[group][0], ORIGIN[group][1], ORIGIN[group][2]), model, light, 0xFFFFFFFF, 0);
    }

    /** Voxel preview of a look for menus: front view, slowly turning. */
    public VoxModel flatten(Look l) {
        CharModel cm = model(l);
        VoxModel out = new VoxModel(26, 36, 14);
        int[][] off = new int[GROUPS][];
        // rest pose placement of each group's grid inside one model
        float[][] piv = new float[GROUPS][3];
        for (int g : ORDER) {
            float[] par = PARENT[g] < 0 ? new float[]{0, 0, 0} : piv[PARENT[g]];
            piv[g][0] = par[0] + PIVOT[g][0]; piv[g][1] = par[1] + PIVOT[g][1]; piv[g][2] = par[2] + PIVOT[g][2];
            off[g] = new int[]{Math.round(13 + piv[g][0] - ORIGIN[g][0]), Math.round(piv[g][1] - ORIGIN[g][1]), Math.round(7 + piv[g][2] - ORIGIN[g][2])};
        }
        for (int g = 0; g < GROUPS; g++) out.paste(cm.groups[g], off[g][0], off[g][1], off[g][2]);
        return out;
    }

    /** World light at a point for model shading (sky * daylight vs block light). */
    public static float lightAt(World w, float x, float y, float z, float daylight) {
        int ix = (int) Math.floor(x), iy = (int) Math.floor(y + 1), iz = (int) Math.floor(z);
        float s = (float) Math.pow(w.sky(ix, iy, iz) / 15f, 1.5) * daylight, b = (float) Math.pow(w.blockLight(ix, iy, iz) / 15f, 1.35);
        return Math.max(0.08f, Math.max(s * 0.95f + 0.06f, b * 1.1f));
    }

    /** Unused tint helper kept for callers that colour-code debug overlays. */
    public static int factionColor(String f) {
        return switch (f) { case "military" -> Tex.rgb(96, 130, 70); case "raiders" -> Tex.rgb(190, 70, 50); case "survivors" -> Tex.rgb(70, 120, 190); case "mercenaries" -> Tex.rgb(150, 150, 160); default -> Tex.rgb(170, 190, 90); };
    }
}
