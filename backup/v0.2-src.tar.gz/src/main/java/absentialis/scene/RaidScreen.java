package absentialis.scene;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;

import absentialis.character.Animator;
import absentialis.character.Anims;
import absentialis.character.Pose;
import absentialis.character.Rig;
import absentialis.engine.Input;
import absentialis.engine.math.Mat4;
import absentialis.engine.render.WorldRenderer;
import absentialis.engine.voxel.VoxModel;
import absentialis.entity.Actor;
import absentialis.entity.Physics;
import absentialis.gameplay.inventory.Container;
import absentialis.gameplay.inventory.InventoryService;
import absentialis.gameplay.inventory.Loadout;
import absentialis.gameplay.items.ItemDef;
import absentialis.gameplay.items.ItemInstance;
import absentialis.gameplay.weapons.Gunsmith;
import absentialis.gameplay.weapons.WeaponService;
import absentialis.ui.ItemModels;
import absentialis.ui.Ui;
import absentialis.world.Block;
import absentialis.world.District;
import absentialis.world.World;

/**
 * The raid as the player experiences it: input -> player body and weapon, camera, world and
 * model rendering, HUD and the in-raid overlays (inventory split view, weapon wheel, map,
 * pause). Simulation authority stays in {@link Raid}.
 */
public final class RaidScreen {
    private final Ctx c;
    public final Raid raid;
    private final Hud hud;
    private final WeaponWheel wheel;
    private final LoadoutPanel panel;
    private String heldSlot = "primary";
    // camera & feel
    private float bobAmt, lean, adsT, recoilPitch, recoilYaw, kick, switchT, shake, swayX, swayY, landDip, lastStepPhase, extractTick, stepGate;
    private ActorRenderer.Look playerLook;
    private final float[] eye = new float[3];
    private final Pose vmPose = new Pose(), vmBase = new Pose();
    /** Floor lookup for foot placement: the top of the first walkable block around the given height. */
    private final Animator.Ground ground = this::groundTop;

    private float groundTop(float x, float z, float y) {
        int ix = (int) Math.floor(x), iz = (int) Math.floor(z);
        for (int by = (int) Math.floor(y + 1.2f); by >= (int) Math.floor(y - 1.3f); by--) if (raid.world.solid(ix, by, iz) && !raid.world.solid(ix, by + 1, iz)) return by + 1;
        return Float.NaN;
    }
    public boolean thirdPerson;
    private final Mat4 proj = new Mat4(), view = new Mat4(), pv = new Mat4(), tmp = new Mat4();
    private float eyeX, eyeY, eyeZ, tpsDistance = 3.2f;
    // weapon timers
    private float fireTimer, reloadT, reloadMax, cycleT, lastShot = -9, lastRTime = -9, meleeT;
    private int shotIndex, burstLeft;
    private String reloadKind;
    private ItemInstance reloadMag;
    private boolean crouchToggle;
    // overlays
    public boolean invOpen, mapOpen, paused, done;
    private Container lootSide;
    private String lootTitle = "";
    private float inspectYaw, inspectPitch = 0.4f, mapZoom = 1;
    private final WorldRenderer.Env env = new WorldRenderer.Env();
    private absentialis.engine.audio.AudioEngine.Voice ambienceVoice;
    private String ambienceName;

    public RaidScreen(Ctx c, Raid raid) {
        this.c = c;
        this.raid = raid;
        hud = new Hud(c);
        wheel = new WeaponWheel(c);
        panel = new LoadoutPanel(c);
        panel.raid = raid;
        raid.listener = new Raid.Listener() {
            public void message(String text, int color) { hud.message(text, color, raid.time); }
            public void caption(String cat, float x, float z, float loud) {
                float ang = (float) Math.atan2(-(x - raid.player.x), -(z - raid.player.z)) - raid.player.yaw;
                hud.caption(cat, (float) Math.toDegrees(-ang), loud, raid.time);
                playWorldSound(cat, x, z, loud);
            }
            public void footstep(Actor a, String material, float speed) {
                if (c.audio == null || !c.audio.available) return;
                boolean giant = "tank".equals(a.archetype);
                float gain = Math.min(0.55f, 0.16f + speed * 0.06f) * (giant ? 0.3f : 1f) * (a.crouch ? 0.4f : 1f);
                c.audio.playAt("step_" + material, a.x, a.y + 0.1f, a.z, gain, giant ? 60 : 30, (giant ? 0.6f : a.infected() ? 0.85f : 1f) * (0.92f + raid.rng.nextFloat() * 0.16f));
            }
        };
        raid.weaponMastery = (w, xp) -> c.profile.prog.addMastery(w, xp);
        if (c.profile.loadout.slot("primary") == null) heldSlot = c.profile.loadout.slot("sidearm") != null ? "sidearm" : "melee";
        c.win.setCursorLocked(true);
        raid.player.weapon = held();
        if (raid.player.anim == null) raid.player.anim = new Animator();
        raid.player.anim.play("equip", 0.45f);
        if (held() != null) c.sfx(equipSound(held()), 0.5f);
        hud.message("Deployed at " + raid.insertion.name + " (" + raid.debrief.deployedIn.display + "). Find an exit before the window closes.", Ui.AMBER, 0);
        hud.message("[I] inventory  [Tab] weapon wheel  [M] map  [F] interact  [V] view  [~] console", Ui.TXT_DIM, 0);
    }

    private void playWorldSound(String cat, float x, float z, float loud) {
        if (c.audio == null || !c.audio.available) return;
        String s = switch (cat) {
            case "shot" -> loud < 0.3f ? "shot_distant" : "shot_rifle"; case "shot_suppressed" -> "shot_suppressed"; case "explosion" -> loud < 0.3f ? "explosion_far" : "explosion";
            case "glass_break" -> "glass_break"; case "groan" -> "groan"; case "screech" -> "screech"; case "shriek" -> "shriek"; case "gurgle" -> "gurgle"; case "retch" -> "retch"; case "roar" -> "roar";
            case "splash" -> "splash"; case "stomp" -> "stomp"; case "shout" -> "shout"; case "whistle" -> "whistle"; case "radio_chatter" -> "radio"; case "search" -> "search";
            case "door_open" -> "door_open"; case "door_close" -> "door_close"; case "impact" -> "impact_concrete"; case "melee" -> "melee_hit"; case "alarm_clock" -> "beep";
            case "flare" -> "flare"; case "reload" -> "mag_in"; case "bounce" -> "bounce"; case "debris" -> "impact_wood";
            default -> null;
        };
        boolean voice = cat.equals("shout") || cat.equals("groan") || cat.equals("screech") || cat.equals("shriek") || cat.equals("roar") || cat.equals("retch") || cat.equals("gurgle") || cat.equals("radio_chatter") || cat.equals("whistle");
        if (s != null) c.audio.playAt(s, x, raid.player.y + 1, z, 0.9f, 300, voice ? 0.94f + raid.rng.nextFloat() * 0.12f : 1, voice ? absentialis.engine.audio.AudioEngine.VOICE : absentialis.engine.audio.AudioEngine.SFX);
    }

    private ItemInstance held() { return c.profile.loadout.slot(heldSlot); }
    private Loadout lo() { return c.profile.loadout; }
    private boolean overlay() { return invOpen || mapOpen || paused || c.console.open; }

    // ================================================================== update
    public void update(float dt) {
        Input in = c.in;
        if (raid.debrief.outcome != Raid.Debrief.Outcome.NONE) { done = true; return; }
        boolean consoleWas = c.console.open;
        if (in.keyPressed(GLFW_KEY_GRAVE_ACCENT)) c.console.toggle();
        if (c.console.input(in)) { c.win.setCursorLocked(false); if (!consoleWas) in.typed.clear(); raid.update(dt * 0.0f); return; }
        // overlays
        if (in.keyPressed(GLFW_KEY_ESCAPE)) {
            if (c.inv.drag != null) c.inv.drag = null;
            else if (invOpen) closeInventory();
            else if (mapOpen) mapOpen = false;
            else paused = !paused;
        }
        if (!paused && in.pressed("inventory")) { if (invOpen) closeInventory(); else openInventory(null, ""); }
        if (!paused && !invOpen && in.pressed("map")) mapOpen = !mapOpen;
        boolean wheelKey = in.down("wheel") && !overlay();
        if (wheelKey && !wheel.open) wheel.openWheel();
        if (!wheelKey && wheel.open) { wheel.open = false; commitWheel(); }
        c.win.setCursorLocked(!invOpen && !paused && !mapOpen);
        if (paused) return;
        float simDt = wheel.open ? dt * 0.3f : dt; // SP slow-time while choosing
        if (wheel.open) wheel.update((float) in.dx, (float) in.dy);
        else if (!invOpen && !mapOpen) look(in);
        if (!invOpen && !mapOpen) controls(in, simDt);
        else { raid.player.vx *= 0.8f; raid.player.vz *= 0.8f; }
        movePlayer(simDt);
        raid.update(simDt);
        footfalls();
        music(dt);
        weaponTimers(simDt);
        useTimer(simDt);
        // extraction countdown: one tick per second, rising toward departure
        if (raid.extracting != null && raid.extractProgress > 0) {
            if ((int) raid.extractProgress != (int) extractTick) c.sfx("extract_tick", 0.5f, 0.8f + raid.extractProgress * 0.06f);
            extractTick = raid.extractProgress;
        } else extractTick = 0;
        if (invOpen && in.keyDown(GLFW_KEY_F) && c.inv.inspected != null) { inspectYaw += (float) in.dx * 0.01f; inspectPitch = Math.max(-1.2f, Math.min(1.2f, inspectPitch + (float) in.dy * 0.01f)); }
        if (mapOpen) mapZoom = Math.max(0.6f, Math.min(4f, mapZoom * (1 + (float) in.scroll * 0.12f)));
        // audio listener + ambience bed per district
        if (c.audio != null) {
            c.audio.lx = raid.player.x; c.audio.ly = raid.player.eyeY(); c.audio.lz = raid.player.z; c.audio.lyaw = raid.player.yaw;
            String amb = "amb_" + (raid.player.y < World.GROUND - 3 ? "interior" : raid.profile.zone.weatherRain > 0.5f ? "rain" : ambienceFor(raid.world.district(raid.player.x, raid.player.z)));
            if (!amb.equals(ambienceName)) { if (ambienceVoice != null) ambienceVoice.fadeTo(0, 2); ambienceVoice = c.audio.loop(amb, 0.5f, true); ambienceName = amb; }
        }
    }

    private absentialis.engine.audio.AudioEngine.Voice tensionVoice;
    private float tension;

    /** Combat music: fades in while something hostile is actively engaging the player, out again afterwards. */
    private void music(float dt) {
        if (c.audio == null || !c.audio.available) return;
        if (tensionVoice == null) { tensionVoice = c.audio.loop("music_tension", 0f, absentialis.engine.audio.AudioEngine.MUSIC); }
        boolean hot = false;
        for (Actor a : raid.actors) if (!a.isPlayer && !a.dead && "engage".equals(a.state) && a.targetId == raid.player.id && a.distXZ(raid.player.x, raid.player.z) < 70) { hot = true; break; }
        tension += ((hot ? 0.6f : 0f) - tension) * Math.min(1, dt * (hot ? 1.2f : 0.25f));
        tensionVoice.setGain(tension);
    }

    private static String ambienceFor(District d) { return switch (d.ambience) { case "bells" -> "bells"; case "machines" -> "machines"; case "drone" -> "drone"; case "city" -> "city"; default -> "wind"; }; }

    public void stopAudio() { if (ambienceVoice != null) ambienceVoice.fadeTo(0, 1); if (tensionVoice != null) tensionVoice.fadeTo(0, 1); }

    private void look(Input in) {
        Actor p = raid.player;
        float sens = c.settings.sensitivity * 0.01f * (adsT > 0.5f ? 1f / Math.max(1, zoom()) : 1);
        p.yaw -= (float) in.dx * sens;
        p.pitch = Math.max(-1.5f, Math.min(1.5f, p.pitch - (float) in.dy * sens));
    }

    private float zoom() { ItemInstance h = held(); return h == null ? 1 : h.zoom(); }

    private void controls(Input in, float dt) {
        Actor p = raid.player;
        if (in.pressed("view")) thirdPerson = !thirdPerson;
        if (in.pressed("flashlight")) raid.playerFlashlight = !raid.playerFlashlight;
        if (c.settings.toggleCrouch) { if (in.pressed("crouch")) crouchToggle = !crouchToggle; p.crouch = crouchToggle; }
        else p.crouch = in.down("crouch");
        if (p.crouch == false && !Physics.boxFree(raid.world, p.x, p.y, p.z, p.radius, p.stand)) p.crouch = true;
        float tl = in.down("lean_left") ? -1 : in.down("lean_right") ? 1 : 0;
        lean += (tl - lean) * Math.min(1, dt * 10);
        // weapon selection
        if (in.pressed("primary")) switchTo("primary");
        if (in.pressed("sidearm")) switchTo("sidearm");
        if (in.pressed("melee")) switchTo("melee");
        for (int k = 0; k < 4; k++) if (in.pressed("quick" + (k + 1))) { ItemInstance[] s = wheel.slots(lo()); if (s[4 + k] != null) useItem(s[4 + k]); }
        if (in.pressed("throw")) { ItemInstance[] s = wheel.slots(lo()); if (s[3] != null) throwIt(s[3]); }
        if (in.pressed("firemode")) { ItemInstance h = held(); if (h != null && h.def().weapon != null && h.def().weapon.modes.size() > 1) { h.fireMode = (h.fireMode + 1) % h.def().weapon.modes.size(); c.sfx("ui_click", 0.4f); hud.message("Fire mode: " + h.fireModeName().toUpperCase(), Ui.TXT, raid.time); } }
        if (in.pressed("reload")) reload();
        if (in.pressed("interact")) interact();
        if (in.pressed("jump") && p.onGround && !p.crouch && raid.body.stamina > 5) { p.vy = 7.2f; raid.body.stamina -= 4; c.sfx("jump", 0.35f); }
        // ADS
        boolean aim = c.settings.toggleAim ? (in.pressed("aim") ? adsT < 0.5f : adsT > 0.5f) : in.down("aim");
        ItemInstance h = held();
        boolean canAim = h != null && h.def().weapon != null && !h.def().weapon.melee() && reloadT <= 0 && !p.sprinting;
        float adsSpeed = h != null && h.def().weapon != null && !h.def().weapon.melee() ? 1f / Gunsmith.stats(h, 0).adsTime : 8;
        adsT += ((aim && canAim ? 1 : 0) - adsT) * Math.min(1, dt * adsSpeed);
        raid.playerAiming = adsT > 0.6f;
        fire(in, dt);
    }

    private void movePlayer(float dt) {
        Actor p = raid.player;
        Input in = c.in;
        boolean ctl = !overlay();
        float f = ctl ? (in.down("forward") ? 1 : 0) - (in.down("back") ? 1 : 0) : 0;
        float s = ctl ? (in.down("right") ? 1 : 0) - (in.down("left") ? 1 : 0) : 0;
        boolean moving = f != 0 || s != 0;
        p.sprinting = ctl && in.down("sprint") && f > 0 && !p.crouch && adsT < 0.3f && raid.body.canSprint();
        ItemInstance h = held();
        float wMass = h == null ? 0 : h.mass();
        float speed = raid.body.moveSpeed(p, p.sprinting, ctl && in.down("walk"), lo().mass(), c.profile.prog.carryCapacityKg(), wMass);
        if (adsT > 0.5f) speed *= 0.6f;
        if (raid.body.using != null) speed *= 0.5f;
        if (raid.noclip) {
            float fx = (float) (-Math.sin(p.yaw) * Math.cos(p.pitch)), fy = (float) Math.sin(p.pitch), fz = (float) (-Math.cos(p.yaw) * Math.cos(p.pitch));
            float sp = (in.down("sprint") ? 40 : 14) * dt;
            p.x += (fx * f + (float) Math.cos(p.yaw) * s) * sp; p.y += fy * f * sp + (in.down("jump") ? sp : 0) - (in.down("crouch") ? sp : 0); p.z += (fz * f - (float) Math.sin(p.yaw) * s) * sp;
            p.vx = p.vy = p.vz = 0;
            return;
        }
        float fx = (float) -Math.sin(p.yaw), fz = (float) -Math.cos(p.yaw), rx = (float) Math.cos(p.yaw), rz = (float) -Math.sin(p.yaw);
        float tx = (fx * f + rx * s), tz = (fz * f + rz * s);
        float l = (float) Math.sqrt(tx * tx + tz * tz);
        if (l > 0) { tx = tx / l * speed; tz = tz / l * speed; }
        float acc = p.onGround ? 14 : 3;
        p.vx += (tx - p.vx) * Math.min(1, dt * acc);
        p.vz += (tz - p.vz) * Math.min(1, dt * acc);
        p.wantClimb = ctl && f > 0 && Physics.inClimb(raid.world, p.x, p.y, p.z);
        p.climbDir = p.pitch < -0.35f ? -1 : 1;
        Physics.move(raid.world, p, dt);
        // fall damage
        if (p.onGround && p.fallSpeed > 13) { float dmg = (p.fallSpeed - 13) * 6; raid.damageActor(p, null, dmg, null, "legs", p.x, p.y, p.z); if (dmg > 20) raid.body.fracture = true; hud.message("Hard landing", Ui.RED, raid.time); }
        if (p.onGround && p.fallSpeed > 5) { landDip = Math.min(0.22f, p.fallSpeed * 0.012f); playStep(0.5f + Math.min(0.4f, p.fallSpeed * 0.03f), 0.85f); }
        p.fallSpeed = 0;
        p.stepped = 0;
        landDip = Math.max(0, landDip - dt * 0.9f);
        float hs = (float) Math.sqrt(p.vx * p.vx + p.vz * p.vz);
        bobAmt += ((p.onGround && moving ? Math.min(1, hs / 4f) : 0) - bobAmt) * Math.min(1, dt * 8);
    }

    /** Footstep material under the player: water when wading, otherwise the block's material. */
    private String stepMaterial() {
        Actor p = raid.player;
        Block in = raid.world.block((int) Math.floor(p.x), (int) Math.floor(p.y + 0.2f), (int) Math.floor(p.z));
        if (in != null && in.mat == absentialis.world.Material.WATER) return "water";
        Block under = raid.world.block((int) Math.floor(p.x), (int) Math.floor(p.y - 0.1f), (int) Math.floor(p.z));
        return under == null ? "concrete" : under.mat.stepSound;
    }

    private void playStep(float gain, float pitch) {
        String mat = stepMaterial();
        if (c.audio != null && !"none".equals(mat)) c.audio.play("step_" + mat, gain, (raid.rng.nextFloat() - 0.5f) * 0.3f, pitch * (0.92f + raid.rng.nextFloat() * 0.16f));
    }

    /** One footstep per animated footfall (each half gait cycle): what you hear is what the legs do. */
    private void footfalls() {
        Actor p = raid.player;
        Animator an = p.anim;
        if (an == null) return;
        float ph = an.phase;
        boolean crossed = (lastStepPhase < 0.5f) != (ph < 0.5f);
        lastStepPhase = ph;
        stepGate -= c.ui.dt;
        if (!crossed || !p.onGround || an.speed < 0.5f || stepGate > 0 || p.climbing) return;
        stepGate = 0.14f;
        Block under = raid.world.block((int) Math.floor(p.x), (int) Math.floor(p.y - 0.1f), (int) Math.floor(p.z));
        boolean walk = c.in.down("walk");
        float radius = (p.crouch ? 2.5f : p.sprinting ? 20 : walk ? 4 : 9) * (under == null ? 1 : under.mat.noiseMul) * (1 + lo().charm("noise")) * (1 + Math.max(0, lo().mass() - c.profile.prog.carryCapacityKg()) * 0.02f);
        raid.emitSound(p.x, p.y, p.z, radius, "step", p.id, false);
        playStep(p.crouch ? 0.15f : p.sprinting ? 0.5f : walk ? 0.2f : 0.32f, 1f);
        // loose kit rattles when you run with a heavy pack
        if (p.sprinting && lo().mass() > 14 && raid.rng.chance(0.5)) c.sfx("gear_rattle", 0.12f);
    }

    // ------------------------------------------------------------------ weapons
    private void switchTo(String slot) {
        if (slot.equals(heldSlot) || lo().slot(slot) == null) return;
        heldSlot = slot;
        cancelReload();
        switchT = 0.45f;
        adsT = 0;
        c.sfx(equipSound(held()), 0.5f);
        raid.player.weapon = held();
        raid.player.anim.play("equip", 0.45f);
    }

    private static String equipSound(ItemInstance w) {
        if (w == null || w.def().weapon == null) return "zipper";
        return w.def().weapon.melee() ? "equip_melee" : "sidearm".equals(w.def().slot) ? "equip_pistol" : "equip_rifle";
    }

    private void cancelReload() {
        if (reloadT > 0 && raid.player.anim != null && raid.player.anim.action.startsWith("reload")) raid.player.anim.action = "";
        reloadT = 0; reloadKind = null; reloadMag = null;
    }

    private boolean reloadEmpty;
    private int reloadCue;

    /** Reload foley keyed to the animation: tactical and empty reloads sound as different as they look. */
    private void reloadFoley(float t) {
        if (reloadKind == null) return;
        float[] at; String[] snd;
        switch (reloadKind) {
            case "jam", "rack" -> { at = new float[]{0.42f, 0.60f}; snd = new String[]{"bolt_back", "bolt_release"}; }
            case "internal" -> { at = new float[]{0.80f}; snd = new String[]{"shell_in"}; }
            default -> {
                if (reloadEmpty) { at = new float[]{0.16f, 0.26f, 0.64f, 0.80f, 0.88f}; snd = new String[]{"mag_out", "mag_drop", "mag_in", "bolt_back", "bolt_release"}; }
                else { at = new float[]{0.20f, 0.50f, 0.82f}; snd = new String[]{"mag_out", "pouch", "mag_in"}; }
            }
        }
        while (reloadCue < at.length && t >= at[reloadCue]) { c.sfx(snd[reloadCue], 0.6f); reloadCue++; }
    }

    private void fire(Input in, float dt) {
        ItemInstance h = held();
        raid.player.weapon = h;
        if (h == null || switchT > 0 || raid.body.using != null) return;
        ItemDef.Weapon w = h.def().weapon;
        if (w == null) return;
        boolean press = in.pressed("fire"), down = in.down("fire");
        if (w.melee()) { if (press && meleeT <= 0) melee(h); return; }
        if (reloadT > 0) {
            if (press && "internal".equals(reloadKind)) cancelReload(); // interrupt shell-by-shell loading
            return;
        }
        String mode = h.fireModeName();
        boolean want = switch (mode) { case "auto" -> down; case "burst" -> press || burstLeft > 0; default -> press; };
        if (!want || fireTimer > 0 || cycleT > 0) return;
        if (h.jammed) { if (press) { c.sfx("jam", 0.6f); hud.message("Weapon jammed - press [R] to clear", Ui.RED, raid.time); } burstLeft = 0; return; }
        if (!WeaponService.canFire(h)) {
            if (press) { c.sfx("dry_fire", 0.6f); hud.ammoShown = raid.time; if (!w.internal() && h.mag != null && h.mag.rounds > 0 && !h.chambered) hud.message("Chamber empty - reload to rack", Ui.AMBER, raid.time); }
            burstLeft = 0;
            return;
        }
        Gunsmith.Stats st = Gunsmith.stats(h, lo().charm("wear"));
        ItemDef ammo = WeaponService.fire(h, st, raid.environmentWear(), raid.rng);
        if (ammo == null) return;
        if ("burst".equals(mode)) burstLeft = burstLeft > 0 ? burstLeft - 1 : 2;
        Actor p = raid.player;
        float pitch = p.pitch + recoilPitch, yaw = p.yaw + recoilYaw;
        float dx = (float) (-Math.sin(yaw) * Math.cos(pitch)), dy = (float) Math.sin(pitch), dz = (float) (-Math.cos(yaw) * Math.cos(pitch));
        boolean moving = Math.abs(p.vx) + Math.abs(p.vz) > 0.5f;
        float spread = st.dispersion * (0.35f + (1 - adsT) * 1.6f) * (moving ? 1.6f : 1) * (p.crouch ? 0.8f : 1) * (p.onGround ? 1 : 2.5f);
        raid.fireProjectiles(p, h, ammo, eyeX + dx * 0.4f, eyeY + dy * 0.4f, eyeZ + dz * 0.4f, dx, dy, dz, spread);
        raid.shotSignature(p, h, st, p.x, p.eyeY(), p.z);
        // recoil: per-platform pattern scaled by focus (recoil control) and ADS
        if (raid.time - lastShot > Gunsmith.recoveryTime(st) + 0.1f) shotIndex = 0;
        float[] k = Gunsmith.recoilKick(h.def(), shotIndex++);
        float mul = raid.body.recoilMul() * (adsT > 0.5f ? 0.75f : 1f) * (p.crouch ? 0.85f : 1f);
        p.pitch = Math.min(1.5f, p.pitch + (float) Math.toRadians(k[0] * 0.55f * mul));
        p.yaw -= (float) Math.toRadians(k[1] * 0.55f * mul);
        recoilPitch += (float) Math.toRadians(k[0] * 0.35f * mul);
        kick = Math.min(1, kick + 0.35f + w.recoilV * 0.05f);
        raid.body.focus = Math.max(0, raid.body.focus - w.recoilV * 0.8f);
        raid.body.focusChanged = raid.time;
        lastShot = raid.time;
        fireTimer = 60f / st.rpm;
        if ("bolt".equals(mode) || "pump".equals(mode)) cycleT = 60f / st.rpm;
        raid.muzzleFlash = st.suppressed ? 0.3f : 1;
        p.anim.fire();
        hud.ammoShown = raid.time;
        if (c.audio != null) c.audio.play(st.suppressed ? "shot_suppressed" : w.sound, 0.9f, 0, 0.95f + raid.rng.nextFloat() * 0.1f);
        if ("bolt".equals(mode)) c.sfx("bolt", 0.5f);
        if ("pump".equals(mode)) c.sfx("pump", 0.5f);
        if (h.jammed) { c.sfx("jam", 0.7f); hud.message("Jammed! (condition " + Math.round(h.condition()) + ") [R] to clear", Ui.RED, raid.time); }
        if (h.condition() < 25 && raid.rng.chance(0.05)) hud.message("Weapon is in critical condition - it needs a workbench", Ui.AMBER, raid.time);
    }

    private void melee(ItemInstance h) {
        meleeT = 60f / h.def().weapon.rpm;
        c.sfx("melee_swing", 0.6f);
        raid.player.anim.play("melee", Math.min(0.5f, meleeT));
        Actor p = raid.player;
        float fx = (float) -Math.sin(p.yaw), fz = (float) -Math.cos(p.yaw);
        Actor best = null; float bd = h.def().weapon.meleeRange + 0.4f;
        for (Actor a : raid.nearby(p.x, p.z, 4)) {
            if (a.isPlayer || a.dead) continue;
            float dx = a.x - p.x, dz = a.z - p.z, d = (float) Math.sqrt(dx * dx + dz * dz);
            if (d < bd && (dx * fx + dz * fz) / Math.max(0.01f, d) > 0.6f) { bd = d; best = a; }
        }
        if (best != null) {
            boolean sneak = !"engage".equals(best.state);
            float dmg = h.def().weapon.meleeDamage * (sneak ? 2.5f : 1);
            raid.damageActor(best, p, dmg, null, sneak && best.infected() ? "head" : "torso", best.x, best.y + 1.4f, best.z);
            c.sfx("melee_hit", 0.7f);
            raid.emitSound(p.x, p.y, p.z, h.def().weapon.noise, "melee", p.id, false);
            return;
        }
        int[] hit = Physics.ray(raid.world, eyeX, eyeY, eyeZ, fx * (float) Math.cos(p.pitch), (float) Math.sin(p.pitch), fz * (float) Math.cos(p.pitch), 2.2f, false);
        if (hit != null) { raid.damageBlock(hit[0], hit[1], hit[2], h.def().weapon.meleeDamage * ("melee.crowbar".equals(h.defId) ? 2 : 0.5f), p.id); c.sfx("impact_wood", 0.5f); }
    }

    private void reload() {
        ItemInstance h = held();
        if (h == null || h.def().weapon == null || h.def().weapon.melee() || reloadT > 0) return;
        ItemDef.Weapon w = h.def().weapon;
        if (h.jammed) { reloadKind = "jam"; reloadT = reloadMax = 1.2f; reloadCue = 0; raid.player.anim.play("clear_jam", 1.2f); return; }
        if (w.internal()) {
            if (h.rounds >= w.capacity) return;
            if (findAmmo(w.caliber, h.rounds > 0 ? h.ammoId : null) == null) { hud.message("No " + w.caliber + " rounds in the case", Ui.RED, raid.time); return; }
            reloadKind = "internal"; reloadT = reloadMax = Gunsmith.stats(h, 0).reloadTime; reloadCue = 0;
            raid.player.anim.play("reload_shell", reloadMax);
            return;
        }
        boolean speed = raid.time - lastRTime < 0.35f;
        lastRTime = raid.time;
        ItemInstance best = null;
        for (ItemInstance i : lo().caseGrid.items) if (i.def().magazine != null && i.def().magazine.magType.equals(w.magType) && i.rounds > 0 && (best == null || i.rounds > best.rounds)) best = i;
        if (best == null) {
            if (!h.chambered && h.mag != null && h.mag.rounds > 0) { reloadKind = "rack"; reloadT = reloadMax = 0.6f; reloadCue = 0; raid.player.anim.play("clear_jam", 0.6f); return; }
            hud.message("No loaded " + w.magType.toUpperCase() + " magazines - load one in the inventory", Ui.RED, raid.time);
            return;
        }
        if (h.mag != null && h.mag.rounds >= best.rounds && h.chambered) { hud.message("Current magazine is fuller", Ui.TXT_DIM, raid.time); return; }
        reloadMag = best;
        reloadKind = speed ? "speed" : "mag";
        reloadEmpty = !h.chambered;
        reloadCue = 0;
        reloadT = reloadMax = Gunsmith.stats(h, 0).reloadTime * (h.chambered ? 0.8f : 1.15f) * (speed ? 0.75f : 1);
        // bullets fired decide the animation: a round still chambered = tactical, run dry = full reload with a rack
        raid.player.anim.play(reloadEmpty ? "reload_empty" : "reload_tac", reloadMax);
        hud.ammoShown = raid.time;
        hud.message(h.chambered ? "Tactical reload (round kept in chamber)" + (speed ? " - dropping mag" : "") : "Empty reload - racking the action", Ui.TXT_DIM, raid.time);
    }

    private ItemInstance findAmmo(String caliber, String prefer) {
        ItemInstance best = null;
        for (ItemInstance i : lo().caseGrid.items) if (i.def().ammo != null && i.def().ammo.caliber.equals(caliber) && (prefer == null || prefer.equals(i.defId))) { best = i; break; }
        return best;
    }

    private void weaponTimers(float dt) {
        fireTimer -= dt; cycleT -= dt; switchT -= dt; meleeT -= dt;
        kick = Math.max(0, kick - dt * 6);
        recoilPitch *= Math.max(0, 1 - dt * 9);
        recoilYaw *= Math.max(0, 1 - dt * 9);
        if (reloadT <= 0) return;
        ItemInstance h = held();
        if (h == null) { cancelReload(); return; }
        reloadT -= dt;
        hud.ammoShown = raid.time;
        reloadFoley(1 - Math.max(0, reloadT) / Math.max(0.01f, reloadMax));
        if (reloadT > 0) return;
        switch (reloadKind) {
            case "jam" -> { WeaponService.clearJam(h); hud.message("Jam cleared", Ui.TXT, raid.time); }
            case "rack" -> WeaponService.chamberFromMag(h);
            case "internal" -> {
                ItemInstance ammo = findAmmo(h.def().weapon.caliber, h.rounds > 0 ? h.ammoId : null);
                if (ammo != null && WeaponService.loadOne(h, ammo)) {
                    if (h.rounds < h.def().weapon.capacity && findAmmo(h.def().weapon.caliber, h.ammoId) != null) { reloadT = reloadMax; reloadCue = 0; raid.player.anim.play("reload_shell", reloadMax); return; }
                }
            }
            default -> {
                if (reloadMag != null && reloadMag.container == lo().caseGrid) {
                    WeaponService.Reload r = WeaponService.reloadMag(h, reloadMag, lo().caseGrid, 0, "speed".equals(reloadKind));
                    if (r.oldMag() != null) { raid.dropItem(r.oldMag(), raid.player.x, raid.player.y + 0.3f, raid.player.z); hud.message("Dropped magazine (" + r.oldMag().rounds + " rds) - it's on the ground", Ui.TXT_DIM, raid.time); }
                }
            }
        }
        cancelReload();
    }

    // ------------------------------------------------------------------ items
    private void useItem(ItemInstance it) {
        if (it.def().throwable != null) { throwIt(it); return; }
        String r = panel.act(c.profile, it, "use", lo().caseGrid);
        if (r != null) hud.message(r, Ui.TXT, raid.time);
        if (raid.body.using != null) raid.player.anim.play("heal", Math.max(0.6f, raid.body.useTimer));
    }

    private void useTimer(float dt) {
        if (raid.body.using == null) return;
        raid.body.useTimer -= dt;
        if (raid.body.useTimer > 0) return;
        ItemInstance it = panel.pendingUse;
        if (it != null && (it.container != null || it.slot != null)) {
            String r = raid.body.apply(raid.player, it.def());
            LoadoutPanel.consumeOne(it);
            c.sfx(it.def().food != null ? (it.def().food.hydration > it.def().food.energy ? "drink" : "eat") : it.def().medical.heal > 30 ? "injector" : "bandage", 0.6f);
            hud.message(it.def().name + ": " + r, Ui.GREEN, raid.time);
        }
        raid.body.using = null;
        panel.pendingUse = null;
    }

    private void throwIt(ItemInstance it) {
        Actor p = raid.player;
        float dx = (float) (-Math.sin(p.yaw) * Math.cos(p.pitch)), dy = (float) Math.sin(p.pitch), dz = (float) (-Math.cos(p.yaw) * Math.cos(p.pitch));
        ItemInstance one = it;
        InventoryService.consume(it, 1);
        raid.throwItem(one, dx, dy, dz);
        raid.player.anim.play("throw", 0.6f);
        c.sfx("melee_swing", 0.4f);
        hud.message("Threw " + it.def().name, Ui.TXT_DIM, raid.time);
    }

    private void commitWheel() {
        int s = wheel.selected;
        if (s < 0) return;
        ItemInstance[] slots = wheel.slots(lo());
        if (slots[s] == null) return;
        switch (s) {
            case 0 -> switchTo("primary");
            case 1 -> switchTo("sidearm");
            case 2 -> switchTo("melee");
            case 3 -> throwIt(slots[3]);
            default -> useItem(slots[s]);
        }
    }

    /** What [F] would do right now (for the HUD prompt). */
    private String interactPrompt() {
        Actor p = raid.player;
        if (raid.extortion() != null) return "[F] Pay " + Raid.EXTORT_PRICE + " scrip   -   or raise your weapon";
        if (raid.lonerInNeed(2.6f) != null) return "[F] Give a bandage";
        Raid.WorldItem wi = raid.nearestItem(p.x, p.y + 0.3f, p.z, 1.8f);
        if (wi != null) return "[F] Pick up " + wi.it.name();
        Actor corpse = raid.nearestCorpse(p.x, p.z, 1.8f);
        if (corpse != null) return "[F] Search " + corpse.corpse.label;
        int[] hit = rayInteract();
        if (hit != null) {
            Block b = raid.world.block(hit[0], hit[1], hit[2]);
            if (b.is(Block.DOOR)) return b.solid() ? "[F] Open door" : "[F] Close door";
            if (b.is(Block.CONTAINER)) return "[F] Search " + b.name.replace('_', ' ');
            if (b.id == Block.TRANSFORMER) return "[F] Repair substation (2x Electrical Parts)";
            if (b.id == Block.BARRICADE) return "Barricade - break it with a crowbar or explosives";
        }
        return null;
    }

    private int[] rayInteract() {
        Actor p = raid.player;
        float dx = (float) (-Math.sin(p.yaw) * Math.cos(p.pitch)), dy = (float) Math.sin(p.pitch), dz = (float) (-Math.cos(p.yaw) * Math.cos(p.pitch));
        return Physics.ray(raid.world, eyeX, eyeY, eyeZ, dx, dy, dz, 3.0f, true);
    }

    private void interact() {
        Actor p = raid.player;
        p.anim.play("interact", 0.7f);
        if (raid.extortion() != null) { String r = raid.payExtortion(); hud.message(r, r.startsWith("Paid") ? Ui.AMBER : Ui.RED, raid.time); c.sfx(r.startsWith("Paid") ? "ui_buy" : "ui_error", 0.5f); return; }
        Actor needy = raid.lonerInNeed(2.6f);
        if (needy != null) { String r = raid.helpLoner(needy); hud.message(r, r.startsWith("You have") ? Ui.RED : Ui.GREEN, raid.time); c.sfx("bandage", 0.5f); return; }
        Raid.WorldItem wi = raid.nearestItem(p.x, p.y + 0.3f, p.z, 1.8f);
        if (wi != null) {
            InventoryService.Result r = InventoryService.store(wi.it, lo());
            if (r.ok()) { raid.items.remove(wi); c.sfx("pickup", 0.5f); hud.message("Picked up " + wi.it.name(), Ui.TXT, raid.time); }
            else hud.message(r.msg(), Ui.RED, raid.time);
            return;
        }
        Actor corpse = raid.nearestCorpse(p.x, p.z, 1.8f);
        if (corpse != null) { openInventory(corpse.corpse, corpse.corpse.label); return; }
        int[] hit = rayInteract();
        if (hit == null) return;
        Block b = raid.world.block(hit[0], hit[1], hit[2]);
        if (b.is(Block.DOOR)) raid.toggleDoor(hit[0], hit[1], hit[2]);
        else if (b.is(Block.CONTAINER)) { Container box = raid.openContainer(hit[0], hit[1], hit[2]); openInventory(box, box.label); if (c.audio != null) c.audio.playAt("search", hit[0] + 0.5f, hit[1] + 0.5f, hit[2] + 0.5f, 0.6f, 20, 1); }
        else if (b.id == Block.TRANSFORMER) hud.message(raid.repairSite(hit[0], hit[1], hit[2]), Ui.AMBER, raid.time);
    }

    /** Automation: opens the nearest searchable container within r blocks. */
    public boolean debugOpenNearestContainer(int r) {
        Actor p = raid.player;
        int px = (int) p.x, py = (int) p.y, pz = (int) p.z;
        for (int d = 1; d <= r; d++) for (int x = px - d; x <= px + d; x++) for (int z = pz - d; z <= pz + d; z++) for (int y = py - 2; y <= py + 3; y++) {
            Block b = raid.world.block(x, y, z);
            if (b != null && b.is(Block.CONTAINER)) { Container box = raid.openContainer(x, y, z); openInventory(box, box.label); return true; }
        }
        return false;
    }

    private void openInventory(Container loot, String title) {
        invOpen = true;
        lootSide = loot;
        lootTitle = title;
        c.inv.quickA = loot;
        c.inv.quickB = lo().caseGrid;
        if (held() != null) c.inv.inspected = held();
        c.inv.owner = lo();
        c.inv.allowDrop = true;
        c.inv.extraActions.clear();
        c.inv.extraActions.add("quick");
        c.inv.onAction = (it, act) -> { String r = panel.act(c.profile, it, act, lootSide); if (r != null) { c.inv.say(r, Ui.TXT); if (act.equals("use")) closeInventory(); } };
        c.sfx("zipper", 0.4f);
    }

    private void closeInventory() {
        invOpen = false;
        c.inv.drag = null;
        c.inv.menu.clear();
        raid.applyArmor();
        raid.player.weapon = held();
        if (held() == null) for (String s : new String[]{"primary", "sidearm", "melee"}) if (lo().slot(s) != null) { heldSlot = s; break; }
    }

    // ================================================================== render
    public void render(float dt) {
        Actor p = raid.player;
        int W = c.win.width, H = c.win.height;
        glViewport(0, 0, W, H);
        // camera: first person rides the head bone of the animated body (gait, crouch, step-ups, landings)
        playerLook = ActorRenderer.playerLook(c.profile, playerLook);
        shake = Math.max(shake * Math.max(0, 1 - dt * 5), raid.damageShake * c.settings.shake);
        c.ar.eye(p, playerLook, p.pitch, eye);
        float rx = (float) Math.cos(p.yaw), rz = (float) -Math.sin(p.yaw);
        eyeX = eye[0] + rx * lean * 0.45f;
        eyeY = eye[1] - landDip;
        eyeZ = eye[2] + rz * lean * 0.45f;
        float yaw = p.yaw + (raid.rng.nextFloat() - 0.5f) * shake * 0.02f, pitch = p.pitch + (raid.rng.nextFloat() - 0.5f) * shake * 0.02f;
        float cx = eyeX, cy = eyeY, cz = eyeZ;
        float fx = (float) (-Math.sin(yaw) * Math.cos(pitch)), fy = (float) Math.sin(pitch), fz = (float) (-Math.cos(yaw) * Math.cos(pitch));
        if (thirdPerson) {
            // over-the-shoulder boom, pulled in when geometry is in the way
            float d = 3.2f;
            float bx = -fx + rx * 0.25f, by = -fy + 0.08f, bz = -fz + rz * 0.25f, bl = (float) Math.sqrt(bx * bx + by * by + bz * bz);
            int[] hit = Physics.ray(raid.world, eyeX, eyeY, eyeZ, bx / bl, by / bl, bz / bl, d + 0.4f, false);
            if (hit != null) {
                float hx = hit[0] + 0.5f - eyeX, hy = hit[1] + 0.5f - eyeY, hz = hit[2] + 0.5f - eyeZ;
                d = Math.max(0.35f, Math.min(d, (float) Math.sqrt(hx * hx + hy * hy + hz * hz) - 0.95f));
            }
            tpsDistance += (d - tpsDistance) * Math.min(1, dt * (d < tpsDistance ? 30 : 6));
            cx = eyeX - fx * tpsDistance + rx * 0.55f * Math.min(1, tpsDistance / 1.5f); cy = eyeY - fy * tpsDistance + 0.2f; cz = eyeZ - fz * tpsDistance + rz * 0.55f * Math.min(1, tpsDistance / 1.5f);
        }
        float fov = c.settings.fov / (1 + (zoom() - 1) * adsT) - adsT * 8 + (p.sprinting ? 4 : 0);
        float aspect = W / (float) Math.max(1, H);
        proj.perspective((float) Math.toRadians(fov), aspect, 0.05f, 900f);
        view.identity().rotateZ(-lean * 0.08f).rotateX(-pitch).rotateY(-yaw).translate(-cx, -cy, -cz);
        pv.set(proj).mul(view);
        setupEnv(cx, cy, cz, fx, fy, fz);
        glClearColor(env.fogR, env.fogG, env.fogB, 1);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        c.wr.scheduleDirty();
        c.wr.uploadResults(24);
        c.wr.viewDistance = 260;
        float[] f = {fx, fy, fz}, r = {(float) Math.cos(yaw), 0, (float) -Math.sin(yaw)};
        float[] up = {r[1] * fz - r[2] * fy, r[2] * fx - r[0] * fz, r[0] * fy - r[1] * fx};
        c.wr.renderSky(env, f, r, up, (float) Math.tan(Math.toRadians(fov / 2)), aspect);
        c.wr.render(pv, env);
        drawModels(dt);
        if (!thirdPerson && !invOpen && !raid.player.dead) drawViewmodel(fov, aspect);
        // 2D
        Ui ui = c.ui;
        ui.b.begin(W, H);
        ui.begin(dt, W, H);
        ui.showCursor = invOpen || paused || mapOpen || c.console.open;
        if (raid.muzzleFlash > 0.3f && !thirdPerson) ui.b.rect(0, 0, W, H, Ui.alpha(0x30FFD080, raid.muzzleFlash * 0.3f));
        if (!invOpen && !mapOpen) {
            hud.draw(raid, held(), reloadT, reloadMax, interactPrompt(), adsT > 0.6f, dt);
            if (adsT > 0.6f && zoom() > 2) scopeOverlay(ui, W, H);
            if (raid.body.using != null) { ui.textC("Using " + raid.body.using.name + String.format("  %.1fs", raid.body.useTimer), W / 2f, H * 0.7f, 15, Ui.TXT_HI); }
            drawMinimap(ui);
            if (raid.aiDebug) aiDebug(ui);
        }
        wheel.draw(ui, lo(), dt);
        if (invOpen) drawInventory(ui, dt);
        if (mapOpen) drawMap(ui);
        if (paused) drawPause(ui);
        c.console.draw(ui, dt);
        if (c.settings.showFps) ui.text(Math.round(1 / Math.max(1e-4f, dt)) + " fps  " + c.wr.drawnColumns + " cols  actors " + raid.actors.size(), ui.s(8), H - ui.s(20), 12, Ui.TXT_DIM);
        ui.end();
        ui.b.end();
    }

    private void setupEnv(float cx, float cy, float cz, float fx, float fy, float fz) {
        District d = raid.world.district(cx, cz);
        float day = raid.daylight();
        env.daylight = day;
        env.time = raid.time;
        env.rain = raid.profile.zone.weatherRain > 0.5f ? (raid.profile.zone.weatherRain - 0.5f) * 2 : 0;
        float out = World.outsideDistance(cx, cz);
        float dens = d.fogDensity * (1 + env.rain * 0.8f) * (1 + Math.min(1.5f, out / 60f));
        env.fogDensity = dens / 230f;
        float nightK = 0.12f + 0.88f * day;
        env.fogR = d.fogR * nightK; env.fogG = d.fogG * nightK; env.fogB = d.fogB * nightK;
        if (cy < World.GROUND - 3) { env.fogDensity = 1 / 45f; env.fogR = 0.04f; env.fogG = 0.05f; env.fogB = 0.04f; }
        env.skyR = 0.85f + 0.15f * day; env.skyG = 0.9f; env.skyB = 1f;
        env.tintR = d.tintR; env.tintG = d.tintG; env.tintB = d.tintB;
        double h = raid.profile.zone.hour + raid.time / 60.0 * 0.5;
        double sa = (h % 24 - 6) / 12.0 * Math.PI;
        env.sunX = (float) Math.cos(sa) * 0.8f; env.sunY = (float) Math.sin(sa); env.sunZ = 0.35f;
        env.camX = cx; env.camY = cy; env.camZ = cz; env.dirX = fx; env.dirY = fy; env.dirZ = fz;
        ItemInstance hw = held();
        env.flashlight = raid.playerFlashlight || hw != null && hw.hasLight() && raid.playerFlashlight ? 1 : 0;
        env.flashR = raid.muzzleFlash; env.flashX = eyeX + fx; env.flashY = eyeY; env.flashZ = eyeZ + fz;
    }

    private void drawModels(float dt) {
        var mr = c.mr;
        mr.begin(pv, env);
        float day = raid.daylight();
        for (Actor a : raid.actors) {
            if (a.distXZ(env.camX, env.camZ) > 150) continue;
            a.hurtFlash = Math.max(0, a.hurtFlash - dt);
            float light = ActorRenderer.lightAt(raid.world, a.x, a.y, a.z, day);
            if (a.isPlayer) {
                if (a.dead) continue;
                if (thirdPerson) {
                    c.ar.alpha = Math.max(0.25f, Math.min(1, (tpsDistance - 0.6f) / 1.4f));
                    c.ar.draw(a, playerLook, light, a.pitch, ground, 0, false);
                    c.ar.alpha = 1;
                } else {
                    // true first-person body: the same rig and gait, minus the head and the arms the viewmodel draws
                    c.ar.draw(a, playerLook, light, a.pitch, ground, ActorRenderer.FP_HIDE, true);
                }
                continue;
            }
            ActorRenderer.Look look = ActorRenderer.lookFor(a);
            // agents look where they believe their target is
            float pitch = 0;
            if (!a.dead && "engage".equals(a.state)) { float dd = a.distXZ(a.memX, a.memZ); pitch = (float) Math.atan2(a.memY + 1.2f - a.eyeY(), Math.max(1, dd)); }
            c.ar.draw(a, look, light, pitch, a.distXZ(env.camX, env.camZ) < 40 ? ground : null, 0, false);
            if (a.dead) continue;
            // telegraphs are visual too (accessibility: never audio-only)
            float top = a.y + a.height();
            if (raid.telegraphing(a, "swell")) { float k = 0.9f + 0.25f * (float) Math.sin(raid.time * 30); tmp.identity().translate(a.x, a.y + 1.0f, a.z).scale(k, k, k).translate(0, -0.5f, 0); mr.cube(tmp, 0x70A0D040, 1, 1); }
            if (raid.telegraphing(a, "retch")) { tmp.identity().translate(a.x, top + 0.05f, a.z).scale(0.3f, 0.3f, 0.3f).translate(0, -0.5f, 0); mr.cube(tmp, 0xE0B4E040, 1, 1); }
            if (raid.telegraphing(a, "screech") || raid.telegraphing(a, "shriek")) { tmp.identity().translate(a.x, top + 0.3f, a.z).scale(0.25f, 0.25f, 0.25f); mr.cube(tmp, 0xFFFF3020, 1, 1); }
            if (raid.telegraphing(a, "throw")) { tmp.identity().translate(a.x + (float) Math.cos(a.yaw) * 0.9f, top + 0.5f, a.z - (float) Math.sin(a.yaw) * 0.9f).scale(0.7f, 0.6f, 0.7f).translate(0, -0.5f, 0); mr.cube(tmp, 0xFF8A8478, 0.9f, 0); tmp.identity().translate(a.x, top + 1.4f, a.z).scale(0.3f, 0.3f, 0.3f); mr.cube(tmp, 0xFFFF7020, 1, 1); }
            if (raid.telegraphing(a, "charge")) { for (int k = 0; k < 3; k++) { tmp.identity().translate(a.x + (float) Math.sin(raid.time * 9 + k * 2) * 0.8f, a.y + 0.1f + k * 0.12f, a.z + (float) Math.cos(raid.time * 7 + k * 2) * 0.8f).scale(0.25f, 0.25f, 0.25f); mr.cube(tmp, 0xB0A09880, 0.9f, 0); } tmp.identity().translate(a.x, top + 0.4f, a.z).scale(0.3f, 0.3f, 0.3f); mr.cube(tmp, 0xFFFF3020, 1, 1); }
        }
        for (Raid.WorldItem w : raid.items) {
            VoxModel m = ItemModels.of(w.it);
            float s = 1 / 40f;
            tmp.identity().translate(w.x, w.y + 0.05f + (float) Math.sin(raid.time * 2 + w.x) * 0.03f, w.z).rotateY(raid.time * 0.6f + w.z).scale(s, s, s);
            mr.draw(mr.mesh("w:" + w.it.visualKey(), m, 1), tmp, ActorRenderer.lightAt(raid.world, w.x, w.y, w.z, day) + 0.15f, 0xFFFFFFFF, 0.15f);
        }
        for (Raid.Thrown t : raid.thrown) {
            float sz = t.debris ? 0.55f : 0.12f;
            tmp.identity().translate(t.x, t.y, t.z).rotateY(raid.time * 5).rotateX(raid.time * 7).scale(sz, sz, sz).translate(0, -0.5f, 0);
            mr.cube(tmp, t.debris ? 0xFF8A8478 : 0xFF4A5030, 0.8f, 0);
        }
        for (Raid.Projectile pr : raid.projectiles) {
            if (!pr.tracer && pr.owner == raid.player.id) continue;
            mr.beam(pr.px, pr.py, pr.pz, pr.x, pr.y, pr.z, pr.tracer ? 0.04f : 0.015f, pr.tracer ? 0xFFFFC060 : 0x80FFF0C0, 1);
        }
        for (Raid.Effect e : raid.effects) {
            tmp.identity().translate(e.x, e.y, e.z).scale(e.size, e.size, e.size).translate(0, -0.5f, 0);
            mr.cube(tmp, Ui.alpha(e.color, Math.min(1, e.life / e.max * 2)), e.glow ? 1 : 0.7f, e.glow ? 1 : 0);
        }
        // hazard zones: a stippled pool so the edge of the danger is readable
        for (Raid.Zone z : raid.zones) {
            int col = z.kind.equals("contam") ? 0x508CA83A : 0x70B4D040;
            for (int k = 0; k < 14; k++) {
                float ang = k * 2.4f + z.x, rad = z.radius * (float) Math.sqrt((k + 0.5f) / 14f);
                tmp.identity().translate(z.x + (float) Math.sin(ang) * rad, z.y + 0.02f, z.z + (float) Math.cos(ang) * rad).scale(0.9f, 0.04f, 0.9f).translate(0, 0, 0);
                mr.cube(tmp, col, 1, 0.6f);
            }
        }
        // smoke columns over places where the strategic tier resolved a fight
        for (float[] sm : raid.smoke) {
            if (raid.player.distXZ(sm[0], sm[2]) > 220) continue;
            for (int k = 0; k < 10; k++) {
                float t = (raid.time * 0.25f + k / 10f) % 1f, sz = 0.5f + t * 2.2f;
                tmp.identity().translate(sm[0] + (float) Math.sin(t * 5 + k) * t * 2.5f, sm[1] + t * 26, sm[2] + t * 4).scale(sz, sz, sz).translate(0, -0.5f, 0);
                mr.cube(tmp, Ui.alpha(0xFF2A2826, (1 - t) * 0.55f), 0.5f, 0);
            }
        }
        if (raid.noiseDebug) for (Raid.Sound s : raid.sounds) {
            float age = raid.time - s.time(), rad = s.radius() * Math.min(1, age * 3);
            for (int k = 0; k < 24; k++) {
                double a0 = k * Math.PI * 2 / 24, a1 = (k + 1) * Math.PI * 2 / 24;
                mr.beam(s.x() + (float) Math.sin(a0) * rad, s.y(), s.z() + (float) Math.cos(a0) * rad, s.x() + (float) Math.sin(a1) * rad, s.y(), s.z() + (float) Math.cos(a1) * rad, 0.06f, Ui.alpha(0xFF40C0FF, 1 - age / 4), 1);
            }
        }
        // extraction beacons: visible signal columns at eligible exits nearby
        for (Raid.ExitState s : raid.exits) {
            if (!s.eligible) continue;
            float d = raid.player.distXZ(s.exit.x, s.exit.z);
            if (d > 120 || !c.profile.discovered(s.exit.x / 8, s.exit.z / 8)) continue;
            tmp.identity().translate(s.exit.x + 0.5f, s.exit.y, s.exit.z + 0.5f).scale(0.15f, 18f, 0.15f);
            mr.cube(tmp, 0x5050FF70, 1, 1);
        }
        mr.end();
    }

    // ------------------------------------------------------------------ first-person viewmodel
    /** Viewmodel space is a miniature of the world in front of the camera: this is one character voxel there. */
    private static final float VM_VOX = Rig.VOX * 40f / 88f;
    private final Mat4 vmWeapon = new Mat4(), vmBone = new Mat4();
    private final float[] vt = new float[3], ve = new float[3];

    /**
     * Weapon and both arms. The weapon follows the same action clips as the third-person body
     * (tactical reload, empty reload with a rack, shell loading, jam clearing), so a reload looks
     * different depending on whether a round is still chambered. Sway lags the mouse and scales
     * with the weapon's mass; the arms are the player's own sleeves and gloves, solved onto the grips.
     */
    private void drawViewmodel(float fov, float aspect) {
        ItemInstance h = held();
        if (h == null) return;
        Actor p = raid.player;
        Animator an = p.anim;
        glClear(GL_DEPTH_BUFFER_BIT);
        Mat4 vp = new Mat4().perspective((float) Math.toRadians(60), aspect, 0.01f, 10f);
        WorldRenderer.Env e = new WorldRenderer.Env();
        e.fogDensity = 0; e.camX = 0; e.camY = 0; e.camZ = 0;
        c.mr.begin(vp, e);
        VoxModel m = ItemModels.of(h);
        boolean melee = h.def().weapon != null && h.def().weapon.melee();
        boolean pistol = !melee && m.sx < 26;
        float s = 1 / 88f;
        // weight: heavier weapons lag further behind the look, drift more at rest and settle slower
        float mass = Math.max(0.4f, h.mass()), heft = 0.6f + mass * 0.16f;
        float dt = c.ui.dt;
        float lagX = overlay() ? 0 : (float) -c.in.dx * 0.00045f * heft, lagY = overlay() ? 0 : (float) c.in.dy * 0.00045f * heft;
        swayX += (Math.max(-0.05f, Math.min(0.05f, lagX)) - swayX) * Math.min(1, dt * (14f / heft));
        swayY += (Math.max(-0.05f, Math.min(0.05f, lagY)) - swayY) * Math.min(1, dt * (14f / heft));
        float tired = 1 + (1 - raid.body.stamina / 100f) * 1.5f;
        float idleX = (float) Math.sin(raid.time * 0.9f) * 0.0022f * heft * tired * (1 - adsT * 0.6f), idleY = (float) Math.sin(raid.time * 1.3f + 1) * 0.0018f * heft * tired * (1 - adsT * 0.6f);
        // gait bob straight from the animated footfalls
        float ph = an.phase * 6.2832f, walk = bobAmt * (1 - adsT * 0.75f);
        float bobX = (float) Math.sin(ph) * 0.010f * walk, bobY = -Math.abs((float) Math.cos(ph)) * 0.008f * walk;
        // action clip (weapon channel) relative to the shouldered pose
        float aw = 0;
        Anims.get("wpn_aim").sample(0, vmBase);
        vmPose.set(vmBase);
        if (!an.action.isEmpty() && Anims.get(an.action).drivesWeapon && !Anims.get(an.action).additive && !an.action.equals("equip")) {
            Anims.get(an.action).sample(an.actionTime / an.actionDur, vmPose);
            aw = Math.max(0, Math.min(1, Math.min(an.actionTime / Animator.BLEND, (an.actionDur - an.actionTime) / Animator.BLEND)));
        }
        float dxp = (vmPose.wpn[0] - vmBase.wpn[0]) * aw, dyp = (vmPose.wpn[1] - vmBase.wpn[1]) * aw, dzp = (vmPose.wpn[2] - vmBase.wpn[2]) * aw;
        float dpitch = (vmPose.wpn[3] - vmBase.wpn[3]) * aw, dyaw = (vmPose.wpn[4] - vmBase.wpn[4]) * aw, droll = (vmPose.wpn[5] - vmBase.wpn[5]) * aw;
        float sw = Math.max(0, switchT) / 0.45f;
        float ax = 0.13f * (1 - adsT) + swayX + idleX + bobX + dxp * VM_VOX;
        float ay = -0.13f + adsT * 0.07f + swayY + idleY + bobY + dyp * VM_VOX - sw * sw * 0.32f - landDip * 0.4f;
        float az = -0.34f + kick * 0.04f + dzp * VM_VOX;
        float sprintLower = p.sprinting ? 1 : 0;
        vmWeapon.identity().translate(ax, ay - sprintLower * 0.05f, az)
                .rotateY(dyaw + (1 - adsT) * 0.06f - swayX * 2.5f + sprintLower * 0.5f + sw * 0.4f)
                .rotateX(kick * 0.08f + dpitch * 0.8f + swayY * 2.5f - sw * 0.9f - sprintLower * 0.25f)
                .rotateZ(droll * 0.7f - swayX * 3f + lean * -0.12f);
        Mat4 mm = new Mat4().set(vmWeapon).rotateY((float) Math.PI / 2).scale(s, s, s).translate(m.sx * 0.22f, -m.sy * 0.55f, 0);
        if (melee) mm.rotateZ(meleeT > 0 ? -1.2f * meleeT : 0);
        float light = Math.max(0.25f, ActorRenderer.lightAt(raid.world, p.x, p.y, p.z, raid.daylight())) + raid.muzzleFlash * 0.4f;
        c.mr.draw(c.mr.mesh("w:" + h.visualKey(), m, 1), mm, light, 0xFFFFFFFF, 0);

        // hands: firing grip, and the support hand on the fore-end or wherever the clip sends it
        float gz = -0.06f * m.sx * s, gy = -0.17f * m.sy * s;
        vmWeapon.transformPoint(0.004f, gy - 0.012f, gz + 0.01f, vt);
        if (melee) vmWeapon.transformPoint(0, -0.5f * m.sy * s, 0.30f * m.sx * s, vt);
        arm(playerLook, true, vt[0], vt[1], vt[2], 0.17f, -0.30f, -0.06f, light);
        if (!melee) {
            float sep = pistol ? 0.012f : 0.34f * m.sx * s;
            float lx = vmPose.lhOnWeapon > 0.5f ? vmPose.wpn[6] * aw : 0, ly = vmPose.lhOnWeapon > 0.5f ? vmPose.wpn[7] * aw : 0, lz = vmPose.lhOnWeapon > 0.5f ? vmPose.wpn[8] * aw : 0;
            vmWeapon.transformPoint((pistol ? -0.012f : 0) + lx * VM_VOX, gy + (pistol ? -0.012f : 0.006f) + ly * VM_VOX, gz - sep + lz * VM_VOX, vt);
            if (aw > 0 && vmPose.lhOnWeapon < 0.5f) {
                // free hand (interact / heal): an eye-space reach instead of a grip
                float k = aw;
                vt[0] += (vmPose.wpn[6] * VM_VOX * 1.6f - 0.02f - vt[0]) * k; vt[1] += (-0.20f + (vmPose.wpn[7] + 6) * VM_VOX - vt[1]) * k; vt[2] += (-0.30f + vmPose.wpn[8] * VM_VOX * 0.6f - vt[2]) * k;
            }
            arm(playerLook, false, vt[0], vt[1], vt[2], -0.12f, -0.32f, -0.14f, light);
            // the fresh magazine travels in the support hand from the pouch to the well
            if (reloadT > 0 && reloadMag != null && ("mag".equals(reloadKind) || "speed".equals(reloadKind))) {
                float t = 1 - reloadT / Math.max(0.01f, reloadMax), t0 = reloadEmpty ? 0.40f : 0.52f, t1 = reloadEmpty ? 0.66f : 0.84f;
                if (t > t0 && t < t1) {
                    VoxModel mg = ItemModels.of(reloadMag);
                    vmBone.identity().translate(vt[0], vt[1] + 0.01f, vt[2]).rotateY((float) Math.PI / 2 + dyaw).rotateZ(-0.2f).scale(s, s, s).translate(0, -mg.sy * 0.2f, 0);
                    c.mr.draw(c.mr.mesh("w:" + reloadMag.visualKey(), mg, 1), vmBone, light, 0xFFFFFFFF, 0);
                }
            }
        }
        if (raid.muzzleFlash > 0.2f && h.def().weapon != null && !melee) {
            float[] mz = new float[3];
            mm.transformPoint(m.sx / 2f + 1, m.sy * 0.6f, 0, mz);
            float fs = 0.05f * raid.muzzleFlash;
            Mat4 fm = new Mat4().translate(mz[0], mz[1] - fs / 2, mz[2]).scale(fs, fs, fs);
            c.mr.cube(fm, 0xB0FFD070, 1, 1);
        }
        c.mr.end();
    }

    /** One viewmodel arm: forearm and hand run from an off-screen elbow to the hand target, upper arm behind it. */
    private void arm(ActorRenderer.Look look, boolean right, float tx, float ty, float tz, float ex, float ey, float ez, float light) {
        float ux = tx - ex, uy = ty - ey, uz = tz - ez, ul = (float) Math.sqrt(ux * ux + uy * uy + uz * uz);
        if (ul < 1e-4f) return;
        ux /= ul; uy /= ul; uz /= ul;
        float k = VM_VOX, fore = 7 * k;
        // forearm pivot (elbow) sits a forearm-and-hand behind the target
        float px = tx - ux * fore, py = ty - uy * fore, pz = tz - uz * fore;
        int up = right ? Rig.R_UPPER_ARM : Rig.L_UPPER_ARM;
        Rig.aimBone(vmBone, px, py, pz, ux, uy, uz, k);
        c.ar.drawPart(look, up + 1, vmBone, light);
        Rig.aimBone(vmBone, px + ux * 5 * k, py + uy * 5 * k, pz + uz * 5 * k, ux, uy, uz, k);
        c.ar.drawPart(look, up + 2, vmBone, light);
        // upper arm from an off-screen shoulder down to the elbow
        float sx = right ? 0.24f : -0.22f, sy = -0.46f, sz = 0.10f;
        float wx = px - sx, wy = py - sy, wz = pz - sz, wl = (float) Math.sqrt(wx * wx + wy * wy + wz * wz);
        wx /= wl; wy /= wl; wz /= wl;
        Rig.aimBone(vmBone, px - wx * 5 * k, py - wy * 5 * k, pz - wz * 5 * k, wx, wy, wz, k);
        c.ar.drawPart(look, up, vmBone, light);
    }

    private void scopeOverlay(Ui ui, int W, int H) {
        float r = Math.min(W, H) * 0.42f;
        float cx = W / 2f, cy = H / 2f;
        ui.b.rect(0, 0, cx - r, H, 0xF0000000); ui.b.rect(cx + r, 0, W - cx - r, H, 0xF0000000);
        ui.b.rect(cx - r, 0, 2 * r, cy - r, 0xF0000000); ui.b.rect(cx - r, cy + r, 2 * r, H - cy - r, 0xF0000000);
        ui.b.rect(cx - r, cy, 2 * r, 1, 0xC0000000); ui.b.rect(cx, cy - r, 1, 2 * r, 0xC0000000);
        ui.b.rect(cx - 2, cy - 2, 4, 4, 0xFFE03020);
    }

    private void drawMinimap(Ui ui) {
        float s = ui.s(180), x = ui.w - s - ui.s(18), y = ui.s(18);
        ui.nine("panel_dark", x - ui.s(6), y - ui.s(6), s + ui.s(12), s + ui.s(12), 0xE0FFFFFF);
        float span = 120;
        c.map.draw(ui, c.profile, x, y, s, s, raid.player.x - span / 2, raid.player.z - span / 2, span, raid.exits, raid.player.x, raid.player.z, raid.player.yaw, false);
        District d = raid.world.district(raid.player.x, raid.player.z);
        ui.textR(d.display.toUpperCase(), x + s, y + s + ui.s(10), 12, Ui.TXT);
        float out = World.outsideDistance(raid.player.x, raid.player.z);
        if (out > 0) ui.textR("RADIATION ZONE", x + s, y + s + ui.s(28), 12, Ui.RED);
    }

    private void drawMap(Ui ui) {
        ui.b.rect(0, 0, ui.w, ui.h, 0xD0080807);
        float s = Math.min(ui.w, ui.h) - ui.s(120), x = (ui.w - s) / 2, y = ui.s(70);
        ui.window("Field Map  -  " + raid.profile.zone.day + "d " + String.format("%02d:00", (int) (raid.profile.zone.hour + raid.time / 120) % 24), "map", x - ui.s(12), y - ui.s(56), s + ui.s(24), s + ui.s(70));
        float span = World.W / mapZoom;
        float cx = Math.max(span / 2, Math.min(World.W - span / 2, raid.player.x)), cz = Math.max(span / 2, Math.min(World.D - span / 2, raid.player.z));
        c.map.draw(ui, c.profile, x, y, s, s, cx - span / 2, cz - span / 2, span, raid.exits, raid.player.x, raid.player.z, raid.player.yaw, true);
        c.map.legend(ui, c.profile, x + s + ui.s(30), y);
        float ly = y + ui.s(220);
        ui.text("EXITS", x + s + ui.s(30), ly, 14, Ui.TXT_HI);
        for (Raid.ExitState e : raid.exits) {
            ly += ui.s(34);
            if (ly > ui.h - ui.s(40)) break;
            ui.text(e.exit.name, x + s + ui.s(30), ly, 13, e.eligible ? Ui.GREEN : Ui.TXT_DIM);
            ui.text(e.requirement, x + s + ui.s(30), ly + ui.s(15), 10, Ui.TXT_DIM);
        }
        ui.text("[Scroll] zoom   [M] close", x, y + s + ui.s(8), 12, Ui.TXT_DIM);
    }

    private void drawInventory(Ui ui, float dt) {
        ui.b.rect(0, 0, ui.w, ui.h, 0xC8060706);
        var inv = c.inv;
        inv.begin(36);
        float pad = ui.s(24);
        inv.fit(ui.h - ui.s(48) - ui.s(40) - ui.s(44) - ui.s(150), lo().caseGrid.h + (lo().packGrid() == null ? 0 : lo().packGrid().h + 2));
        float rightW = panel.width(lo());
        float leftW = lootSide != null ? Math.max(lootSide.w * inv.cell + ui.s(24), ui.s(300)) : ui.s(300);
        float inspW = ui.s(300);
        float total = leftW + rightW + inspW + pad * 4;
        float x0 = Math.max(pad, (ui.w - total) / 2);
        float top = ui.s(48);
        // left: container / corpse / ground
        float lh = ui.h - top - ui.s(40);
        float cy = ui.window(lootSide != null ? "Searching" : "Nearby", "search", x0, top, leftW + pad, lh);
        if (lootSide != null) inv.grid(lootSide, x0 + ui.s(16), cy + ui.s(30), lootSide.label);
        else ui.wrap("Nothing open. Search containers, bodies or pick items up with [F]. Shift+click moves items between sides.", x0 + ui.s(16), cy + ui.s(8), leftW - ui.s(8), 13, Ui.TXT_DIM);
        // right: loadout (gear, charms, case, tabs)
        float rx = x0 + leftW + pad * 2;
        float ry = ui.window("Survivor  -  " + c.profile.name, "inv", rx, top, rightW + pad, lh);
        panel.draw(c.profile, rx + ui.s(12), ry, rightW, lh - (ry - top) - ui.s(20), lootSide);
        // inspect
        float ix = rx + rightW + pad * 2;
        inv.inspectPanel(ix, top, inspW, lh);
        ui.text("[I]/[Esc] close   [R] rotate   [Shift+Click] transfer   [RMB] actions   [Z] sort case   hold [F] inspect", x0, ui.h - ui.s(30), 12, Ui.TXT_DIM);
        if (c.in.pressed("sort")) { InventoryService.Result r = InventoryService.autoSort(lo().caseGrid); inv.say(r.ok() ? "Case sorted" : r.msg(), r.ok() ? Ui.GREEN : Ui.RED); }
        inv.end();
        if (c.in.keyDown(GLFW_KEY_F)) inv.fullInspect(inspectYaw + inv.spin * 0.2f, inspectPitch);
    }

    private void drawPause(Ui ui) {
        ui.b.rect(0, 0, ui.w, ui.h, 0xB0000000);
        float w = ui.s(360), h = ui.s(330), x = (ui.w - w) / 2, y = (ui.h - h) / 2;
        float cy = ui.window("Paused", "cog", x, y, w, h);
        float bw = w - ui.s(48), bh = ui.s(44);
        if (ui.button("p_resume", x + ui.s(24), cy + ui.s(6), bw, bh, "RESUME", "arrow", true)) paused = false;
        if (ui.button("p_settings", x + ui.s(24), cy + ui.s(58), bw, bh, "SETTINGS", "cog", true)) pauseAction = "settings";
        if (ui.button("p_abandon", x + ui.s(24), cy + ui.s(110), bw, bh, "ABANDON RAID (MIA)", "skull", true)) { raid.debrief.outcome = Raid.Debrief.Outcome.MIA; raid.debrief.reason = "Abandoned the operation"; paused = false; }
        if (ui.button("p_quit", x + ui.s(24), cy + ui.s(162), bw, bh, "QUIT TO DESKTOP", "cross", true)) pauseAction = "quit";
        ui.text("Quitting mid-raid counts as missing in action.", x + ui.s(24), cy + ui.s(222), 12, Ui.TXT_DIM);
    }

    public String pauseAction;

    private void aiDebug(Ui ui) {
        float[] o = new float[3];
        for (Actor a : raid.actors) {
            if (a.isPlayer || a.dead || a.distXZ(raid.player.x, raid.player.z) > 80) continue;
            float w = pv.project(a.x, a.y + a.height() + 0.4f, a.z, o);
            if (w <= 0) continue;
            float sx = (o[0] * 0.5f + 0.5f) * ui.w, sy = (1 - (o[1] * 0.5f + 0.5f)) * ui.h;
            int col = "engage".equals(a.state) ? Ui.RED : "investigate".equals(a.state) || "search".equals(a.state) ? Ui.AMBER : Ui.GREEN;
            ui.textC(a.faction + "/" + a.archetype + " " + a.state + (a.hostileToPlayer ? " H" : "") + String.format(" aw%.1f T%d", a.awareness, a.tier), sx, sy, 11, col);
        }
        ui.text("AI tiers: active " + raid.actors.stream().filter(a -> !a.dead && a.tier == 0).count() + "  regional " + raid.actors.stream().filter(a -> !a.dead && a.tier == 1).count() + "  population " + raid.populationTotal(), ui.s(8), ui.s(110), 12, Ui.AMBER);
    }
}
