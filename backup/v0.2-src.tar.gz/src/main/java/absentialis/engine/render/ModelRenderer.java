package absentialis.engine.render;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL15.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL30.*;

import absentialis.engine.math.Mat4;
import absentialis.engine.voxel.VoxModel;
import java.nio.FloatBuffer;
import java.util.HashMap;
import java.util.Map;
import org.lwjgl.system.MemoryUtil;

/**
 * Renders small voxel models (characters, items, viewmodel, debris, tracers) as face-culled meshes
 * with baked face shading, lit by the world light sampled at the model and fogged like the world.
 */
public final class ModelRenderer {
    public static final class Mesh { int vao, vbo, count; }

    private Shader shader;
    private final Map<String, Mesh> cache = new HashMap<>();
    private Mesh cube;
    private final Mat4 tmp = new Mat4();

    public void init() {
        shader = new Shader(VS, FS);
        VoxModel c = new VoxModel(1, 1, 1);
        c.set(0, 0, 0, 0xFFFFFFFF);
        cube = build(c, 1f, true);
    }

    public Mesh mesh(String key, VoxModel m, float voxelSize) {
        Mesh me = cache.get(key);
        if (me == null) {
            if (cache.size() > 6000) { for (Mesh x : cache.values()) free(x); cache.clear(); }
            me = build(m, voxelSize, true);
            cache.put(key, me);
        }
        return me;
    }

    /** Mesh whose origin is a pivot inside the model grid (skinned character parts: one mesh per SKIN group). */
    public Mesh meshAt(String key, VoxModel m, float ox, float oy, float oz) {
        Mesh me = cache.get(key);
        if (me == null) {
            if (cache.size() > 6000) { for (Mesh x : cache.values()) free(x); cache.clear(); }
            me = build(m, 1f, -ox, -oy, -oz);
            cache.put(key, me);
        }
        return me;
    }

    private static void free(Mesh m) { glDeleteBuffers(m.vbo); glDeleteVertexArrays(m.vao); }

    /** Builds a mesh centred on the model's bottom-centre (x, z centre; y = 0). */
    public static Mesh build(VoxModel m, float s, boolean centre) {
        return build(m, s, centre ? -m.sx / 2f : 0, 0, centre ? -m.sz / 2f : 0);
    }

    public static Mesh build(VoxModel m, float s, float ox, float oy, float oz) {
        int faces = 0;
        int[][] dirs = {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};
        float[] shade = {0.80f, 0.80f, 1.0f, 0.55f, 0.90f, 0.70f};
        for (int x = 0; x < m.sx; x++) for (int y = 0; y < m.sy; y++) for (int z = 0; z < m.sz; z++) {
            if (m.get(x, y, z) == 0) continue;
            for (int[] d : dirs) if (m.get(x + d[0], y + d[1], z + d[2]) == 0) faces++;
        }
        FloatBuffer fb = MemoryUtil.memAllocFloat(Math.max(1, faces) * 6 * 7);
        for (int x = 0; x < m.sx; x++) for (int y = 0; y < m.sy; y++) for (int z = 0; z < m.sz; z++) {
            int c = m.get(x, y, z);
            if (c == 0) continue;
            for (int f = 0; f < 6; f++) {
                int[] d = dirs[f];
                if (m.get(x + d[0], y + d[1], z + d[2]) != 0) continue;
                float r = ((c >> 16) & 255) / 255f * shade[f], g = ((c >> 8) & 255) / 255f * shade[f], bl = (c & 255) / 255f * shade[f], a = ((c >>> 24) & 255) / 255f;
                float[][] q = quad(f);
                int[] order = {0, 1, 2, 2, 3, 0};
                for (int k : order) fb.put((x + q[k][0] + ox) * s).put((y + q[k][1] + oy) * s).put((z + q[k][2] + oz) * s).put(r).put(g).put(bl).put(a);
            }
        }
        fb.flip();
        Mesh me = new Mesh();
        me.vao = glGenVertexArrays();
        me.vbo = glGenBuffers();
        glBindVertexArray(me.vao);
        glBindBuffer(GL_ARRAY_BUFFER, me.vbo);
        glBufferData(GL_ARRAY_BUFFER, fb, GL_STATIC_DRAW);
        glVertexAttribPointer(0, 3, GL_FLOAT, false, 28, 0);
        glVertexAttribPointer(1, 4, GL_FLOAT, false, 28, 12);
        glEnableVertexAttribArray(0);
        glEnableVertexAttribArray(1);
        glBindVertexArray(0);
        me.count = faces * 6;
        MemoryUtil.memFree(fb);
        return me;
    }

    /** Counter-clockwise quads (outside view) per face direction. */
    private static float[][] quad(int f) {
        switch (f) {
            case 0: return new float[][]{{1, 0, 1}, {1, 0, 0}, {1, 1, 0}, {1, 1, 1}};
            case 1: return new float[][]{{0, 0, 0}, {0, 0, 1}, {0, 1, 1}, {0, 1, 0}};
            case 2: return new float[][]{{0, 1, 1}, {1, 1, 1}, {1, 1, 0}, {0, 1, 0}};
            case 3: return new float[][]{{0, 0, 0}, {1, 0, 0}, {1, 0, 1}, {0, 0, 1}};
            case 4: return new float[][]{{0, 0, 1}, {1, 0, 1}, {1, 1, 1}, {0, 1, 1}};
            default: return new float[][]{{1, 0, 0}, {0, 0, 0}, {0, 1, 0}, {1, 1, 0}};
        }
    }

    // ------------------------------------------------------------------ drawing
    public void begin(Mat4 pv, WorldRenderer.Env e) {
        shader.use();
        shader.mat4("uPV", pv);
        shader.f3("uFog", e.fogR, e.fogG, e.fogB);
        shader.f1("uFogDensity", e.fogDensity);
        shader.f3("uCam", e.camX, e.camY, e.camZ);
        glEnable(GL_DEPTH_TEST);
        glDisable(GL_CULL_FACE);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    }

    public void draw(Mesh m, Mat4 model, float light, int tintArgb, float emissive) {
        shader.mat4("uModel", model);
        shader.f1("uLight", light);
        shader.f1("uEmissive", emissive);
        shader.f4("uTint", ((tintArgb >> 16) & 255) / 255f, ((tintArgb >> 8) & 255) / 255f, (tintArgb & 255) / 255f, ((tintArgb >>> 24) & 255) / 255f);
        glBindVertexArray(m.vao);
        glDrawArrays(GL_TRIANGLES, 0, m.count);
    }

    /** Axis-aligned or transformed solid cube: model maps the unit cube. */
    public void cube(Mat4 model, int argb, float light, float emissive) { draw(cube, model, light, argb, emissive); }

    /** Thin box from a to b (tracers, beams). */
    public void beam(float ax, float ay, float az, float bx, float by, float bz, float thick, int argb, float emissive) {
        float dx = bx - ax, dy = by - ay, dz = bz - az, len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-4f) return;
        float yaw = (float) Math.atan2(dx, dz), pitch = (float) Math.asin(dy / len);
        tmp.identity().translate(ax, ay, az).rotateY(yaw).rotateX(-pitch).scale(thick, thick, len).translate(0, -0.5f, 0.5f);
        cube(tmp, argb, 1, emissive);
    }

    public void end() { glBindVertexArray(0); glDisable(GL_BLEND); glEnable(GL_CULL_FACE); }

    private static final String VS = """
        #version 330 core
        layout(location=0) in vec3 aPos;
        layout(location=1) in vec4 aCol;
        uniform mat4 uPV, uModel;
        out vec4 vCol; out vec3 vWorld;
        void main() { vec4 w = uModel * vec4(aPos, 1.0); vWorld = w.xyz; vCol = aCol; gl_Position = uPV * w; }
        """;
    private static final String FS = """
        #version 330 core
        in vec4 vCol; in vec3 vWorld;
        uniform vec3 uFog, uCam; uniform float uFogDensity, uLight, uEmissive; uniform vec4 uTint;
        out vec4 frag;
        void main() {
            vec3 c = vCol.rgb * uTint.rgb * mix(uLight, 1.4, uEmissive);
            float d = length(vWorld - uCam);
            float f = clamp(1.0 - exp(-pow(d * uFogDensity, 1.35)), 0.0, 1.0);
            frag = vec4(mix(c, uFog, f * (1.0 - uEmissive * 0.5)), vCol.a * uTint.a);
            if (frag.a < 0.02) discard;
        }
        """;
}
