package absentialis.engine.render;

import static org.lwjgl.opengl.GL20.*;

import absentialis.engine.math.Mat4;
import java.util.HashMap;
import java.util.Map;

/** Compiled GLSL program with cached uniform locations. */
public final class Shader {
    public final int id;
    private final Map<String, Integer> locs = new HashMap<>();

    public Shader(String vs, String fs) {
        int v = compile(GL_VERTEX_SHADER, vs), f = compile(GL_FRAGMENT_SHADER, fs);
        id = glCreateProgram();
        glAttachShader(id, v);
        glAttachShader(id, f);
        glLinkProgram(id);
        if (glGetProgrami(id, GL_LINK_STATUS) == 0) throw new IllegalStateException("Link: " + glGetProgramInfoLog(id));
        glDeleteShader(v);
        glDeleteShader(f);
    }

    private static int compile(int type, String src) {
        int s = glCreateShader(type);
        glShaderSource(s, src);
        glCompileShader(s);
        if (glGetShaderi(s, GL_COMPILE_STATUS) == 0) throw new IllegalStateException("Shader compile: " + glGetShaderInfoLog(s) + "\n" + src);
        return s;
    }

    public void use() { glUseProgram(id); }

    private int loc(String n) { return locs.computeIfAbsent(n, k -> glGetUniformLocation(id, k)); }

    private final float[] buf = new float[16];
    public void mat4(String n, Mat4 m) { glUniformMatrix4fv(loc(n), false, m.m); }
    public void f1(String n, float v) { glUniform1f(loc(n), v); }
    public void i1(String n, int v) { glUniform1i(loc(n), v); }
    public void f2(String n, float a, float b) { glUniform2f(loc(n), a, b); }
    public void f3(String n, float a, float b, float c) { glUniform3f(loc(n), a, b, c); }
    public void f4(String n, float a, float b, float c, float d) { glUniform4f(loc(n), a, b, c, d); }
}
