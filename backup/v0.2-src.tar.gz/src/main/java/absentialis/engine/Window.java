package absentialis.engine;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.system.MemoryUtil.NULL;

import org.lwjgl.glfw.GLFWErrorCallback;
import org.lwjgl.glfw.GLFWVidMode;
import org.lwjgl.opengl.GL;

/** GLFW window + OpenGL 3.3 core context. */
public final class Window {
    public long handle;
    public int width, height;
    public final Input input = new Input();
    private boolean cursorLocked;

    public void create(String title, int w, int h) {
        GLFWErrorCallback.createPrint(System.err).set();
        if (!glfwInit()) throw new IllegalStateException("GLFW init failed");
        glfwDefaultWindowHints();
        glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
        glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
        glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
        glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GLFW_TRUE);
        glfwWindowHint(GLFW_VISIBLE, GLFW_FALSE);
        glfwWindowHint(GLFW_RESIZABLE, GLFW_TRUE);
        glfwWindowHint(GLFW_SAMPLES, 0);
        GLFWVidMode vm = glfwGetVideoMode(glfwGetPrimaryMonitor());
        if (vm != null) { w = Math.min(w, vm.width() - 80); h = Math.min(h, vm.height() - 100); }
        handle = glfwCreateWindow(w, h, title, NULL, NULL);
        if (handle == NULL) throw new IllegalStateException("Window creation failed (OpenGL 3.3 required)");
        width = w; height = h;
        if (vm != null) glfwSetWindowPos(handle, (vm.width() - w) / 2, (vm.height() - h) / 2);

        glfwSetKeyCallback(handle, (win, key, sc, action, mods) -> input.onKey(key, action));
        glfwSetMouseButtonCallback(handle, (win, b, action, mods) -> input.onMouseButton(b, action));
        glfwSetCursorPosCallback(handle, (win, x, y) -> input.onCursor(x, y));
        glfwSetScrollCallback(handle, (win, sx, sy) -> input.onScroll(sy));
        glfwSetCharCallback(handle, (win, cp) -> input.onChar(cp));
        glfwSetFramebufferSizeCallback(handle, (win, fw, fh) -> { width = fw; height = fh; });

        glfwMakeContextCurrent(handle);
        GL.createCapabilities();
        glfwSwapInterval(1);
        int[] fw = new int[1], fh = new int[1];
        glfwGetFramebufferSize(handle, fw, fh);
        width = fw[0]; height = fh[0];
        glfwShowWindow(handle);
        glClearColor(0.05f, 0.05f, 0.06f, 1);
    }

    public void setCursorLocked(boolean locked) {
        if (locked == cursorLocked) return;
        cursorLocked = locked;
        glfwSetInputMode(handle, GLFW_CURSOR, locked ? GLFW_CURSOR_DISABLED : GLFW_CURSOR_HIDDEN); // the UI draws a pixel-art cursor
        if (locked && glfwRawMouseMotionSupported()) glfwSetInputMode(handle, GLFW_RAW_MOUSE_MOTION, GLFW_TRUE);
        input.resetMouseDelta();
    }

    public boolean cursorLocked() { return cursorLocked; }
    public boolean shouldClose() { return glfwWindowShouldClose(handle); }
    public void requestClose() { glfwSetWindowShouldClose(handle, true); }
    public void swap() { glfwSwapBuffers(handle); }
    public void poll() { glfwPollEvents(); }
    public void setTitle(String t) { glfwSetWindowTitle(handle, t); }

    public void destroy() {
        glfwDestroyWindow(handle);
        glfwTerminate();
    }
}
