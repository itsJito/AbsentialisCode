package absentialis.engine.audio;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;

/**
 * Software mixer on a javax.sound.sampled SourceDataLine (iteration P0.3).
 *
 * Voices are routed to buses - Effects, Music, Voice, Ambience and Interface - each with its own
 * level and mute under one master level and mute. Bus levels are read while mixing, so moving a
 * slider changes sounds that are already playing. Positional one-shots get inverse-distance
 * attenuation, constant-power pan from the listener's facing, and a low-pass that grows with
 * distance so far gunfire sounds far rather than merely quiet.
 */
public final class AudioEngine {
    public static final int RATE = 44100;
    public static final int SFX = 0, MUSIC = 1, VOICE = 2, AMBIENCE = 3, UI = 4, BUSES = 5;
    public static final String[] BUS_NAMES = {"Effects", "Music", "Voice", "Ambience", "Interface"};
    private static final int FRAMES = 1024;
    private SourceDataLine line;
    private Thread thread;
    private volatile boolean running;
    public final Map<String, float[]> samples = new HashMap<>();
    private final List<Voice> voices = new ArrayList<>();
    private final Object lock = new Object();
    public volatile float master = 0.8f;
    public volatile boolean muted;
    /** Level per bus (0..1) and per-bus mute. */
    public final float[] bus = {1f, 0.55f, 1f, 0.7f, 0.8f};
    public final boolean[] busMuted = new boolean[BUSES];
    public float lx, ly, lz, lyaw; // listener
    public boolean available;
    /** Directional caption hook (accessibility): name, bearing text, distance. */
    public CaptionSink captions;
    /** Mixed output peak of the last block per bus (meters / tests). */
    public final float[] peak = new float[BUSES];
    /** Voices started per bus since start (tests / debug). */
    public final int[] started = new int[BUSES];

    public interface CaptionSink { void caption(String sound, float x, float y, float z, float loudness); }

    public static final class Voice {
        float[] data;
        double pos;
        float pitch = 1, gl = 1, gr = 1, gain = 1, pan, lp, lpState;
        int bus = SFX;
        boolean loop, stopped;
        float fade = 1, fadeTarget = 1, fadeSpeed;
        public void stop() { stopped = true; }
        public void setGain(float g) { gain = g; recalc(); }
        public void setPan(float p) { pan = p; recalc(); }
        void recalc() { float p = Math.max(-1, Math.min(1, pan)); gl = gain * (float) Math.sqrt(0.5 * (1 - p)); gr = gain * (float) Math.sqrt(0.5 * (1 + p)); }
        public void fadeTo(float target, float seconds) { fadeTarget = target; fadeSpeed = seconds <= 0 ? 1 : 1f / (seconds * RATE); }
        public boolean done() { return stopped; }
        public float gain() { return gain; }
        public float pan() { return pan; }
        public float lowpass() { return lp; }
        public int bus() { return bus; }
    }

    public void start() {
        try {
            AudioFormat fmt = new AudioFormat(RATE, 16, 2, true, false);
            line = AudioSystem.getSourceDataLine(fmt);
            line.open(fmt, FRAMES * 4 * 4);
            line.start();
            available = true;
        } catch (Exception e) {
            System.err.println("[Audio] unavailable: " + e.getMessage());
            available = false;
            return;
        }
        running = true;
        thread = new Thread(this::loop, "audio-mixer");
        thread.setDaemon(true);
        thread.setPriority(Thread.MAX_PRIORITY - 1);
        thread.start();
    }

    public void stop() { running = false; if (line != null) { line.stop(); line.close(); } }

    /** Effective level of a bus right now (master, mutes included). */
    public float level(int b) { return muted || busMuted[b] ? 0 : master * bus[b]; }

    private void loop() {
        float[] mix = new float[FRAMES * 2];
        byte[] out = new byte[FRAMES * 4];
        while (running) {
            mixBlock(mix);
            for (int i = 0; i < FRAMES * 2; i++) {
                float s = (float) Math.tanh(mix[i] * 1.1); // soft limiter
                int v = (int) (s * 32000);
                out[i * 2] = (byte) v;
                out[i * 2 + 1] = (byte) (v >> 8);
            }
            line.write(out, 0, out.length);
        }
    }

    /** Mixes one block of all voices into an interleaved stereo buffer (also used headless by the quality gate). */
    public void mixBlock(float[] mix) {
        java.util.Arrays.fill(mix, 0f);
        int frames = mix.length / 2;
        java.util.Arrays.fill(peak, 0);
        synchronized (lock) {
            for (int vi = voices.size() - 1; vi >= 0; vi--) {
                Voice v = voices.get(vi);
                if (v.stopped) { voices.remove(vi); continue; }
                float lvl = level(v.bus);
                float[] d = v.data;
                float keep = v.lp;
                for (int f = 0; f < frames; f++) {
                    int i0 = (int) v.pos;
                    if (i0 >= d.length - 1) {
                        if (v.loop) { v.pos -= d.length - 1; i0 = (int) v.pos; }
                        else { v.stopped = true; break; }
                    }
                    float frac = (float) (v.pos - i0);
                    float s = d[i0] + (d[i0 + 1] - d[i0]) * frac;
                    if (keep > 0) { v.lpState += (s - v.lpState) * (1 - keep); s = v.lpState; }
                    if (v.fade != v.fadeTarget) {
                        v.fade = v.fade < v.fadeTarget ? Math.min(v.fadeTarget, v.fade + v.fadeSpeed) : Math.max(v.fadeTarget, v.fade - v.fadeSpeed);
                        if (v.fade <= 0 && v.fadeTarget <= 0) { v.stopped = true; break; }
                    }
                    s *= v.fade * lvl;
                    float l = s * v.gl, r = s * v.gr;
                    mix[f * 2] += l;
                    mix[f * 2 + 1] += r;
                    float a = Math.max(Math.abs(l), Math.abs(r));
                    if (a > peak[v.bus]) peak[v.bus] = a;
                    v.pos += v.pitch;
                }
            }
        }
    }

    public Voice play(String name, float gain, float pan, float pitch, int busId) {
        float[] d = samples.get(name);
        if (d == null) return new Voice();
        Voice v = new Voice();
        v.data = d; v.pitch = pitch; v.gain = gain; v.pan = pan; v.bus = busId;
        v.recalc();
        started[busId]++;
        synchronized (lock) { if (voices.size() < 96) voices.add(v); }
        return v;
    }

    public Voice play(String name, float gain, float pan, float pitch) { return play(name, gain, pan, pitch, SFX); }
    public Voice play(String name, float gain) { return play(name, gain, 0, 1, SFX); }

    /** Positional one-shot: inverse-distance attenuation with range, pan from listener yaw, distance muffling. */
    public Voice playAt(String name, float x, float y, float z, float gain, float range, float pitch, int busId) {
        float dx = x - lx, dy = y - ly, dz = z - lz;
        float d = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (d > range) return new Voice();
        float att = (float) Math.pow(1 - d / range, 1.6) * Math.min(1f, 6f / Math.max(1f, d * 0.4f + 1));
        att = Math.max(att, (1 - d / range) * 0.25f);
        float pan = pan(x, z);
        if (captions != null && gain * att > 0.08f) captions.caption(name, x, y, z, gain * att);
        Voice v = play(name, gain * att, pan * Math.min(1, d / 3f), pitch, busId);
        v.lp = Math.max(0, Math.min(0.93f, (d - 12) / Math.max(40f, range * 0.5f)));
        return v;
    }

    public Voice playAt(String name, float x, float y, float z, float gain, float range, float pitch) { return playAt(name, x, y, z, gain, range, pitch, SFX); }

    public float pan(float x, float z) {
        float dx = x - lx, dz = z - lz;
        // listener right vector for yaw (yaw 0 faces -z): right = (cos, 0, -sin)
        float rx = (float) Math.cos(lyaw), rz = (float) -Math.sin(lyaw);
        float l = (float) Math.sqrt(dx * dx + dz * dz);
        if (l < 1e-3f) return 0;
        return (dx * rx + dz * rz) / l;
    }

    /** Looping bed on a bus, faded in. */
    public Voice loop(String name, float gain, int busId) {
        float[] d = samples.get(name);
        if (d == null) return new Voice();
        Voice v = new Voice();
        v.data = d; v.loop = true; v.gain = gain; v.bus = busId; v.fade = 0;
        v.recalc();
        v.fadeTo(1, 2f);
        started[busId]++;
        synchronized (lock) { voices.add(v); }
        return v;
    }

    public Voice loop(String name, float gain, boolean ambient) { return loop(name, gain, ambient ? AMBIENCE : SFX); }

    public int activeVoices() { synchronized (lock) { return voices.size(); } }
    public void stopAll() { synchronized (lock) { for (Voice v : voices) v.stopped = true; } }
}
