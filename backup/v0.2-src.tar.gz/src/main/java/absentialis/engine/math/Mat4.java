package absentialis.engine.math;

/** Column-major 4x4 float matrix (OpenGL layout). Mutable, allocation-light. */
public final class Mat4 {
    public final float[] m = new float[16];

    public Mat4() { identity(); }

    public Mat4 identity() {
        java.util.Arrays.fill(m, 0f);
        m[0] = m[5] = m[10] = m[15] = 1f;
        return this;
    }

    public Mat4 set(Mat4 o) { System.arraycopy(o.m, 0, m, 0, 16); return this; }

    public Mat4 perspective(float fovyRad, float aspect, float near, float far) {
        java.util.Arrays.fill(m, 0f);
        float f = (float) (1.0 / Math.tan(fovyRad / 2));
        m[0] = f / aspect;
        m[5] = f;
        m[10] = (far + near) / (near - far);
        m[11] = -1f;
        m[14] = (2 * far * near) / (near - far);
        return this;
    }

    public Mat4 ortho(float l, float r, float b, float t, float n, float f) {
        java.util.Arrays.fill(m, 0f);
        m[0] = 2 / (r - l);
        m[5] = 2 / (t - b);
        m[10] = -2 / (f - n);
        m[12] = -(r + l) / (r - l);
        m[13] = -(t + b) / (t - b);
        m[14] = -(f + n) / (f - n);
        m[15] = 1;
        return this;
    }

    private static final ThreadLocal<float[]> TMP = ThreadLocal.withInitial(() -> new float[16]);
    private static final ThreadLocal<Mat4> TMPM = ThreadLocal.withInitial(Mat4::new);

    /** this = this * o */
    public Mat4 mul(Mat4 o) {
        float[] a = m, b = o.m, r = TMP.get();
        for (int c = 0; c < 4; c++) {
            for (int rr = 0; rr < 4; rr++) {
                r[c * 4 + rr] = a[rr] * b[c * 4] + a[4 + rr] * b[c * 4 + 1] + a[8 + rr] * b[c * 4 + 2] + a[12 + rr] * b[c * 4 + 3];
            }
        }
        System.arraycopy(r, 0, m, 0, 16);
        return this;
    }

    public Mat4 translate(float x, float y, float z) {
        m[12] += m[0] * x + m[4] * y + m[8] * z;
        m[13] += m[1] * x + m[5] * y + m[9] * z;
        m[14] += m[2] * x + m[6] * y + m[10] * z;
        m[15] += m[3] * x + m[7] * y + m[11] * z;
        return this;
    }

    public Mat4 scale(float x, float y, float z) {
        for (int i = 0; i < 4; i++) { m[i] *= x; m[4 + i] *= y; m[8 + i] *= z; }
        return this;
    }

    public Mat4 rotateX(float a) {
        Mat4 r = TMPM.get().identity();
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        r.m[5] = c; r.m[6] = s; r.m[9] = -s; r.m[10] = c;
        return mul(r);
    }

    public Mat4 rotateY(float a) {
        Mat4 r = TMPM.get().identity();
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        r.m[0] = c; r.m[2] = -s; r.m[8] = s; r.m[10] = c;
        return mul(r);
    }

    public Mat4 rotateZ(float a) {
        Mat4 r = TMPM.get().identity();
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        r.m[0] = c; r.m[1] = s; r.m[4] = -s; r.m[5] = c;
        return mul(r);
    }

    /** Transforms point (x,y,z,1) and writes into out[0..2]. */
    public void transformPoint(float x, float y, float z, float[] out) {
        float ox = m[0] * x + m[4] * y + m[8] * z + m[12];
        float oy = m[1] * x + m[5] * y + m[9] * z + m[13];
        float oz = m[2] * x + m[6] * y + m[10] * z + m[14];
        out[0] = ox; out[1] = oy; out[2] = oz;
    }

    /** Transforms a direction (x,y,z,0). */
    public void transformDir(float x, float y, float z, float[] out) {
        float ox = m[0] * x + m[4] * y + m[8] * z;
        float oy = m[1] * x + m[5] * y + m[9] * z;
        float oz = m[2] * x + m[6] * y + m[10] * z;
        out[0] = ox; out[1] = oy; out[2] = oz;
    }

    /** Projects world point to clip space; returns w; writes NDC into out. */
    public float project(float x, float y, float z, float[] out) {
        float cx = m[0] * x + m[4] * y + m[8] * z + m[12];
        float cy = m[1] * x + m[5] * y + m[9] * z + m[13];
        float cz = m[2] * x + m[6] * y + m[10] * z + m[14];
        float cw = m[3] * x + m[7] * y + m[11] * z + m[15];
        if (Math.abs(cw) < 1e-6f) cw = 1e-6f;
        out[0] = cx / cw; out[1] = cy / cw; out[2] = cz / cw;
        return cw;
    }
}
