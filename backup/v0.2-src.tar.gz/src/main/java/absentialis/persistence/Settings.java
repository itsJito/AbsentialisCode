package absentialis.persistence;

import absentialis.engine.Input;
import absentialis.engine.util.Json;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/** Global (not per-profile) options: accessibility, audio, controls (GDD 18.3/18.4). */
public final class Settings {
    public float uiScale = 1f, shake = 0.5f, sensitivity = 0.12f, fov = 75, master = 0.8f, sfx = 1f, ambience = 0.7f, music = 0.55f, voice = 1f, uiVolume = 0.8f;
    public boolean muteAll, muteMusic, muteSfx, muteVoice;
    public boolean subtitles = true, hitDirection = true, toggleAim, toggleCrouch = true, showFps;
    public int difficulty = 1; // 0 Recon (relaxed), 1 Standard, 2 Hardcore survival
    public static final String[] DIFFICULTY = {"Recon", "Standard", "Hardcore"};
    private static final Path FILE = Path.of("saves", "settings.json");

    public static Settings load(Input in) {
        Settings s = new Settings();
        try {
            if (!Files.exists(FILE)) return s;
            Map<String, Object> m = Json.parseObject(Files.readString(FILE, StandardCharsets.UTF_8));
            s.uiScale = (float) Json.num(m, "uiScale", 1);
            s.shake = (float) Json.num(m, "shake", 0.5);
            s.sensitivity = (float) Json.num(m, "sensitivity", 0.12);
            s.fov = (float) Json.num(m, "fov", 75);
            s.master = (float) Json.num(m, "master", 0.8);
            s.sfx = (float) Json.num(m, "sfx", 1);
            s.ambience = (float) Json.num(m, "ambience", 0.7);
            s.music = (float) Json.num(m, "music", 0.55);
            s.voice = (float) Json.num(m, "voice", 1);
            s.uiVolume = (float) Json.num(m, "uiVolume", 0.8);
            s.muteAll = Json.bool(m, "muteAll", false);
            s.muteMusic = Json.bool(m, "muteMusic", false);
            s.muteSfx = Json.bool(m, "muteSfx", false);
            s.muteVoice = Json.bool(m, "muteVoice", false);
            s.subtitles = Json.bool(m, "subtitles", true);
            s.hitDirection = Json.bool(m, "hitDirection", true);
            s.toggleAim = Json.bool(m, "toggleAim", false);
            s.toggleCrouch = Json.bool(m, "toggleCrouch", true);
            s.showFps = Json.bool(m, "showFps", false);
            s.difficulty = Json.integer(m, "difficulty", 1);
            for (Map.Entry<String, Object> e : Json.obj(m, "bindings").entrySet())
                if (in.bindings.containsKey(e.getKey()) && e.getValue() instanceof Number n) in.bindings.put(e.getKey(), n.intValue());
        } catch (Exception e) {
            System.err.println("[Settings] " + e.getMessage());
        }
        return s;
    }

    /** Pushes the audio options to the mixer buses (called whenever a slider moves). */
    public void applyAudio(absentialis.engine.audio.AudioEngine a) {
        if (a == null) return;
        a.master = master;
        a.muted = muteAll;
        a.bus[absentialis.engine.audio.AudioEngine.SFX] = sfx;
        a.bus[absentialis.engine.audio.AudioEngine.MUSIC] = music;
        a.bus[absentialis.engine.audio.AudioEngine.VOICE] = voice;
        a.bus[absentialis.engine.audio.AudioEngine.AMBIENCE] = ambience;
        a.bus[absentialis.engine.audio.AudioEngine.UI] = uiVolume;
        a.busMuted[absentialis.engine.audio.AudioEngine.SFX] = muteSfx;
        a.busMuted[absentialis.engine.audio.AudioEngine.MUSIC] = muteMusic;
        a.busMuted[absentialis.engine.audio.AudioEngine.VOICE] = muteVoice;
    }

    public void save(Input in) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("uiScale", (double) uiScale); m.put("shake", (double) shake); m.put("sensitivity", (double) sensitivity); m.put("fov", (double) fov);
        m.put("master", (double) master); m.put("sfx", (double) sfx); m.put("ambience", (double) ambience);
        m.put("music", (double) music); m.put("voice", (double) voice); m.put("uiVolume", (double) uiVolume);
        m.put("muteAll", muteAll); m.put("muteMusic", muteMusic); m.put("muteSfx", muteSfx); m.put("muteVoice", muteVoice);
        m.put("subtitles", subtitles); m.put("hitDirection", hitDirection); m.put("toggleAim", toggleAim); m.put("toggleCrouch", toggleCrouch);
        m.put("showFps", showFps); m.put("difficulty", difficulty);
        m.put("bindings", new LinkedHashMap<String, Object>(in.bindings));
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, Json.write(m), StandardCharsets.UTF_8);
        } catch (Exception e) {
            System.err.println("[Settings] save failed: " + e.getMessage());
        }
    }
}
