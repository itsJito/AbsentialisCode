package absentialis.persistence;

import absentialis.engine.util.Json;
import absentialis.gameplay.inventory.Container;
import absentialis.gameplay.inventory.InventoryService;
import absentialis.gameplay.inventory.Loadout;
import absentialis.gameplay.items.ItemInstance;
import absentialis.gameplay.missions.Contracts;
import absentialis.gameplay.progression.Progression;
import absentialis.sim.ZoneState;
import absentialis.world.World;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * One of four isolated survivor profiles (GDD 4.1): appearance, currency, stash, loadout,
 * progression, reputation, hideout, contracts, world-state branch, map discovery and statistics.
 */
public final class Profile {
    public static final int STASH_W = 10, STASH_BASE_H = 24, MAP_CELL = 8, MAP_CELLS = World.W / MAP_CELL;

    public int slot;
    public String name = "Survivor";
    public int armVariant = 4, skin = 1, outfit = 0, tagColor = 0;
    /** Customization: definition-table ids only (iteration P3). */
    public absentialis.character.Appearance appearance = absentialis.character.Appearance.legacy(1, 0);
    public boolean facePaint = true;
    public long scrip = 1500;
    public long seed = 1337L;
    public final Container stash = new Container("stash", STASH_W, STASH_BASE_H);
    public Loadout loadout = new Loadout();
    public Progression prog = new Progression();
    public final Map<String, Float> rep = new LinkedHashMap<>();
    public final Map<String, Integer> hideout = new LinkedHashMap<>();
    public Contracts contracts = new Contracts();
    public ZoneState zone = ZoneState.fresh();
    public final BitSet discovered = new BitSet(MAP_CELLS * MAP_CELLS);
    public final Map<String, Integer> stats = new LinkedHashMap<>();
    public final Map<String, Integer> recentSales = new LinkedHashMap<>();
    public final List<Map<String, Object>> presets = new ArrayList<>();
    public float health = 100, energy = 80, hydration = 80;
    public long lastFallbackDay = -10;
    public String lastDebrief = "";

    public Profile() {
        for (String f : ZoneState.FACTIONS) rep.put(f, "raiders".equals(f) ? -20f : "mercenaries".equals(f) ? -10f : 0f);
        hideout.put("workbench", 1);
        hideout.put("medical", 1);
        hideout.put("kitchen", 1);
        hideout.put("radio", 0);
        hideout.put("case", 0);
        hideout.put("stash", 0);
    }

    public int level(String facility) {
        int l = hideout.getOrDefault(facility, 0);
        if (prog.tokenUnlocks.contains("hideout:" + facility)) l += 1;
        return l;
    }

    public float rep(String faction) { return rep.getOrDefault(faction, 0f); }
    public void addRep(String faction, float d) { if (rep.containsKey(faction)) rep.put(faction, Math.max(-100, Math.min(100, rep(faction) + d))); }
    public void stat(String k, int d) { stats.merge(k, d, Integer::sum); }
    public int stat(String k) { return stats.getOrDefault(k, 0); }

    /** Applies stash height from rank/prestige/hideout and case size from the case workshop. */
    public void applyCapacity() {
        int rows = STASH_BASE_H + prog.stashRows() + level("stash") * 4;
        stash.h = Math.max(stash.h, rows);
        int c = level("case");
        loadout.resizeCase(Loadout.CASE_W + c, Loadout.CASE_H + c);
    }

    public boolean discovered(int cx, int cz) { return cx >= 0 && cz >= 0 && cx < MAP_CELLS && cz < MAP_CELLS && discovered.get(cx * MAP_CELLS + cz); }

    /** Marks map cells around a world position as reconnoitred; returns newly revealed count. */
    public int discover(float x, float z, int radiusCells) {
        int cx = (int) x / MAP_CELL, cz = (int) z / MAP_CELL, n = 0;
        for (int dx = -radiusCells; dx <= radiusCells; dx++) for (int dz = -radiusCells; dz <= radiusCells; dz++) {
            if (dx * dx + dz * dz > radiusCells * radiusCells) continue;
            int a = cx + dx, b = cz + dz;
            if (a < 0 || b < 0 || a >= MAP_CELLS || b >= MAP_CELLS) continue;
            int i = a * MAP_CELLS + b;
            if (!discovered.get(i)) { discovered.set(i); n++; }
        }
        return n;
    }

    /** Every instance the profile owns (stash + loadout), for audits and uid uniqueness checks. */
    public List<ItemInstance> allItems() {
        List<ItemInstance> out = new ArrayList<>();
        for (ItemInstance i : stash.items) i.collect(out);
        out.addAll(loadout.all());
        return out;
    }

    public String verify() {
        String s = stash.verify();
        if (s != null) return s;
        s = loadout.caseGrid.verify();
        if (s != null) return s;
        java.util.Set<Long> seen = new java.util.HashSet<>();
        for (ItemInstance i : allItems()) if (!seen.add(i.uid)) return "duplicate instance uid " + i.uid + " (" + i.name() + ")";
        if (scrip < 0) return "negative currency";
        return null;
    }

    /** Starting kit for a brand-new profile. */
    public void starterKit() {
        String[][] kit = {{"weapon.akr", "1"}, {"mag.akr", "1"}, {"mag.akr", "1"}, {"ammo.545", "60"}, {"weapon.pm9", "1"}, {"mag.pm9", "1"},
                {"ammo.9x19", "40"}, {"melee.knife", "1"}, {"med.bandage", "1"}, {"med.bandage", "1"}, {"med.painkillers", "2"}, {"food.crackers", "1"},
                {"drink.water", "1"}, {"armor.vest_soft", "1"}, {"helmet.cap", "1"}, {"mat.gun_oil", "2"}, {"att.reddot", "1"}, {"tool.noisemaker", "1"}};
        for (String[] k : kit) {
            ItemInstance i = new ItemInstance(k[0]);
            i.qty = Integer.parseInt(k[1]);
            i.origin = "starter";
            if (i.def().magazine != null) { i.rounds = i.capacity(); i.ammoId = absentialis.gameplay.items.Content.ammoFor(i.def().magazine.caliber).id; }
            InventoryService.add(i, stash);
        }
        ItemInstance charm = new ItemInstance("charm.rabbit");
        charm.origin = "starter";
        InventoryService.add(charm, stash);
    }

    // ------------------------------------------------------------------ persistence
    public Map<String, Object> toJson() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("version", 3);
        m.put("slot", slot);
        m.put("name", name);
        m.put("armVariant", armVariant);
        m.put("skin", skin);
        m.put("outfit", outfit);
        m.put("tagColor", tagColor);
        m.put("appearance", appearance.toJson());
        m.put("facePaint", facePaint);
        m.put("scrip", String.valueOf(scrip));
        m.put("seed", String.valueOf(seed));
        m.put("nextUid", String.valueOf(ItemInstance.peekUid()));
        m.put("stashH", stash.h);
        List<Object> st = new ArrayList<>();
        for (ItemInstance i : stash.items) st.add(i.toJson());
        m.put("stash", st);
        m.put("loadout", loadout.toJson());
        m.put("progression", prog.toJson());
        Map<String, Object> r = new LinkedHashMap<>();
        for (Map.Entry<String, Float> e : rep.entrySet()) r.put(e.getKey(), (double) e.getValue());
        m.put("rep", r);
        m.put("hideout", new LinkedHashMap<String, Object>(hideout));
        m.put("contracts", contracts.toJson());
        m.put("zone", zone.toJson());
        m.put("discovered", java.util.Base64.getEncoder().encodeToString(discovered.toByteArray()));
        m.put("stats", new LinkedHashMap<String, Object>(stats));
        m.put("recentSales", new LinkedHashMap<String, Object>(recentSales));
        m.put("presets", new ArrayList<Object>(presets));
        m.put("health", (double) health);
        m.put("energy", (double) energy);
        m.put("hydration", (double) hydration);
        m.put("lastFallbackDay", String.valueOf(lastFallbackDay));
        m.put("lastDebrief", lastDebrief);
        return m;
    }

    @SuppressWarnings("unchecked")
    public static Profile fromJson(Map<String, Object> m) {
        Profile p = new Profile();
        p.slot = Json.integer(m, "slot", 0);
        p.name = Json.str(m, "name", "Survivor");
        p.armVariant = Json.integer(m, "armVariant", 4);
        p.skin = Json.integer(m, "skin", 1);
        p.outfit = Json.integer(m, "outfit", 0);
        p.tagColor = Json.integer(m, "tagColor", 0);
        p.appearance = m.containsKey("appearance") ? absentialis.character.Appearance.fromJson(Json.obj(m, "appearance")) : absentialis.character.Appearance.legacy(p.skin, p.outfit);
        p.facePaint = Json.bool(m, "facePaint", true);
        ItemInstance.legacyOrientation = Json.integer(m, "version", 2) < 3;
        try { load(p, m); } finally { ItemInstance.legacyOrientation = false; }
        return p;
    }

    @SuppressWarnings("unchecked")
    private static void load(Profile p, Map<String, Object> m) {
        p.scrip = Json.lng(m, "scrip", 0);
        p.seed = Json.lng(m, "seed", 1337L);
        ItemInstance.ensureUidAbove(Json.lng(m, "nextUid", 1) - 1);
        p.stash.h = Json.integer(m, "stashH", STASH_BASE_H);
        for (Object o : Json.list(m, "stash")) { ItemInstance i = ItemInstance.fromJson((Map<String, Object>) o); if (i != null) p.stash.restore(i); }
        p.loadout = Loadout.fromJson(Json.obj(m, "loadout"));
        p.prog = Progression.fromJson(Json.obj(m, "progression"));
        for (Map.Entry<String, Object> e : Json.obj(m, "rep").entrySet()) p.rep.put(e.getKey(), ((Number) e.getValue()).floatValue());
        for (Map.Entry<String, Object> e : Json.obj(m, "hideout").entrySet()) p.hideout.put(e.getKey(), ((Number) e.getValue()).intValue());
        p.contracts = Contracts.fromJson(Json.obj(m, "contracts"));
        p.zone = ZoneState.fromJson(Json.obj(m, "zone"));
        String disc = Json.str(m, "discovered", "");
        if (!disc.isEmpty()) p.discovered.or(BitSet.valueOf(java.util.Base64.getDecoder().decode(disc)));
        for (Map.Entry<String, Object> e : Json.obj(m, "stats").entrySet()) p.stats.put(e.getKey(), ((Number) e.getValue()).intValue());
        for (Map.Entry<String, Object> e : Json.obj(m, "recentSales").entrySet()) p.recentSales.put(e.getKey(), ((Number) e.getValue()).intValue());
        for (Object o : Json.list(m, "presets")) if (o instanceof Map) p.presets.add((Map<String, Object>) o);
        p.health = (float) Json.num(m, "health", 100);
        p.energy = (float) Json.num(m, "energy", 80);
        p.hydration = (float) Json.num(m, "hydration", 80);
        p.lastFallbackDay = Json.lng(m, "lastFallbackDay", -10);
        p.lastDebrief = Json.str(m, "lastDebrief", "");
        p.applyCapacity();
    }
}
