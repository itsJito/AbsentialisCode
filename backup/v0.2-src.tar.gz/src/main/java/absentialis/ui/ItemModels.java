package absentialis.ui;

import absentialis.engine.render.Tex;
import absentialis.engine.voxel.VoxModel;
import absentialis.gameplay.items.ItemDef;
import absentialis.gameplay.items.ItemInstance;
import absentialis.gameplay.weapons.Gunsmith;
import java.util.HashMap;
import java.util.Map;

/**
 * Procedural voxel models for every item. Weapons are assembled from their platform body plus the
 * fitted gunsmith parts (muzzle, barrel, optic, stock, grip, light, magazine, finish) and
 * weathered by condition, so modifications visibly change the silhouette in the case, the
 * inspect view, the first-person viewmodel and on the character. Long axis = X.
 */
public final class ItemModels {
    private ItemModels() {}

    private static final Map<String, VoxModel> CACHE = new HashMap<>();

    static final int METAL = Tex.rgb(52, 54, 58), METAL_LT = Tex.rgb(96, 100, 106), POLY = Tex.rgb(34, 35, 37), WOOD = Tex.rgb(122, 74, 38),
            WOOD_DK = Tex.rgb(88, 52, 26), STEEL = Tex.rgb(140, 144, 150), BRASS = Tex.rgb(196, 160, 70), OLIVE = Tex.rgb(86, 96, 60),
            RED = Tex.rgb(170, 40, 36), WHITE = Tex.rgb(220, 218, 210), CLOTH = Tex.rgb(196, 190, 170), GLASS = 0xC060A0C0;

    public static VoxModel of(ItemInstance it) {
        String key = it.visualKey();
        VoxModel m = CACHE.get(key);
        if (m == null) {
            m = build(it);
            if (CACHE.size() > 600) CACHE.clear();
            CACHE.put(key, m);
        }
        return m;
    }

    public static VoxModel of(ItemDef d) {
        return CACHE.computeIfAbsent("def:" + d.id, k -> build(new ItemInstance(-9, d.id)));
    }

    private static VoxModel build(ItemInstance it) {
        ItemDef d = it.def();
        VoxModel m;
        if (d.weapon != null) m = weapon(it);
        else m = misc(d);
        return m.jitter(0.06f, d.id.hashCode());
    }

    // ------------------------------------------------------------------ weapons
    private static VoxModel weapon(ItemInstance it) {
        ItemDef d = it.def();
        String model = d.weapon.model;
        int tint = Gunsmith.finishTint(it);
        int body = tint != 0 ? tint : POLY, metal = tint != 0 ? Tex.shade(tint, 0.75f) : METAL;
        boolean longB = it.attachments.containsKey("barrel") && it.attachment("barrel").defId.equals("att.barrel_long");
        boolean shortB = it.attachments.containsKey("barrel") && it.attachment("barrel").defId.equals("att.barrel_short");
        int bx = longB ? 5 : shortB ? -4 : 0;
        VoxModel m;
        int muzzleX, boreY, topY, opticX, gripX, magX, railZ = 2;
        switch (model) {
            case "pistol" -> {
                m = new VoxModel(22, 14, 5);
                m.box(2, 7, 1, 13 + bx / 2, 10, 3, metal);           // slide
                m.box(2, 10, 2, 3, 11, 2, METAL_LT);                  // rear sight
                m.box(12, 10, 2, 12, 11, 2, METAL_LT);
                m.box(2, 1, 1, 6, 7, 3, body);                         // grip
                m.box(6, 5, 2, 8, 6, 2, metal);                        // trigger guard
                muzzleX = 14 + bx / 2; boreY = 9; topY = 11; opticX = 6; gripX = 9; magX = 3;
            }
            case "revolver" -> {
                m = new VoxModel(24, 14, 6);
                m.box(8, 8, 1, 18 + bx / 2, 10, 3, STEEL);            // barrel
                m.cylX(6, 10, 8, 2.5f, 3f, STEEL);                     // cylinder
                m.box(3, 7, 1, 7, 11, 3, STEEL);                       // frame
                m.box(1, 1, 1, 5, 7, 3, WOOD);                         // grip
                muzzleX = 19 + bx / 2; boreY = 9; topY = 11; opticX = 10; gripX = 12; magX = -1;
            }
            case "mosin" -> {
                m = new VoxModel(56, 14, 5);
                m.box(0, 3, 1, 14, 8, 3, WOOD); m.box(0, 2, 1, 4, 3, 3, WOOD_DK);
                m.box(15, 5, 1, 38, 8, 3, WOOD);                       // fore stock
                m.box(14, 8, 2, 46 + bx, 9, 2, metal);                 // barrel
                m.box(16, 8, 1, 24, 10, 3, metal);                     // receiver
                m.box(22, 9, 3, 22, 10, 4, STEEL); m.box(22, 10, 4, 22, 10, 4, STEEL); // bolt handle
                muzzleX = 47 + bx; boreY = 8; topY = 10; opticX = 18; gripX = 30; magX = -1;
            }
            case "shotgun" -> {
                m = new VoxModel(52, 14, 5);
                boolean folding = it.attachments.containsKey("stock");
                if (!folding) { m.box(0, 3, 1, 12, 8, 3, WOOD); m.box(0, 2, 1, 3, 3, 3, WOOD_DK); }
                m.box(12, 5, 1, 22, 10, 3, metal);                     // receiver
                m.box(22, 8, 2, 44 + bx, 9, 2, metal);                 // barrel
                m.box(22, 6, 2, 40 + bx, 7, 2, METAL_LT);              // tube
                m.box(27, 5, 1, 34, 7, 3, WOOD);                       // pump
                m.box(14, 1, 1, 16, 5, 3, WOOD);                       // grip
                muzzleX = 45 + bx; boreY = 8; topY = 10; opticX = 15; gripX = 30; magX = -1;
            }
            case "lmg" -> {
                m = new VoxModel(56, 16, 7);
                m.box(0, 5, 2, 10, 10, 4, body);
                m.box(11, 6, 1, 26, 12, 5, metal);                     // receiver
                m.box(26, 9, 2, 48 + bx, 10, 3, metal);                // barrel
                m.box(26, 8, 1, 36, 11, 5, METAL_LT);                  // shroud
                m.box(44 + bx, 3, 3, 44 + bx, 8, 3, METAL);            // bipod
                m.box(13, 1, 2, 15, 6, 4, body);                       // grip
                m.box(17, 12, 2, 24, 13, 4, METAL_LT);                 // feed cover
                muzzleX = 49 + bx; boreY = 9; topY = 13; opticX = 17; gripX = 32; magX = 18;
            }
            case "knife" -> {
                m = new VoxModel(16, 6, 3);
                m.box(0, 2, 1, 5, 3, 1, POLY); m.box(5, 1, 1, 5, 4, 1, METAL);
                m.box(6, 2, 1, 15, 3, 1, STEEL); m.box(6, 3, 1, 13, 3, 1, METAL_LT);
                return m;
            }
            case "crowbar" -> {
                m = new VoxModel(28, 8, 3);
                m.box(2, 3, 1, 25, 3, 1, Tex.rgb(150, 40, 34));
                m.box(0, 4, 1, 1, 5, 1, Tex.rgb(150, 40, 34)); m.box(25, 1, 1, 27, 2, 1, Tex.rgb(150, 40, 34));
                return m;
            }
            default -> { // akr / sr16 carbines
                boolean ar = model.equals("sr16");
                m = new VoxModel(52, 16, 5);
                int furn = ar ? body : WOOD;
                if (!it.attachments.containsKey("stock")) {
                    if (ar) { m.box(0, 6, 1, 3, 11, 3, body); m.box(4, 8, 2, 9, 10, 2, metal); }
                    else { m.box(0, 4, 1, 4, 10, 3, furn); m.box(5, 7, 1, 9, 10, 3, furn); }
                }
                m.box(10, 7, 1, 22, 11, 3, metal);                      // receiver
                if (ar) m.box(10, 12, 2, 30, 12, 2, METAL_LT);           // flat-top rail
                else m.box(11, 12, 2, 19, 12, 2, metal);                 // dust cover ridge
                m.box(23, 7, 1, 31, 11, 3, ar ? body : furn);           // handguard
                m.box(31, 9, 2, 40 + bx, 10, 2, metal);                 // barrel
                m.box(36, 10, 2, 36, 12, 2, metal);                     // front sight
                m.box(12, 2, 1, 14, 7, 3, body);                        // pistol grip
                muzzleX = 41 + bx; boreY = 9; topY = 12; opticX = 14; gripX = 26; magX = 16;
            }
        }
        // magazine
        if (magX >= 0 && it.mag != null) {
            ItemDef md = it.mag.def();
            int mc = md.magazine.capacity >= 60 ? METAL : (model.equals("akr") ? Tex.rgb(150, 82, 40) : POLY);
            if (md.magazine.capacity >= 60) m.cylX(magX - 1, magX + 3, 3.5f, 2.5f, 3.2f, mc);
            else if (model.equals("pistol")) m.box(magX, 0, 1, magX + 2, 1, 3, METAL_LT);
            else if (model.equals("lmg")) m.box(magX - 2, 0, 0, magX + 4, 6, 6, OLIVE);
            else for (int k = 0; k < 6; k++) m.box(magX + (model.equals("akr") ? k / 2 : 0), 6 - k, 1, magX + 2 + (model.equals("akr") ? k / 2 : 0), 6 - k, 3, mc);
        }
        // parts
        for (Map.Entry<String, ItemInstance> e : it.attachments.entrySet()) {
            String s = e.getKey(), id = e.getValue().defId;
            switch (s) {
                case "muzzle" -> {
                    if (id.contains("suppressor")) m.cylX(muzzleX, Math.min(m.sx - 1, muzzleX + 9), boreY + 0.5f, railZ + 0.5f, 1.8f, POLY);
                    else m.box(muzzleX, boreY - 1, railZ - 1, Math.min(m.sx - 1, muzzleX + 2), boreY + 1, railZ + 1, METAL_LT);
                }
                case "optic" -> {
                    if (id.contains("scope")) { m.cylX(opticX, opticX + 12, topY + 2.5f, railZ + 0.5f, 1.6f, POLY); m.box(opticX + 5, topY, railZ, opticX + 6, topY + 1, railZ, METAL); m.set(opticX, topY + 2, railZ, GLASS); }
                    else { m.box(opticX, topY, railZ - 1, opticX + 3, topY + 1, railZ + 1, POLY); m.box(opticX + 1, topY + 2, railZ - 1, opticX + 2, topY + 3, railZ + 1, POLY); m.set(opticX + 1, topY + 2, railZ, Tex.rgb(220, 40, 40)); }
                }
                case "grip" -> m.box(gripX, Math.max(0, boreY - 6), railZ, gripX + 1, boreY - 2, railZ, POLY);
                case "light" -> m.box(gripX + 2, boreY - 1, Math.min(m.sz - 1, railZ + 2), gripX + 5, boreY, Math.min(m.sz - 1, railZ + 2), METAL_LT);
                case "stock" -> {
                    if (id.contains("folding")) m.box(0, 9, 2, 9, 9, 2, METAL_LT);
                    else { m.box(0, 5, 1, 3, 11, 3, POLY); m.box(4, 8, 1, 9, 10, 3, POLY); }
                }
                default -> {}
            }
        }
        return m.weather(1f - it.condition() / 100f, (int) it.uid);
    }

    // ------------------------------------------------------------------ everything else
    private static VoxModel misc(ItemDef d) {
        String icon = d.icon == null ? d.category : d.icon;
        int h = Math.abs(d.id.hashCode());
        VoxModel m;
        switch (d.category) {
            case "magazine" -> {
                if (d.magazine.capacity >= 60 && d.magazine.magType.equals("stanag")) { m = new VoxModel(10, 10, 6); m.cylY(0, 4, 5, 3, 3.6f, POLY); m.cylY(5, 9, 5, 3, 3.6f, POLY); m.box(4, 7, 2, 6, 9, 3, METAL); }
                else if (d.magazine.magType.equals("belt")) { m = new VoxModel(10, 8, 7); m.box(0, 0, 0, 9, 6, 6, OLIVE); m.box(3, 7, 3, 6, 7, 3, METAL); }
                else if (d.magazine.magType.equals("pm9")) { m = new VoxModel(4, 10, 3); m.box(0, 0, 0, 3, 9, 2, METAL); m.box(0, 9, 1, 2, 9, 1, BRASS); }
                else { m = new VoxModel(8, 16, 4); int c = d.magazine.magType.equals("akr") ? Tex.rgb(150, 82, 40) : POLY;
                    for (int k = 0; k < 15; k++) m.box(k / 4, k, 0, k / 4 + 3, k, 3, c); m.box(3, 15, 1, 5, 15, 2, BRASS); }
            }
            case "ammo" -> {
                m = new VoxModel(14, 6, 8);
                int box = icon.contains("shell") ? Tex.rgb(150, 40, 30) : icon.contains("heavy") ? OLIVE : Tex.rgb(110, 98, 70);
                m.box(0, 0, 0, 13, 3, 7, box);
                for (int k = 0; k < 5; k++) m.box(1 + k * 2 + 1, 4, 2, 1 + k * 2 + 1, 5, 2, icon.contains("shell") ? RED : BRASS);
                m.box(2, 2, 0, 11, 2, 0, WHITE);
            }
            case "attachment" -> {
                if (d.attachment.socket.equals("finish")) { m = new VoxModel(8, 10, 4); m.box(1, 0, 0, 6, 7, 3, d.attachment.tint == 0 ? STEEL : d.attachment.tint); m.box(2, 8, 1, 5, 9, 2, METAL); }
                else if (d.attachment.socket.equals("muzzle")) { m = new VoxModel(14, 5, 5); if (d.id.contains("suppressor")) m.cylX(0, 13, 2.5f, 2.5f, 2.2f, POLY); else { m.cylX(0, 5, 2.5f, 2.5f, 1.8f, METAL_LT); m.box(1, 2, 0, 4, 2, 4, METAL); } }
                else if (d.attachment.socket.equals("optic")) { m = new VoxModel(14, 8, 5); if (d.id.contains("scope")) { m.cylX(0, 13, 5, 2.5f, 2.2f, POLY); m.box(5, 0, 2, 7, 2, 2, METAL); m.set(0, 5, 2, GLASS); } else { m.box(3, 0, 1, 9, 2, 3, POLY); m.box(4, 3, 1, 8, 6, 3, POLY); m.set(6, 5, 2, Tex.rgb(220, 40, 40)); } }
                else if (d.attachment.socket.equals("barrel")) { m = new VoxModel(20, 5, 5); m.cylX(0, d.id.contains("short") ? 9 : 19, 2.5f, 2.5f, 1.4f, d.id.contains("chrome") ? STEEL : METAL); }
                else if (d.attachment.socket.equals("stock")) { m = new VoxModel(14, 9, 4); if (d.id.contains("folding")) { m.box(0, 4, 1, 12, 5, 2, METAL_LT); m.box(0, 0, 1, 1, 8, 2, METAL_LT); } else { m.box(0, 0, 1, 4, 8, 2, POLY); m.box(5, 4, 1, 13, 6, 2, POLY); } }
                else if (d.attachment.socket.equals("grip")) { m = new VoxModel(6, 10, 4); m.box(1, 0, 1, 3, 9, 2, POLY); m.box(0, 9, 0, 5, 9, 3, METAL); }
                else { m = new VoxModel(8, 5, 5); m.cylX(0, 7, 2.5f, 2.5f, 2f, METAL_LT); m.box(7, 1, 1, 7, 3, 3, Tex.rgb(240, 230, 160)); }
            }
            case "medical" -> {
                if (icon.contains("bandage")) { m = new VoxModel(8, 8, 8); m.cylY(0, 7, 4, 4, 3.6f, CLOTH); m.cylY(0, 7, 4, 4, 1.2f, 0); }
                else if (icon.contains("pills")) { m = new VoxModel(6, 10, 6); m.cylY(0, 7, 3, 3, 2.8f, icon.contains("green") ? Tex.rgb(70, 140, 70) : Tex.rgb(200, 130, 40)); m.cylY(8, 9, 3, 3, 2.8f, WHITE); }
                else if (icon.contains("injector")) { m = new VoxModel(16, 4, 4); m.box(0, 1, 1, 10, 2, 2, Tex.rgb(80, 160, 90)); m.box(11, 1, 1, 15, 1, 1, STEEL); m.box(0, 0, 0, 1, 3, 3, POLY); }
                else if (icon.contains("tourniquet")) { m = new VoxModel(10, 4, 10); for (int k = 0; k < 10; k++) { m.set(k, 1, 0, POLY); m.set(k, 1, 9, POLY); m.set(0, 1, k, POLY); m.set(9, 1, k, POLY); } m.box(3, 2, 3, 6, 3, 6, RED); }
                else if (icon.contains("splint")) { m = new VoxModel(14, 3, 6); m.box(0, 0, 0, 13, 0, 1, Tex.rgb(200, 120, 40)); m.box(0, 0, 4, 13, 0, 5, Tex.rgb(200, 120, 40)); m.box(3, 1, 0, 4, 2, 5, CLOTH); m.box(9, 1, 0, 10, 2, 5, CLOTH); }
                else if (icon.contains("spray")) { m = new VoxModel(6, 14, 6); m.cylY(0, 10, 3, 3, 2.8f, WHITE); m.box(2, 4, 0, 3, 6, 0, RED); m.cylY(11, 13, 3, 3, 1.4f, POLY); }
                else { m = new VoxModel(14, 8, 12); m.box(0, 0, 0, 13, 7, 11, Tex.rgb(170, 36, 32)); m.box(5, 2, 0, 8, 5, 0, WHITE); m.box(3, 3, 0, 10, 4, 0, WHITE); m.box(4, 8 - 1, 4, 9, 7, 7, METAL); }
            }
            case "food" -> {
                if (icon.contains("bottle")) { m = new VoxModel(6, 16, 6); int c = icon.contains("dirty") ? 0xD0807050 : 0xC080B0D0; m.cylY(0, 11, 3, 3, 2.8f, c); m.cylY(12, 13, 3, 3, 1.6f, c); m.cylY(14, 15, 3, 3, 1.4f, Tex.rgb(40, 90, 170)); m.box(1, 5, 0, 4, 8, 0, WHITE); }
                else if (icon.contains("can") || icon.contains("soda") || icon.contains("coffee")) { m = new VoxModel(8, 10, 8); int c = icon.contains("soda") ? RED : icon.contains("coffee") ? Tex.rgb(90, 60, 40) : Tex.rgb(160, 150, 130); m.cylY(0, 9, 4, 4, 3.6f, c); m.cylY(9, 9, 4, 4, 3.6f, STEEL); m.box(2, 3, 0, 5, 6, 0, WHITE); }
                else if (icon.contains("meat")) { m = new VoxModel(10, 5, 8); m.sphere(5, 2, 4, 4f, Tex.rgb(150, 60, 60)); m.box(8, 2, 3, 9, 3, 4, WHITE); }
                else { m = new VoxModel(12, 4, 14); m.box(0, 0, 0, 11, 3, 13, icon.contains("mre") ? Tex.rgb(130, 112, 70) : Tex.rgb(200, 170, 100)); m.box(3, 3, 3, 8, 3, 10, icon.contains("mre") ? Tex.rgb(90, 80, 50) : WHITE); }
            }
            case "armor" -> {
                if (d.slot.equals("head")) { m = new VoxModel(12, 9, 12); if (icon.contains("cap")) { m.sphere(6, 1, 6, 5f, OLIVE); m.box(0, 0, 0, 11, 8, 11, 0); m.sphere(6, 1, 6, 5f, OLIVE); m.box(0, 0, 6, 11, 1, 11, 0); m.box(3, 0, 10, 8, 1, 11, OLIVE); } else { m.sphere(6, 1, 6, 6f, Tex.rgb(80, 92, 64)); } }
                else if (d.slot.equals("face")) { m = new VoxModel(10, 10, 6); if (icon.contains("gas")) { m.box(1, 2, 0, 8, 8, 4, Tex.rgb(60, 64, 60)); m.cylX(0, 2, 4, 2, 1.4f, GLASS); m.cylX(7, 9, 4, 2, 1.4f, GLASS); m.cylY(0, 2, 5, 1, 2f, POLY); } else m.box(1, 1, 0, 8, 9, 3, POLY); }
                else { m = new VoxModel(14, 16, 6); int c = icon.contains("plate") ? Tex.rgb(70, 74, 66) : icon.contains("mil") ? OLIVE : Tex.rgb(46, 52, 70);
                    m.box(0, 0, 0, 13, 13, 5, c); m.box(3, 10, 0, 10, 15, 5, 0); m.box(0, 14, 1, 2, 15, 4, c); m.box(11, 14, 1, 13, 15, 4, c);
                    if (icon.contains("mil") || icon.contains("plate")) for (int k = 0; k < 3; k++) m.box(2 + k * 4, 2, 0, 4 + k * 4, 5, 0, Tex.shade(c, 0.7f)); }
            }
            case "backpack" -> { m = new VoxModel(12, 14, 8); m.box(0, 0, 1, 11, 12, 7, icon.contains("large") ? OLIVE : Tex.rgb(70, 60, 50)); m.box(2, 2, 0, 9, 6, 0, Tex.rgb(50, 44, 38)); m.box(4, 13, 3, 7, 13, 4, POLY); }
            case "explosive" -> {
                if (icon.equals("grenade")) { m = new VoxModel(8, 10, 8); m.sphere(4, 4, 4, 3.6f, OLIVE); m.box(3, 7, 3, 4, 9, 4, METAL); m.box(5, 8, 3, 6, 8, 3, STEEL); }
                else if (icon.equals("clock")) { m = new VoxModel(10, 10, 5); m.cylX(0, 0, 0, 0, 0, 0); m.sphere(5, 5, 2.5f, 4.2f, RED); m.box(1, 2, 0, 8, 8, 4, 0); m.sphere(5, 5, 2.5f, 4f, RED); m.box(3, 3, 0, 6, 6, 0, WHITE); m.box(2, 9, 2, 2, 9, 2, BRASS); m.box(7, 9, 2, 7, 9, 2, BRASS); }
                else { m = new VoxModel(5, 14, 5); m.cylY(0, 12, 2.5f, 2.5f, 2.2f, icon.contains("flare") ? RED : METAL); m.cylY(13, 13, 2.5f, 2.5f, 1.2f, icon.contains("flare") ? WHITE : POLY); }
            }
            case "charm" -> { m = new VoxModel(6, 10, 3); m.box(2, 8, 1, 3, 9, 1, BRASS); m.sphere(3, 4, 1.5f, 3f, h % 2 == 0 ? Tex.rgb(200, 190, 160) : BRASS); }
            case "treasure" -> {
                if (icon.contains("map")) { m = new VoxModel(12, 2, 10); m.box(0, 0, 0, 11, 0, 9, Tex.rgb(200, 180, 130)); m.box(2, 1, 2, 9, 1, 2, Tex.rgb(140, 90, 50)); m.box(4, 1, 5, 7, 1, 7, Tex.rgb(120, 70, 40)); }
                else if (icon.contains("gem")) { m = new VoxModel(6, 6, 6); m.sphere(3, 3, 3, 2.9f, Tex.rgb(200, 30, 60)); m.set(2, 4, 2, Tex.rgb(255, 160, 180)); }
                else { m = new VoxModel(8, 12, 8); m.cylY(0, 1, 4, 4, 3f, BRASS); m.cylY(2, 6, 4, 4, 1f, BRASS); m.cylY(7, 11, 4, 4, 3.5f, BRASS); m.cylY(8, 11, 4, 4, 2.4f, 0); if (icon.contains("gem")) m.set(4, 9, 0, RED); }
            }
            case "herb" -> { m = new VoxModel(8, 10, 8); int c = icon.contains("red") ? Tex.rgb(170, 40, 50) : Tex.rgb(60, 140, 60); m.box(3, 0, 3, 4, 5, 4, Tex.rgb(60, 90, 40)); m.sphere(4, 6, 4, 3.4f, c); m.sphere(2, 8, 3, 1.6f, c); }
            case "key" -> { m = new VoxModel(12, 6, 2); if (icon.contains("card")) { m.box(0, 0, 0, 11, 5, 0, WHITE); m.box(1, 3, 0, 4, 4, 0, Tex.rgb(40, 90, 170)); } else { m.box(0, 1, 0, 3, 4, 1, BRASS); m.box(4, 2, 0, 11, 3, 0, BRASS); m.box(9, 0, 0, 9, 1, 0, BRASS); m.box(11, 0, 0, 11, 1, 0, BRASS); } }
            case "document" -> { m = new VoxModel(10, 2, 12); m.box(0, 0, 0, 9, 0, 11, icon.contains("drive") ? POLY : WHITE); if (!icon.contains("drive")) for (int k = 2; k < 10; k += 2) m.box(1, 1, k, 8, 1, k, Tex.rgb(60, 60, 70)); }
            case "valuable" -> {
                if (icon.contains("cash")) { m = new VoxModel(12, 3, 6); m.box(0, 0, 0, 11, 2, 5, Tex.rgb(110, 140, 90)); m.box(5, 0, 0, 6, 3, 5, WHITE); }
                else if (icon.contains("gpu")) { m = new VoxModel(18, 4, 8); m.box(0, 0, 0, 17, 1, 7, Tex.rgb(30, 90, 50)); m.box(2, 2, 1, 15, 3, 6, POLY); m.cylY(2, 3, 6, 4, 2.2f, METAL); m.cylY(2, 3, 12, 4, 2.2f, METAL); }
                else if (icon.contains("chain") || icon.contains("watch")) { m = new VoxModel(10, 3, 10); for (int k = 0; k < 10; k++) { m.set(k, 0, 0, BRASS); m.set(k, 0, 9, BRASS); m.set(0, 0, k, BRASS); m.set(9, 0, k, BRASS); } if (icon.contains("watch")) { m.box(3, 0, 3, 6, 2, 6, STEEL); m.box(4, 2, 4, 5, 2, 5, WHITE); } }
                else if (icon.contains("artifact")) { m = new VoxModel(6, 14, 6); m.box(2, 0, 2, 3, 13, 3, Tex.rgb(120, 230, 200)); m.box(1, 3, 1, 4, 9, 4, 0xC060D0B0); m.box(2, 0, 2, 3, 13, 3, Tex.rgb(160, 250, 220)); }
                else if (icon.contains("icon_art")) { m = new VoxModel(14, 16, 2); m.box(0, 0, 0, 13, 15, 1, BRASS); m.box(2, 2, 0, 11, 13, 0, Tex.rgb(140, 40, 30)); m.box(5, 9, 0, 8, 12, 0, Tex.rgb(220, 190, 150)); }
                else { m = new VoxModel(8, 6, 6); m.box(0, 0, 0, 7, 5, 5, Tex.rgb(80 + h % 100, 80 + (h >> 3) % 80, 60 + (h >> 5) % 80)); m.box(2, 5, 2, 5, 5, 3, STEEL); }
            }
            case "quest" -> { m = new VoxModel(12, 10, 10); m.box(0, 0, 0, 11, 9, 9, Tex.rgb(150, 120, 80)); m.box(0, 4, 0, 11, 5, 9, Tex.rgb(200, 170, 60)); m.box(5, 0, 0, 6, 9, 9, Tex.rgb(200, 170, 60)); }
            default -> { // materials / tools
                if (icon.contains("fuel")) { m = new VoxModel(10, 14, 6); m.box(0, 0, 0, 9, 11, 5, RED); m.box(2, 12, 2, 7, 13, 3, POLY); }
                else if (icon.contains("oil")) { m = new VoxModel(6, 12, 6); m.cylY(0, 8, 3, 3, 2.6f, Tex.rgb(200, 160, 40)); m.cylY(9, 11, 3, 3, 1f, POLY); }
                else if (icon.contains("scrap") || icon.contains("parts")) { m = new VoxModel(14, 5, 8); m.box(0, 0, 0, 9, 1, 5, METAL_LT); m.box(5, 2, 2, 13, 3, 7, Tex.rgb(130, 80, 50)); m.box(2, 2, 1, 3, 4, 2, STEEL); }
                else if (icon.contains("tape")) { m = new VoxModel(8, 4, 8); m.cylY(0, 3, 4, 4, 3.8f, Tex.rgb(150, 150, 150)); m.cylY(0, 3, 4, 4, 1.8f, 0); }
                else if (icon.contains("circuit") || icon.contains("electrical")) { m = new VoxModel(12, 3, 10); m.box(0, 0, 0, 11, 0, 9, Tex.rgb(30, 110, 60)); m.box(2, 1, 2, 4, 2, 4, POLY); m.box(7, 1, 5, 9, 1, 8, BRASS); }
                else if (icon.contains("repairkit") || icon.contains("camera")) { m = new VoxModel(14, 10, 10); m.box(0, 0, 0, 13, 8, 9, icon.contains("camera") ? POLY : Tex.rgb(170, 50, 40)); m.box(4, 9, 4, 9, 9, 5, METAL); if (icon.contains("camera")) m.cylX(13, 13, 4, 5, 2, GLASS); }
                else { m = new VoxModel(10, 8, 10); int c = Tex.rgb(90 + h % 90, 90 + (h >> 4) % 70, 80 + (h >> 8) % 60); m.box(0, 0, 0, 9, 6, 9, c); m.box(0, 7, 0, 9, 7, 9, Tex.shade(c, 1.2f)); m.box(3, 3, 0, 6, 4, 0, Tex.shade(c, 0.6f)); }
            }
        }
        return m;
    }
}
