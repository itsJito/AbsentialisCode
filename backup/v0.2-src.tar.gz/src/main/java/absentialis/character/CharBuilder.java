package absentialis.character;

import static absentialis.character.Rig.*;

import absentialis.character.CharDefs.Category;
import absentialis.engine.render.Tex;
import absentialis.engine.util.Rng;
import java.util.List;

/**
 * Combines a small library of parts into one character model at runtime: naked body, then the
 * selected definition-table parts, then visible equipment (headgear, face cover, armour, pack) and
 * finally infected mutations. Equipment changes the silhouette; nothing here mutates a part.
 */
public final class CharBuilder {
    private CharBuilder() {}

    /** Visible equipment and faction dressing layered over an {@link Appearance}. */
    public static final class Gear {
        public String head = "", face = "", vest = "", pack = "";
        /** Uniform colour forced onto torso and sleeves (0 = keep the garment's own colour). */
        public int uniform, gearColor = Tex.rgb(70, 76, 64);
        public boolean facePaint, helmetMarks;
        /** Infected archetype ("" for humans): walker, sprinter, boomer, tank ... */
        public String infected = "";

        public String key() { return head + "|" + face + "|" + vest + "|" + pack + "|" + uniform + "|" + gearColor + "|" + (facePaint ? 1 : 0) + (helmetMarks ? 1 : 0) + "|" + infected; }
    }

    private static final Category[] ORDER = {Category.HEAD, Category.LEGS, Category.FEET, Category.TORSO, Category.SLEEVES, Category.HANDS, Category.HAIR, Category.FACIAL_HAIR};

    public static String key(Appearance a, Gear g) { return a.key() + g.key(); }

    public static CharModel build(Appearance a, Gear g) {
        CharModel m = new CharModel();
        CharDefs.Ctx c = new CharDefs.Ctx();
        c.skin = CharDefs.SKIN_TONES[a.get(Category.SKIN)];
        c.hair = CharDefs.HAIR_TONES[a.get(Category.HAIR_COLOR)];
        c.infected = !g.infected.isEmpty();
        if (c.infected) { c.skin = Tex.mix(c.skin, Tex.rgb(146, 158, 118), 0.62f); c.hair = Tex.shade(c.hair, 0.7f); }
        int[] tc = CharDefs.torsoColors(a.part(Category.TORSO));
        c.cloth = g.uniform != 0 ? g.uniform : tc[0];
        c.cloth2 = g.uniform != 0 ? Tex.shade(g.uniform, 0.74f) : tc[1];
        if (c.infected) { c.cloth = Tex.shade(c.cloth, 0.62f); c.cloth2 = Tex.shade(c.cloth2, 0.55f); }
        CharDefs.body(m, c);
        for (Category cat : ORDER) a.part(cat).painter().paint(m, c);
        if (g.facePaint) { m.tint(HEAD, 2, 4, 2, 9, 5, 2, Tex.rgb(40, 60, 44)); m.tint(HEAD, 2, 8, 2, 9, 8, 2, Tex.rgb(30, 30, 30)); }
        gear(m, g, c);
        if (c.infected) mutate(m, g.infected, c, a.key().hashCode());
        m.finish(key(a, g).hashCode());
        return m;
    }

    private static void gear(CharModel m, Gear g, CharDefs.Ctx c) {
        int gc = g.gearColor, dark = Tex.shade(gc, 0.72f);
        if (!g.head.isEmpty()) m.box(HEAD, 0, 10, 0, 11, 13, 11, 0); // headgear sits on the skull: hair above the brow is tucked in
        switch (g.head) {
            case "cap" -> { m.box(HEAD, 2, 10, 2, 9, 10, 9, gc); m.shell(HEAD, 1, 9, 2, 1, 9, 9, gc); m.shell(HEAD, 10, 9, 2, 10, 9, 9, gc); m.shell(HEAD, 2, 9, 10, 9, 9, 10, gc); m.box(HEAD, 2, 9, 0, 9, 9, 1, dark); }
            case "helmet" -> {
                m.shell(HEAD, 1, 7, 1, 10, 10, 10, gc); m.box(HEAD, 2, 11, 2, 9, 11, 9, gc);
                m.box(HEAD, 2, 7, 1, 9, 9, 1, 0); m.box(HEAD, 1, 10, 1, 10, 10, 1, dark);
                m.shell(HEAD, 1, 4, 4, 1, 6, 4, dark); m.shell(HEAD, 10, 4, 4, 10, 6, 4, dark);
                if (g.helmetMarks) { m.box(HEAD, 5, 9, 10, 6, 10, 10, Tex.rgb(220, 216, 200)); m.box(HEAD, 10, 9, 5, 10, 9, 7, Tex.rgb(200, 60, 40)); }
            }
            case "beanie" -> { m.box(HEAD, 2, 10, 2, 9, 11, 9, gc); m.shell(HEAD, 1, 8, 1, 10, 9, 10, dark); m.box(HEAD, 3, 12, 3, 8, 12, 8, gc); }
            case "hood" -> { m.shell(HEAD, 1, 3, 3, 10, 9, 10, gc); m.box(HEAD, 1, 10, 1, 10, 11, 10, gc); m.shell(HEAD, 1, 9, 1, 10, 9, 2, dark); }
            default -> {}
        }
        switch (g.face) {
            case "gasmask" -> {
                int rubber = Tex.rgb(38, 42, 40);
                m.box(HEAD, 2, 2, 1, 9, 7, 1, rubber); m.box(HEAD, 3, 5, 0, 4, 6, 0, Tex.rgb(120, 150, 150)); m.box(HEAD, 7, 5, 0, 8, 6, 0, Tex.rgb(120, 150, 150));
                m.box(HEAD, 5, 2, 0, 6, 3, 0, Tex.rgb(80, 84, 80)); m.box(HEAD, 1, 5, 2, 1, 5, 9, rubber); m.box(HEAD, 10, 5, 2, 10, 5, 9, rubber);
            }
            case "balaclava" -> { int k = Tex.rgb(32, 34, 38); for (int x = 2; x <= 9; x++) for (int y = 2; y <= 9; y++) for (int z = 2; z <= 9; z++) { boolean eyes = z == 2 && y == 6 && x >= 3 && x <= 8; if (!eyes && m.get(HEAD, x, y, z) != 0) m.set(HEAD, x, y, z, k); } m.box(HEAD, 5, 4, 1, 6, 5, 1, k); }
            case "bandana" -> { int k = Tex.rgb(150, 32, 30); m.box(HEAD, 2, 2, 1, 9, 4, 1, k); m.box(HEAD, 1, 3, 2, 1, 4, 9, k); m.box(HEAD, 10, 3, 2, 10, 4, 9, k); m.box(HEAD, 2, 3, 10, 9, 4, 10, k); m.box(HEAD, 4, 1, 1, 7, 1, 1, k); }
            default -> {}
        }
        switch (g.vest) {
            case "soft" -> { int k = Tex.rgb(52, 58, 72); m.shell(TORSO, 2, 3, 3, 11, 10, 8, k); m.tint(TORSO, 3, 3, 4, 10, 10, 7, k); m.box(TORSO, 4, 10, 3, 5, 11, 8, k); m.box(TORSO, 8, 10, 3, 9, 11, 8, k); }
            case "plate", "mil" -> {
                boolean plate = g.vest.equals("plate");
                m.shell(TORSO, 2, 3, 3, 11, 10, 8, gc); m.tint(TORSO, 3, 3, 4, 10, 10, 7, gc);
                m.box(TORSO, 4, 10, 3, 5, 12, 8, dark); m.box(TORSO, 8, 10, 3, 9, 12, 8, dark);
                m.box(TORSO, 4, 5, 2, 9, 9, 2, plate ? dark : gc);
                for (int x = 3; x <= 9; x += 3) m.box(TORSO, x, 3, 2, x + 1, 4, 2, Tex.rgb(96, 88, 64));   // magazine pouches
                if (plate) { m.box(TORSO, 4, 5, 9, 9, 9, 9, dark); m.box(TORSO, 1, 9, 4, 1, 10, 7, dark); m.box(TORSO, 12, 9, 4, 12, 10, 7, dark); }
            }
            default -> {}
        }
        switch (g.pack) {
            case "case" -> { m.box(TORSO, 5, 4, 8, 8, 8, 9, Tex.rgb(66, 58, 44)); m.box(TORSO, 5, 9, 8, 8, 9, 8, Tex.rgb(40, 34, 28)); }
            case "small" -> { int k = Tex.rgb(78, 70, 52); m.box(TORSO, 4, 4, 8, 9, 10, 10, k); m.box(TORSO, 5, 5, 11, 8, 8, 11, Tex.shade(k, 0.8f)); m.box(TORSO, 4, 11, 4, 4, 11, 8, DARK_STRAP); m.box(TORSO, 9, 11, 4, 9, 11, 8, DARK_STRAP); }
            case "large" -> {
                int k = Tex.rgb(70, 78, 56);
                m.box(TORSO, 3, 2, 8, 10, 12, 11, k); m.box(TORSO, 4, 3, 11, 9, 7, 11, Tex.shade(k, 0.78f));
                m.box(TORSO, 3, 13, 8, 10, 13, 10, Tex.rgb(120, 104, 72));   // bedroll
                m.box(TORSO, 2, 4, 9, 2, 8, 10, Tex.shade(k, 0.85f)); m.box(TORSO, 11, 4, 9, 11, 8, 10, Tex.shade(k, 0.85f));
                m.box(TORSO, 4, 11, 4, 4, 12, 8, DARK_STRAP); m.box(TORSO, 9, 11, 4, 9, 12, 8, DARK_STRAP);
            }
            default -> {}
        }
    }

    private static final int DARK_STRAP = Tex.rgb(40, 36, 30);

    /** Readable infected silhouettes: every archetype's role is legible from its outline. */
    private static void mutate(CharModel m, String arch, CharDefs.Ctx c, int seed) {
        int glow = Tex.rgb(226, 204, 84), gore = Tex.rgb(96, 30, 28), bile = Tex.rgb(170, 196, 70);
        // torn clothing and sores everywhere
        for (int g = 0; g < GROUPS; g++) {
            var v = m.groups[g];
            for (int x = 0; x < v.sx; x++) for (int y = 0; y < v.sy; y++) for (int z = 0; z < v.sz; z++) {
                if (v.get(x, y, z) == 0) continue;
                float h = Rng.hash(x * 3 + g, y * 5, z * 7, seed);
                if (h < 0.07f) v.set(x, y, z, gore); else if (h < 0.15f && g != HEAD) v.set(x, y, z, c.skin);
            }
        }
        m.set(HEAD, 4, 6, 2, glow); m.set(HEAD, 7, 6, 2, glow); m.set(HEAD, 3, 6, 2, Tex.shade(glow, 0.7f)); m.set(HEAD, 8, 6, 2, Tex.shade(glow, 0.7f));
        m.box(HEAD, 4, 2, 2, 7, 3, 2, Tex.rgb(50, 14, 14));
        switch (arch) {
            case "boomer" -> {
                int belly = Tex.mix(c.skin, Tex.rgb(126, 150, 70), 0.5f);
                m.groups[TORSO].sphere(7, 5.5f, 5.2f, 6.1f, belly);
                m.groups[TORSO].sphere(7, 10.5f, 6f, 4.6f, belly);
                for (int k = 0; k < 16; k++) { int x = 2 + (int) (Rng.hash(k, 1, 2, seed) * 10), y = 1 + (int) (Rng.hash(k, 3, 4, seed) * 9); for (int z = 0; z < 4; z++) if (m.get(TORSO, x, y, z) != 0) { m.set(TORSO, x, y, z, bile); break; } }
                m.shellBoth(L_THIGH, 0, 0, 0, 5, 6, 5, c.skin); m.shellBoth(L_UPPER_ARM, 0, 1, 0, 5, 6, 5, c.skin);
                m.box(HEAD, 3, 1, 2, 8, 2, 5, belly);   // goitre
                m.box(HEAD, 4, 1, 1, 7, 2, 1, bile);
            }
            case "tank" -> {
                int hide = Tex.shade(c.skin, 0.78f), bone = Tex.rgb(172, 160, 138);
                m.shell(TORSO, 1, 2, 3, 12, 12, 9, hide); m.tint(TORSO, 3, 2, 4, 10, 11, 7, hide);
                m.box(TORSO, 0, 9, 3, 4, 13, 9, hide); m.box(TORSO, 9, 9, 3, 13, 13, 9, hide);
                m.box(TORSO, 1, 12, 5, 2, 13, 7, bone); m.box(TORSO, 11, 12, 5, 12, 13, 7, bone);
                for (int y = 3; y <= 9; y += 2) m.box(TORSO, 6, y, 9, 7, y, 10, bone);   // spine ridge
                m.shellBoth(L_UPPER_ARM, 0, 0, 0, 5, 6, 5, hide); m.shellBoth(L_FOREARM, 0, 0, 0, 5, 5, 5, hide); m.shellBoth(L_HAND, 0, 0, 0, 5, 2, 5, bone);
                m.shellBoth(L_THIGH, 0, 0, 0, 5, 6, 5, hide); m.shellBoth(L_SHIN, 0, 0, 1, 5, 6, 6, hide);
            }
            case "sprinter", "screecher" -> {
                for (int y = 4; y <= 9; y += 2) m.tint(TORSO, 4, y, 4, 9, y, 4, Tex.shade(c.skin, 0.62f));   // ribs through the shirt
                m.box(HEAD, 4, 0, 2, 7, 1, 4, Tex.rgb(40, 10, 10));   // unhinged jaw
                m.box(HEAD, 4, 1, 1, 7, 1, 1, Tex.rgb(214, 206, 180));
                m.tintBoth(L_FOREARM, 1, 0, 1, 4, 2, 4, gore);
            }
            case "shambler" -> { m.shell(TORSO, 2, 1, 3, 11, 11, 8, Tex.shade(c.cloth, 0.8f)); m.box(TORSO, 4, 4, 3, 6, 8, 3, gore); }
            default -> m.box(TORSO, 4, 5, 4, 6, 8, 4, gore);
        }
    }

    // ------------------------------------------------------------------ faction dressing for NPCs (same tables as the player)
    private static Appearance pick(Rng r, String[] torso, String[] sleeves, String[] legs, String[] feet, String[] hands) {
        Appearance a = Appearance.random(r);
        a.set(Category.TORSO, r.pick(torso)).set(Category.SLEEVES, r.pick(sleeves)).set(Category.LEGS, r.pick(legs)).set(Category.FEET, r.pick(feet)).set(Category.HANDS, r.pick(hands));
        return a;
    }

    /** Seeded look for a faction member; armour/helmet/pack come from what the agent actually carries. */
    public static Appearance factionLook(String faction, long seed, Gear g) {
        Rng r = new Rng(seed * 2654435761L + 17);
        switch (faction) {
            case "military" -> {
                g.gearColor = Tex.rgb(78, 88, 62);
                return pick(r, new String[]{"field"}, new String[]{"long", "camo", "rolled"}, new String[]{"camo"}, new String[]{"combat", "jungle"}, new String[]{"tactical", "bare"});
            }
            case "mercenaries" -> {
                g.uniform = Tex.rgb(50, 54, 60);
                g.gearColor = Tex.rgb(40, 42, 46);
                if (g.face.isEmpty() && r.chance(0.7)) g.face = "balaclava";
                if (g.head.isEmpty()) g.head = r.chance(0.5) ? "cap" : "";
                return pick(r, new String[]{"field", "tee"}, new String[]{"long", "rolled"}, new String[]{"tactical"}, new String[]{"combat"}, new String[]{"tactical"});
            }
            case "raiders" -> {
                g.gearColor = Tex.rgb(70, 60, 46);
                if (g.face.isEmpty() && r.chance(0.55)) g.face = r.chance(0.6) ? "bandana" : "balaclava";
                if (g.head.isEmpty() && r.chance(0.35)) g.head = r.chance(0.5) ? "beanie" : "hood";
                return pick(r, new String[]{"leather", "tracksuit", "hoodie", "flannel", "tank"}, new String[]{"long", "jacket", "bare", "ink", "striped"}, new String[]{"track", "jeans", "patched", "leather"}, new String[]{"sneaker_w", "hightop", "trainer", "combat"}, new String[]{"fingerless", "bare", "wraps"});
            }
            case "survivors" -> {
                g.gearColor = Tex.rgb(96, 84, 60);
                if (g.pack.isEmpty()) g.pack = r.chance(0.6) ? "small" : "large";
                if (g.head.isEmpty() && r.chance(0.4)) g.head = r.chance(0.5) ? "beanie" : "hood";
                return pick(r, new String[]{"parka", "sweater", "workjacket", "hoodie", "puffer", "flannel"}, new String[]{"long", "jacket", "patched"}, new String[]{"cargo", "jeans", "work", "sweats"}, new String[]{"hiking", "rubber", "work", "valenki"}, new String[]{"work", "mittens", "bare", "leather"});
            }
            default -> {
                Appearance a = Appearance.random(r);
                List<CharDefs.Part> torso = CharDefs.parts(Category.TORSO);
                a.set(Category.TORSO, r.nextInt(torso.size()));
                return a;
            }
        }
    }
}
