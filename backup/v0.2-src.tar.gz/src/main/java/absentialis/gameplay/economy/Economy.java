package absentialis.gameplay.economy;

import absentialis.gameplay.items.Content;
import absentialis.gameplay.items.ItemDef;
import absentialis.gameplay.items.ItemInstance;
import absentialis.gameplay.progression.Progression;
import absentialis.sim.ZoneState;
import absentialis.world.District;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Traders and prices (GDD 14). Buy prices respond to district supply and reputation; sell prices
 * are always strictly below the matching buy price, decay with repeated sales of the same item
 * (saturation) and are zero for fallback kit items, so no buy/sell loop can mint currency.
 */
public final class Economy {
    private Economy() {}

    public record Trader(String id, String name, String faction, String blurb, List<String> categories, float sellRate) {}

    public static final List<Trader> TRADERS = List.of(
            new Trader("mara", "Quartermaster Mara", "survivors", "Survivor co-op. Food, medicine, basics. Buys almost anything.",
                    List.of("food", "medical", "material", "ammo", "magazine", "valuable", "treasure", "herb", "tool", "explosive"), 0.45f),
            new Trader("voss", "Lt. Voss (Armory)", "military", "Cordon armory. Weapons, armour, parts. Requires standing with the military.",
                    List.of("weapon", "ammo", "magazine", "armor", "attachment", "medical", "charm"), 0.40f),
            new Trader("kessler", "Kessler (Fence)", "raiders", "No questions asked. Buys stolen faction gear and quest goods - at a cut.",
                    List.of("valuable", "quest", "weapon", "explosive", "attachment", "document", "treasure", "charm"), 0.33f));

    public static Trader trader(String id) { for (Trader t : TRADERS) if (t.id.equals(id)) return t; return null; }

    /** Minimum trader tier at which an item is stocked (enlisted rank gates breadth). */
    public static int tierOf(ItemDef d) {
        if (d.value >= 2000) return 4;
        if (d.value >= 900) return 3;
        if (d.value >= 300) return 2;
        return 1;
    }

    private static float supplyFactor(ZoneState z, ItemDef d) {
        String cat = Content.supplyCategory(d);
        float avg = 0;
        for (District dd : District.CITY) avg += z.supply[dd.ordinal()][ZoneState.si(cat)];
        avg /= District.CITY.length;
        return 1.35f - Math.min(1.2f, avg) * 0.35f; // scarce -> pricier (x0.93 .. x1.3)
    }

    private static float repFactor(float rep) { return 1.15f - Math.max(-100, Math.min(100, rep)) / 100f * 0.15f; }

    public static int buyPrice(ItemDef d, Trader t, ZoneState z, float rep) {
        float p = Math.max(1, d.value) * supplyFactor(z, d) * repFactor(rep);
        if (d.stackable()) p *= 1; // per unit
        return Math.max(1, Math.round(p));
    }

    /** Sale price for one instance (whole stack). recentSales = times this def was sold recently. */
    public static int sellPrice(ItemInstance it, Trader t, ZoneState z, float rep, int recentSales) {
        ItemDef d = it.def();
        if (it.fallback || d.value <= 0 && !"kessler".equals(t.id)) return 0;
        float unitBuy = buyPrice(d, t, z, rep);
        float sat = (float) Math.pow(0.9, Math.min(15, recentSales));
        float v = it.baseValueTotal() / (float) Math.max(1, d.stackable() ? it.qty : 1);
        if (d.value <= 0 && "kessler".equals(t.id)) v = 150; // quest goods fenced
        float unit = Math.min(unitBuy * 0.9f, v * t.sellRate * sat * repFactor(-rep) * 0.95f);
        int qty = d.stackable() ? it.qty : 1;
        return Math.max(0, Math.round(unit * qty));
    }

    public static boolean accepts(Trader t, ItemDef d) { return t.categories.contains(d.category); }

    /** Trader stock for the current progression tier and reputation. */
    public static List<ItemDef> stock(Trader t, Progression p, float rep) {
        List<ItemDef> out = new ArrayList<>();
        if ("voss".equals(t.id) && rep < 0) return out;
        int tier = p.traderTier() + (rep >= 50 ? 1 : 0);
        for (ItemDef d : Content.ITEMS.values()) {
            if (!accepts(t, d) || d.questItem || d.value <= 0 || "treasure".equals(d.category) || "document".equals(d.category)) continue;
            if (d.id.startsWith("finish.gold") || "valuable".equals(d.category) && !"kessler".equals(t.id)) continue;
            if ("kessler".equals(t.id) && !"explosive".equals(d.category) && !"attachment".equals(d.category)) continue;
            if (tierOf(d) > tier) continue;
            if (d.weapon != null && !p.platformUnlocked(d.id)) continue;
            out.add(d);
        }
        return out;
    }

    /** Free fallback kit (GDD 4.4): offered when the survivor cannot afford to deploy. */
    public static List<ItemInstance> fallbackKit() {
        List<ItemInstance> l = new ArrayList<>();
        ItemInstance pistol = new ItemInstance("weapon.pm9");
        ItemInstance mag = new ItemInstance("mag.pm9");
        mag.rounds = 12; mag.ammoId = "ammo.9x19";
        pistol.mag = mag; mag.parent = pistol;
        ItemInstance mag2 = new ItemInstance("mag.pm9");
        mag2.rounds = 12; mag2.ammoId = "ammo.9x19";
        ItemInstance knife = new ItemInstance("melee.knife");
        ItemInstance band = new ItemInstance("med.bandage");
        ItemInstance water = new ItemInstance("drink.water");
        for (ItemInstance i : List.of(pistol, mag, mag2, knife, band, water)) { i.fallback = true; i.origin = "fallback"; }
        l.add(pistol); l.add(mag2); l.add(knife); l.add(band); l.add(water);
        return l;
    }

    /** Audit: proves no buy->sell round trip is profitable for any stocked item (anti-exploit). */
    public static String audit(ZoneState z, Map<String, Float> reps) {
        StringBuilder b = new StringBuilder();
        int worst = Integer.MIN_VALUE;
        String worstId = "";
        for (Trader t : TRADERS) for (ItemDef d : Content.ITEMS.values()) {
            if (!accepts(t, d) || d.value <= 0) continue;
            for (Trader s : TRADERS) {
                if (!accepts(s, d)) continue;
                float rep = reps.getOrDefault(t.faction, 0f);
                int buy = buyPrice(d, t, z, rep);
                ItemInstance probe = new ItemInstance(-77, d.id);
                probe.qty = 1;
                int sell = sellPrice(probe, s, z, 100, 0);
                if (sell - buy > worst) { worst = sell - buy; worstId = d.id + " (" + t.id + "->" + s.id + ")"; }
            }
        }
        b.append("Best buy->sell margin: ").append(worst).append(" scrip on ").append(worstId).append(worst < 0 ? "  [OK: no loop]" : "  [EXPLOIT]");
        return b.toString();
    }
}
