package absentialis.gameplay.weapons;

import absentialis.gameplay.items.Content;
import absentialis.gameplay.items.ItemDef;
import absentialis.gameplay.items.ItemInstance;
import java.util.ArrayList;
import java.util.List;

/**
 * Weapon platform rules (addendum P2.2): 5-9 modification slots per platform, part compatibility,
 * and the derived handling statistics after parts, magazine, ammunition and condition are applied.
 * Rank and prestige never feed into these numbers - only physical configuration and condition.
 */
public final class Gunsmith {
    private Gunsmith() {}

    /** Ordered slot list for a platform. "mag" and "ammo" are virtual slots shown by the bench. */
    public static List<String> slotsFor(ItemDef d) {
        List<String> s = new ArrayList<>();
        if (d.weapon == null || d.weapon.melee()) return s;
        switch (d.weapon.family) {
            case "rifle" -> s.addAll(List.of("muzzle", "barrel", "optic", "stock", "grip", "light"));
            case "sniper" -> s.addAll(List.of("muzzle", "barrel", "optic", "stock"));
            case "shotgun" -> s.addAll(List.of("barrel", "stock", "light"));
            case "heavy" -> s.addAll(List.of("barrel", "optic", "stock", "muzzle"));
            default -> s.addAll(d.weapon.internal() ? List.of("barrel", "optic", "grip") : List.of("muzzle", "barrel", "optic"));
        }
        if (!d.weapon.internal()) s.add("mag");
        s.add("ammo");
        s.add("finish");
        return s;
    }

    /** Null when the part can be fitted, otherwise a player-readable reason. */
    public static String incompatibility(ItemInstance weapon, ItemInstance part) {
        ItemDef w = weapon.def(), p = part.def();
        if (w.weapon == null || w.weapon.melee()) return "Melee weapons take no parts";
        if (p.attachment == null) return p.name + " is not a weapon part";
        String socket = p.attachment.socket;
        if (!slotsFor(w).contains(socket)) return w.name + " has no " + socket + " slot";
        if (!p.attachment.calibers.isEmpty() && !p.attachment.calibers.contains(w.weapon.caliber)) return p.name + " does not fit " + w.weapon.caliber;
        if (!p.attachment.families.isEmpty() && !p.attachment.families.contains(w.weapon.family)) return p.name + " does not fit a " + w.weapon.family;
        return null;
    }

    /** Final handling numbers for one weapon instance. */
    public static final class Stats {
        public float dispersion, recoilV, recoilH, ergo, noise, mass, zoom = 1, wearMul = 1, jamChance, rpm, range, reloadTime, adsTime;
        public boolean light, suppressed;
        public int conditionBand; // 0 = fine, 1 = worn (<50), 2 = critical (<25)
    }

    public static Stats stats(ItemInstance it, float charmWear) {
        ItemDef.Weapon w = it.def().weapon;
        Stats s = new Stats();
        float noiseMul = 1, recoilMul = 1;
        s.dispersion = w.dispersion;
        s.ergo = w.ergo;
        for (ItemInstance a : it.attachments.values()) {
            ItemDef.Attachment at = a.def().attachment;
            if (at == null) continue;
            s.dispersion += at.dispersion;
            s.ergo += at.ergo;
            noiseMul += at.noise;
            recoilMul += at.recoil;
            s.wearMul += at.wear;
            s.zoom = Math.max(s.zoom, at.zoom);
            if (at.light) s.light = true;
            if (at.noise <= -0.4f) s.suppressed = true;
        }
        if (it.mag != null && it.mag.def().magazine != null) s.ergo += it.mag.def().magazine.ergo;
        s.wearMul = Math.max(0.2f, s.wearMul + charmWear);
        s.mass = it.mass();
        s.noise = w.noise * Math.max(0.25f, noiseMul);
        s.recoilV = w.recoilV * Math.max(0.3f, recoilMul);
        s.recoilH = w.recoilH * Math.max(0.3f, recoilMul);
        s.rpm = w.rpm;
        s.range = w.range;
        s.reloadTime = w.reloadTime * (1.25f - Math.min(100, s.ergo) / 400f);
        s.adsTime = 0.12f + s.mass * 0.035f + (100 - Math.min(100, s.ergo)) * 0.002f;
        // condition (addendum): <50 red stat bars, spread +2%, 2% jam; <25 8% jam, needs bench
        float cond = it.condition();
        if (cond < 25) { s.conditionBand = 2; s.jamChance = 0.08f; s.dispersion *= 1.06f; }
        else if (cond < 50) { s.conditionBand = 1; s.jamChance = 0.02f; s.dispersion *= 1.02f; }
        else s.jamChance = 0.0005f;
        s.dispersion = Math.max(0.02f, s.dispersion);
        return s;
    }

    /** Ammo types compatible with the platform (for the bench's ammo slot). */
    public static List<ItemDef> ammoFor(ItemDef w) {
        List<ItemDef> out = new ArrayList<>();
        if (w.weapon == null) return out;
        for (ItemDef d : Content.ITEMS.values()) if (d.ammo != null && d.ammo.caliber.equals(w.weapon.caliber)) out.add(d);
        return out;
    }

    /** Finish tint for the voxel model (0 = factory). */
    public static int finishTint(ItemInstance it) {
        ItemInstance f = it.attachments.get("finish");
        return f == null || f.def().attachment == null ? 0 : f.def().attachment.tint;
    }

    // ------------------------------------------------------------------ recoil patterns
    /**
     * Distinct, learnable per-platform recoil pattern: shot index -> {pitchUp, yaw} in degrees,
     * before per-instance scaling. Deterministic so players can learn to pull against it.
     */
    public static float[] recoilKick(ItemDef d, int shotIndex) {
        ItemDef.Weapon w = d.weapon;
        int seed = d.id.hashCode();
        float t = shotIndex;
        float up = w.recoilV, side;
        switch (w.family) {
            case "rifle" -> {
                // climbs, then a drift whose direction is a platform signature
                float dir = (seed & 1) == 0 ? 1 : -1;
                up *= t < 4 ? 1.0f : 0.65f;
                side = w.recoilH * (t < 4 ? 0.2f * (float) Math.sin(t * 1.7) : dir * (0.6f + 0.35f * (float) Math.sin(t * 0.9 + seed)));
            }
            case "heavy" -> { up *= 0.8f; side = w.recoilH * (float) Math.sin(t * 0.55 + seed) * 1.2f; }
            case "shotgun", "sniper" -> { side = w.recoilH * ((seed >> 3 & 1) == 0 ? 0.5f : -0.5f); }
            default -> side = w.recoilH * (float) Math.sin(t * 2.3 + seed) * 0.8f;
        }
        return new float[]{up, side};
    }

    /** Seconds for the view to settle back after the last shot. */
    public static float recoveryTime(Stats s) { return 0.18f + s.recoilV * 0.05f + (100 - Math.min(100, s.ergo)) * 0.002f; }
}
