package absentialis.gameplay.progression;

import absentialis.engine.util.Json;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Rank / Prestige (addendum P2.1). 50 ranks per cycle; a cycle costs exactly 1,265,500 XP
 * (rank r -> r+1 costs 2360 + 900r, with rank 50 itself requiring a final 47,360 to complete).
 * 15 prestiges -> Master at 18,982,500 XP (~19M).
 *
 * Rank never grants damage. It grants: stash rows, loadout presets, trader breadth, carry weight,
 * weapon platforms and cosmetics. Prestiging forfeits enlisted (rank-gated) unlocks, trader access
 * and the deployed loadout, but keeps cosmetics, banners, emblems, weapon mastery and spent tokens.
 */
public final class Progression {
    public static final int RANKS = 50, MAX_PRESTIGE = 15;
    public static final long CYCLE_XP = 1_265_500L;

    public long cycleXp;        // XP inside the current cycle [0, CYCLE_XP]
    public long lifetimeXp;
    public int prestige;        // 0..15 (15 = Master)
    public int tokens;          // unspent prestige tokens (must be spent before the next prestige)
    /** Permanent token unlocks: "platform:weapon.sr16", "trader:2", "hideout:workbench". No stacking. */
    public final Set<String> tokenUnlocks = new LinkedHashSet<>();
    public final Set<String> cosmetics = new LinkedHashSet<>();
    public final Map<String, Long> mastery = new LinkedHashMap<>(); // weapon defId -> mastery xp (persists)

    // ------------------------------------------------------------------ curve
    public static long costOf(int rank) { return 2360L + 900L * rank; }

    /** XP needed from the start of the cycle to reach the given rank. */
    public static long xpToReach(int rank) {
        long s = 0;
        for (int r = 1; r < Math.min(rank, RANKS + 1); r++) s += costOf(r);
        return s;
    }

    public int rank() {
        int r = 1;
        long acc = 0;
        while (r < RANKS && acc + costOf(r) <= cycleXp) { acc += costOf(r); r++; }
        return r;
    }

    /** Progress 0..1 toward the next rank (or toward cycle completion at rank 50). */
    public float rankProgress() {
        int r = rank();
        long base = xpToReach(r), need = costOf(r);
        return Math.min(1f, (cycleXp - base) / (float) need);
    }

    public boolean cycleComplete() { return cycleXp >= CYCLE_XP; }
    public boolean canPrestige() { return cycleComplete() && prestige < MAX_PRESTIGE && tokens == 0; }
    public boolean master() { return prestige >= MAX_PRESTIGE; }
    public static long totalToMaster() { return CYCLE_XP * MAX_PRESTIGE; }

    /** Adds XP; returns the number of ranks gained. Overflow past cycle completion is banked. */
    public int addXp(long xp) {
        if (xp <= 0) return 0;
        int before = rank();
        lifetimeXp += xp;
        cycleXp = Math.min(CYCLE_XP, cycleXp + xp);
        return rank() - before;
    }

    public void addMastery(String weapon, long xp) { mastery.merge(weapon, xp, Long::sum); }
    public static int masteryLevel(long xp) { int l = 0; long need = 1500; while (xp >= need && l < 10) { xp -= need; l++; need = (long) (need * 1.45); } return l; }
    public int masteryLevel(String weapon) { return masteryLevel(mastery.getOrDefault(weapon, 0L)); }

    // ------------------------------------------------------------------ rank-gated access (enlisted)
    private static final Object[][] PLATFORMS = {
            {"weapon.pm9", 1}, {"melee.knife", 1}, {"melee.crowbar", 1}, {"weapon.akr", 1}, {"weapon.pump12", 6},
            {"weapon.r45", 10}, {"weapon.sr16", 18}, {"weapon.mosin", 26}, {"weapon.lmg74", 38}};

    public static int platformRank(String weaponId) {
        for (Object[] p : PLATFORMS) if (p[0].equals(weaponId)) return (Integer) p[1];
        return 1;
    }

    public boolean platformUnlocked(String weaponId) {
        return tokenUnlocks.contains("platform:" + weaponId) || rank() >= platformRank(weaponId) || prestige > 0 && master();
    }

    public static List<String> platforms() { List<String> l = new ArrayList<>(); for (Object[] p : PLATFORMS) l.add((String) p[0]); return l; }

    /** Trader tier 1..4 by rank; a token can raise the floor permanently. */
    public int traderTier() {
        int r = rank();
        int t = r >= 40 ? 4 : r >= 25 ? 3 : r >= 12 ? 2 : 1;
        for (String u : tokenUnlocks) if (u.startsWith("trader:")) t = Math.max(t, Integer.parseInt(u.substring(7)));
        return t;
    }

    public float carryCapacityKg() { return 28f + rank() * 0.25f; }

    /** Extra stash rows: 1 per 10 ranks (enlisted) + prestige rows (kept across prestige). */
    public int stashRows() { return rank() / 10 + prestigeStashRows(); }
    public int prestigeStashRows() { int n = 0; for (int p : new int[]{1, 3, 5, 7, 9}) if (prestige >= p) n++; return n; }

    /** Loadout presets: 1 base + 1 at rank 20 and 40 + prestige 1/3/5/7/9 grants. */
    public int presets() { int r = rank(); return 1 + (r >= 20 ? 1 : 0) + (r >= 40 ? 1 : 0) + prestigeStashRows(); }

    public int bannerLayers() { int n = 1; for (int p : new int[]{2, 4, 6, 8, 10}) if (prestige >= p) n++; return n; }

    // ------------------------------------------------------------------ prestige
    public record PrestigeReward(int level, String text) {}

    public static String rewardText(int p) {
        switch (p) {
            case 1: case 3: case 5: case 7: case 9: return "+1 loadout preset, +1 stash row";
            case 2: case 4: case 6: case 8: case 10: return "+1 banner layer";
            case 11: return "Face paint & helmet marks";
            case 12: return "Veteran callsign frame";
            case 13: return "Coloured callsign tags";
            case 14: return "Gold voxel finish (applied at the bench for a fee)";
            case 15: return "MASTER emblem";
            default: return "";
        }
    }

    /** Token options shown at prestige. Already-owned unlocks are excluded (no stacking). */
    public List<String> tokenOptions() {
        List<String> o = new ArrayList<>();
        for (String p : platforms()) if (platformRank(p) > 1 && !tokenUnlocks.contains("platform:" + p)) o.add("platform:" + p);
        for (int t = 2; t <= 4; t++) if (!tokenUnlocks.contains("trader:" + t)) { o.add("trader:" + t); break; }
        for (String h : new String[]{"workbench", "medical", "case", "radio"}) if (!tokenUnlocks.contains("hideout:" + h)) o.add("hideout:" + h);
        return o;
    }

    public String spendToken(String unlock) {
        if (tokens <= 0) return "No token to spend";
        if (tokenUnlocks.contains(unlock)) return "Already unlocked - tokens do not stack";
        if (!tokenOptions().contains(unlock)) return "Not a valid token unlock";
        tokenUnlocks.add(unlock);
        tokens--;
        return null;
    }

    /**
     * Performs a prestige. The caller strips the deployed loadout (enlisted items) and resets
     * trader standing; this object resets rank and grants the cosmetic reward plus one token.
     */
    public String prestige() {
        if (!cycleComplete()) return "Complete rank 50 first";
        if (prestige >= MAX_PRESTIGE) return "Already Master";
        if (tokens > 0) return "Spend your prestige token first";
        prestige++;
        cycleXp = 0;
        tokens = 1;
        switch (prestige) {
            case 2, 4, 6, 8, 10 -> cosmetics.add("banner_layer_" + prestige);
            case 11 -> { cosmetics.add("face_paint"); cosmetics.add("helmet_marks"); }
            case 12 -> cosmetics.add("callsign_frame");
            case 13 -> cosmetics.add("callsign_tags");
            case 14 -> cosmetics.add("gold_finish");
            case 15 -> cosmetics.add("master_emblem");
            default -> cosmetics.add("prestige_emblem_" + prestige);
        }
        cosmetics.add("prestige_emblem_" + prestige);
        return null;
    }

    public String title() {
        if (master()) return "MASTER";
        return (prestige > 0 ? "P" + prestige + " " : "") + "Rank " + rank() + " " + rankName(rank());
    }

    private static final String[] RANK_NAMES = {"Stray", "Scavenger", "Runner", "Pathfinder", "Stalker", "Veteran", "Operator", "Specialist", "Warden", "Zone Marshal", "Legend"};

    /** Every five ranks carry a name; rank 50 has its own. */
    public static String rankName(int rank) { return RANK_NAMES[Math.max(0, Math.min(RANK_NAMES.length - 1, rank == RANKS ? RANK_NAMES.length - 1 : (rank - 1) / 5))]; }

    /**
     * What each rank of the enlisted cycle opens, in order: {rank, description}. Flexibility, rows,
     * breadth, weight and cosmetics only - no entry here ever changes damage.
     */
    public static List<String[]> roadmap() {
        List<String[]> l = new ArrayList<>();
        for (int r = 2; r <= RANKS; r++) {
            for (Object[] p : PLATFORMS) if ((Integer) p[1] == r) l.add(new String[]{String.valueOf(r), "Weapon platform: " + p[0]});
            if (r == 12 || r == 25 || r == 40) l.add(new String[]{String.valueOf(r), "Trader tier " + (r == 12 ? 2 : r == 25 ? 3 : 4) + " (broader stock)"});
            if (r % 10 == 0) l.add(new String[]{String.valueOf(r), "+1 stash row"});
            if (r == 20 || r == 40) l.add(new String[]{String.valueOf(r), "+1 loadout preset"});
            if (r % 5 == 1 && r > 1) l.add(new String[]{String.valueOf(r), "Title: " + rankName(r) + ", +1.25 kg carry"});
        }
        return l;
    }

    /** The next few roadmap entries above the current rank. */
    public List<String[]> nextUnlocks(int n) {
        List<String[]> out = new ArrayList<>();
        int r = rank();
        for (String[] e : roadmap()) { if (Integer.parseInt(e[0]) > r && out.size() < n) out.add(e); }
        return out;
    }

    // ------------------------------------------------------------------ persistence
    public Map<String, Object> toJson() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("cycleXp", String.valueOf(cycleXp));
        m.put("lifetimeXp", String.valueOf(lifetimeXp));
        m.put("prestige", prestige);
        m.put("tokens", tokens);
        m.put("tokenUnlocks", new ArrayList<>(tokenUnlocks));
        m.put("cosmetics", new ArrayList<>(cosmetics));
        Map<String, Object> ms = new LinkedHashMap<>();
        for (Map.Entry<String, Long> e : mastery.entrySet()) ms.put(e.getKey(), String.valueOf(e.getValue()));
        m.put("mastery", ms);
        return m;
    }

    public static Progression fromJson(Map<String, Object> m) {
        Progression p = new Progression();
        if (m == null) return p;
        p.cycleXp = Json.lng(m, "cycleXp", 0);
        p.lifetimeXp = Json.lng(m, "lifetimeXp", 0);
        p.prestige = Json.integer(m, "prestige", 0);
        p.tokens = Json.integer(m, "tokens", 0);
        p.tokenUnlocks.addAll(Json.strList(m, "tokenUnlocks"));
        p.cosmetics.addAll(Json.strList(m, "cosmetics"));
        for (Map.Entry<String, Object> e : Json.obj(m, "mastery").entrySet()) p.mastery.put(e.getKey(), Long.parseLong(String.valueOf(e.getValue())));
        return p;
    }
}
