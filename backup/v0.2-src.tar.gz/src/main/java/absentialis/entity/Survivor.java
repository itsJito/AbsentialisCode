package absentialis.entity;

import absentialis.gameplay.items.ItemDef;

/**
 * Player body state (GDD 9, addendum P2.4): the three cores - Health (red), Stamina (yellow) and
 * Focus (recoil control) - plus injuries, hunger, thirst, pain, radiation and infection. Each core
 * remembers when it last changed so the HUD can show it only on change.
 */
public final class Survivor {
    public float stamina = 100, focus = 100, energy = 80, hydration = 80, pain, rad, infection;
    public boolean bleedLight, bleedHeavy, fracture;
    public float healthChanged = -99, staminaChanged = -99, focusChanged = -99; // raid time of last change
    public float exhausted;     // seconds of forced recovery after hitting 0 stamina
    public float useTimer;      // in-progress item use
    public ItemDef using;
    public float staminaDrainMul = 1;

    /** Movement speed points (addendum): walk 90, run 180, crouch 45 -> metres/s = points / 25. */
    public static final float WALK = 90, RUN = 180, CROUCH = 45;

    public float moveSpeed(Actor a, boolean sprint, boolean walkKey, float massKg, float capacityKg, float weaponMass) {
        float pts = a.crouch ? CROUCH : sprint && canSprint() ? RUN : walkKey ? WALK * 0.55f : WALK;
        float over = Math.max(0, massKg - capacityKg) / Math.max(1, capacityKg);
        float load = 1f - Math.min(0.5f, massKg / Math.max(1, capacityKg) * 0.12f) - Math.min(0.4f, over * 0.8f);
        float weapon = 1f - Math.min(0.15f, weaponMass * 0.012f);
        float injury = fracture ? 0.6f : 1f;
        return pts / 25f * load * weapon * injury * a.speedMul;
    }

    public boolean canSprint() { return stamina > 8 && exhausted <= 0 && !fracture; }

    public void update(Actor a, float dt, float t, boolean moving, boolean sprinting, boolean aiming, float weaponMass, float radiation, boolean gasMask, float hungerMul) {
        float oldS = stamina, oldF = focus, oldH = a.hp;
        if (sprinting && moving && canSprint()) stamina -= dt * (14 + weaponMass * 1.2f) * staminaDrainMul;
        else if (exhausted > 0) exhausted -= dt;
        else stamina += dt * (moving ? 7 : 14) * (energy < 15 || hydration < 15 ? 0.5f : 1);
        if (stamina <= 0) { stamina = 0; exhausted = 3; }
        stamina = Math.min(100, stamina);
        // focus: drains while steadying an aimed weapon, recovers otherwise
        if (aiming) focus -= dt * (6 + weaponMass * 1.5f);
        else focus += dt * 16;
        focus = Math.max(0, Math.min(100, focus));
        // survival drains
        energy = Math.max(0, energy - dt * 0.018f * hungerMul);
        hydration = Math.max(0, hydration - dt * 0.03f * hungerMul);
        if (energy <= 0 || hydration <= 0) a.hp -= dt * 0.25f;
        if (bleedLight) a.hp -= dt * 0.35f;
        if (bleedHeavy) a.hp -= dt * 1.4f;
        pain = Math.max(0, pain - dt * 0.6f);
        if (radiation > 0) rad = Math.min(100, rad + radiation * dt * (gasMask ? 0.35f : 1f));
        if (rad > 60) a.hp -= dt * (rad - 60) * 0.02f;
        if (infection > 0) { infection = Math.min(100, infection + dt * 0.05f); if (infection > 50) a.hp -= dt * 0.1f; }
        if (Math.abs(stamina - oldS) > 0.01f) staminaChanged = t;
        if (Math.abs(focus - oldF) > 0.01f) focusChanged = t;
        if (Math.abs(a.hp - oldH) > 0.001f) healthChanged = t;
    }

    /** Recoil multiplier from focus: steady when focused, sloppy when spent. */
    public float recoilMul() { return 1.35f - 0.55f * (focus / 100f) + (pain > 30 ? 0.1f : 0); }

    /** Applies a consumable's effect. Returns a short feedback line. */
    public String apply(Actor a, ItemDef d) {
        StringBuilder s = new StringBuilder();
        if (d.medical != null) {
            ItemDef.Medical m = d.medical;
            if (m.heal > 0) { a.hp = Math.min(a.maxHp, a.hp + m.heal); s.append("+").append((int) m.heal).append(" health "); }
            if (m.stopLight && bleedLight) { bleedLight = false; s.append("bleeding stopped "); }
            if (m.stopHeavy && bleedHeavy) { bleedHeavy = false; s.append("heavy bleed clamped "); }
            if (m.fracture && fracture) { fracture = false; s.append("fracture splinted "); }
            if (m.pain > 0) { pain = Math.max(pain, m.pain); s.append("pain suppressed "); }
            if (m.rad > 0) { rad = Math.max(0, rad - m.rad); s.append("-").append((int) m.rad).append(" rad "); }
            if (m.infection) { infection = 0; s.append("infection treated "); }
        }
        if (d.food != null) {
            ItemDef.Food f = d.food;
            energy = Math.max(0, Math.min(100, energy + f.energy));
            hydration = Math.max(0, Math.min(100, hydration + f.hydration));
            if (f.infection > 0) infection = Math.min(100, infection + f.infection * 40);
            if (f.fatigue < 0) stamina = Math.min(100, stamina + 40);
            s.append(f.energy > 0 ? "+food " : "").append(f.hydration > 0 ? "+water " : "");
        }
        return s.toString().trim();
    }
}
