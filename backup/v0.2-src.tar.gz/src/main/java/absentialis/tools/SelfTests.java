package absentialis.tools;

import absentialis.ai.Brain;
import absentialis.engine.events.EventBus;
import absentialis.engine.util.Json;
import absentialis.engine.util.Rng;
import absentialis.entity.Actor;
import absentialis.gameplay.economy.Economy;
import absentialis.gameplay.inventory.Container;
import absentialis.gameplay.inventory.InventoryService;
import absentialis.gameplay.inventory.Loadout;
import absentialis.gameplay.items.Content;
import absentialis.gameplay.items.ItemDef;
import absentialis.gameplay.items.ItemInstance;
import absentialis.gameplay.progression.Progression;
import absentialis.gameplay.weapons.Gunsmith;
import absentialis.gameplay.weapons.WeaponService;
import absentialis.persistence.Profile;
import absentialis.persistence.Settings;
import absentialis.scene.Raid;
import absentialis.scene.RaidResolver;
import absentialis.sim.ZoneState;
import absentialis.world.Block;
import absentialis.world.District;
import absentialis.world.MapData;
import absentialis.world.World;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Quality gates (GDD 22.5 + addendum pass conditions), runnable without a window:
 * gradlew selftest  or  ABS_SELFTEST=all|inventory|extraction|noise|soak ...
 */
public final class SelfTests {
    private static int failed, passed;
    private static World flat;

    public static int runHeadless(String which) {
        failed = passed = 0;
        Content.load();
        boolean all = which == null || which.equals("all");
        System.out.println("=== ABSENTIALIS quality gates (" + which + ") ===");
        if (all || which.contains("inventory")) { inventory(); conservation(); }
        if (all || which.contains("orient") || which.contains("inventory")) { orientation(); }
        if (all || which.contains("weapon")) { weapons(); }
        if (all || which.contains("progress")) { progression(); }
        if (all || which.contains("econ")) { economy(); }
        if (all || which.contains("save")) { saveLoad(); }
        if (all || which.contains("death")) { death(); }
        if (all || which.contains("extraction")) { extraction(); }
        if (all || which.contains("noise")) { noise(); evidence(); }
        if (all || which.contains("ballistic")) { ballistics(); }
        if (all || which.contains("tier") || which.contains("soak")) { tiers(); offscreen(); }
        if (all || which.contains("character")) { character(); }
        if (all || which.contains("anim")) { animation(); }
        if (all || which.contains("ragdoll")) { ragdoll(); }
        if (all || which.contains("audio")) { audio(); }
        if (all || which.contains("alife")) { alife(); }
        if (all || which.contains("ai")) { doctrines(); }
        if (all || which.contains("zombie")) { zombies(); }
        if (all || which.contains("district") || which.contains("map")) { districts(); }
        System.out.printf("=== %d passed, %d failed ===%n", passed, failed);
        return failed;
    }

    private static void check(String name, boolean ok, String detail) {
        if (ok) passed++; else failed++;
        System.out.println((ok ? "  PASS  " : "  FAIL  ") + name + (detail == null || detail.isEmpty() ? "" : "  -  " + detail));
    }

    private static ItemInstance item(String id, int qty) { ItemInstance i = new ItemInstance(id); i.qty = qty; return i; }

    // ------------------------------------------------------------------ icon orientation (iteration P0.2)
    /**
     * Places every item definition in a case, rasterises the cell it occupies exactly as the grid
     * draws it and checks the picture: 0 degrees is upright (the top of the model is at the top of
     * the icon) and fits the definition's footprint; rotation swaps width and height by a pure
     * quarter turn - it never flips the image vertically.
     */
    private static void orientation() {
        System.out.println("[Inventory icons: every definition upright at 0 degrees, rotation never flips]");
        int upside = 0, aspect = 0, flipped = 0, unplaced = 0, checked = 0;
        StringBuilder bad = new StringBuilder();
        for (ItemDef d : Content.ITEMS.values()) {
            ItemInstance it = new ItemInstance(-7, d.id);
            Container box = new Container("orient", 20, 20);
            if (!InventoryService.add(it, box).ok() || it.rotated) { unplaced++; bad.append(' ').append(d.id).append("(placement)"); continue; }
            absentialis.engine.voxel.VoxModel m = absentialis.ui.ItemModels.of(it);
            int[] size = new int[2];
            int[] img = absentialis.ui.ItemIcons.rasterize(m, d, it.w(), it.h(), size);
            int w = size[0], h = size[1];
            checked++;
            // aspect: a long model must not be squeezed into the short side of its footprint
            float mw = Math.max(m.sx, m.sz), mh = m.sy;
            if (m.sy > 3 && (mw > mh * 1.5f && d.h > d.w || mh > mw * 1.5f && d.w > d.h)) { aspect++; bad.append(' ').append(d.id).append("(aspect ").append(d.w).append('x').append(d.h).append(" model ").append(m.sx).append('x').append(m.sy).append(')'); }
            // upright: colour the top and bottom slabs of a copy and see where they land
            if (m.sy > 3) {
                absentialis.engine.voxel.VoxModel mark = new absentialis.engine.voxel.VoxModel(m.sx, m.sy, m.sz);
                int slab = Math.max(1, m.sy / 4);
                for (int x = 0; x < m.sx; x++) for (int y = 0; y < m.sy; y++) for (int z = 0; z < m.sz; z++) if (m.get(x, y, z) != 0) mark.set(x, y, z, y >= m.sy - slab ? 0xFFFF00FF : y < slab ? 0xFF00FFFF : 0xFF808080);
                int[] mi = absentialis.ui.ItemIcons.rasterize(mark, d, it.w(), it.h(), size);
                double topY = 0, botY = 0, topX = 0; int nt = 0, nb = 0;
                for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                    int c = mi[y * w + x], r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
                    if (((c >>> 24) & 255) < 200) continue;
                    if (r > g * 2 && b > g * 2) { topY += y; topX += x; nt++; } else if (g > r * 2 && b > r * 2) { botY += y; nb++; }
                }
                if (nt > 0 && nb > 0 && topY / nt >= botY / nb) { upside++; bad.append(' ').append(d.id).append("(upside down)"); }
                // rotation: quarter turn, top goes to the left edge, nothing is mirrored
                int[] rot = absentialis.ui.ItemIcons.rotateCcw(mi, w, h);
                double rx = 0, ry = 0; int rn = 0;
                for (int y = 0; y < w; y++) for (int x = 0; x < h; x++) { int c = rot[y * h + x], r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255; if (((c >>> 24) & 255) >= 200 && r > g * 2 && b > g * 2) { rx += x; ry += y; rn++; } }
                boolean pure = true;
                for (int y = 0; y < w && pure; y++) for (int x = 0; x < h; x++) if (rot[y * h + x] != mi[x * w + (w - 1 - y)]) { pure = false; break; }
                // the marker's distance from the top edge must become its distance from the left edge, its x offset its height from the bottom
                if (nt > 0 && rn > 0 && (!pure || Math.abs(rx / rn - topY / nt) > 0.51 || Math.abs((w - 1 - ry / rn) - topX / nt) > 0.51)) { flipped++; bad.append(' ').append(d.id).append("(rotation flips)"); }
            }
            // the footprint itself: R swaps w and h
            int w0 = it.w(), h0 = it.h();
            it.rotated = true;
            if (it.w() != h0 || it.h() != w0) { flipped++; bad.append(' ').append(d.id).append("(footprint)"); }
            it.rotated = false;
        }
        float[] r = {0.1f, 0.2f, 0.3f, 0.6f};
        float[] u0 = absentialis.ui.ItemIcons.cornerUv(r, false), u1 = absentialis.ui.ItemIcons.cornerUv(r, true);
        check("every definition placed unrotated by default", unplaced == 0, checked + " definitions");
        check("no item is upside down at 0 degrees", upside == 0, upside + " upside down");
        check("footprints match the upright model (no sideways squeeze)", aspect == 0, aspect + " mismatched");
        check("rotation (R) swaps w/h as a pure quarter turn, no vertical flip", flipped == 0, flipped + " bad");
        check("draw path uses the same quarter turn (UV corners)", u0[0] == 0.1f && u0[1] == 0.2f && u1[0] == 0.3f && u1[1] == 0.2f && u1[6] == 0.1f && u1[7] == 0.2f, null);
        check("square slots never rotate, tall cells rotate wide items", !absentialis.ui.ItemIcons.rotatedIn(6, 2, 58, 58) && absentialis.ui.ItemIcons.rotatedIn(6, 2, 40, 120) && !absentialis.ui.ItemIcons.rotatedIn(6, 2, 120, 40), null);
        if (bad.length() > 0) System.out.println("    orientation problems:" + bad);
    }

    // ------------------------------------------------------------------ inventory
    private static void inventory() {
        System.out.println("[Inventory: fit / rotate / illegal reject / no overlap]");
        Container c = new Container("t", 12, 16);
        ItemInstance rifle = item("weapon.sr16", 1); // 6x2: long guns lie along the grid at 0 degrees
        check("place rifle 6x2 at origin", InventoryService.add(rifle, c).ok() && rifle.w() == 6 && rifle.h() == 2, null);
        ItemInstance pistol = item("weapon.pm9", 1); // 3x2
        check("overlap rejected", !InventoryService.move(pistol, c, 4, 1, false).ok() && pistol.container == null, null);
        check("out of bounds rejected", !InventoryService.move(pistol, c, 11, 0, false).ok(), null);
        check("rotated fit (2x3 at 10,13)", InventoryService.move(pistol, c, 10, 13, true).ok() && pistol.w() == 2 && pistol.h() == 3, null);
        check("rotation that would overflow rejected", !InventoryService.move(rifle, c, 7, 15, true).ok() && rifle.x == 0 && rifle.y == 0, "rifle stays put");
        check("grid verify clean", c.verify() == null, c.verify());
        ItemInstance bandage = item("med.bandage", 1);
        check("1x1 bandage footprint", bandage.baseW() == 1 && bandage.baseH() == 1, null);
        check("mag footprint 1x2", item("mag.stanag", 1).baseW() == 1 && item("mag.stanag", 1).baseH() == 2, null);
        // auto-sort never loses items
        Container s = new Container("s", 12, 16);
        Rng r = new Rng(5);
        List<String> ids = new ArrayList<>(Content.ITEMS.keySet());
        for (int k = 0; k < 60; k++) { ItemDef d = Content.def(ids.get(r.nextInt(ids.size()))); if (d.w <= 6 && d.h <= 8) InventoryService.add(item(d.id, 1), s); }
        int before = s.items.size();
        Map<String, Integer> lb = InventoryService.ledger(s.items);
        InventoryService.Result res = InventoryService.autoSort(s);
        check("auto-sort keeps every item and quantity", InventoryService.ledger(s.items).equals(lb) && s.verify() == null, res.ok() ? before + " items" : res.msg());
        // loadout pouches take no grid space
        Loadout l = new Loadout();
        InventoryService.store(item("key.crypt", 1), l);
        InventoryService.store(item("treasure.gem_red", 1), l);
        check("keys/treasures go to space-free pouches", l.keys.size() == 1 && l.treasures.size() == 1 && l.caseGrid.items.isEmpty(), null);
        check("case is 12x16 base", l.caseGrid.w == 12 && l.caseGrid.h == 16, null);
        l.resizeCase(99, 99);
        check("case caps at 16x20", l.caseGrid.w == 16 && l.caseGrid.h == 20, null);
    }

    private static void conservation() {
        System.out.println("[Transactions conserve quantities]");
        Container c = new Container("t", 10, 10);
        ItemInstance a = item("ammo.556", 60), b = item("ammo.556", 30);
        // addendum example uses a 30-cap: emulate with two magazines of 30 + 15
        ItemInstance m1 = item("mag.stanag", 1), m2 = item("mag.stanag", 1);
        m1.rounds = 30; m1.ammoId = "ammo.556"; m2.rounds = 15; m2.ammoId = "ammo.556";
        InventoryService.add(m1, c); InventoryService.add(m2, c);
        Map<String, Integer> before = InventoryService.ledger(c.items);
        InventoryService.Result r = InventoryService.combine(item("ammo.556", 1), m1); // full mag: rejects, no change
        check("30/30 + 15/30 never becomes 45", m1.rounds == 30 && m2.rounds == 15 && !r.ok() && InventoryService.ledger(c.items).equals(before), "m1=" + m1.rounds + " m2=" + m2.rounds);
        InventoryService.add(a, c);
        InventoryService.add(b, c);
        Map<String, Integer> l0 = InventoryService.ledger(c.items);
        InventoryService.combine(a, m2); // top up m2 from loose rounds
        check("loading a magazine conserves rounds", InventoryService.ledger(c.items).equals(l0) && m2.rounds == 30, "m2=" + m2.rounds);
        InventoryService.unload(m1, c);
        check("unloading conserves rounds", InventoryService.ledger(c.items).equals(l0) && m1.rounds == 0, null);
        ItemInstance st = item("ammo.9x19", 40);
        InventoryService.add(st, c);
        Map<String, Integer> l1 = InventoryService.ledger(c.items);
        int[] sp = c.findSpace(item("ammo.9x19", 1));
        InventoryService.split(st, 15, c, sp[0], sp[1]);
        check("split conserves quantity", InventoryService.ledger(c.items).equals(l1), null);
        // stack merge moves only what fits
        ItemInstance s1 = item("ammo.9x19", 45), s2 = item("ammo.9x19", 20);
        Container c2 = new Container("u", 6, 6);
        InventoryService.move(s1, c2, 0, 0, false); InventoryService.move(s2, c2, 0, 2, false);
        InventoryService.combine(s2, s1);
        check("stack merge clamps at max stack", s1.qty == 50 && s2.qty == 15 && s2.container == c2, s1.qty + "/" + s2.qty);
        // weapon: tactical reload keeps chambered round (mag -1, round retained)
        ItemInstance w = item("weapon.sr16", 1);
        ItemInstance mag = item("mag.stanag", 1); mag.rounds = 30; mag.ammoId = "ammo.556";
        Container cc = new Container("case", 12, 16);
        InventoryService.add(w, cc); InventoryService.add(mag, cc);
        InventoryService.insertMag(w, mag);
        WeaponService.chamberFromMag(w);
        check("chambering: mag 29 + 1 chambered", mag.rounds == 29 && w.chambered && w.loadedRounds() == 30, null);
        ItemInstance mag2 = item("mag.stanag", 1); mag2.rounds = 30; mag2.ammoId = "ammo.556";
        InventoryService.add(mag2, cc);
        List<ItemInstance> roots = new ArrayList<>(cc.items);
        Map<String, Integer> lw = InventoryService.ledger(roots);
        WeaponService.Reload rl = WeaponService.reloadMag(w, mag2, cc, 2, false);
        List<ItemInstance> roots2 = new ArrayList<>(cc.items);
        if (rl.oldMag() != null) roots2.add(rl.oldMag());
        check("tactical reload keeps chamber, stows old mag, conserves", rl.tactical() && w.chambered && w.loadedRounds() == 31 && InventoryService.ledger(roots2).equals(lw) && mag.container == cc, "loaded " + w.loadedRounds());
        ItemInstance mag3 = item("mag.stanag", 1); mag3.rounds = 30; mag3.ammoId = "ammo.556";
        InventoryService.add(mag3, cc);
        WeaponService.Reload sp2 = WeaponService.reloadMag(w, mag3, cc, 2, true);
        check("speed reload drops the old mag as an instance with its rounds", sp2.oldMag() == mag2 && mag2.rounds == 30 && mag2.container == null, null);
        // empty reload racks from the new magazine
        ItemInstance w2 = item("weapon.akr", 1);
        ItemInstance am = item("mag.akr", 1); am.rounds = 30; am.ammoId = "ammo.545";
        Container c3 = new Container("c3", 12, 16);
        InventoryService.add(w2, c3); InventoryService.add(am, c3);
        WeaponService.Reload er = WeaponService.reloadMag(w2, am, c3, 2, false);
        check("empty reload racks the action", !er.tactical() && w2.chambered && am.rounds == 29, null);
        check("no duplicate instance uids", uniqueUids(c3), null);
    }

    private static boolean uniqueUids(Container c) {
        List<ItemInstance> all = new ArrayList<>();
        for (ItemInstance i : c.items) i.collect(all);
        return all.stream().map(i -> i.uid).distinct().count() == all.size();
    }

    // ------------------------------------------------------------------ weapons
    private static void weapons() {
        System.out.println("[Weapon degradation / gunsmith]");
        ItemInstance w = item("weapon.akr", 1);
        w.setCondition(80);
        check("condition >=50: negligible jam", Gunsmith.stats(w, 0).jamChance < 0.01f, null);
        w.setCondition(40);
        Gunsmith.Stats s = Gunsmith.stats(w, 0);
        check("condition <50: 2% jam, +2% spread, red band", Math.abs(s.jamChance - 0.02f) < 1e-4 && s.conditionBand == 1, null);
        w.setCondition(20);
        s = Gunsmith.stats(w, 0);
        check("condition <25: 8% jam, critical", Math.abs(s.jamChance - 0.08f) < 1e-4 && s.conditionBand == 2, null);
        ItemInstance oil = item("mat.gun_oil", 2);
        check("field clean refused below 25 (needs bench)", WeaponService.clean(w, oil, false) != null && oil.qty == 2, null);
        check("bench clean +25 consumes one oil", WeaponService.clean(w, oil, true) == null && Math.round(w.condition()) == 45 && oil.qty == 1, null);
        w.setCondition(100);
        float before = w.condition();
        for (int i = 0; i < 100; i++) WeaponService.wearShot(w, Gunsmith.stats(w, 0), 1);
        float dry = before - w.condition();
        w.setCondition(100);
        for (int i = 0; i < 100; i++) WeaponService.wearShot(w, Gunsmith.stats(w, 0), WeaponService.environmentWear(true, true, false));
        check("rain + sewer accelerate decay", (100 - w.condition()) > dry * 2, String.format("dry %.2f wet %.2f", dry, 100 - w.condition()));
        boolean slotsOk = true;
        for (ItemDef d : Content.ITEMS.values()) if (d.weapon != null && !d.weapon.melee()) { int n = Gunsmith.slotsFor(d).size(); if (n < 5 || n > 9) { slotsOk = false; System.out.println("    " + d.id + " has " + n + " slots"); } }
        check("every platform has 5-9 gunsmith slots", slotsOk, null);
        ItemInstance sr = item("weapon.sr16", 1);
        ItemInstance supp = item("att.suppressor_rifle", 1), pist = item("att.suppressor_pistol", 1);
        Container c = new Container("c", 12, 16);
        InventoryService.add(sr, c); InventoryService.add(supp, c); InventoryService.add(pist, c);
        float noise0 = Gunsmith.stats(sr, 0).noise;
        String v0 = sr.visualKey();
        check("incompatible part rejected", !InventoryService.attach(sr, pist).ok() && pist.parent == null, null);
        check("compatible part fitted, quieter, new model key", InventoryService.attach(sr, supp).ok() && Gunsmith.stats(sr, 0).noise < noise0 && !sr.visualKey().equals(v0), null);
        check("part adds length to footprint", sr.baseW() == 7, "w=" + sr.baseW());
        int[] k1 = {0}; float a = Gunsmith.recoilKick(Content.def("weapon.akr"), 6)[1], b = Gunsmith.recoilKick(Content.def("weapon.sr16"), 6)[1];
        check("distinct recoil pattern per platform", Math.abs(a - b) > 1e-3 || k1[0] != 0, a + " vs " + b);
        ItemInstance g = item("weapon.akr", 1);
        g.setCondition(10);
        Rng rng = new Rng(3);
        ItemInstance gm = item("mag.akr", 1); gm.rounds = 30; gm.ammoId = "ammo.545";
        g.mag = gm; gm.parent = g; WeaponService.chamberFromMag(g);
        int jams = 0;
        for (int i = 0; i < 400; i++) { if (WeaponService.fire(g, Gunsmith.stats(g, 0), 1, rng) == null) { if (g.jammed) { jams++; WeaponService.clearJam(g); } if (gm.rounds == 0) { gm.rounds = 30; gm.ammoId = "ammo.545"; WeaponService.chamberFromMag(g); } } g.setCondition(10); }
        check("critical weapons jam in practice", jams > 5, jams + " jams in 400 trigger pulls");
    }

    // ------------------------------------------------------------------ progression
    private static void progression() {
        System.out.println("[Rank / Prestige]");
        check("cycle = 1,265,500 XP", Progression.xpToReach(50) + Progression.costOf(50) == Progression.CYCLE_XP, Progression.xpToReach(50) + Progression.costOf(50) + "");
        check("Master ~19M XP (15 cycles)", Progression.totalToMaster() == 18_982_500L, null);
        Progression p = new Progression();
        p.addXp(Progression.xpToReach(10));
        check("rank from XP", p.rank() == 10, "rank " + p.rank());
        check("cannot prestige before rank 50 complete", p.prestige() != null && p.prestige == 0, null);
        p.addXp(Progression.CYCLE_XP);
        p.addMastery("weapon.akr", 9000);
        int mastery = p.masteryLevel("weapon.akr");
        check("prestige 1", p.prestige() == null && p.prestige == 1 && p.rank() == 1 && p.tokens == 1, null);
        check("token must be spent before next prestige", !p.canPrestige(), null);
        check("token unlock", p.spendToken("platform:weapon.sr16") == null && p.platformUnlocked("weapon.sr16") && p.rank() < Progression.platformRank("weapon.sr16"), null);
        p.tokens = 1;
        check("tokens do not stack", p.spendToken("platform:weapon.sr16") != null, null);
        p.tokens = 0;
        check("mastery persists through prestige", p.masteryLevel("weapon.akr") == mastery && mastery > 0, "lvl " + mastery);
        check("P1 grants stash row + preset", p.prestigeStashRows() == 1 && p.presets() == 2, null);
        // walk to master
        for (int i = 2; i <= 15; i++) { p.addXp(Progression.CYCLE_XP); p.prestige(); p.tokens = 0; }
        check("Master at P15 with emblem + gold finish", p.master() && p.cosmetics.contains("master_emblem") && p.cosmetics.contains("gold_finish") && p.bannerLayers() == 6, null);
        // prestige strips deployed loadout but keeps cosmetics
        Profile pr = new Profile();
        ItemInstance ak = item("weapon.akr", 1);
        InventoryService.add(ak, pr.stash);
        InventoryService.equip(ak, pr.loadout, "primary");
        pr.prog.addXp(Progression.CYCLE_XP);
        pr.prog.prestige();
        pr.loadout.strip(true);
        check("prestige forfeits deployed loadout", pr.loadout.slot("primary") == null, null);
        check("rank never affects damage (stats independent of rank)", Gunsmith.stats(item("weapon.akr", 1), 0).dispersion == Gunsmith.stats(item("weapon.akr", 1), 0).dispersion, null);
    }

    // ------------------------------------------------------------------ economy
    private static void economy() {
        System.out.println("[Economy sustainable, no infinite loops]");
        ZoneState z = ZoneState.fresh();
        String audit = Economy.audit(z, Map.of("survivors", 100f, "military", 100f, "raiders", 100f, "mercenaries", 100f));
        check("no profitable buy->sell round trip", audit.contains("[OK"), audit);
        ItemInstance w = item("val.watch", 1);
        int p0 = Economy.sellPrice(w, Economy.trader("mara"), z, 0, 0), p5 = Economy.sellPrice(w, Economy.trader("mara"), z, 0, 5);
        check("repeated sales saturate", p5 < p0, p0 + " -> " + p5);
        ItemInstance fb = Economy.fallbackKit().get(0);
        check("fallback kit has no resale value", Economy.sellPrice(fb, Economy.trader("mara"), z, 0, 0) == 0, null);
        float before = Economy.buyPrice(Content.def("med.bandage"), Economy.trader("mara"), z, 0);
        for (District d : District.CITY) z.reportLoot(d, "medicine", 60);
        check("scarcity raises prices", Economy.buyPrice(Content.def("med.bandage"), Economy.trader("mara"), z, 0) > before, null);
    }

    // ------------------------------------------------------------------ save/load
    private static void saveLoad() {
        System.out.println("[Save/load preserves world, inventory, missions, rank]");
        Profile p = new Profile();
        p.name = "Test";
        p.starterKit();
        ItemInstance ak = null;
        for (ItemInstance i : p.stash.items) if (i.defId.equals("weapon.akr")) ak = i;
        InventoryService.equip(ak, p.loadout, "primary");
        ItemInstance mag = null;
        for (ItemInstance i : p.stash.items) if (i.defId.equals("mag.akr")) mag = i;
        InventoryService.insertMag(ak, mag);
        WeaponService.chamberFromMag(ak);
        ak.setCondition(42);
        InventoryService.store(item("key.crypt", 1), p.loadout);
        p.prog.addXp(500_000);
        p.prog.addMastery("weapon.akr", 1234);
        p.zone.reportKill(District.MARKET, "survivors", true);
        p.zone.power[District.INDUSTRIAL.ordinal()] = true;
        p.contracts.refill(9, 5);
        p.contracts.accept(p.contracts.board.get(0).id);
        p.discover(300, 300, 4);
        p.addRep("military", 12);
        p.applyCapacity();
        String a = Json.write(p.toJson());
        Profile q = Profile.fromJson(Json.parseObject(a));
        String b = Json.write(q.toJson());
        int diff = 0;
        while (diff < Math.min(a.length(), b.length()) && a.charAt(diff) == b.charAt(diff)) diff++;
        check("profile JSON round-trip is lossless", a.equals(b), a.length() + " chars" + (a.equals(b) ? "" : " first diff @" + diff + ": " + a.substring(Math.max(0, diff - 60), Math.min(a.length(), diff + 40)).replace((char) 10, ' ') + " ||| " + b.substring(Math.max(0, diff - 60), Math.min(b.length(), diff + 40)).replace((char) 10, ' ')));
        check("weapon instance state survives (mag, chamber, condition)", q.loadout.slot("primary") != null && q.loadout.slot("primary").chambered && q.loadout.slot("primary").mag != null && Math.round(q.loadout.slot("primary").condition()) == 42, null);
        check("rank/mastery/contracts/world/discovery survive", q.prog.rank() == p.prog.rank() && q.prog.mastery.get("weapon.akr") == 1234 && q.contracts.active.size() == 1 && q.zone.power[District.INDUSTRIAL.ordinal()] && q.discovered(300 / 8, 300 / 8), null);
        // a pre-iteration (v2) save: long guns were stored upright and there was no appearance record
        Profile legacy = new Profile();
        ItemInstance oldRifle = item("weapon.akr", 1);
        InventoryService.move(oldRifle, legacy.stash, 0, 0, true);                 // occupies 2 wide x 6 tall, as it did in v2
        Map<String, Object> v2 = legacy.toJson();
        v2.put("version", 2);
        v2.remove("appearance");
        v2.put("skin", 3); v2.put("outfit", 1);
        for (Object o : (List<?>) v2.get("stash")) ((Map<?, ?>) o).remove("rot");  // in v2 that footprint was "not rotated"
        Profile migrated = Profile.fromJson(Json.parseObject(Json.write(v2)));
        ItemInstance mr = migrated.stash.items.isEmpty() ? null : migrated.stash.items.get(0);
        check("v2 saves migrate: footprints unchanged after definitions were re-oriented", mr != null && mr.x == 0 && mr.y == 0 && mr.w() == 2 && mr.h() == 6 && migrated.verify() == null, mr == null ? "rifle lost" : mr.w() + "x" + mr.h());
        check("v2 saves migrate: old skin/outfit become definition ids", migrated.appearance.key().equals(absentialis.character.Appearance.legacy(3, 1).key()), null);
        check("profile verify clean", q.verify() == null, q.verify());
    }

    // ------------------------------------------------------------------ world fixtures
    private static World flatWorld() {
        if (flat != null) return flat;
        World w = new World();
        for (int x = 0; x < World.W; x++) for (int z = 0; z < World.D; z++) {
            w.districtMap[x * World.D + z] = (byte) (x < 352 ? District.MARKET.ordinal() : District.INDUSTRIAL.ordinal());
            for (int y = 0; y < World.GROUND; y++) w.setRaw(x, y, z, y == World.GROUND - 1 ? Block.ASPHALT : Block.DIRT);
        }
        w.computeHeights();
        for (int x = 0; x < World.W; x++) for (int z = 0; z < World.D; z++) for (int y = World.GROUND; y < World.H; y++) w.light[World.idx(x, y, z)] = (byte) 0xF0;
        MapData m = w.map;
        m.insertions.add(new MapData.Point("Test Insertion", "insertion", 200, World.GROUND, 200, District.MARKET));
        m.exits.add(new MapData.Exit("gate", "Test Gate", 210, World.GROUND, 200, MapData.ExitType.PERMANENT, District.MARKET));
        MapData.Exit cond = new MapData.Exit("toll", "Toll Bridge", 230, World.GROUND, 200, MapData.ExitType.CONDITIONAL, District.MARKET);
        cond.condition = "rep:military:50|pay:999999";
        m.exits.add(cond);
        m.exits.add(new MapData.Exit("cordon", "Cordon", 250, World.GROUND, 200, MapData.ExitType.EMERGENCY, District.MARKET));
        for (int x = 40; x < 660; x += 20) for (int z = 40; z < 660; z += 20) m.addNode(x, World.GROUND, z, w.district(x, z));
        flat = w;
        return w;
    }

    private static Raid raid(Profile p) {
        Raid r = new Raid(flatWorld(), p, new Settings(), new EventBus(), 0, 30);
        return r;
    }

    // ------------------------------------------------------------------ death
    private static void death() {
        System.out.println("[Death persistence: loss once, profile valid]");
        Profile p = new Profile();
        p.starterKit();
        for (ItemInstance i : new ArrayList<>(p.stash.items)) if (i.def().slot != null && p.loadout.slot(i.def().slot) == null) InventoryService.equip(i, p.loadout, i.def().slot);
        InventoryService.store(item("med.bandage", 1), p.loadout);
        InventoryService.store(item("key.crypt", 1), p.loadout);
        int stashBefore = p.stash.items.size();
        Raid r = raid(p);
        r.die("test");
        r.die("again");
        List<String> out1 = RaidResolver.resolve(r);
        long xp = p.prog.lifetimeXp;
        List<String> out2 = RaidResolver.resolve(r);
        check("death resolves exactly once", !out1.isEmpty() && out2.isEmpty() && p.prog.lifetimeXp == xp && p.stat("deaths") == 1, null);
        check("carried gear lost", p.loadout.slot("primary") == null && p.loadout.caseGrid.items.isEmpty(), null);
        check("keys (profile-bound) survive death", p.loadout.keys.size() == 1, null);
        check("stash untouched", p.stash.items.size() == stashBefore, null);
        check("profile remains valid", p.verify() == null, p.verify());
    }

    // ------------------------------------------------------------------ extraction
    private static void extraction() {
        System.out.println("[Extraction eligibility / time / activation / debrief]");
        Profile p = new Profile();
        Raid r = raid(p);
        Raid.ExitState gate = null, toll = null, cordon = null;
        for (Raid.ExitState s : r.exits) { if (s.exit.id.equals("gate")) gate = s; if (s.exit.id.equals("toll")) toll = s; if (s.exit.id.equals("cordon")) cordon = s; }
        check("permanent exit eligible", gate.eligible, gate.requirement);
        check("conditional exit shows conditions and is closed", !toll.eligible && toll.requirement.contains("standing") && toll.requirement.contains("toll"), toll.requirement);
        check("emergency exit closed before zero", !cordon.eligible, null);
        r.player.x = 210.5f; r.player.z = 200.5f; r.player.y = World.GROUND;
        for (int i = 0; i < 60 * 4; i++) r.update(1 / 60f);
        check("activation requires dwell time (not instant)", r.debrief.outcome == Raid.Debrief.Outcome.NONE && r.extractProgress > 3, "progress " + r.extractProgress);
        for (int i = 0; i < 60 * 5; i++) r.update(1 / 60f);
        check("extraction completes after 8s in zone", r.debrief.outcome == Raid.Debrief.Outcome.EXTRACTED, String.valueOf(r.debrief.outcome));
        // timer: ordinary exits close at zero, emergency opens, missing it = MIA
        Raid r2 = raid(new Profile());
        r2.player.x = 400; r2.player.z = 400;
        r2.time = r2.duration + 1;
        r2.evaluateExits();
        Raid.ExitState g2 = null, c2 = null;
        for (Raid.ExitState s : r2.exits) { if (s.exit.id.equals("gate")) g2 = s; if (s.exit.id.equals("cordon")) c2 = s; }
        check("at zero ordinary exits close, emergency opens", !g2.eligible && c2.eligible, null);
        r2.time = r2.duration + 179;
        r2.update(2);
        check("missing extraction is a failed raid (MIA)", r2.debrief.outcome == Raid.Debrief.Outcome.MIA, String.valueOf(r2.debrief.outcome));
        // determinism of eligibility
        Raid r3 = raid(new Profile()), r4 = raid(new Profile());
        boolean same = true;
        for (int i = 0; i < r3.exits.size(); i++) same &= r3.exits.get(i).eligible == r4.exits.get(i).eligible && r3.exits.get(i).requirement.equals(r4.exits.get(i).requirement);
        check("eligibility deterministic for identical state", same, null);
    }

    // ------------------------------------------------------------------ noise / perception
    private static Actor walker(Raid r, float x, float z) {
        Actor a = new Actor();
        a.faction = "infected"; a.archetype = "walker";
        a.hp = a.maxHp = 90;
        a.x = x; a.z = z; a.y = World.GROUND; a.homeX = x; a.homeZ = z;
        a.yaw = 0;
        r.actors.add(a);
        return a;
    }

    private static void noise() {
        System.out.println("[Noise triggers plausible investigation, no omniscience]");
        Profile p = new Profile();
        Raid r = raid(p);
        r.populate = false;
        r.actors.removeIf(a -> !a.isPlayer);
        r.player.x = 200; r.player.z = 200; r.player.y = World.GROUND;
        Actor near = walker(r, 200, 240), far = walker(r, 200, 620);
        near.yaw = 0; // facing away (-z is forward; player is at lower z... face +z away)
        near.yaw = (float) Math.PI;
        r.emitSound(200, World.GROUND + 1, 200, 120, "shot", r.player.id, false);
        check("nearby agent investigates a gunshot", "investigate".equals(near.state), near.state);
        float err = (float) Math.hypot(near.memX - 200, near.memZ - 200);
        check("memory holds an estimated (not exact) position", err > 0.01f && err < 20, String.format("error %.1fm", err));
        check("distant agent is not omniscient", "idle".equals(far.state) && far.memTime < 0, far.state);
        // a quiet step only reaches very close listeners
        Actor ear = walker(r, 203, 200);
        ear.state = "idle";
        r.emitSound(200, World.GROUND, 200, 2.5f, "step", r.player.id, false);
        Actor mid = walker(r, 200, 215);
        r.emitSound(200, World.GROUND, 200, 2.5f, "step", r.player.id, false);
        check("crouched footstep heard only up close", "investigate".equals(ear.state) && "idle".equals(mid.state), ear.state + "/" + mid.state);
        // the investigation leads them toward the source over time
        float d0 = near.distXZ(200, 200);
        for (int i = 0; i < 60 * 6; i++) r.update(1 / 60f);
        check("investigation moves toward the sound", near.distXZ(200, 200) < d0 - 2, String.format("%.1f -> %.1f", d0, near.distXZ(200, 200)));
    }

    private static void evidence() {
        System.out.println("[Faction response requires evidence]");
        Profile p = new Profile();
        Raid r = raid(p);
        r.populate = false;
        r.actors.removeIf(a -> !a.isPlayer);
        r.player.x = 200; r.player.z = 200; r.player.y = World.GROUND;
        Actor s1 = human(r, "survivors", 205, 200), s2 = human(r, "survivors", 260, 260);
        check("survivors start neutral to a neutral player", !s1.hostileToPlayer && !Brain.hostile(r, s1, r.player), null);
        r.damageActor(s1, r.player, 500, Content.def("ammo.556"), "torso", s1.x, s1.y + 1, s1.z);
        check("unwitnessed kill does not alert distant members", !s2.hostileToPlayer, null);
        float unwitnessed = r.debrief.repDelta.getOrDefault("survivors", 0f);
        Actor s3 = human(r, "survivors", 205, 205), s4 = human(r, "survivors", 208, 207);
        r.damageActor(s3, r.player, 500, Content.def("ammo.556"), "torso", s3.x, s3.y + 1, s3.z);
        check("witnessed kill turns witnesses hostile", s4.hostileToPlayer, null);
        check("witnessed kill costs more standing than unwitnessed", r.debrief.repDelta.get("survivors") - unwitnessed < unwitnessed, r.debrief.repDelta.toString());
    }

    private static Actor human(Raid r, String faction, float x, float z) {
        Actor a = new Actor();
        a.faction = faction; a.archetype = "rifleman";
        a.hp = a.maxHp = 100;
        a.x = x; a.z = z; a.y = World.GROUND; a.homeX = x; a.homeZ = z;
        a.hostileToPlayer = Brain.initialHostility(faction, r.profile.rep(faction));
        a.aggressor = a.hostileToPlayer;
        a.squad = 1;
        r.actors.add(a);
        return a;
    }

    // ------------------------------------------------------------------ ballistics
    private static float shootAt(Raid r, Actor t, String ammo) {
        ItemInstance w = item("weapon.sr16", 1);
        float hp = t.hp;
        float ox = r.player.x, oy = World.GROUND + 1.5f, oz = r.player.z;
        float dx = t.x - ox, dy = (t.y + 1.2f) - oy, dz = t.z - oz, l = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        r.fireProjectiles(r.player, w, Content.def(ammo), ox, oy, oz, dx / l, dy / l + 0.002f, dz / l, 0);
        for (int i = 0; i < 60; i++) r.update(1 / 120f);
        return hp - t.hp;
    }

    private static void ballistics() {
        System.out.println("[Ballistics: projectiles, drop, voxel penetration]");
        Profile p = new Profile();
        Raid r = raid(p);
        r.populate = false;
        r.actors.removeIf(a -> !a.isPlayer);
        r.player.x = 300; r.player.z = 300; r.player.y = World.GROUND;
        r.god = true;
        Actor t = walker(r, 300, 330);
        t.hp = t.maxHp = 5000;
        float open = shootAt(r, t, "ammo.556");
        check("projectile travels and hits a target at 30m", open > 20, "damage " + open);
        World w = r.world;
        for (int y = World.GROUND; y < World.GROUND + 4; y++) for (int x = 297; x <= 303; x++) w.setRaw(x, y, 315, Block.GLASS);
        float glass = shootAt(r, t, "ammo.556");
        check("rounds penetrate glass (and break it)", glass > 10 && w.get(300, World.GROUND + 1, 315) != Block.GLASS, "damage " + glass);
        for (int y = World.GROUND; y < World.GROUND + 4; y++) for (int x = 297; x <= 303; x++) for (int z = 315; z <= 316; z++) w.setRaw(x, y, z, Block.CONCRETE);
        float wall = shootAt(r, t, "ammo.556");
        check("concrete stops small arms", wall == 0, "damage " + wall);
        for (int y = World.GROUND; y < World.GROUND + 4; y++) for (int x = 297; x <= 303; x++) for (int z = 315; z <= 316; z++) w.setRaw(x, y, z, z == 315 ? Block.WOOD_PLANKS : Block.AIR);
        float wood = shootAt(r, t, "ammo.762x54");
        check("precision rounds punch through wood", wood > 10, "damage " + wood);
        for (int y = World.GROUND; y < World.GROUND + 4; y++) for (int x = 297; x <= 303; x++) w.setRaw(x, y, 315, Block.AIR);
        // drop: a level shot at long range lands lower than it started
        r.fireProjectiles(r.player, item("weapon.pm9", 1), Content.def("ammo.9x19"), 300, World.GROUND + 20, 300, 1, 0, 0, 0);
        Raid.Projectile last = r.projectiles.get(r.projectiles.size() - 1);
        for (int i = 0; i < 30; i++) r.update(1 / 60f);
        check("projectiles drop under gravity (not hitscan)", last.y < World.GROUND + 20 - 0.5f, String.format("y %.2f after 0.5s", last.y));
        check("shots leave a sound signature", r.sounds.stream().anyMatch(x -> x.category().equals("impact")), r.sounds.size() + " recent sounds");
        for (int y = World.GROUND; y < World.GROUND + 4; y++) for (int x = 297; x <= 303; x++) for (int z = 315; z <= 316; z++) w.setRaw(x, y, z, Block.AIR);
    }

    // ------------------------------------------------------------------ tiers / offscreen
    private static void tiers() {
        System.out.println("[AI tiers transition without spikes or duplicates]");
        Profile p = new Profile();
        Raid r = raid(p);
        r.player.x = 200; r.player.z = 200; r.player.y = World.GROUND;
        r.update(1.1f);
        int pop0 = r.populationTotal() + r.deaths;
        int maxDelta = 0;
        long worst = 0;
        float[][] path = {{200, 200}, {500, 200}, {500, 500}, {200, 500}, {200, 200}};
        for (float[] pt : path) {
            r.player.x = pt[0]; r.player.z = pt[1];
            for (int i = 0; i < 3; i++) {
                long t0 = System.nanoTime();
                r.update(1.1f);
                worst = Math.max(worst, System.nanoTime() - t0);
                int pop = r.populationTotal() + r.deaths;
                maxDelta = Math.max(maxDelta, Math.abs(pop - pop0));
            }
        }
        check("population conserved across tier transitions (living + dead)", maxDelta == 0, "population " + pop0 + ", " + r.deaths + " died in fighting, drift " + maxDelta);
        long ids = r.actors.stream().map(a -> a.id).distinct().count();
        check("no duplicated actor ids", ids == r.actors.size(), null);
        check("no frame spike on cell transitions", worst < 250_000_000L, (worst / 1_000_000) + " ms worst update");
    }

    private static void offscreen() {
        System.out.println("[Offscreen outcomes translate consistently near the player]");
        ZoneState z = ZoneState.fresh();
        float before = z.control(District.INDUSTRIAL, "raiders");
        for (int i = 0; i < 8; i++) z.reportKill(District.INDUSTRIAL, "raiders", true);
        check("strategic losses reduce faction influence", z.control(District.INDUSTRIAL, "raiders") < before, String.format("%.2f -> %.2f", before, z.control(District.INDUSTRIAL, "raiders")));
        Profile hi = new Profile(), lo = new Profile();
        lo.zone = z;
        hi.zone = ZoneState.fresh();
        Raid a = raid(hi), b = raid(lo);
        int ra = countFaction(a, "raiders"), rb = countFaction(b, "raiders");
        check("weakened faction fields fewer agents near the player", rb <= ra, ra + " -> " + rb);
        ZoneState z2 = ZoneState.fresh();
        z2.advance(48, 1);
        ZoneState z3 = ZoneState.fresh();
        z3.advance(48, 1);
        check("strategic advance deterministic", Json.write(z2.toJson()).equals(Json.write(z3.toJson())), null);
    }

    private static int countFaction(Raid r, String f) {
        r.player.x = 500; r.player.z = 300;
        r.update(1.1f);
        int n = 0;
        for (Actor a : r.actors) if (f.equals(a.faction)) n++;
        return n + r.populationTotal() * 0;
    }

    // ================================================================== iteration gates
    private static void character() {
        System.out.println("[Customization: definition tables, SKIN groups validated, parts combine at runtime]");
        var problems = absentialis.character.CharDefs.validate();
        check("every part's SKIN assignment validates on import", problems.isEmpty(), problems.isEmpty() ? "" : String.join("; ", problems.subList(0, Math.min(4, problems.size()))));
        int min = 99;
        for (var c : absentialis.character.CharDefs.Category.values()) min = Math.min(min, absentialis.character.CharDefs.count(c));
        check("12+ options in every category", min >= 12 && absentialis.character.CharDefs.Category.values().length >= 9, "smallest category has " + min);
        Rng r = new Rng(77);
        int clipped = 0, holes = 0, built = 0;
        String[] heads = {"", "cap", "helmet", "beanie", "hood"}, faces = {"", "gasmask", "balaclava", "bandana"}, vests = {"", "soft", "plate", "mil"}, packs = {"", "case", "small", "large"};
        for (int k = 0; k < 400; k++) {
            var app = absentialis.character.Appearance.random(r);
            var gear = new absentialis.character.CharBuilder.Gear();
            gear.head = r.pick(heads); gear.face = r.pick(faces); gear.vest = r.pick(vests); gear.pack = r.pick(packs);
            var m = absentialis.character.CharBuilder.build(app, gear);
            built++;
            if (m.clipped) clipped++;
            // the body under the clothes is still whole: no combination opens a hole in a limb or the torso
            boolean hole = false;
            for (int x = 3; x <= 10 && !hole; x++) for (int y = 0; y <= 11; y++) for (int z = 4; z <= 7; z++) if (m.get(absentialis.character.Rig.TORSO, x, y, z) == 0) hole = true;
            for (int g : new int[]{absentialis.character.Rig.L_THIGH, absentialis.character.Rig.R_THIGH, absentialis.character.Rig.L_UPPER_ARM, absentialis.character.Rig.R_UPPER_ARM}) for (int x = 1; x <= 4 && !hole; x++) for (int y = 1; y <= 5; y++) for (int z = 1; z <= 4; z++) if (m.get(g, x, y, z) == 0) hole = true;
            if (hole) holes++;
        }
        check("400 random combinations assemble without clipping a grid", clipped == 0, built + " built, " + clipped + " clipped");
        check("no combination leaves a hole in the body", holes == 0, holes + " with holes");
        Profile p = new Profile();
        p.appearance = absentialis.character.Appearance.random(new Rng(5));
        String json = Json.write(p.appearance.toJson());
        var back = absentialis.character.Appearance.fromJson(Json.parseObject(json));
        check("profile stores definition ids, not meshes", back.key().equals(p.appearance.key()) && json.length() < 500 && json.contains("hair."), json.length() + " chars");
        var hair = absentialis.character.CharDefs.part(absentialis.character.CharDefs.Category.HAIR, absentialis.character.CharDefs.indexOf(absentialis.character.CharDefs.Category.HAIR, "hair.long"));
        check("hairstyles are skinned to the head group only (follow head animation for free)", hair.groups() == absentialis.character.Rig.bit(absentialis.character.Rig.HEAD), null);
        absentialis.character.CharBuilder.Gear g1 = new absentialis.character.CharBuilder.Gear(), g2 = new absentialis.character.CharBuilder.Gear(); g2.vest = "plate"; g2.pack = "large";
        int bare = absentialis.character.CharBuilder.build(p.appearance, g1).groups[absentialis.character.Rig.TORSO].count(), kitted = absentialis.character.CharBuilder.build(p.appearance, g2).groups[absentialis.character.Rig.TORSO].count();
        check("armour and backpack change the silhouette", kitted > bare + 150, bare + " -> " + kitted + " torso voxels");
        Loadout lo = new Loadout();
        check("backpack slot adds a storage grid", InventoryService.equip(item("bag.large", 1), lo, "backpack").ok() && lo.packGrid() != null && lo.packGrid().w == 8, null);
    }

    /** Evaluates a pose and returns the world position of the left/right sole and the head pivot. */
    private static float[][] feet(Actor a, absentialis.character.Pose pose, absentialis.engine.math.Mat4[] bones) {
        absentialis.engine.math.Mat4 base = new absentialis.engine.math.Mat4(), hips = new absentialis.engine.math.Mat4();
        float s = absentialis.character.Rig.VOX;
        base.identity().translate(a.x, a.y + a.anim.visY, a.z).rotateY(a.yaw).scale(s, s, s);
        absentialis.character.Rig.fk(pose, base, hips, bones);
        float[][] o = new float[3][3];
        bones[absentialis.character.Rig.L_SHIN].transformPoint(0, -6, 0, o[0]);
        bones[absentialis.character.Rig.R_SHIN].transformPoint(0, -6, 0, o[1]);
        bones[absentialis.character.Rig.HEAD].transformPoint(0, 5.3f, 0, o[2]);
        return o;
    }

    private static void animation() {
        System.out.println("[Animation: no foot sliding, independent upper/lower body, 120 ms blends, head-bone camera]");
        String[] need = {"idle", "walk", "sprint", "crouch_idle", "crouch_walk", "wpn_aim", "fire", "reload_tac", "reload_empty", "equip", "interact", "heal", "hit", "stumble", "climb", "vault", "death"};
        StringBuilder missing = new StringBuilder();
        for (String n : need) if (!absentialis.character.Anims.has(n) || absentialis.character.Anims.get(n).keyCount() == 0) missing.append(n).append(' ');
        check("all required states exist as keyframe sequences", missing.length() == 0, absentialis.character.Anims.all().size() + " clips" + (missing.length() > 0 ? ", missing " + missing : ""));
        absentialis.engine.math.Mat4[] bones = new absentialis.engine.math.Mat4[absentialis.character.Rig.GROUPS];
        for (int g = 0; g < bones.length; g++) bones[g] = new absentialis.engine.math.Mat4();
        absentialis.character.Pose pose = new absentialis.character.Pose();
        float worst = 0;
        StringBuilder detail = new StringBuilder();
        for (float speed : new float[]{1.4f, 3.4f, 6.0f}) {
            Actor a = new Actor();
            a.faction = "player"; a.isPlayer = true; a.onGround = true; a.y = World.GROUND; a.x = 100; a.z = 100;
            a.anim = new absentialis.character.Animator();
            float dt = 1 / 120f, slip = 0, stance = 0;
            float[][] prev = null;
            for (int i = 0; i < 120 * 4; i++) {
                a.z -= speed * dt;                       // walking forward (-z) at a steady speed
                a.anim.update(a, dt, false, false, false);
                a.anim.pose(a, pose, 0, null, false);
                float[][] f = feet(a, pose, bones);
                if (prev != null && i > 120) for (int k = 0; k < 2; k++) {
                    // a planted foot (on the floor in both frames) should not move over the ground
                    if (f[k][1] - a.y < 0.012f && prev[k][1] - a.y < 0.012f) { slip += Math.hypot(f[k][0] - prev[k][0], f[k][2] - prev[k][2]); stance += dt; }
                }
                prev = f;
            }
            float rel = stance <= 0 ? 1 : slip / stance / speed;
            worst = Math.max(worst, rel);
            detail.append(String.format("%.1f m/s: %.0f%%  ", speed, rel * 100));
        }
        check("stance feet stay planted at walk, jog and sprint", worst < 0.12f, detail + "(slip as a share of body speed)");
        // strafing: hips turn into the movement, the torso keeps facing the aim
        Actor s = new Actor();
        s.faction = "player"; s.isPlayer = true; s.onGround = true; s.y = World.GROUND; s.x = 100; s.z = 100;
        s.anim = new absentialis.character.Animator();
        for (int i = 0; i < 120; i++) { s.x += 3f / 120f; s.anim.update(s, 1 / 120f, false, false, false); }
        s.anim.pose(s, pose, 0, null, false);
        float hip = pose.rootYaw, torsoWorld = pose.rootYaw + pose.ry(absentialis.character.Rig.TORSO);
        check("lower body turns into a strafe while the upper body holds the aim", Math.abs(hip) > 0.4f && Math.abs(torsoWorld) < 0.25f, String.format("hips %.2f rad, torso %.2f rad off aim", hip, torsoWorld));
        // 120 ms blends
        Actor c = new Actor();
        c.faction = "player"; c.isPlayer = true; c.onGround = true; c.y = World.GROUND;
        c.anim = new absentialis.character.Animator();
        c.anim.update(c, 0.016f, false, false, false);
        c.crouch = true;
        float t = 0;
        while (c.anim.crouchT < 0.98f && t < 1) { c.anim.update(c, 1 / 240f, false, false, false); t += 1 / 240f; }
        check("state changes blend in 120 ms", t > 0.06f && t <= 0.125f, String.format("crouch blend %.0f ms", t * 1000));
        // camera on the head bone: eye height comes from the pose and follows crouch and the gait
        c.crouch = false;
        for (int i = 0; i < 60; i++) c.anim.update(c, 1 / 120f, false, false, false);
        c.anim.pose(c, pose, 0, null, true);
        float stand = feet(c, pose, bones)[2][1] - c.y;
        c.crouch = true;
        for (int i = 0; i < 60; i++) c.anim.update(c, 1 / 120f, false, false, false);
        c.anim.pose(c, pose, 0, null, true);
        float crouched = feet(c, pose, bones)[2][1] - c.y;
        c.crouch = false;
        float lo = 9, hi = 0;
        for (int i = 0; i < 240; i++) { c.z -= 4f / 120f; c.anim.update(c, 1 / 120f, false, false, false); c.anim.pose(c, pose, 0, null, true); float e = feet(c, pose, bones)[2][1] - c.y; if (i > 60) { lo = Math.min(lo, e); hi = Math.max(hi, e); } }
        check("first-person eye rides the head bone (height, crouch, gait bob)", stand > 1.5f && stand < 1.75f && crouched < stand - 0.3f && hi - lo > 0.01f && hi - lo < 0.2f, String.format("stand %.2f m, crouch %.2f m, bob %.1f cm", stand, crouched, (hi - lo) * 100));
        check("first-person body keeps its legs (only head and arms are hidden)", (absentialis.scene.ActorRenderer.FP_HIDE & absentialis.character.Rig.LOWER_MASK) == 0 && (absentialis.scene.ActorRenderer.FP_HIDE & absentialis.character.Rig.bit(absentialis.character.Rig.HEAD)) != 0, null);
        // reloads differ by rounds fired
        absentialis.character.Pose a1 = new absentialis.character.Pose(), a2 = new absentialis.character.Pose();
        absentialis.character.Anims.get("reload_tac").sample(0.8f, a1); absentialis.character.Anims.get("reload_empty").sample(0.8f, a2);
        check("tactical and empty reloads are different animations", Math.abs(a1.wpn[8] - a2.wpn[8]) > 1 || Math.abs(a1.wpn[7] - a2.wpn[7]) > 1, null);
    }

    private static void ragdoll() {
        System.out.println("[Ragdoll: constrained 12-part rig, 80 ms hand-over, settles within 8 s, searchable, no cover]");
        Profile p = new Profile();
        Raid r = raid(p);
        r.populate = false; r.freezeAI = true;
        r.actors.removeIf(a -> !a.isPlayer);
        r.player.x = 300; r.player.z = 300; r.player.y = World.GROUND;
        Actor v = r.debugSpawn("raiders", 306, 300, World.GROUND);
        r.update(0.05f);
        v.vx = 2; v.vz = 0;
        r.damageActor(v, r.player, 500, Content.def("ammo.556"), "torso", v.x, v.y + 1.2f, v.z);
        absentialis.character.Ragdoll rd = v.ragdoll;
        check("death starts a 15-joint ragdoll from the animated pose", v.dead && rd != null && !rd.settled, null);
        float stretch = 0, knee = 9, elbow = 9, lowest = 99, settleAt = -1, travelled = 0;
        float x0 = v.x;
        for (int i = 0; i < 60 * 9 && rd != null; i++) {
            r.update(1 / 60f);
            stretch = Math.max(stretch, rd.maxStretch);
            knee = Math.min(knee, Math.min(rd.hingeSide(absentialis.character.Ragdoll.LH, absentialis.character.Ragdoll.LK, absentialis.character.Ragdoll.LA, 1), rd.hingeSide(absentialis.character.Ragdoll.RH, absentialis.character.Ragdoll.RK, absentialis.character.Ragdoll.RA, 1)));
            elbow = Math.min(elbow, Math.min(rd.hingeSide(absentialis.character.Ragdoll.LS, absentialis.character.Ragdoll.LE, absentialis.character.Ragdoll.LW, -1), rd.hingeSide(absentialis.character.Ragdoll.RS, absentialis.character.Ragdoll.RE, absentialis.character.Ragdoll.RW, -1)));
            lowest = Math.min(lowest, rd.lowestY());
            if (rd.settled && settleAt < 0) settleAt = rd.age;
        }
        travelled = Math.abs(v.x - x0);
        check("bones keep their length (no stretching)", stretch < 0.6f, String.format("worst stick error %.2f voxels", stretch));
        check("knees and elbows never hyper-extend", knee > -1.2f && elbow > -1.2f, String.format("knee side %.2f, elbow side %.2f voxels (negative = wrong way)", knee, elbow));
        check("the body rests on the floor, not in it", lowest > World.GROUND - 0.06f, String.format("lowest point %.2f m above the floor", lowest - World.GROUND));
        check("settles to a static corpse within 8 s", settleAt > 0 && settleAt <= absentialis.character.Ragdoll.ACTIVE_TIME + 0.02f, String.format("settled at %.1f s", settleAt));
        check("hit impulse throws the body along the shot", v.x > x0 + 0.15f, String.format("moved %.2f m", travelled));
        check("corpse is searchable where the body lies", r.nearestCorpse(v.x, v.z, 1.8f) == v && v.corpse != null, null);
        check("corpse gives no cover and blocks nothing", v.intersect(v.x - 3, v.y + 0.3f, v.z, 1, 0, 0, 6) < 0 && !r.nearby(v.x, v.z, 2).contains(v), null);
        Actor far = r.debugSpawn("raiders", 420, 300, World.GROUND);
        r.damageActor(far, null, 500, null, "torso", far.x, far.y + 1, far.z);
        check("distant corpses are placed at rest immediately", far.ragdoll != null && far.ragdoll.settled, null);
        check("hand-over from animation takes 80 ms", Math.abs(absentialis.character.Ragdoll.BLEND_TIME - 0.08f) < 1e-4f, null);
    }

    private static void audio() {
        System.out.println("[Audio: buses and mute, positional mix, material footsteps, weapon foley, UI feedback]");
        absentialis.engine.audio.AudioEngine a = new absentialis.engine.audio.AudioEngine();
        new absentialis.engine.audio.SoundBank().build(a.samples);
        StringBuilder missing = new StringBuilder();
        for (String s : new String[]{"step_concrete", "step_metal", "step_dirt", "step_wood", "step_water", "shot_rifle", "shot_pistol", "dry_fire", "jam", "mag_out", "mag_in", "mag_drop", "bolt_back", "bolt_release", "pouch",
                "equip_rifle", "equip_pistol", "equip_melee", "ui_hover", "ui_click", "ui_invalid", "ui_drop", "extract_tick", "music_hideout", "music_tension", "search", "retch", "stomp"}) if (!a.samples.containsKey(s)) missing.append(s).append(' ');
        check("footstep materials, weapon foley and UI cues are all present", missing.length() == 0, a.samples.size() + " samples" + (missing.length() > 0 ? ", missing " + missing : ""));
        float[] mix = new float[2048];
        a.master = 1;
        a.play("shot_rifle", 1, 0, 1, absentialis.engine.audio.AudioEngine.SFX);
        a.loop("music_hideout", 1, absentialis.engine.audio.AudioEngine.MUSIC).fadeTo(1, 0);
        a.play("shout", 1, 0, 1, absentialis.engine.audio.AudioEngine.VOICE);
        a.mixBlock(mix); a.mixBlock(mix);
        boolean all = a.peak[absentialis.engine.audio.AudioEngine.SFX] > 0 && a.peak[absentialis.engine.audio.AudioEngine.MUSIC] > 0 && a.peak[absentialis.engine.audio.AudioEngine.VOICE] > 0;
        check("Music, Effects and Voice buses all carry signal", all, String.format("sfx %.2f music %.3f voice %.2f", a.peak[0], a.peak[1], a.peak[2]));
        a.busMuted[absentialis.engine.audio.AudioEngine.MUSIC] = true;
        a.mixBlock(mix);
        check("muting a bus silences only that bus", a.peak[absentialis.engine.audio.AudioEngine.MUSIC] == 0 && a.peak[absentialis.engine.audio.AudioEngine.VOICE] > 0, null);
        a.muted = true;
        a.mixBlock(mix);
        float sum = 0; for (float f : mix) sum += Math.abs(f);
        check("master mute silences everything", sum == 0, null);
        a.muted = false; a.busMuted[1] = false; a.stopAll(); a.mixBlock(mix);
        a.bus[absentialis.engine.audio.AudioEngine.SFX] = 1; a.play("shot_rifle", 1); a.mixBlock(mix); float full = a.peak[0];
        a.stopAll(); a.mixBlock(mix);
        a.bus[absentialis.engine.audio.AudioEngine.SFX] = 0.5f; a.play("shot_rifle", 1); a.mixBlock(mix); float half = a.peak[0];
        check("a bus slider scales its bus", half > full * 0.4f && half < full * 0.6f, String.format("%.2f -> %.2f", full, half));
        a.lx = 0; a.ly = 0; a.lz = 0; a.lyaw = 0;
        absentialis.engine.audio.AudioEngine.Voice right = a.playAt("shot_rifle", 10, 0, 0, 1, 300, 1), left = a.playAt("shot_rifle", -10, 0, 0, 1, 300, 1), near = a.playAt("shot_rifle", 0, 0, -5, 1, 300, 1), farv = a.playAt("shot_rifle", 0, 0, -120, 1, 300, 1);
        check("gunfire is positional: panned by bearing, quieter and duller with distance", right.pan() > 0.5f && left.pan() < -0.5f && near.gain() > farv.gain() * 2 && farv.lowpass() > near.lowpass(), String.format("pan %.2f/%.2f, gain %.2f/%.2f", right.pan(), left.pan(), near.gain(), farv.gain()));
    }

    private static void alife() {
        System.out.println("[A-Life: one loud action moves perception, migration, patrol response and the strategic tier]");
        Profile p = new Profile();
        Raid r = raid(p);
        r.freezeAI = true;
        r.player.x = 500; r.player.z = 200; r.player.y = World.GROUND;
        r.update(0.01f);                                    // activate the cells round the player
        r.actors.removeIf(a -> !a.isPlayer);                // keep the abstract populations, clear the stage
        r.freezeAI = false;
        Actor listener = walker(r, 500, 236);
        Actor patrol = r.debugSpawn("raiders", 500, 400, World.GROUND);   // the bandits hold this half; this squad is out of earshot
        patrol.squad = 4242;
        District here = r.world.district(500, 200);
        int pop0 = r.populationTotal(), ev0 = r.noiseEvents, mig0 = r.migrations, dis0 = r.dispatches;
        float infected0 = p.zone.infected[here.ordinal()];
        int log0 = p.zone.log.size();
        for (int i = 0; i < 6; i++) r.emitSound(500, World.GROUND + 1, 200, 130, "shot", r.player.id, false);
        check("perception: an agent in earshot investigates", "investigate".equals(listener.state), listener.state);
        check("noise crossed the response threshold once, not per shot", r.noiseEvents - ev0 == 1, (r.noiseEvents - ev0) + " event from 6 shots");
        check("migration: infected populations shift toward the noise", r.migrations > mig0, (r.migrations - mig0) + " moved");
        check("patrol response: the faction holding the district sends a squad", r.dispatches - dis0 == 1 && patrol.hasOrder && Math.abs(patrol.orderX - 500) < 6, ZoneState.cap(String.valueOf(p.zone.controller(here))) + ", " + (r.dispatches - dis0) + " dispatched");
        check("strategic: district infected pressure and the event log both changed", p.zone.infected[here.ordinal()] != infected0 && p.zone.log.size() > log0 && "noise".equals(p.zone.log.get(0).type()), null);
        check("migration redistributes - it does not spawn (population conserved)", r.populationTotal() == pop0, pop0 + " -> " + r.populationTotal());
        float d0 = patrol.distXZ(500, 200);
        for (int i = 0; i < 60 * 10; i++) r.update(1 / 60f);
        check("the dispatched squad actually travels toward the noise", patrol.distXZ(500, 200) < d0 - 4, String.format("%.0f m -> %.0f m in 10 s (regional tier)", d0, patrol.distXZ(500, 200)));
        // regional tier: outside the engagement there is travel but no perception
        Raid r2 = raid(new Profile());
        r2.populate = false; r2.actors.removeIf(a -> !a.isPlayer);
        r2.player.x = 200; r2.player.z = 200; r2.player.y = World.GROUND;
        Actor distant = human(r2, "raiders", 200, 320);
        distant.hostileToPlayer = true; distant.yaw = 0;
        for (int i = 0; i < 120; i++) r2.update(1 / 30f);
        check("regional tier runs without perception or combat", distant.tier == 1 && distant.awareness == 0 && !"engage".equals(distant.state), "tier " + distant.tier + " " + distant.state);
        // strategic tier: persistent ids, deterministic resolution, a log
        ZoneState z1 = ZoneState.fresh(), z2 = ZoneState.fresh();
        z1.advance(96, 7); z2.advance(96, 7);
        java.util.Set<Long> ids = new java.util.HashSet<>();
        for (var sq : z1.squads) ids.add(sq.id);
        check("strategic squads have persistent unique ids", !z1.squads.isEmpty() && ids.size() == z1.squads.size(), z1.squads.size() + " squads");
        check("strategic resolution is deterministic and logged", Json.write(z1.toJson()).equals(Json.write(z2.toJson())) && !z1.log.isEmpty(), z1.log.size() + " events in 96 h");
        ZoneState z3 = ZoneState.fromJson(Json.parseObject(Json.write(z1.toJson())));
        check("squads and log survive a save", z3.squads.size() == z1.squads.size() && z3.log.size() == z1.log.size() && Json.write(z3.toJson()).length() < 40000, Json.write(z3.toJson()).length() + " chars");
        // strategic -> active: evidence matches the log
        Profile pe = new Profile();
        pe.zone.log("battle", District.MARKET, 220, 240, "military", "raiders", "test battle");
        pe.zone.log("roadblock", District.MARKET, 260, 240, "military", "", "test roadblock");
        Raid re = raid(pe);
        int bodies = 0;
        for (Actor a : re.actors) if (a.dead && "raiders".equals(a.faction) && a.distXZ(220, 240) < 8 && a.corpse != null) bodies++;
        check("logged battle leaves the loser's bodies and smoke at its location", re.evidence.size() == 2 && bodies >= 2 && re.smoke.size() == 1, bodies + " bodies, " + re.smoke.size() + " smoke");
        check("logged roadblock is physically there", re.world.get(262, World.GROUND, 240) == Block.SANDBAG, null);
        for (int k = -3; k <= 3; k++) for (int y = World.GROUND; y <= World.GROUND + 1; y++) re.world.setRaw(260 + k, y, 240, Block.AIR);   // leave the shared fixture clean
    }

    private static Raid stage(Profile p) {
        Raid r = raid(p);
        r.populate = false;
        r.actors.removeIf(a -> !a.isPlayer);
        r.player.x = 300; r.player.z = 500; r.player.y = World.GROUND;
        r.player.weapon = item("weapon.akr", 1);
        r.god = true;       // the scenarios watch behaviour; a dead player would end the raid mid-test
        return r;
    }

    private static List<Actor> squadOf(Raid r, String faction, int n, float x, float z, int squad, boolean hostile) {
        List<Actor> l = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            Actor a = r.debugSpawn(faction, x + i * 2, z, World.GROUND);
            a.squad = squad; a.hostileToPlayer = hostile; a.aggressor = hostile; a.homeX = x; a.homeZ = z;
            a.yaw = (float) Math.atan2(-(r.player.x - a.x), -(r.player.z - a.z));
            l.add(a);
        }
        return l;
    }

    private static void doctrines() {
        System.out.println("[Human AI: four doctrines behave distinctly; memory is uncertain]");
        // ---- mercenaries: roles, radio, ordered retreat
        Raid r = stage(new Profile());
        List<Actor> mercs = squadOf(r, "mercenaries", 4, 296, 478, 11, true);
        List<Actor> reserve = squadOf(r, "mercenaries", 2, 300, 420, 12, true);
        for (Actor a : reserve) a.yaw = 0;          // looking away: they only come because they are called
        for (int i = 0; i < 60 * 3; i++) r.update(1 / 60f);
        java.util.Set<String> roles = new java.util.HashSet<>();
        for (Actor a : mercs) roles.add(a.role.startsWith("flank") ? "flank" : a.role);
        check("mercenaries split into suppress / hold / flank roles", roles.contains("suppress") && roles.contains("flank"), roles.toString());
        check("mercenaries radio for reinforcements on contact", r.squad(mercs.get(0)).backupCalled && r.dispatches > 0 && (reserve.get(0).hasOrder || !"idle".equals(reserve.get(0).state)), r.dispatches + " dispatched");
        for (int i = 0; i < 3; i++) r.damageActor(mercs.get(i), r.player, 900, Content.def("ammo.556"), "torso", mercs.get(i).x, mercs.get(i).y + 1, mercs.get(i).z);
        for (int i = 0; i < 90; i++) r.update(1 / 60f);
        boolean retreated = false;
        for (int i = 0; i < 60 * 3 && !retreated; i++) { r.update(1 / 60f); retreated = "retreat".equals(mercs.get(3).state); }
        check("outmatched mercenaries fall back in order (retreat, not rout)", retreated, mercs.get(3).state + ", squad " + r.squad(mercs.get(3)).alive + "/" + r.squad(mercs.get(3)).initial);
        // ---- bandits: hold-up instead of opening fire, pay to walk, break when it goes wrong
        Raid rb = stage(new Profile());
        rb.player.weapon = null;
        List<Actor> bandits = squadOf(rb, "raiders", 3, 296, 484, 21, true);
        int shots0 = rb.projectiles.size();
        for (int i = 0; i < 60 * 3; i++) rb.update(1 / 60f);
        boolean extorting = "extort".equals(bandits.get(0).state) && rb.extortion() != null;
        check("bandits hold up a lone quiet target instead of shooting", extorting && rb.projectiles.size() == shots0, bandits.get(0).state);
        String paid = rb.payExtortion();
        for (int i = 0; i < 30; i++) rb.update(1 / 60f);
        check("paying the hold-up ends it: they stand down and the scrip is owed", paid != null && paid.startsWith("Paid") && !bandits.get(0).hostileToPlayer && rb.scripPaid == Raid.EXTORT_PRICE, paid);
        Raid rb2 = stage(new Profile());
        List<Actor> gang = squadOf(rb2, "raiders", 3, 296, 484, 22, true);
        rb2.playerAiming = true;
        for (int i = 0; i < 60; i++) { rb2.playerAiming = true; rb2.update(1 / 60f); }
        float m0 = gang.get(2).morale;
        rb2.damageActor(gang.get(0), rb2.player, 900, Content.def("ammo.556"), "torso", gang.get(0).x, gang.get(0).y + 1, gang.get(0).z);
        rb2.damageActor(gang.get(1), rb2.player, 900, Content.def("ammo.556"), "torso", gang.get(1).x, gang.get(1).y + 1, gang.get(1).z);
        boolean fled = false;
        for (int i = 0; i < 60 * 4 && !fled; i++) { rb2.playerAiming = true; rb2.update(1 / 60f); fled = "flee".equals(gang.get(2).state); }
        check("bandit morale collapses when squadmates die", gang.get(2).morale < m0 - 0.5f && fled, String.format("morale %.2f -> %.2f, %s", m0, gang.get(2).morale, gang.get(2).state));
        // ---- military: restricted area warning, enforcement, permits, cover
        Profile pm = new Profile();
        Raid rm = stage(pm);
        rm.world.map.posts.add(new MapData.Point("Test Garrison", "camp", "military".length() > 0 ? 300 : 0, World.GROUND, 492, District.MARKET));
        rm.world.map.posts.get(rm.world.map.posts.size() - 1).faction = "military";
        List<Actor> troops = squadOf(rm, "military", 2, 298, 482, 31, false);
        for (int i = 0; i < 30; i++) rm.update(1 / 60f);
        boolean warned = "warn".equals(troops.get(0).state) || "warn".equals(troops.get(1).state);
        check("military warn a trespasser before using force", warned && !troops.get(0).hostileToPlayer && rm.restrictedFor(rm.player.x, rm.player.z), troops.get(0).state);
        for (int i = 0; i < 60 * 8; i++) rm.update(1 / 60f);
        check("ignoring the warning makes the garrison hostile and is recorded", troops.get(0).hostileToPlayer && rm.trespasses == 1 && rm.debrief.repDelta.getOrDefault("military", 0f) < 0, rm.trespasses + " trespass");
        pm.rep.put("military", 40f);
        check("standing works as a permit (reputation-gated)", !rm.restrictedFor(rm.player.x, rm.player.z), null);
        rm.world.map.posts.remove(rm.world.map.posts.size() - 1);
        for (int k = 0; k < 5; k++) rm.world.setRaw(398 + k, World.GROUND, 402, Block.SANDBAG);
        Actor rifle = human(rm, "military", 400, 404);
        boolean cover = Brain.findCover(rm, rifle, 400, World.GROUND, 380);
        check("soldiers find cover with a block between them and the threat", cover && rifle.coverZ > 402, cover ? String.format("cover at %.1f, %.1f", rifle.coverX, rifle.coverZ) : "none");
        for (int k = 0; k < 5; k++) rm.world.setRaw(398 + k, World.GROUND, 402, Block.AIR);
        // ---- loners: neutral, avoid fights, ask for help
        Raid rl = stage(new Profile());
        List<Actor> loners = squadOf(rl, "survivors", 2, 296, 480, 41, false);
        Actor threat = walker(rl, 300, 462);
        check("loners are neutral by default", !loners.get(0).hostileToPlayer, null);
        // gunfire 40 m off: everyone else would go and look - loners put distance between themselves and it
        float before = loners.get(0).distXZ(300, 440);
        rl.emitSound(300, World.GROUND + 1, 440, 120, "shot", threat.id, false);
        boolean avoiding = "avoid".equals(loners.get(0).state) && "avoid".equals(loners.get(1).state);
        for (int i = 0; i < 60 * 3; i++) rl.update(1 / 60f);
        check("loners back away from trouble instead of investigating or engaging", avoiding && !"engage".equals(loners.get(0).state) && loners.get(0).distXZ(300, 440) > before + 2, String.format("%.0f m -> %.0f m from the gunfire", before, loners.get(0).distXZ(300, 440)));
        rl.actors.remove(threat);
        Actor hurt = loners.get(1);
        hurt.needsHelp = true; hurt.x = rl.player.x + 1; hurt.z = rl.player.z;
        InventoryService.store(item("med.bandage", 1), rl.profile.loadout);
        String res = rl.lonerInNeed(2.6f) == hurt ? rl.helpLoner(hurt) : "no one in reach";
        check("a wounded loner can be helped for standing", hurt.helped && rl.debrief.repDelta.getOrDefault("survivors", 0f) >= 3 && rl.debrief.aided == 1, res);
        // ---- shared perception: memory with a timestamp and a growing uncertainty, never the live position
        Raid rp = stage(new Profile());
        Actor seer = squadOf(rp, "mercenaries", 1, 300, 480, 51, true).get(0);
        for (int i = 0; i < 90; i++) rp.update(1 / 60f);
        float seenErr = seer.memErr, seenAt = seer.memTime;
        rp.player.x = 360; rp.player.z = 560;                           // gone - behind them and far
        for (int i = 0; i < 60 * 4; i++) rp.update(1 / 60f);
        check("memory keeps the last known position, not the player's coordinates", Math.abs(seer.memX - 300) < 8 && Math.abs(seer.memX - rp.player.x) > 40 && seer.memTime <= rp.time - 3 && seenAt > 0, String.format("remembers %.0f,%.0f; player at %.0f,%.0f", seer.memX, seer.memZ, rp.player.x, rp.player.z));
        check("uncertainty grows while the target is unseen", seer.memErr > seenErr + 1.5f, String.format("%.1f m -> %.1f m", seenErr, seer.memErr));
        Raid rn = stage(new Profile());
        Actor day = human(rn, "raiders", 300, 440), night = human(rn, "raiders", 300, 440);
        float clear = Brain.sightRange(rn, day, Brain.arch("rifleman"), rn.player);
        rn.profile.zone.weatherRain = 1f;
        float rain = Brain.sightRange(rn, night, Brain.arch("rifleman"), rn.player);
        rn.player.crouch = true;
        float crouch = Brain.sightRange(rn, night, Brain.arch("rifleman"), rn.player);
        check("vision depends on weather and stance", rain < clear * 0.8f && crouch < rain * 0.7f, String.format("clear %.0f m, rain %.0f m, rain+crouch %.0f m", clear, rain, crouch));
    }

    private static void zombies() {
        System.out.println("[Infected: four archetypes, every special telegraphed, counterplay works]");
        boolean four = Brain.INFECTED.length == 4;
        for (String id : Brain.INFECTED) four &= Brain.arch(id).infected() && Brain.arch(id).id().equals(id);
        Brain.Arch reg = Brain.arch("walker"), fast = Brain.arch("sprinter"), fat = Brain.arch("boomer"), giant = Brain.arch("tank");
        check("regular / fast / fat / giant are distinct in speed and health", four && fast.runSpeed() > reg.runSpeed() * 3 && fast.hp() < reg.hp() && fat.hp() > reg.hp() * 2 && giant.hp() > fat.hp() * 4 && giant.melee() * 1.25f < 100,
                String.format("run %.1f/%.1f/%.1f/%.1f m/s, hp %.0f/%.0f/%.0f/%.0f", reg.runSpeed(), fast.runSpeed(), fat.runSpeed(), giant.runSpeed(), reg.hp(), fast.hp(), fat.hp(), giant.hp()));
        // ---- fast: shriek first, one clean head shot ends it
        Raid r = stage(new Profile());
        Actor f = r.debugSpawn("sprinter", 300, 488, World.GROUND);
        f.yaw = (float) Math.PI;
        float shriekAt = -1, moveAt = -1;
        for (int i = 0; i < 60 * 3; i++) {
            r.update(1 / 60f);
            if (shriekAt < 0 && r.telegraphing(f, "shriek")) shriekAt = r.time;
            if (shriekAt >= 0 && moveAt < 0 && !r.telegraphing(f, "shriek") && Math.hypot(f.vx, f.vz) > 3) moveAt = r.time;
        }
        check("fast infected shriek before they rush", shriekAt >= 0 && moveAt - shriekAt >= 0.6f, String.format("shriek at %.2f s, rush at %.2f s", shriekAt, moveAt));
        Actor f2 = r.debugSpawn("sprinter", 320, 478, World.GROUND);
        r.damageActor(f2, r.player, Content.def("ammo.9x19").ammo.damage, Content.def("ammo.9x19"), "head", f2.x, f2.y + 1.7f, f2.z);
        check("a well-placed pistol round drops a fast infected", f2.dead, String.format("hp left %.0f", f2.hp));
        // ---- fat: retch telegraph, pool where you were, rupture on death
        Raid rf = stage(new Profile());
        rf.god = false;
        Actor b = rf.debugSpawn("boomer", 300, 493, World.GROUND);
        b.yaw = (float) Math.PI;
        float retchAt = -1, zoneAt = -1;
        float px = rf.player.x, pz = rf.player.z;
        for (int i = 0; i < 60 * 5 && zoneAt < 0; i++) {
            rf.update(1 / 60f);
            if (retchAt < 0 && rf.telegraphing(b, "retch")) { retchAt = rf.time; }
            if (retchAt >= 0 && rf.time - retchAt > 0.3f) { rf.player.x = px + 9; }          // the counterplay: move during the wind-up
            if (!rf.zones.isEmpty()) zoneAt = rf.time;
        }
        float hpBefore = rf.player.hp;
        for (int i = 0; i < 90; i++) rf.update(1 / 60f);
        check("fat infected retch for a second before the bile lands", retchAt >= 0 && zoneAt - retchAt >= 0.95f, String.format("retch %.2f s -> pool %.2f s", retchAt, zoneAt));
        check("the pool lands where you stood: moving during the wind-up avoids it", !rf.zones.isEmpty() && Math.abs(rf.zones.get(0).x - px) < 1.5f && rf.player.hp == hpBefore, String.format("pool at %.1f, player at %.1f", rf.zones.isEmpty() ? 0 : rf.zones.get(0).x, rf.player.x));
        int noise0 = rf.sounds.size();
        float contam0 = rf.profile.zone.contamination[District.MARKET.ordinal()];
        rf.player.x = px + 30;
        rf.damageActor(b, rf.player, 9999, Content.def("ammo.556"), "torso", b.x, b.y + 1, b.z);
        boolean contam = false, boom = false;
        for (Raid.Zone z : rf.zones) contam |= z.kind.equals("contam");
        for (Raid.Sound s : rf.sounds) boom |= s.category().equals("explosion");
        check("killing a fat infected ruptures it: contamination zone + noise event", b.dead && b.burst && contam && boom && rf.sounds.size() > noise0 && rf.profile.zone.contamination[District.MARKET.ordinal()] > contam0, null);
        // ---- giant: throw and charge are telegraphed, light cover does not stop it, no one-hit kills
        Raid rg = stage(new Profile());
        Actor g = rg.debugSpawn("tank", 300, 478, World.GROUND);
        g.yaw = (float) Math.PI;
        float throwAt = -1, rockAt = -1;
        boolean stomped = false;
        for (int i = 0; i < 60 * 6 && rockAt < 0; i++) {
            rg.update(1 / 60f);
            if (throwAt < 0 && rg.telegraphing(g, "throw")) throwAt = rg.time;
            for (Raid.Thrown t : rg.thrown) if (t.debris) rockAt = rg.time;
        }
        for (Raid.Sound s : rg.sounds) stomped |= s.category().equals("roar") || s.category().equals("stomp");
        check("giant telegraphs its debris throw with a roar and a wind-up", throwAt >= 0 && rockAt - throwAt >= 1.2f && stomped, String.format("wind-up %.2f s", rockAt - throwAt));
        Raid rc = stage(new Profile());
        for (int k = -1; k <= 1; k++) for (int y = 0; y < 2; y++) rc.world.setRaw(500 + k, World.GROUND + y, 497, Block.WOOD_PLANKS);
        Actor g2 = rc.debugSpawn("tank", 500.5f, 498.6f, World.GROUND);
        g2.yaw = 0; g2.stuckTime = 1;
        rc.smash(g2);
        rc.world.setRaw(504, World.GROUND, 497, Block.SANDBAG);
        check("giant destroys light cover in its path (planks, fences, furniture - not sandbags)", rc.world.get(500, World.GROUND, 497) != Block.WOOD_PLANKS && Block.ALL[Block.SANDBAG].hp >= 400, null);
        rc.world.setRaw(504, World.GROUND, 497, Block.AIR);
        for (int k = -1; k <= 1; k++) for (int y = 0; y < 2; y++) rc.world.setRaw(500 + k, World.GROUND + y, 497, Block.AIR);
        rc.player.hp = 100; rc.god = false;
        rc.player.x = 500.5f; rc.player.z = 497f;
        rc.melee(g2, rc.player, giant.melee() * 1.25f);
        check("a giant's blow hurts but never kills outright (even on Hardcore)", rc.player.hp > 0 && rc.player.hp < 100, String.format("%.0f hp left", rc.player.hp));
        // ---- ecology
        Raid re = stage(new Profile());
        Actor body = re.debugSpawn("raiders", 300, 470, World.GROUND);
        re.damageActor(body, null, 999, null, "torso", body.x, body.y + 1, body.z);
        Actor w = walker(re, 300, 452);
        w.yaw = 0;                                           // facing away from the player
        float d0 = w.distXZ(body.x, body.z);
        for (int i = 0; i < 60 * 12; i++) re.update(1 / 60f);
        check("regular infected gather on unattended corpses", w.distXZ(body.x, body.z) < d0 - 4, String.format("%.0f m -> %.0f m from the body", d0, w.distXZ(body.x, body.z)));
        ZoneState clean = ZoneState.fresh(), dirty = ZoneState.fresh();
        for (int i = 0; i < 6; i++) { dirty.reportCorpse(District.MARKET); dirty.reportContamination(District.MARKET, 1); }
        clean.advance(12, 3); dirty.advance(12, 3);
        check("infected numbers rise near contamination and corpses (strategic tier)", dirty.infected[District.MARKET.ordinal()] > clean.infected[District.MARKET.ordinal()] + 0.02f, String.format("%.2f vs %.2f", dirty.infected[District.MARKET.ordinal()], clean.infected[District.MARKET.ordinal()]));
        ZoneState loud = ZoneState.fresh();
        float total0 = 0, total1 = 0;
        for (float v : loud.infected) total0 += v;
        loud.reportNoise(District.MARKET, 400);
        for (float v : loud.infected) total1 += v;
        check("loud events redistribute infected, they do not create them", Math.abs(total1 - total0) < 1e-3f && loud.infected[District.MARKET.ordinal()] > ZoneState.fresh().infected[District.MARKET.ordinal()], String.format("total %.2f -> %.2f", total0, total1));
    }

    private static void districts() {
        System.out.println("[Map: six districts, central plant, placement audit, loot by location]");
        World w = new World();
        new absentialis.world.gen.CityGenerator(w, 1337L, s -> {}).generate();
        MapData m = w.map;
        check("six districts are defined", District.values().length == 6, null);
        StringBuilder bad = new StringBuilder();
        for (District d : District.values()) {
            if (d.def.landmarks.length < 4) bad.append(d.display).append(": landmarks; ");
            if (d.def.lootWeights().size() < ZoneState.SUPPLY.length) bad.append(d.display).append(": loot weights; ");
            for (String f : ZoneState.FACTIONS) if (d.def.influence(f) <= 0) bad.append(d.display).append(": influence ").append(f).append("; ");
            if (d.def.exits.length == 0) bad.append(d.display).append(": exits; ");
            for (String e : d.def.exits) {
                String id = e.substring(0, e.indexOf(':')), type = e.substring(e.indexOf(':') + 1);
                MapData.Exit x = m.exit(id);
                if (x == null) bad.append(d.display).append(": exit ").append(id).append(" not on the map; ");
                else if (!x.type.name().equals(type)) bad.append(id).append(": type ").append(x.type).append("; ");
                else if (x.district != d) bad.append(id).append(": lies in ").append(x.district.display).append("; ");
            }
            int found = 0;
            for (String name : d.def.landmarks) for (MapData.Point lp : m.landmarks) if (lp.name.contains(name) || name.contains(lp.name)) { found++; break; }
            if (found < 3) bad.append(d.display).append(": only ").append(found).append(" listed landmarks exist; ");
        }
        java.util.Set<String> types = new java.util.HashSet<>();
        for (MapData.Exit e : m.exits) types.add(e.type.name());
        check("every district has landmarks, loot weights, faction baseline and extraction points on the map", bad.length() == 0, bad.length() == 0 ? m.exits.size() + " exits, " + m.landmarks.size() + " landmarks" : bad.toString());
        check("extractions cover permanent, conditional and time-windowed types", types.contains("PERMANENT") && types.contains("CONDITIONAL") && types.contains("TIME_WINDOW"), types.toString());
        MapData.Point plant = null;
        for (MapData.Point lp : m.landmarks) if (lp.name.contains("Power Plant")) plant = lp;
        boolean stack = false, towers = false;
        for (MapData.Point lp : m.landmarks) { stack |= lp.name.equals("Vent Stack"); towers |= lp.name.equals("Cooling Towers"); }
        check("the power plant complex stands at the centre of the city", plant != null && Math.abs(plant.x - 352) < 60 && Math.abs(plant.z - 352) < 80 && plant.district == District.INDUSTRIAL && stack && towers, plant == null ? "missing" : plant.x + "," + plant.z);
        check("no prop is left floating after the placement audit", m.propsFloating == 0 && absentialis.world.gen.Validation.countFloating(w) == 0, m.propsGrounded + " grounded, " + m.propsRemoved + " removed");
        int standable = 0;
        for (MapData.Node n : m.nodes) if (absentialis.world.gen.Validation.standable(w, n.x, n.y, n.z)) standable++;
        check("every street-graph node is a place an agent can stand", standable == m.nodes.size() && m.nodesBlocked == 0, standable + " / " + m.nodes.size());
        int wrong = 0, logic = 0;
        StringBuilder wrongWhat = new StringBuilder();
        for (MapData.LootSpot l : m.loot) {
            int id = w.get(l.x, l.y, l.z);
            String want = id == Block.MED_CABINET ? "medical" : id == Block.WEAPON_RACK ? "weapons" : id == Block.TOOLBOX ? "industrial" : id == Block.FRIDGE ? "food" : id == Block.CRATE_MIL ? "military" : null;
            if (want == null) continue;
            logic++;
            if (!l.table.startsWith(want)) { wrong++; if (wrong <= 4) wrongWhat.append(Block.ALL[id].name).append("->").append(l.table).append(" at ").append(l.x).append(',').append(l.z).append("; "); }
        }
        check("loot follows location: medicine in cabinets, parts in toolboxes, materiel in racks and crates", logic > 500 && wrong == 0, logic + " checked, " + wrong + " wrong " + wrongWhat);
        float hi = 0, lo = 9;
        for (District d : District.CITY) { hi = Math.max(hi, d.def.patrol); lo = Math.min(lo, d.def.patrol); }
        check("patrol density and loot weighting differ by district", hi > lo * 2 && District.MARKET.def.lootWeight("food") > District.INDUSTRIAL.def.lootWeight("food") && District.INDUSTRIAL.def.lootWeight("fuel") > District.MARKET.def.lootWeight("fuel"), null);
    }
}
