package absentialis.ai;

import absentialis.entity.Actor;
import absentialis.entity.Physics;
import absentialis.scene.Raid;
import absentialis.world.MapData;

/**
 * Agent behaviour (iteration P6 / P8).
 *
 * Shared by everyone: a vision cone limited by distance, light, weather, stance and movement; hearing
 * through attenuated, occluded sound events; and a memory that stores a last-known position with a
 * timestamp, a confidence and an uncertainty radius that grows while the target is unseen - agents
 * act on where they think something is, never on the player's real coordinates.
 *
 * Human factions run four distinct doctrines on top of that:
 *   MERC     disciplined fire teams - suppress, flank, radio for reinforcements, hold their asset,
 *            fall back in order when outmatched, strip weapons from the dead.
 *   BANDIT   predatory and loud - lurk on routes, size the target up, extort the weak, rush, and
 *            break quickly when it goes wrong; rifle through corpses in seconds.
 *   MILITARY cordon troops - fixed patrol routes and posts, cover and peek, warn before enforcing
 *            a restricted area, call in support, never chase beyond the perimeter.
 *   LONER    cautious scavengers - neutral by default, back away from trouble, search containers,
 *            ask for help, fight only when cornered or when one of their own is hit.
 *
 * Infected archetypes (regular, fast, fat, giant) share one ecology and telegraph every special.
 */
public final class Brain {
    private Brain() {}

    /** Archetype tuning: speed, hp, melee damage, sight range, hearing multiplier, fov (cos). */
    public record Arch(String id, float speed, float runSpeed, float hp, float melee, float sight, float hearing, float fovCos, boolean infected) {}

    public static final Arch[] ARCHS = {
            new Arch("rifleman", 1.6f, 4.6f, 100, 0, 70, 1.0f, 0.45f, false),
            new Arch("marksman", 1.4f, 4.2f, 90, 0, 110, 0.9f, 0.6f, false),
            new Arch("shotgunner", 1.7f, 4.8f, 110, 0, 45, 1.0f, 0.4f, false),
            new Arch("walker", 0.9f, 1.6f, 90, 14, 16, 1.3f, 0.3f, true),       // Regular
            new Arch("sprinter", 1.4f, 6.4f, 55, 10, 26, 1.4f, 0.2f, true),     // Fast
            new Arch("boomer", 0.8f, 1.3f, 260, 0, 16, 1.0f, 0.3f, true),       // Fat
            new Arch("tank", 1.2f, 3.0f, 1400, 48, 30, 0.9f, 0.3f, true),       // Giant
            new Arch("shambler", 0.7f, 1.1f, 230, 22, 14, 1.2f, 0.3f, true),    // legacy variants (console spawn only)
            new Arch("screecher", 1.0f, 2.0f, 70, 8, 30, 1.6f, 0.0f, true),
    };
    /** The four infected archetypes that populate the Zone. */
    public static final String[] INFECTED = {"walker", "sprinter", "boomer", "tank"};

    public static Arch arch(String id) { for (Arch a : ARCHS) if (a.id.equals(id)) return a; return ARCHS[0]; }

    public static String displayName(String archetype) {
        return switch (archetype) { case "walker" -> "Regular"; case "sprinter" -> "Fast"; case "boomer" -> "Fat"; case "tank" -> "Giant"; default -> archetype; };
    }

    // ------------------------------------------------------------------ doctrines
    public enum Doctrine { MERC, BANDIT, MILITARY, LONER }

    /** leash = how far from home they will fight; fightDist = preferred engagement range. */
    public record Doc(Doctrine d, float leash, float morale, float risk, float fightDist, float breakAt, boolean cover) {}

    private static final Doc MERC = new Doc(Doctrine.MERC, 46, 0.95f, 0.55f, 18, 0.25f, true);
    private static final Doc BANDIT = new Doc(Doctrine.BANDIT, 70, 0.60f, 0.75f, 10, 0.45f, false);
    private static final Doc MILITARY = new Doc(Doctrine.MILITARY, 34, 0.90f, 0.40f, 22, 0.20f, true);
    private static final Doc LONER = new Doc(Doctrine.LONER, 40, 0.55f, 0.15f, 16, 0.50f, true);

    public static Doc doc(String faction) {
        return switch (faction) { case "mercenaries" -> MERC; case "raiders" -> BANDIT; case "military" -> MILITARY; default -> LONER; };
    }

    /** Sets the doctrine's starting morale and risk tolerance on a freshly spawned human. */
    public static void initHuman(Actor a) { Doc d = doc(a.faction); a.morale = d.morale(); a.risk = d.risk(); }

    // ------------------------------------------------------------------ hostility
    /** Hostility from the diplomatic matrix + player standing + observed evidence. */
    public static boolean hostile(Raid r, Actor a, Actor b) {
        if (a.faction.equals(b.faction)) return false;
        if (a.infected() || b.infected()) return true;
        if (b.isPlayer) return a.hostileToPlayer;
        if (a.isPlayer) return b.hostileToPlayer;
        String x = a.faction, y = b.faction;
        // The cordon suppresses bandits; bandits prey on loners and probe the contractors' sites.
        // Military and mercenaries keep an uneasy truce; loners have no standing feud with either.
        return pair(x, y, "military", "raiders") || pair(x, y, "survivors", "raiders") || pair(x, y, "raiders", "mercenaries");
    }

    private static boolean pair(String a, String b, String p, String q) { return a.equals(p) && b.equals(q) || a.equals(q) && b.equals(p); }

    /** Initial disposition toward the player for this raid, from standing. */
    public static boolean initialHostility(String faction, float rep) {
        switch (faction) {
            case "military": return rep < -10;
            case "survivors": return rep < -25;
            case "raiders": return rep < 30;
            case "mercenaries": return rep < 20;
            default: return true;
        }
    }

    // ------------------------------------------------------------------ perception
    /** A heard sound: memory update + reaction. Called by Raid.emitSound for agents in range. */
    public static void hear(Raid r, Actor a, float sx, float sy, float sz, float loudness, String category, int sourceId) {
        if (a.dead || a.id == sourceId) return;
        float conf = Math.min(1f, loudness);
        // positional uncertainty grows with distance and shrinks with loudness
        float d = a.distXZ(sx, sz), err = d * 0.12f * (1.2f - conf);
        float ex = sx + (r.rng.nextFloat() - 0.5f) * err * 2, ez = sz + (r.rng.nextFloat() - 0.5f) * err * 2;
        if (conf >= a.memConfidence * 0.7f || r.time - a.memTime > 6) remember(r, a, ex, sy, ez, conf * 0.6f, Math.max(1.5f, err));
        a.alertness = Math.min(1f, a.alertness + conf * 0.6f);
        if (a.infected()) {
            if ("screech".equals(category) || "shriek".equals(category)) a.alertness = 1;
            if (!"engage".equals(a.state)) setState(a, "investigate");
            return;
        }
        if ("engage".equals(a.state) || "flee".equals(a.state) || "retreat".equals(a.state) || "extort".equals(a.state) || "warn".equals(a.state)) return;
        Doc dc = doc(a.faction);
        boolean combatNoise = category.startsWith("shot") || category.equals("explosion") || category.equals("shout") || category.equals("screech") || category.equals("roar");
        // loners move away from gunfire that is not on top of them; everyone else goes to look
        if (dc.d() == Doctrine.LONER && combatNoise && d > 14) { setState(a, "avoid"); return; }
        setState(a, "investigate");
    }

    private static void remember(Raid r, Actor a, float x, float y, float z, float conf, float err) {
        a.memX = x; a.memY = y; a.memZ = z; a.memTime = r.time; a.memConfidence = conf; a.memErr = err;
    }

    private static void setState(Actor a, String s) { if (!a.state.equals(s)) { a.state = s; a.stateTime = 0; a.hasGoal = false; a.hasCover = false; } }

    /** Sight range of a against o right now: light, weather, stance and movement all matter. */
    public static float sightRange(Raid r, Actor a, Arch ar, Actor o) {
        float light = r.world.brightness(o.x, o.y + 1, o.z, r.daylight());
        if (o.isPlayer && r.playerFlashlight) light = 1;
        float stance = o.crouch ? 0.6f : 1f;
        float moving = (Math.abs(o.vx) + Math.abs(o.vz)) > 0.5f ? 1.25f : 0.85f;
        float weather = 1 - 0.3f * r.rain() - 0.25f * r.fogAt(o.x, o.z);
        return ar.sight * (0.35f + 0.65f * light) * stance * moving * weather * r.difficultySight();
    }

    /** Sight: awareness accumulates while a hostile is visible; returns the confirmed target or null. */
    private static Actor look(Raid r, Actor a, Arch ar, float dt) {
        Actor best = null;
        float bestScore = 0;
        float fx = (float) -Math.sin(a.yaw), fz = (float) -Math.cos(a.yaw);
        for (Actor o : r.nearby(a.x, a.z, ar.sight * 1.2f)) {
            if (o == a || o.dead || !hostile(r, a, o) && !(o.isPlayer && !a.infected() && !a.hostileToPlayer && a.sawPlayerAggress)) continue;
            float dx = o.x - a.x, dz = o.z - a.z, d = (float) Math.sqrt(dx * dx + dz * dz);
            if (d < 0.01f) continue;
            float cos = (dx * fx + dz * fz) / d;
            boolean close = d < 3.2f;
            if (!close && cos < ar.fovCos) continue;
            float range = sightRange(r, a, ar, o);
            if (d > range && !close) continue;
            if (!Physics.los(r.world, a.x, a.eyeY(), a.z, o.x, o.eyeY() - 0.2f, o.z)) continue;
            float score = (1 - d / Math.max(1, range)) + (o.isPlayer ? 0.2f : 0);
            if (score > bestScore) { bestScore = score; best = o; }
        }
        if (best == null) { a.awareness = Math.max(0, a.awareness - dt * 0.35f); return null; }
        float d = a.dist(best);
        float rate = (a.alertness > 0.5f ? 2.2f : 0.9f) * (d < 8 ? 3 : d < 20 ? 1.4f : 0.7f);
        a.awareness = Math.min(1.2f, a.awareness + dt * rate);
        remember(r, a, best.x, best.y, best.z, Math.min(1, a.awareness), 0.3f);
        a.lastSeenTime = r.time;
        if (a.awareness >= 1f) { a.targetId = best.id; return best; }
        // partial: turn toward the suspicious shape
        a.yaw = turn(a.yaw, (float) Math.atan2(-(best.x - a.x), -(best.z - a.z)), dt * 1.5f);
        return null;
    }

    // ------------------------------------------------------------------ update
    public static void update(Raid r, Actor a, float dt) {
        if (a.dead) return;
        Arch ar = arch(a.archetype);
        a.stateTime += dt;
        a.fireCooldown -= dt;
        a.specialTimer -= dt;
        a.alertness = Math.max(0, a.alertness - dt * 0.03f);
        if (a.memConfidence > 0) a.memConfidence = Math.max(0, a.memConfidence - dt * 0.02f);
        // unseen targets move: the remembered position gets vaguer every second
        if (r.time - a.lastSeenTime > 0.5f) a.memErr = Math.min(14, a.memErr + dt * 0.7f);
        if (a.tier == 1) { regional(r, a, ar, dt); return; }
        Actor tgt = look(r, a, ar, dt);
        if (ar.infected) infected(r, a, ar, tgt, dt);
        else human(r, a, ar, tgt, dt);
        a.crouch &= !ar.infected;
    }

    /** Regional tier (loaded district, outside the engagement): coarse travel toward goals, no perception or combat. */
    private static void regional(Raid r, Actor a, Arch ar, float dt) {
        if (a.hasOrder && r.time < a.orderUntil) {
            if (a.distXZ(a.orderX, a.orderZ) > 6) { goTo(r, a, a.orderX, a.orderZ, ar.runSpeed * 0.8f, dt); return; }
            a.hasOrder = false;
            remember(r, a, a.orderX, a.y, a.orderZ, 0.5f, 6);
            setState(a, "investigate");
        }
        if ("investigate".equals(a.state) && r.time - a.memTime < 40) {
            if (a.distXZ(a.memX, a.memZ) > 4) goTo(r, a, a.memX, a.memZ, ar.speed * 1.2f, dt); else stop(a);
            return;
        }
        if (!"idle".equals(a.state) && a.stateTime > 20) setState(a, "idle");
        idleMove(r, a, ar, dt);
    }

    // ================================================================== infected
    private static void infected(Raid r, Actor a, Arch ar, Actor tgt, float dt) {
        if (tgt != null) setState(a, "engage");
        boolean fast = "sprinter".equals(a.archetype) || "screecher".equals(a.archetype), fat = "boomer".equals(a.archetype), giant = "tank".equals(a.archetype);
        // the giant is never a surprise: its footfalls carry and shake the ground
        if (giant && (Math.abs(a.vx) + Math.abs(a.vz)) > 0.4f) { a.talkTimer -= dt; if (a.talkTimer <= 0) { a.talkTimer = 0.95f; r.emitSound(a.x, a.y, a.z, 46, "stomp", a.id, false); r.quake(a.x, a.z, 26, 0.22f); } }
        switch (a.state) {
            case "engage" -> {
                Actor t = r.actor(a.targetId);
                if (t == null || t.dead) { setState(a, "search"); break; }
                boolean seen = tgt == t;
                if (!seen && r.time - a.memTime > 2.5f) { setState(a, "search"); break; }
                float d = a.dist(t);
                a.yaw = turn(a.yaw, (float) Math.atan2(-(a.memX - a.x), -(a.memZ - a.z)), dt * 6);
                float speed = ar.runSpeed;
                float gx = a.memX, gz = a.memZ;
                if (fast) {
                    // loud vocal cue first, then the rush; they tire quickly and come in on a flank
                    if (a.stateTime < 0.05f && a.specialTimer <= 0) { a.specialTimer = 12; r.telegraph(a, "shriek", 0.7f); a.fireCooldown = 0.7f; }
                    if (r.telegraphing(a, "shriek")) { stop(a); break; }
                    if (a.stateTime > 7) speed = ar.speed * 1.5f;
                    if (d > 7) { float side = (a.id & 1) == 0 ? 1 : -1, ang = (float) Math.atan2(a.x - t.x, a.z - t.z) + side * 0.9f; gx = t.x + (float) Math.sin(ang) * 5.5f; gz = t.z + (float) Math.cos(ang) * 5.5f; }
                }
                if (fat) {
                    // telegraphed bile: a one-second retch, then a pool where the target WAS standing
                    if (seen && d > 3.2f && d < 10 && a.specialTimer <= 0 && !r.telegraphing(a, "retch")) { a.specialTimer = 7.5f; a.goalX = t.x; a.goalZ = t.z; a.memY = t.y; r.telegraph(a, "retch", 1.0f); a.burstLeft = 1; }
                    if (r.telegraphing(a, "retch")) { stop(a); break; }
                    if (a.burstLeft > 0) { a.burstLeft = 0; r.spit(a, a.goalX, a.memY, a.goalZ); }
                    if (d < 2.4f && !r.telegraphing(a, "swell")) { if (a.suppressUntil <= 0) { a.suppressUntil = r.time + 0.9f; r.telegraph(a, "swell", 0.9f); } }
                    if (a.suppressUntil > 0 && r.time >= a.suppressUntil) { r.explodeBoomer(a, null); return; }
                    if (a.suppressUntil > 0) { stop(a); break; }
                }
                if (giant) {
                    if (seen && d > 10 && d < 30 && a.specialTimer <= 0 && !r.telegraphing(a, "throw")) { a.specialTimer = 9; a.goalX = t.x; a.goalZ = t.z; a.memY = t.y; r.telegraph(a, "throw", 1.3f); a.burstLeft = 1; }
                    if (r.telegraphing(a, "throw")) { stop(a); break; }
                    if (a.burstLeft > 0) { a.burstLeft = 0; r.hurl(a, a.goalX, a.memY, a.goalZ); }
                    if (d > 5 && d <= 10 && a.specialTimer <= 0) { a.specialTimer = 8; a.suppressUntil = r.time + 2.6f; r.telegraph(a, "charge", 1.1f); }
                    if (r.telegraphing(a, "charge")) { stop(a); break; }
                    if (r.time < a.suppressUntil) speed = 8.5f;                                   // the charge itself
                    if (a.stuckTime > 0.15f) r.smash(a);                                          // light cover does not stop it
                }
                if (d < 1.6f + ar.melee * 0.01f + (giant ? 0.6f : 0) && a.fireCooldown <= 0 && ar.melee > 0) {
                    a.fireCooldown = giant ? 1.8f : 1.1f;
                    if (a.anim != null) a.anim.play(giant ? "giant_smash" : "inf_attack", 0);
                    r.melee(a, t, ar.melee * r.difficultyDamage());
                }
                if (d > (fat ? 2.0f : 1.1f)) goTo(r, a, gx, gz, speed, dt); else stop(a);
            }
            case "investigate" -> {
                if (r.time - a.memTime > 30) { setState(a, "idle"); break; }
                float d = a.distXZ(a.memX, a.memZ);
                if (d > 2.2f) goTo(r, a, a.memX, a.memZ, ar.speed * 1.3f, dt);
                else { stop(a); a.yaw += dt * 1.2f; if (a.stateTime > 10) setState(a, "idle"); }
            }
            case "search" -> {
                float d = a.distXZ(a.memX, a.memZ);
                if (d > 2) goTo(r, a, a.memX, a.memZ, ar.speed * 1.2f, dt); else { stop(a); a.yaw += dt * 1.6f; }
                if (a.stateTime > 14) setState(a, "idle");
            }
            default -> {
                // ecology: the regular dead drift to unattended corpses and gather there (group pressure builds on bodies)
                if ("walker".equals(a.archetype)) {
                    a.lootTimer -= dt;
                    if (a.lootTimer <= 0) {
                        a.lootTimer = 4 + r.rng.nextFloat() * 4;
                        Actor c = r.nearestCorpse(a.x, a.z, 26);
                        if (c != null && a.distXZ(c.x, c.z) > 3) { a.goalX = c.x + r.rng.range(-1.5f, 1.5f); a.goalZ = c.z + r.rng.range(-1.5f, 1.5f); a.hasGoal = true; a.stateTime = 0; a.thinkTimer = 0; }
                    }
                }
                idleMove(r, a, ar, dt);
            }
        }
    }

    // ================================================================== humans
    private static void human(Raid r, Actor a, Arch ar, Actor tgt, float dt) {
        Doc dc = doc(a.faction);
        Raid.Squad sq = r.squad(a);
        a.morale = Math.min(dc.morale(), a.morale + dt * 0.012f);
        if (tgt != null) contact(r, a, dc, sq, tgt);
        else if (sq != null && sq.contactTime > r.time - 3 && ("idle".equals(a.state) || "investigate".equals(a.state) || "search".equals(a.state)) && sq.targetId != 0 && a.distXZ(sq.tx, sq.tz) < 60
                && !(sq.extortDone && !sq.bloodied) && !a.paidOff) {
            // squad radio: a teammate has eyes on - share the last known position (with error), not the truth
            remember(r, a, sq.tx + (r.rng.nextFloat() - 0.5f) * 4, a.y, sq.tz + (r.rng.nextFloat() - 0.5f) * 4, 0.6f, 4);
            a.targetId = sq.targetId;
            if (dc.d() != Doctrine.LONER) setState(a, "engage");
        }
        // self-preservation and morale
        if (!"flee".equals(a.state) && !"retreat".equals(a.state)) {
            boolean hurt = a.hp < a.maxHp * 0.3f, broken = a.morale < dc.breakAt();
            boolean outmatched = sq != null && sq.initial >= 2 && sq.alive <= Math.max(1, Math.round(sq.initial * 0.35f)) && "engage".equals(a.state);
            if (dc.d() == Doctrine.MERC && (outmatched || hurt)) { setState(a, "retreat"); r.say(a, "Falling back!", "shout"); }
            else if (dc.d() == Doctrine.MILITARY && hurt && r.rng.chance(dt * 0.6)) setState(a, "retreat");
            else if ((dc.d() == Doctrine.BANDIT || dc.d() == Doctrine.LONER) && (broken || hurt) && r.rng.chance(dt * 2)) { setState(a, "flee"); if (dc.d() == Doctrine.BANDIT) r.say(a, "Screw this - run!", "shout"); }
        }
        switch (a.state) {
            case "engage" -> engage(r, a, ar, dc, sq, tgt, dt);
            case "extort" -> extort(r, a, ar, sq, dt);
            case "warn" -> warn(r, a, ar, sq, dt);
            case "investigate" -> {
                if (r.time - a.memTime > 30) { setState(a, "idle"); break; }
                float d = a.distXZ(a.memX, a.memZ);
                float sp = dc.d() == Doctrine.MILITARY || dc.d() == Doctrine.MERC ? ar.runSpeed * 0.75f : ar.speed * 1.2f;
                if (d > Math.max(2.2f, a.memErr * 0.6f)) goTo(r, a, a.memX, a.memZ, sp, dt);
                else { stop(a); a.yaw += dt * 1.2f; if (a.stateTime > 10) setState(a, "idle"); }
                a.crouch = dc.d() == Doctrine.BANDIT && d < 12;
            }
            case "search" -> {
                // sweep the uncertainty area instead of homing on the target
                if (!a.hasGoal || a.distXZ(a.goalX, a.goalZ) < 1.6f) {
                    float ang = r.rng.range(0f, 6.28f), rad = r.rng.range(0.3f, 1f) * Math.max(3, a.memErr);
                    a.goalX = a.memX + (float) Math.sin(ang) * rad; a.goalZ = a.memZ + (float) Math.cos(ang) * rad; a.hasGoal = true;
                }
                goTo(r, a, a.goalX, a.goalZ, ar.speed * 1.2f, dt);
                if (a.stateTime > (dc.d() == Doctrine.BANDIT ? 9 : 16)) { setState(a, canLoot(dc) && !a.looted ? "loot" : "idle"); }
            }
            case "loot" -> loot(r, a, ar, dc, dt);
            case "avoid" -> {
                // loners put distance and a wall between themselves and trouble
                float ax = a.x - a.memX, az = a.z - a.memZ, l = (float) Math.sqrt(ax * ax + az * az);
                if (!a.hasGoal) { float k = l < 0.1f ? 0 : 22 / l; a.goalX = a.x + ax * k * 0.6f + (a.homeX - a.x) * 0.4f; a.goalZ = a.z + az * k * 0.6f + (a.homeZ - a.z) * 0.4f; a.hasGoal = true; }
                goTo(r, a, a.goalX, a.goalZ, ar.runSpeed * 0.8f, dt);
                a.crouch = a.stateTime > 4;
                if (a.stateTime > 9 || a.distXZ(a.goalX, a.goalZ) < 2) { a.crouch = false; setState(a, "idle"); }
            }
            case "retreat" -> {
                // ordered withdrawal toward the post: move, turn, cover the squad, never rout
                float d = a.distXZ(a.homeX, a.homeZ);
                boolean coverTurn = ((int) (a.stateTime / 1.6f) & 1) == 1 && tgt != null;
                if (coverTurn) { stop(a); a.yaw = turn(a.yaw, (float) Math.atan2(-(tgt.x - a.x), -(tgt.z - a.z)), dt * 7); if (a.weapon != null && a.fireCooldown <= 0) r.npcFire(a, tgt, dt); }
                else if (d > 5) goTo(r, a, a.homeX, a.homeZ, ar.runSpeed, dt); else stop(a);
                if (a.stateTime > 14 || d <= 5 && tgt == null && a.stateTime > 5) { a.hp = Math.min(a.maxHp, a.hp + 12); a.morale = Math.max(a.morale, 0.6f); setState(a, "idle"); }
            }
            case "flee" -> {
                if (!a.hasGoal) { a.goalX = a.homeX + (r.rng.nextFloat() - 0.5f) * 50; a.goalZ = a.homeZ + (r.rng.nextFloat() - 0.5f) * 50; a.hasGoal = true; }
                goTo(r, a, a.goalX, a.goalZ, ar.runSpeed, dt);
                if (a.stateTime > 12) { setState(a, "idle"); a.hp = Math.min(a.maxHp, a.hp + 10); a.morale = Math.max(a.morale, dc.breakAt() + 0.15f); }
            }
            default -> idleHuman(r, a, ar, dc, sq, dt);
        }
    }

    private static boolean canLoot(Doc dc) { return dc.d() == Doctrine.MERC || dc.d() == Doctrine.BANDIT; }

    /** First confirmed sight of a hostile: doctrine decides between attack, hold-up, warning and withdrawal. */
    private static void contact(Raid r, Actor a, Doc dc, Raid.Squad sq, Actor tgt) {
        if ("flee".equals(a.state) || "retreat".equals(a.state)) return;
        if (a.paidOff && tgt.isPlayer && !a.hostileToPlayer) return;
        if (sq != null) { sq.tx = tgt.x; sq.tz = tgt.z; sq.targetId = tgt.id; sq.contactTime = r.time; }
        if ("engage".equals(a.state) || "extort".equals(a.state)) return;
        float d = a.dist(tgt);
        switch (dc.d()) {
            case BANDIT -> {
                // predators size the prey up: rob a lone, quiet target; back off from a strong one
                int mine = sq == null ? 1 : sq.alive;
                float theirs = r.strengthNear(tgt, a.faction);
                if (tgt.isPlayer && sq != null && !sq.extortDone && mine >= 2 && d > 5 && !r.playerAiming && r.time - r.lastPlayerShot > 6) {
                    sq.extortDone = true;
                    sq.extortUntil = r.time + 8;
                    r.say(a, "Hands where we can see them! " + Raid.EXTORT_PRICE + " scrip and you walk.", "shout");
                    for (Actor m : r.squadMembers(a)) { setState(m, "extort"); m.targetId = tgt.id; }
                    return;
                }
                if (mine < theirs * 0.8f && d > 9) { a.morale -= 0.15f; setState(a, "flee"); r.say(a, "Too many of them!", "shout"); return; }
                if (r.rng.chance(0.6)) r.say(a, r.rng.chance(0.5) ? "Fresh meat!" : "Get 'em!", "shout");
            }
            case LONER -> {
                // avoid the fight unless it is on top of us or they hurt one of ours
                if (d > 10 && a.hp >= a.maxHp * 0.95f && (sq == null || !sq.bloodied)) { setState(a, "avoid"); return; }
            }
            case MERC -> {
                if (sq != null && !sq.backupCalled) { sq.backupCalled = true; r.say(a, "Contact! Requesting support on my position.", "radio_chatter"); r.dispatch(a.faction, tgt.x, tgt.z, a.squad, "reinforce"); }
                assignRoles(r, a);
            }
            case MILITARY -> { if (r.rng.chance(0.5)) r.say(a, "Contact front!", "shout"); }
        }
        setState(a, "engage");
    }

    /** Mercenary fire team: the first rifle suppresses, the second holds an angle, the rest flank. */
    private static void assignRoles(Raid r, Actor a) {
        int k = 0;
        for (Actor m : r.squadMembers(a)) { m.role = k == 0 ? "suppress" : k == 1 ? "hold" : (k % 2 == 0 ? "flank_l" : "flank_r"); k++; }
    }

    private static void engage(Raid r, Actor a, Arch ar, Doc dc, Raid.Squad sq, Actor tgt, float dt) {
        Actor t = r.actor(a.targetId);
        if (t == null || t.dead) { setState(a, canLoot(dc) && !a.looted ? "loot" : "search"); return; }
        boolean seen = tgt == t;
        float lostAfter = dc.d() == Doctrine.MERC ? 6 : 2.5f;
        if (!seen && r.time - a.memTime > lostAfter) { setState(a, "search"); return; }
        float d = a.dist(t), md = a.distXZ(a.memX, a.memZ);
        a.yaw = turn(a.yaw, (float) Math.atan2(-(a.memX - a.x), -(a.memZ - a.z)), dt * 6);
        float want = "shotgunner".equals(a.archetype) ? 7 : "marksman".equals(a.archetype) ? 35 : dc.fightDist();
        float speed = ar.speed;
        boolean leashed = a.distXZ(a.homeX, a.homeZ) > dc.leash();
        boolean fire = seen && a.weapon != null && a.fireCooldown <= 0;
        a.crouch = false;
        switch (dc.d()) {
            case MERC -> {
                if ("suppress".equals(a.role)) {
                    // keep their heads down: fire on the last known position even without a sight line
                    if (!seen && a.weapon != null && a.fireCooldown <= 0 && r.time - a.memTime < 6 && md < 60) r.npcSuppress(a, a.memX, a.memY + 1.1f, a.memZ);
                    if (md > want * 1.6f && !leashed) goTo(r, a, a.memX, a.memZ, speed * 1.3f, dt); else { stop(a); a.crouch = true; }
                } else if (a.role.startsWith("flank") && !leashed) {
                    // swing wide of the squad-target axis, then close from the side
                    float side = a.role.endsWith("l") ? 1 : -1;
                    float ang = (float) Math.atan2(a.homeX - a.memX, a.homeZ - a.memZ) + side * 1.35f;
                    float fx = a.memX + (float) Math.sin(ang) * 13, fz = a.memZ + (float) Math.cos(ang) * 13;
                    if (a.distXZ(fx, fz) > 3 && !(seen && d < 14)) goTo(r, a, fx, fz, ar.runSpeed * 0.85f, dt); else { stop(a); a.crouch = seen; }
                } else cover(r, a, ar, dt, seen, want, leashed);
            }
            case MILITARY -> {
                cover(r, a, ar, dt, seen, want, leashed);
                // call-in: sustained contact brings the next patrol over
                if (sq != null && !sq.backupCalled && a.stateTime > 8) { sq.backupCalled = true; r.say(a, "Command, troops in contact - send the patrol.", "radio_chatter"); r.dispatch(a.faction, a.memX, a.memZ, a.squad, "reinforce"); }
                // fire discipline at range: only peek while standing
                fire &= !a.crouch || d < 8;
            }
            case BANDIT -> {
                // rush and crowd: close the distance, shoot on the move
                if (d > want || !seen) goTo(r, a, a.memX, a.memZ, ar.runSpeed * 0.8f, dt);
                else strafe(a, speed * 0.9f, r);
                if (r.rng.chance(dt * 0.12)) r.say(a, r.rng.chance(0.5) ? "Come out, rat!" : "I see you!", "shout");
            }
            case LONER -> {
                // fight from behind something and keep an exit open
                cover(r, a, ar, dt, seen, want, false);
                if (d > 26 && a.stateTime > 6) { setState(a, "avoid"); return; }
            }
        }
        if (fire) r.npcFire(a, t, dt);
    }

    /** Cover and peek: find a spot with a block between us and the threat, duck, pop up to shoot. */
    private static void cover(Raid r, Actor a, Arch ar, float dt, boolean seen, float want, boolean leashed) {
        float d = a.distXZ(a.memX, a.memZ);
        if (!a.hasCover || r.time > a.coverUntil) {
            a.hasCover = findCover(r, a, a.memX, a.memY, a.memZ);
            a.coverUntil = r.time + (a.hasCover ? 7 : 2.5f);
        }
        if (a.hasCover) {
            if (a.distXZ(a.coverX, a.coverZ) > 0.9f) { goTo(r, a, a.coverX, a.coverZ, ar.runSpeed * 0.8f, dt); return; }
            stop(a);
            float cycle = (r.time + a.id * 0.37f) % 3.4f;
            a.crouch = cycle > 1.7f || !seen && cycle > 0.9f;
            return;
        }
        if (leashed) { if (a.distXZ(a.homeX, a.homeZ) > 4) goTo(r, a, a.homeX, a.homeZ, ar.speed * 1.3f, dt); else stop(a); return; }
        if (d > want * 1.3f || !seen) goTo(r, a, a.memX, a.memZ, ar.speed * 1.4f, dt);
        else if (d < want * 0.5f) { a.vx = (float) Math.sin(a.yaw) * ar.speed; a.vz = (float) Math.cos(a.yaw) * ar.speed; }
        else strafe(a, ar.speed * 0.6f, r);
        a.crouch = seen && d > 12 && (r.time + a.id) % 6 < 3;
    }

    /** Looks for a standable cell near a where a solid block shields a crouched body from the threat. */
    public static boolean findCover(Raid r, Actor a, float tx, float ty, float tz) {
        float best = Float.MAX_VALUE;
        boolean found = false;
        for (int k = 0; k < 20; k++) {
            float ang = k * 0.9f + a.id, rad = 1.5f + (k % 5) * 1.3f;
            float px = (float) Math.floor(a.x + Math.sin(ang) * rad) + 0.5f, pz = (float) Math.floor(a.z + Math.cos(ang) * rad) + 0.5f;
            int gy = r.groundY((int) px, (int) pz);
            if (gy < 0 || Math.abs(gy - a.y) > 1.2f || !Physics.boxFree(r.world, px, gy, pz, a.radius, a.stand)) continue;
            if (Physics.los(r.world, px, gy + 0.75f, pz, tx, ty + 1.3f, tz)) continue;   // crouched body exposed: not cover
            float cost = a.distXZ(px, pz) + (Physics.los(r.world, px, gy + 1.65f, pz, tx, ty + 1.3f, tz) ? 0 : 3);   // prefer cover you can shoot over
            if (cost < best) { best = cost; a.coverX = px; a.coverZ = pz; found = true; }
        }
        return found;
    }

    /** Bandit hold-up: weapons trained, no shots, until the player pays, resists or the clock runs out. */
    private static void extort(Raid r, Actor a, Arch ar, Raid.Squad sq, float dt) {
        Actor p = r.player;
        if (sq == null) { setState(a, "engage"); return; }
        float d = a.dist(p);
        a.yaw = turn(a.yaw, (float) Math.atan2(-(p.x - a.x), -(p.z - a.z)), dt * 6);
        if (d > 9) goTo(r, a, p.x, p.z, ar.speed * 1.2f, dt); else stop(a);
        if (sq.paid) { for (Actor m : r.squadMembers(a)) { m.hostileToPlayer = false; m.paidOff = true; m.awareness = 0; m.targetId = 0; setState(m, "idle"); } r.say(a, "Smart. Now get lost.", "shout"); return; }
        boolean resisted = r.playerAiming || r.time - r.lastPlayerShot < 1 || d < 3.2f || d > 34;
        if (resisted || r.time > sq.extortUntil) {
            if (!sq.bloodied) r.say(a, resisted ? "Wrong move!" : "Time's up!", "shout");
            sq.bloodied = true;
            for (Actor m : r.squadMembers(a)) { m.hostileToPlayer = true; m.targetId = p.id; setState(m, "engage"); }
        }
    }

    /** Military restricted-area enforcement: a spoken warning and a grace period before force. */
    private static void warn(Raid r, Actor a, Arch ar, Raid.Squad sq, float dt) {
        Actor p = r.player;
        a.yaw = turn(a.yaw, (float) Math.atan2(-(p.x - a.x), -(p.z - a.z)), dt * 6);
        stop(a);
        a.warnTimer -= dt;
        if (!r.restrictedFor(p.x, p.z)) { a.warned = false; r.say(a, "Keep moving.", "shout"); setState(a, "idle"); return; }
        if (a.warnTimer <= 0 || r.playerAiming && a.dist(p) < 25) {
            r.say(a, "Final warning ignored - engaging!", "shout");
            r.trespass();
            for (Actor m : r.nearby(a.x, a.z, 40)) if (m.faction.equals(a.faction)) { m.hostileToPlayer = true; m.targetId = p.id; remember(r, m, p.x, p.y, p.z, 1, 0.5f); setState(m, "engage"); }
        }
    }

    /** Walk to the nearest lootable corpse and strip it: mercenaries take the hardware, bandits take everything fast. */
    private static void loot(Raid r, Actor a, Arch ar, Doc dc, float dt) {
        Actor c = r.nearestCorpse(a.x, a.z, 22);
        if (c == null || c.corpse == null || c.corpse.items.isEmpty() || a.stateTime > 25) { a.looted = true; setState(a, "idle"); return; }
        if (a.distXZ(c.x, c.z) > 1.6f) { goTo(r, a, c.x, c.z, dc.d() == Doctrine.BANDIT ? ar.runSpeed * 0.8f : ar.speed * 1.3f, dt); a.lootTimer = 0; return; }
        stop(a);
        a.crouch = true;
        a.lootTimer += dt;
        if (a.lootTimer > (dc.d() == Doctrine.BANDIT ? 1.6f : 3.2f)) { r.npcLoot(a, c, dc.d() == Doctrine.MERC); a.looted = true; a.crouch = false; setState(a, "idle"); }
    }

    // ------------------------------------------------------------------ idle behaviour per doctrine
    private static void idleHuman(Raid r, Actor a, Arch ar, Doc dc, Raid.Squad sq, float dt) {
        a.crouch = false;
        if (a.hasOrder) {
            if (r.time > a.orderUntil) a.hasOrder = false;
            else if (a.distXZ(a.orderX, a.orderZ) > 5) { goTo(r, a, a.orderX, a.orderZ, ar.runSpeed * 0.8f, dt); return; }
            else { a.hasOrder = false; remember(r, a, a.orderX, a.y, a.orderZ, 0.5f, 6); setState(a, "investigate"); return; }
        }
        Actor p = r.player;
        switch (dc.d()) {
            case MILITARY -> {
                // cordon enforcement: the unauthorised get one warning inside a restricted area
                if (!a.hostileToPlayer && !p.dead && r.restrictedFor(p.x, p.z) && a.dist(p) < 30 && Physics.los(r.world, a.x, a.eyeY(), a.z, p.x, p.eyeY(), p.z)) {
                    if (!a.warned) { a.warned = true; a.warnTimer = 7; r.say(a, "Restricted area! Turn back - you have seconds.", "shout"); }
                    setState(a, "warn");
                    return;
                }
                if ("hold".equals(a.role)) { hold(r, a, dt); return; }
                patrol(r, a, ar, sq, dt);
            }
            case MERC -> {
                // guard the asset: half the team is static, the rest walks a tight loop round it
                if (a.dist(p) < 18 && !a.hostileToPlayer && !p.dead && a.talkTimer <= 0 && Physics.los(r.world, a.x, a.eyeY(), a.z, p.x, p.eyeY(), p.z)) { a.talkTimer = 20; r.say(a, "Private site. Keep your distance.", "shout"); }
                a.talkTimer -= dt;
                if ((a.id & 1) == 0) { hold(r, a, dt); return; }
                if (!a.hasGoal || a.distXZ(a.goalX, a.goalZ) < 1.6f) {
                    a.routeIndex = (a.routeIndex + 1) & 3;
                    float ang = a.routeIndex * 1.5708f + (a.squad & 3);
                    a.goalX = a.homeX + (float) Math.sin(ang) * 11; a.goalZ = a.homeZ + (float) Math.cos(ang) * 11; a.hasGoal = true; a.thinkTimer = r.rng.range(1.5f, 4f);
                }
                if (a.thinkTimer > 0) { a.thinkTimer -= dt; stop(a); return; }
                goTo(r, a, a.goalX, a.goalZ, ar.speed, dt);
                if (a.stuckTime > 2.5f) a.hasGoal = false;
            }
            case BANDIT -> {
                // lurk on the route: crouch in wait most of the time, relocate now and then, never quiet for long
                a.talkTimer -= dt;
                if (a.talkTimer <= 0) { a.talkTimer = r.rng.range(14f, 34f); if (r.rng.chance(0.5)) r.emitSound(a.x, a.y + 1.5f, a.z, 22, "whistle", a.id, false); }
                if (a.thinkTimer > 0) { a.thinkTimer -= dt; stop(a); a.crouch = true; a.yaw += (float) Math.sin(r.time * 0.4 + a.id) * dt * 0.5f; return; }
                if (!a.hasGoal) {
                    MapData.Node n = r.world.map.nearestNode(a.homeX + (r.rng.nextFloat() - 0.5f) * 44, a.homeZ + (r.rng.nextFloat() - 0.5f) * 44);
                    a.goalX = n != null ? n.x + r.rng.range(-5f, 5f) : a.homeX; a.goalZ = n != null ? n.z + r.rng.range(-5f, 5f) : a.homeZ; a.hasGoal = true; a.stateTime = 0;
                }
                goTo(r, a, a.goalX, a.goalZ, ar.speed * 0.9f, dt);
                if (a.distXZ(a.goalX, a.goalZ) < 2 || a.stateTime > 22) { a.hasGoal = false; a.thinkTimer = r.rng.range(8f, 22f); }
            }
            case LONER -> scavenge(r, a, ar, dt);
        }
    }

    private static void hold(Raid r, Actor a, float dt) {
        if (a.distXZ(a.homeX, a.homeZ) > 2.5f) { goTo(r, a, a.homeX, a.homeZ, arch(a.archetype).speed, dt); return; }
        stop(a);
        a.yaw += (float) Math.sin(r.time * 0.25f + a.id * 1.7f) * dt * 0.45f;   // slow scan of the arc
    }

    /** Fixed patrol loop on the street graph: same nodes, same order, single file behind the lead. */
    private static void patrol(Raid r, Actor a, Arch ar, Raid.Squad sq, float dt) {
        if (sq == null || sq.route.isEmpty()) { idleMove(r, a, ar, dt); return; }
        if (a.routeIndex < 0) a.routeIndex = 0;
        float[] wp = sq.route.get(a.routeIndex % sq.route.size());
        int rank = r.squadRank(a);
        float gx = wp[0] + (rank % 2 == 0 ? -1.2f : 1.2f), gz = wp[1] + (rank % 2 == 0 ? -1.2f : 1.2f);
        if (a.thinkTimer > 0) { a.thinkTimer -= dt; stop(a); a.yaw += dt * 0.5f * ((a.id & 1) == 0 ? 1 : -1); return; }
        if (a.distXZ(gx, gz) < 2.4f) { a.routeIndex = (a.routeIndex + 1) % sq.route.size(); a.thinkTimer = 2.5f + rank * 0.6f; return; }
        goTo(r, a, gx, gz, ar.speed, dt);
        if (a.stuckTime > 3.5f) { a.routeIndex = (a.routeIndex + 1) % sq.route.size(); a.stuckTime = 0; }
    }

    /** Loners work the nearby containers, one at a time, and take a knee when hurt. */
    private static void scavenge(Raid r, Actor a, Arch ar, float dt) {
        if (a.needsHelp && !a.helped) { stop(a); a.crouch = true; a.talkTimer -= dt; if (a.talkTimer <= 0 && a.dist(r.player) < 14) { a.talkTimer = 12; r.say(a, "Hey - you got a bandage? Please.", "shout"); } return; }
        if (a.thinkTimer > 0) { a.thinkTimer -= dt; stop(a); a.crouch = a.lootTimer > 0; if (a.thinkTimer <= 0 && a.lootTimer > 0) { a.lootTimer = 0; r.emitSound(a.x, a.y + 0.5f, a.z, 6, "search", a.id, false); } return; }
        if (!a.hasGoal) {
            MapData.LootSpot s = r.lootSpotNear(a.homeX, a.homeZ, 26, a.id + (int) (r.time / 20));
            if (s != null) { a.goalX = s.x + 0.5f; a.goalZ = s.z + 0.5f; a.lootTimer = 1; }
            else { a.goalX = a.homeX + (r.rng.nextFloat() - 0.5f) * 20; a.goalZ = a.homeZ + (r.rng.nextFloat() - 0.5f) * 20; a.lootTimer = 0; }
            a.hasGoal = true; a.stateTime = 0;
        }
        goTo(r, a, a.goalX, a.goalZ, ar.speed * 0.85f, dt);
        if (a.distXZ(a.goalX, a.goalZ) < 2.2f || a.stateTime > 20 || a.stuckTime > 2.5f) { a.hasGoal = false; a.thinkTimer = a.lootTimer > 0 && a.distXZ(a.goalX, a.goalZ) < 3 ? 4f : r.rng.range(1f, 4f); if (a.distXZ(a.goalX, a.goalZ) >= 3) a.lootTimer = 0; }
    }

    private static void idleMove(Raid r, Actor a, Arch ar, float dt) {
        // wander around the home post along the street graph
        if (!a.hasGoal || a.distXZ(a.goalX, a.goalZ) < 1.8f || a.stateTime > 25) {
            float rad = ar.infected ? 10 : 18;
            MapData.Node n = r.world.map.nearestNode(a.homeX + (r.rng.nextFloat() - 0.5f) * rad * 2, a.homeZ + (r.rng.nextFloat() - 0.5f) * rad * 2);
            if (n != null && Math.abs(n.x - a.homeX) < 40 && Math.abs(n.z - a.homeZ) < 40 && r.rng.chance(0.6)) { a.goalX = n.x + 0.5f; a.goalZ = n.z + 0.5f; }
            else { a.goalX = a.homeX + (r.rng.nextFloat() - 0.5f) * rad; a.goalZ = a.homeZ + (r.rng.nextFloat() - 0.5f) * rad; }
            a.hasGoal = true;
            a.stateTime = 0;
            a.thinkTimer = r.rng.range(1f, 5f);
        }
        if (a.thinkTimer > 0) { a.thinkTimer -= dt; stop(a); a.yaw += (float) Math.sin(r.time * 0.3 + a.id) * dt * 0.4f; return; }
        goTo(r, a, a.goalX, a.goalZ, ar.speed * (ar.infected ? 0.7f : 0.8f), dt);
    }

    /** A squadmate went down: morale drops by doctrine; bandits take it worst. */
    public static void onAllyDown(Raid r, Actor ally, Actor dead) {
        if (ally.dead || ally.infected()) return;
        Doc dc = doc(ally.faction);
        ally.morale -= switch (dc.d()) { case BANDIT -> 0.38f; case LONER -> 0.30f; case MILITARY -> 0.12f; case MERC -> 0.08f; };
        if (dc.d() == Doctrine.LONER && !"engage".equals(ally.state) && dead.lastAttacker != 0) {
            // defend their own: the attacker becomes a target even for the cautious
            Actor k = r.actor(dead.lastAttacker);
            if (k != null && !k.dead && ally.dist(k) < 40) { ally.targetId = k.id; remember(r, ally, k.x, k.y, k.z, 0.8f, 2); ally.state = "engage"; ally.stateTime = 0; }
        }
    }

    private static void strafe(Actor a, float sp, Raid r) {
        float side = ((int) (r.time * 0.5f + a.id) % 2 == 0) ? 1 : -1;
        a.vx = (float) Math.cos(a.yaw) * sp * side;
        a.vz = (float) -Math.sin(a.yaw) * sp * side;
    }

    private static void stop(Actor a) { a.vx *= 0.5f; a.vz *= 0.5f; }

    /** Steering with simple obstacle avoidance; long detours handled by walking the street graph. */
    public static void goTo(Raid r, Actor a, float tx, float tz, float speed, float dt) {
        float dx = tx - a.x, dz = tz - a.z, d = (float) Math.sqrt(dx * dx + dz * dz);
        if (d < 0.3f) { stop(a); return; }
        float want = (float) Math.atan2(-dx, -dz);
        if (a.stuckTime > 0.6f) {
            // probe left/right for an open heading
            for (float off : new float[]{0.8f, -0.8f, 1.6f, -1.6f, 2.4f}) {
                float h = want + off;
                float px = a.x - (float) Math.sin(h) * 1.2f, pz = a.z - (float) Math.cos(h) * 1.2f;
                if (Physics.boxFree(r.world, px, a.y + 1.01f, pz, a.radius, 1.7f) || Physics.boxFree(r.world, px, a.y, pz, a.radius, 1.7f)) { want = h; break; }
            }
            if (a.stuckTime > 3) { a.hasGoal = false; a.stuckTime = 0; }
        }
        a.yaw = turn(a.yaw, want, dt * 5);
        a.vx = (float) -Math.sin(a.yaw) * speed;
        a.vz = (float) -Math.cos(a.yaw) * speed;
    }

    public static float turn(float cur, float target, float maxStep) {
        float d = target - cur;
        while (d > Math.PI) d -= Math.PI * 2;
        while (d < -Math.PI) d += Math.PI * 2;
        return cur + Math.max(-maxStep, Math.min(maxStep, d));
    }
}
