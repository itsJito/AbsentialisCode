# ABSENTIALIS

Persistent voxel extraction-survival (Java 21 + LWJGL 3.3.3). Current pass: `ITERATION.md`.

## Build & run

```powershell
.\gradlew.bat run --no-daemon        # play
.\gradlew.bat selftest --no-daemon   # 177 quality gates, no window (exit code != 0 on failure)
```

The build pins a **Java 21 toolchain** (LWJGL 3.3.3 does not support Java 24). Gradle uses an installed
JDK 21 or provisions one on first run. GLFW errors go to stderr and init failures throw; any fatal
exception is printed and written to `crash.log` - the app never exits silently.

## Controls (all rebindable in Settings)

| Action | Key | Action | Key |
|---|---|---|---|
| Move / sprint / walk | WASD / LShift / LAlt | Fire / aim | LMB / RMB |
| Crouch / jump | C / Space | Reload (double-tap = speed reload, drops mag) | R |
| Lean | Q / E | Fire mode | B |
| Interact (doors, loot, bodies, substations, pay a hold-up, aid a loner) | F | Primary / sidearm / melee | 1 / 2 / 3 |
| Inventory | I | Quick-use slots | 4-7 |
| Weapon wheel (hold, time slows to 30%) | Tab | Throw | G |
| Map | M | Flashlight | L |
| First / third person | V | Console | ~ |
| Screenshot | F12 | | |

**Inventory:** drag to move (green = fits, amber = combines, red = rejected), **R** rotates while dragging
(a quarter turn; it swaps width and height and never flips the icon), **Shift+click** quick-transfers,
**right-click** for actions, **Z** auto-sorts. An equipped **backpack** adds its own storage grid under the case.

## What this iteration added

| Area | Where | Notes |
|---|---|---|
| Shared 12-group rig, keyframe clip cache, animator | `character/Rig, AnimClip, Anims, Animator` | Gait phase advances by distance travelled / stride, so stance feet stay planted; hips turn into the movement while the torso holds the aim; 120 ms blends; hands are solved onto the weapon; feet follow kerbs and stairs. |
| Ragdoll | `character/Ragdoll` | 15 joints, rigid bone sticks, range limits and one-sided knee/elbow hinges; starts from the animated pose, 80 ms hand-over, hit impulse, static after at most 8 s; distant bodies are placed at rest at once. |
| First person | `scene/RaidScreen, ActorRenderer` | Camera rides the head bone; the same body (minus head and arms) is drawn so legs are visible; viewmodel arms use the player's own sleeves and gloves; tactical vs empty reloads are different clips; sway scales with weapon mass. |
| Customization | `character/CharDefs, Appearance, CharBuilder`, `scene/CharacterCreator` | 10 selectors (head, hair, facial hair, torso, sleeves, legs, hands, feet, skin, hair colour), 12-15 options each, validated SKIN assignment; profiles store definition ids only. Hideout tab **OPERATOR**. |
| Audio | `engine/audio` | Master + Music / Effects / Voice / Ambience / Interface buses with mutes; positional pan, attenuation and distance low-pass; material footsteps (incl. water) for player and NPCs; equip / tactical / empty reload foley; hover, click, invalid, extraction tick. Sounds are synthesised placeholders. |
| Inventory orientation | `ui/ItemIcons`, `engine/voxel/VoxRaster` | The rasteriser's up vector was inverted (91 icons upside down) and 10 definitions had footprints at right angles to their models. Both fixed; v2 saves migrate. |
| Map | `world/gen/Authored, Validation, Streets, Districts` | Central power plant (reactor blocks, sarcophagus, turbine hall, banded vent stack, cooling towers, switchyard), panel-housing microdistricts with a school and polyclinic, Downtown towers; street furniture by rule; placement audit grounds floating props and repairs street-graph nodes. |
| Districts | `world/District` | Downtown, Industrial, Residential, Government, Untamed, Wilderness - each with landmarks, loot weights, faction baseline, patrol density and typed extractions. |
| Rank | `gameplay/progression/Progression`, `scene/RaidResolver` | Rank names and an unlock roadmap; XP from extraction, secured loot value, contracts, weapon mastery milestones, recon and time - none from kills. |
| A-Life | `sim/ALife, ZoneState`, `scene/Raid` | Strategic squads with persistent ids and an event log; evidence (bodies, smoke, roadblocks) spawned from the log; noise service: gunfire -> perception, infected migration, patrol dispatch, district pressure. |
| Human AI | `ai/Brain` | Mercenaries (suppress / hold / flank, radio, ordered retreat), Bandits (hold-ups, strength check, morale), Military (patrol routes, cover, restricted-area warnings, call-ins), Loners (avoid, scavenge, ask for help). |
| Infected | `ai/Brain`, `scene/Raid` | Regular, Fast, Fat (telegraphed bile, ruptures into a contamination zone), Giant (telegraphed throw and charge, breaks light cover, audible footfalls). |

## Console (`~`, Tab autocompletes)

`help`, `god`, `noclip`, `thirdperson`, `give <item> [qty]`, `tp <district|exit>`, `setrep <faction> <value>`,
`econ audit [graph]`, `skip hour [n]`, `ai debug`, `noise debug`, `alife`, `freeze`, `save`, `load`, `xp <n>`, `heal`,
`extract`, `time <minutesLeft>`, `spawn <archetype|faction>`, `selftest`.

Factions: `military`, `raiders` (Bandits), `survivors` (Loners), `mercenaries`. Infected: `walker` (Regular),
`sprinter` (Fast), `boomer` (Fat), `tank` (Giant).

## Test hooks (environment variables)

| Variable | Effect |
|---|---|
| `ABS_SELFTEST=all` or any of `inventory orient weapon progress econ save death extraction noise ballistic tier character anim ragdoll audio alife ai zombie district` | run gates headless and exit |
| `ABS_AUTOSHOT=<dir>` | scripted pass saved as PNGs: menus, creator, a staged line-up of every faction and infected type, first-person legs, third person, firing, reload, ragdolls, the plant |
| `ABS_PREVIEW=<dir>` | fixed map preview renders |
| `ABS_TEST_NOPOP=1` | raid without strategic population |

## Layout

```
character/   rig, poses, clips, animator, ragdoll, customization tables, character assembly (no GL)
engine/      window, input, GL renderers, audio mixer + synthesised sound bank, voxel model + CPU raster
world/       blocks, materials, district definitions; gen/ city generator, authored landmarks, placement audit
entity/      Actor, Survivor (cores/injuries), Physics
ai/          Brain: perception, four human doctrines, infected archetypes
gameplay/    items, inventory, weapons, progression, economy, contracts
sim/         ZoneState + ALife: strategic tier (influence, squads, event log, ecology)
persistence/ Profile (4 slots, v3), SaveSystem, Settings
scene/       GameApp, Hideout, CharacterCreator, Raid (simulation), RaidScreen, HUD, ActorRenderer
ui/          sprite sheet, widgets, item icons, inventory UI, map
tools/       SelfTests (quality gates), MapPreview
```

## Known limits

- Persistent per-entity world changes (opened doors, individual looted caches across raids) are not stored;
  district power, supply, influence, squads and the event log are.
- "Navmesh validation" is the street waypoint graph; there is no full navigation mesh, so agents still steer
  locally between nodes.
- The ragdoll has no self-collision between limbs, and the player's own death does not show a ragdoll.
- Loners give aid/intel interactions only; there is no barter screen with them.
- All audio is synthesised at start-up; there are no recorded assets.
