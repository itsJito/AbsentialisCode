# CLAUDE CODE MASTER IMPLEMENTATION PROMPT — GAME VERSION 1.1

> **PRIMARY DIRECTIVE** You are a senior expert level game-engine engineer, technical director, AI systems architect, physics programmer, gameplay designer, and quality-assurance lead. Utilize the most advanced **appropriate, proven, maintainable, and performant** techniques available within this repository and its existing engine to deliver an exceptionally polished, production-quality **Version 1.1**. Do not settle for superficial fixes, stub implementations, visual fakery, or merely writing a plan. **Refine the execution of the ideas; do not alter, replace, dilute, or reinterpret their creative intent.** The detailed requirements below are the product specification. Inspect the actual project before deciding how to implement anything. Make changes in the codebase, verify them, and clearly report what is complete versus unverified.

Note: any testing of mechanics should be done in devmap

Bugs to be fixed:
  When on the stairs, it forces prone and you can't stand properly.
  At long distances, glass causes flicker effects and eats the wall around it. Glass is also visible through fog, even with buildings completely coverd in fog.
  NPC's still sometimes spin in circles.
  NPC's sometimes try and path-walk into walls as if they're attracted to a point on the other side instead of genuinely pathfinding.
  Female character models should be overhauled, make sure it's 4-pixel-wide arms for Males and 3-pixel-wide arms for Females. Males should be about 4 wide × 12 tall × 4 deep
  When the crawler NPC is ragdolled, it gets up using the default human animation. The crawlers animation should be tweaked to be more spider like in movements but still clearly a humanoid crawling. Crawler NPC also sometimes bugs out and clips underneath map.
  When in firefights, NPC's keep getting stuck on tracking down blood (obviously there will be blood), so fix their priorities in a fire fight and give them context clues to blame someone nearby for the blood or something.
  Humans don't naturally blend animations when injured enough to go into down. Humans also are not reacting to being shot, they should react (e.g if they lose their leg and are only holding a pistol and have a free hand, they should try and grab the area that was shot etc)
  When a player or human is in a vehicle and the tank attacks them, their body goes through the roof but they do not. 
  Top left notification GUI keeps flickering with every update. Space out the notifications (unless it's a rank up notif). All XP related stuff should be center and on top, and the rank up GUI/Animation should look way more impressive and militaristic.
  When entering a vehicle from the passenger side, the doors do not open and they just get put in their seat.
  Infected sometimes get stuck in a turning loop over bodies.
  NPC's appear to still get stuck in a turning loop.
  Other infected also use the human get up animation when recovering from ragdoll
  Can't use the letter 'i' while typing in the devmode search menu
  Turning off rain in the devmenu does not turn off rain.
  NPC's tend to try and always jump onto blocks that just so happen to be one block high. This looks weird in interiors, fix.
  Spewers glow shows outside of walls and into rooms it's not apart of.
  Some objects such as the valve at Coords 556, 24, 286.
  There is smoke (voxel blocks, must be changed, see below) coming from nowhere at 470, 24, 247. Same thing at 350, 24, 350.
  When infected crawl through 1x1 spaces, they must do it naturally and really CRAWL THROUGH IT. right now they just slide through it.
  Spinels currently spin and float in the air. They must actually be attached to a cieling the player can access.
  This wasn't noted during the regular map, but devmode map features broken textures on the road, not sure what it's supposed to be.
  Guns arent locked to player/character models, i note when holding a pistol the characters arm twists without the gun moving.
  Characters do not sit properly in the patrol cruiser.
  When players/npcs grab a ledge and jump onto it, if theyre already walking forward they glitch/phase into the block they're actively climbing.
  When looting the players corpse, sometimes NPC's will loot the area where the player died not the actual corpse of the player where it landed.
  Some NPC's do not ragdoll at all and play a canned animation. ALL ragdolls should be ran through Sydney.
  When out of stamina and attempting to sprint, the camera spams between the sprint and normal state.
  When there are two glass blocks on top of eachother, shooting the top one first and then the second results in the glass physics remaining locked in place in the air. Sydney should kick back in to make them fall.
  When walking over foliage, the foliage enlarges.
  Main menu music and deployment screen music doesn't play. Ensure both are properly functional (they are in the sound effects to add folder)
  
Things to remove:
  Flower/plant foliage types appearing in unnatural places (e.g flower in the middle of a street)
  
Changes to make:
  The Halloran Mansions interior should be iterated on until it is genuinely impressive and AI can pathfind through it. Take reference pictures of interiors until each room reaches atleast a 18/20, with the first photos you take (what it currently is) being an 8/20. Also make sure to naturally spawn infected in these interiors. This is of the upmost importance.
  The Chernobyl Power Plants interior should be iterated on until it is genuinely impressive and AI can pathfind through it. Take reference pictures of interiors until each room reaches atleast a 18/20, with the first photos you take (what it currently is) being an 8/20. Also make sure to naturally spawn infected in these interiors. This is of the upmost importance.
  During specific random encounters with NPC's, such as the player choosing to let them search his bag, should actually showcase an animation of whoever initated it to check the player. Once animation is complete and the player has no valuabes they want, then it completes. But apply that thinking for everything.
  The stealth kill with a knife should have a combined animation for both third and first person, combined in the sense that it shows the player actually performing the stealth kill animation, but the combined part is allowing the sydney engine to take over half way through so that bodies ragdoll.
  The design of the rifle ammo box should be altered, keep the colors but make it look more like an actual box of rifle ammo instead of cash, because it currently looks like money.
  Allow the player to put attachments on any gun if they have the attachment for it in their inventory through the actual inventory screen (showing a simplified workbench menu, only the attachments and current gun stats, this shows up when inspecting weapons), and let's overhaul the way gun progression works entirely so that 1. Weapon Levels give the player Weapon Experience (WXP), and every level up until max on every weapon, they unlock a new attachment slot for that gun. Every level the player will be able to upgrade their gun, and they can upgrade 4 main-gun upgrade categories across all weapons; Firepower (affects damage, so have all guns start at about maybe half as powerful as they are now (but still realistically powerful enough to get the job done for what it is, so set minimums) and their current stats should be increased by about 1-2% and use THAT as the max), Rate of Fire (affects how fast you can lay off singular shots or bursts etc, same principal but affects every weapon differently), Reload Speed (affects how fast you reload. Current animation speeds should be the target for middle ground), and Capacity (Affects ammo capacity, different per gun, with all the current ammo capacities being the middle ground of upgrades). Knives exclusively get a different selection, offering Damage (maxed out is an instant kill on humans) and durability.
  Remove all ammo from the shop; the player should not be able to buy ammo. Sell gunpowder instead. 
  Red laser sight attachment should detect humans/infected. it phases through them currently. Red laser sight should also be given to the starting kit for the player, already attached to the starting pistol.
  Default controls should be remapped so that LCTRL controls positioning (standing, crouch, prone), 
  The entire vehicle engine regarding animations should be overhauled and polished, so that way if a player pressed a button mid-opening door animation, it won't play the get in animation so they can cancel it. Animations should also be much more procedural and simulated.
  The animation system should be entirely overhauled to be able to handle dynamic, polished animations on the fly. The stress test for this should be human aiming of weapons to appear way more natural, along with their body positioning and transitional animations.
  Human AI needs to be polished to behave way more convincingly
  Infected walk animation needs to be tweaked and polished
  When the Tyrant punches anything, they should be flown back about 6 feet, not into the air.
  A pump-12 shotgun next to 12 shotgun shells should always spawn in the halloran mansion on the second floor in a room, make it a logical location.
  The police station as listed doesn't actually exist. Which is fine, since we needed to make one anyway. I found what appears to be the psych hospital, keep that. The police station should be nearly 1:1 with resident evil 2's layout but in our design format, rooms must have cielings of at list 4 blocks or higher and hallways must never be 1x1 wide, always atleast two blocks of pathing. Take multiple reference photos of the exterior and interior as you build so you can iterate on it, score each photo out of 20, and do not approve it and move on until all photos are atleast a 19/20. Do not settle for less, this is important. A desert eagle and full box of ammo should spawn in a room in there.
  The red-light texture used at X610, Y33, Z379 should be removed for an actual object instead of a voxel block, all light sources should be objects and not blocks.
  All smoke must go through the Astratto Engine and look like real smoke.
  Human AI should scale with difficulty, Easy means they miss 50% of the shots they take, Normal means they miss 25% of the shots they take, and Hardcore means they miss 10%.
  Devmode should allow the user to pickup and move NPC's, entities, objects, ETC while in the devmode.
  Allow sprint to slide when sprinting for more than .5 seconds.
  When driving vehicles, if the vehicle is driving AT ANY SPEED, the player should be able to press the enter/exit button and it should open the vehicle door if it's still attached and showcase the player dynamically jumping out of the vehicle, and allowing sydney to handle the actual radgoll.
  When players/npc's grab onto a ledge to pull themselves up, it should actually be broken into 2 phases to allow the character/npc to actually stay held onto the ledge and sydney can handle the dangling of the legs while they are holding on. Pressing the jump button should continue and let them pull themselves onto the ledge, and pressing the button assigned to open doors should let them drop from the ledge. Keep this baked into the Sydney or Astratto engine.
  Fall animations should be present, polished, and dynamic. Sydney should ragdoll the NPC/Player if falling for more than 3 seconds AND ALSO play a small kicking/falling animation.
  The Med Cabinet texture should be redone completely and polished to look like an actual voxel med cabinet.
  The Tool Box texture should be redone entirely to be an actual tool box.
  All objects/blocks that let the player open them should be converted into an object form to allow for dynamic animations. Animations should show the players hand actually interacting with the container and the container opening/closing while in the screen. Make sure to ensure the new models won't conflict with where they currently exist in the world in many interiors.
  Humans/entities/NPCs/infected should all cast a shadow from vehicle lights.
  All special infected should carry at least 1 jewelry item, and randomize it so theres always a chance for valuable loot.
  The leaderboard in the deployment screen should be redone to be more visually appealing, and only include the top 20 on the leaderboard (always show players position, but if they're outside the top 20 put that at the very bottom after the 20th place with their actual spot listed instead of 21) with their #, Name (their rank should be the ranks insignia put next to their name, do the same for the players profile card by placing the insignia next to the name and rank name somewhere neat, and display the faction they belong too next to their name, not in its own tab), kills and standins
  All of the profile card background should be high-quality vectors and not ASCII looking art.
  The Astratto-Engine logo once again needs to be changed, A very aestheticaly pleasing ASCII art of the moons silhouette with an "A" in it.
  When putting wooden planks to board up windows, that texture that is used should be replaced to be a genuine boarded up plank placed over the hole. Make this work well.

Things to add:
  A horde feature, so that way infected actually have hotspots they get attracted to so that way no matter where they spawn within a district, the infected will have atleast some objective (some should still just roam and shuffle around). Gunshots and gunfire should actually attract infected to the place where the audio is originating, aswell as when there is more than six zombies per ally/friendly npc, an NPC will genuinely run away. If we already have this feature, make sure that it works.

  Animals; make sure these are properly rigged and implemented
    The Animal AI should be created using NerualAI. Each animal should have Unique AI. Crows should stay still and only fly away when the player gets within 3 block distance, and dogs should be able to have owners (NPC's it's attached to and protects/follows). Dogs can be an unlocked purchaseble in the shop after rank 10. Animals to add:
    Dog - A white husky, in px head is 6×6×4, body is 6×9×6, shoulder/mane section is 8×6×7, each leg is 2×8×2, tail is 2×8×2, muzzle is 3×3×4 and each ear is 2×2×1. Can actually make dog sounds (download HQ ones) depending on it's context.
    Crow - A small black crow, in px head is 3×3×3, body is 4×5x6, each wing is 1×4×6, each leg is 1×3×1, tail is 3×1×5 and beak is 1×1×3. Can actually make crow sounds (download HQ ones). Crows contain loot, and have a 75% chance of dropping something. They can drop cash, grenades (all types), gunpowder (all types), and ammo directly.
    Bat - A small black bat that flies around and squeeks occassionaly. In px Head is 4×3×2, Body is 3×5×2 and Each wing: inner 2×7×0, outer 6×8×0. When killed it has a small chance to drop any type of gunpowder or ammo.
    Chicken - A white classical chicken. In px Head is 4×6×3, body is 6×8×6 and Each leg: 3×5×3. Can drop 3 types of eggs; Brown White and Golden, each a new item that can be sold in the shop but not bought, and each can be eaten by the player for health.
    Spider - A giant spider. In px head is 8×8×8, Each leg is 16×2×2, it's middle section is 6×6×6 and it's abdomen is 10×8×12.

  New Infected:
    Infected Dog - Black version of the husky, is infected and barks evilly. Roams around just like an infected but is faster than a sprinting infected and runs with its mouth open, revealing sharp teeth. Can bite off limbs like arms but not the head. Infected dogs normally spawn in packs of no less than 2 and no more than six, and infected dogs are only loyal to the pack they spawned with, not every infected or other infected dog. Chases and jumps at to bite at close range.
    Spider - A furry, large mutated spider. Three attacks: short-range thrust, body blow/tackle, and venom spit (same function as spewer spit but make it blackish) at medium range. They can crawl on walls and ceilings, including attacking from above. Some dead spiders have a chance to release baby spiders, which jump at non-infected for small amounts of damage.

  Punching:
    When the player has nothing equipped, they should be able to pull off a three punch combo dynamically and other NPC's should react to the punches realistically through Sydney. The player should also be able to unequip their current weapon by selecting an empty slot in their quick menu. The punch should always start with the right hand, the combos should only happen if performing successive punches in a row, the second punch is a left hand, and the final punch is an even stronger right hand. After this three-piece combo, the player should have to wait 2-3 seconds before punching again, and each punch costs staming. Implement the dynamic contextual animations and ragdolls through Sydney.

  Inventory Discard:
    Add a 9x6 style attache menu in the inventory that contextually appears when an item is being rotated or moved, and stays when an item is placed in it and doesn't appear when the player isnt moving or rotating something. This is to allow the player to discard/drop multiple things at once.

Things to overhaul:
  When any NPC dies and they have loot on them, besides the player, display a non-distracting, visually appealing light beam that stems from the corpse and the beams color should reflect the highest ranked item by loot category (e.g white beam for highest item being a common)
  The games HUD needs to be redesigned and professionalized, shouldn't look poor. Inspect it and review 3 screenshots of it, and iterate until you reach a score of at least 8/10, with the current HUD being a 1/10. Break up the bottom-right dashboard. Keep weapon, ammo, and your health arc together. Move stamina/focus to bottom-left. Show food/water there only when low, changing, or manually requested. Make ammunition the strongest text element. At 1080p, use a 36–40 px loaded count, 18–20 px reserve count, and 14–16 px fire-mode label. Keep CHAMBER / TOTAL, but make the number thats actually in the chamber unmistakable and a slighly different color, the chambered being full white and ammo being grey. No ammo should be red. Simplify health. Keep the arc, replace 100 / 100 with an actual visually dynamic hospital styled reader. Show injury warnings through an icon/text cue as well as color. Remove the large rectangular backing and long divider. Use small localized dark gradients behind information, subtle text shadows, and consistent thin strokes. Preserve contrast against bright concrete and dark interiors. Replace the tiny pixel lettering. Use one clean sans-serif family with tabular numerals. Start at 16 px for readable labels at 1080p. Keep pixel art in item silhouettes (the gun models themselves); avoid making essential text look like debug output. Quiet the minimap. Desaturate its beige background, reduce terrain contrast, and emphasize the player arrow and active objective. Thin the frame. Keep the location label. Don’t add a compass. Hide the persistent Private 1 / 36% panel during ordinary play. Reveal rank progress after kills only for approximately 3 seconds, every other form of XP gain shouldn't show how close the player is to the next level during gameplay. Align the kill feed beneath that notification area instead of leaving it midway down the left edge. Add controlled visibility. Fade inactive survival indicators after 3 seconds, using a 200 ms transition. Keep critical warnings visible. Offer “Always show HUD,” HUD scale, and safe-area settings.
  Engine/overall architecture (new java/c++ split)

Things to Polish:
  Procedural and contextual animation
  The faction system needs polish, look over it.
  NeuralAI needs to be polished so that Human AI actually implement and use tactics, E.G surrounding the player on multiple sides, blocking off exits to interiors if they suspect a player is in there so one member of an NPC team will wait by a door while the other searches the building ETC.
  Doors physically interacting with bodies should be more realistic and pleasing.
  Infected need to have a contextual dynamic animation for crawling through windows.
  NPC pathfinding on the map and in interiors needs to be refined. This is important.
  Aggressively optimize.

Side objective:
  Seperate and help prepare for the creation of the Astratto Engine. Perserve all the value of everything already built as is while producing a genuine engine that future Astratto games can use independently, taking all underlying technology and move it to the Astratto Engine to be handled more efficiently. We need to turn the technology behind Absentialis into a proper, reusable Astratto Engine, preserving everything that can serve future games. Audit every system, tool, shader, and asset pipeline. Move reusable capabilities into Astratto. Preserve their functionality, quality, and accumulated work even where implementation must be rewritten. Document anything proposed for retirement and why. Establish a hard Java/C++ boundary:
   - C++ owns engine execution: world state, resource management, rendering, physics and physical animation through Sydney, NeuralAI’s perception/pathfinding/planning execution, and UltraEngine’s audio processing. GPU shaders remain shader code managed by the renderer.
   - Java owns gameplay and authoring: game rules, inventory behavior, HUD composition, missions, character goals, AI policies, and editor workflows. Java configures and requests engine services; C++ executes them.
   - One documented bridge connects them: a versioned C-compatible API with Java bindings, batched commands, events, and read-only state snapshots. C++ owns native memory and authoritative simulation state. No duplicated simulation, per-object cross-language calls, or Java callbacks inside rendering, physics, or audio processing loops.
  Separate engine capability from game content. Astratto provides reusable UI, devmode, directormode, developer console, persistence, simulation, engines such as Sydney, UltraEngine and NeuralAI and AI services. Absentialis supplies its specific interfaces, items, rules, behaviors, and content. The engine must build and run without depending on Absentialis. Restructure whatever is necessary. Refactor individual systems or rebuild substantial portions of the game where required to achieve this architecture. Preserve working behavior and migrate in verified stages; retaining existing code must not compromise the boundary.

### Special Instructions:
  Update the CHANGELOG.md when finished to succinctly explain every minor and major addition you made to create version 1.1 added follow the format of the previous changelog entries. Dont remove previous entries, add to it.
