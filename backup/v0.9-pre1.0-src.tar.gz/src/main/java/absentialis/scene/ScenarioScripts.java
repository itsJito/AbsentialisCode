package absentialis.scene;

import static absentialis.scene.Scenarios.*;

import absentialis.persistence.Profile;

/**
 * The scripts {@link Scenarios} can run. Each is a short, named sequence built for one thing that has to be looked
 * at: a screen, a pose, a room. Add one here when a change needs eyes on it.
 */
final class ScenarioScripts {
    private ScenarioScripts() {}

    /** Leave the allegiance question unanswered (to photograph it). */
    static boolean keepUnaligned;

    static void build(String name) {
        switch (name == null ? "" : name) {
            case "shop" -> shop();
            case "menus" -> menus();
            case "shop_user" -> shopUser();
            case "specials" -> specials();
            case "falls" -> falls();
            case "car" -> car();
            case "interiors" -> interiors();
            case "devmap" -> devmap();
            case "glass" -> glass();
            case "poses" -> poses();
            case "devmode" -> devmode();
            case "director" -> director();
            case "landmarks" -> landmarks();
            case "v09" -> v09();
            case "gear" -> gear();
            default -> System.out.println("[Scenario] unknown scenario '" + name + "'");
        }
    }

    /** Buying a weapon and seeing it in the stash without reloading the profile (the 0.6 report). */
    private static void shop() {
        profile(p -> p.scrip = 200000);
        hideout(6, h -> h.hideout().tab = HideoutScreen.TAB_INVENTORY);
        hideout(16, h -> shot(h, "shop_00_stash_before"));
        hideout(18, h -> h.hideout().debugShow(0, false));
        hideout(28, h -> shot(h, "shop_01_weapons"));
        hideout(30, h -> { h.hideout().debugBuy("weapon.pm9"); h.console("give weapon.matilda"); });
        hideout(40, h -> shot(h, "shop_02_after_buy"));
        hideout(42, h -> h.hideout().tab = HideoutScreen.TAB_INVENTORY);
        hideout(52, h -> shot(h, "shop_03_stash_after"));
        hideout(54, h -> { Profile p = h.ctx().profile; StringBuilder b = new StringBuilder(); for (var i : p.stash.items) b.append(i.defId).append('@').append(i.x).append(',').append(i.y).append(' '); System.out.println("[Scenario] stash: " + b); });
    }

    /** The same purchase against a profile already in the scratch save directory as slot 3 (a copy of a real one). */
    private static void shopUser() {
        hideout(6, h -> { h.ctx().profile.scrip += 200000; h.hideout().tab = HideoutScreen.TAB_INVENTORY; });
        hideout(16, h -> shot(h, "user_00_stash_before"));
        hideout(18, h -> h.hideout().debugShow(0, false));
        hideout(30, h -> { h.hideout().debugBuy("weapon.pm9"); h.console("give weapon.matilda"); });
        hideout(42, h -> h.hideout().tab = HideoutScreen.TAB_INVENTORY);
        hideout(52, h -> shot(h, "user_01_stash_after"));
        hideout(54, h -> { Profile p = h.ctx().profile; StringBuilder b = new StringBuilder(); for (var i : p.stash.items) b.append(i.defId).append('@').append(i.x).append(',').append(i.y).append(i.rotated ? "r " : " "); System.out.println("[Scenario] stash " + p.stash.w + "x" + p.stash.h + ": " + b + " verify=" + p.verify()); });
    }

    private static final String[] CAST = {"walker", "sprinter", "bomber", "spewer", "tank", "gladiator", "butcher"};
    private static final absentialis.entity.Actor[] cast = new absentialis.entity.Actor[CAST.length];
    private static float cx, cy, cz;

    /** The infected, stood in a row in daylight and walked round: every special's model, front, side and back. */
    private static void specials() {
        profile(null);
        raid(20, h -> {
            Raid r = h.raid().raid;
            r.god = true; r.populate = false; r.freezeAI = true;
            r.actors.removeIf(a -> !a.isPlayer);
            cx = r.player.x; cy = r.player.y; cz = r.player.z;
            for (int i = 0; i < CAST.length; i++) {
                cast[i] = r.debugSpawn(CAST[i], cx + (i - 3) * 2.4f, cz - 7, cy);
                cast[i].yaw = (float) Math.PI;
                cast[i].homeX = cast[i].x; cast[i].homeZ = cast[i].z;
            }
            place(r, cx, cy, cz + 1.5f, 0, -0.02f);
        });
        raid(50, h -> shot(h, "spec_00_row"));
        int f = 54;
        for (int i = 2; i < CAST.length; i++) {
            final int k = i;
            raid(f, h -> place(h.raid().raid, cast[k].x, cast[k].y, cast[k].z + (k == 4 ? 4.2f : 3.0f), 0, k == 4 ? 0.12f : 0.02f));
            raid(f + 12, h -> shot(h, "spec_" + k + "0_" + CAST[k] + "_front"));
            raid(f + 14, h -> place(h.raid().raid, cast[k].x + (k == 4 ? 4.2f : 3.0f), cast[k].y, cast[k].z, (float) Math.PI / 2, k == 4 ? 0.12f : 0.02f));
            raid(f + 26, h -> shot(h, "spec_" + k + "1_" + CAST[k] + "_side"));
            raid(f + 28, h -> place(h.raid().raid, cast[k].x, cast[k].y, cast[k].z - (k == 4 ? 4.2f : 3.0f), (float) Math.PI, k == 4 ? 0.12f : 0.02f));
            raid(f + 40, h -> shot(h, "spec_" + k + "2_" + CAST[k] + "_back"));
            f += 42;
        }
        // bile: what it does to the picture
        raid(f, h -> { Raid r = h.raid().raid; place(r, cx, cy, cz + 1.5f, 0, -0.02f); r.bile(r.player, 15); });
        raid(f + 30, h -> shot(h, "spec_90_biled"));
    }

    private static absentialis.entity.Actor subject;
    private static float sx, sy, sz;

    /** A hit, by name, on the subject standing at the mark. The blow travels +x (left to right across the picture). */
    private static void strike(Raid r, String what) {
        absentialis.entity.Actor from = new absentialis.entity.Actor();
        from.x = sx - 12; from.y = sy; from.z = sz; from.faction = "raiders"; from.archetype = "rifleman";
        absentialis.entity.Actor v = subject;
        switch (what) {
            case "chest" -> r.damageActor(v, from, 9999, absentialis.gameplay.items.Content.def("ammo.556"), "torso", v.x, v.y + 1.25f, v.z);
            case "head_from_behind" -> r.damageActor(v, from, 9999, absentialis.gameplay.items.Content.def("ammo.556"), "head", v.x, v.y + 1.68f, v.z);
            case "leg" -> r.damageActor(v, from, 9999, absentialis.gameplay.items.Content.def("ammo.556"), "legs", v.x, v.y + 0.5f, v.z);
            case "buckshot" -> { r.hitKind = ""; v.hitForce = 160; r.damageActor(v, from, 9999, absentialis.gameplay.items.Content.def("ammo.shells"), "torso", v.x, v.y + 1.2f, v.z); }
            case "running" -> { v.vx = 5.2f; v.pvx = 5.2f; r.damageActor(v, from, 9999, absentialis.gameplay.items.Content.def("ammo.556"), "torso", v.x, v.y + 1.25f, v.z); }
            case "blast" -> r.explode(sx - 2.6f, sy + 0.3f, sz, 6, 400, 0, false);
            case "shove" -> r.gore.ragdolls.knockDown(v, 1, 0, 95, 2.2f);
            case "shove_back" -> r.gore.ragdolls.knockDown(v, 1, 0, 95, 2.2f);
            default -> { }
        }
    }

    /**
     * The fall study (instructions.md, Sydney Engine touching up): one body after another is hit in a named way in
     * front of a fixed camera and photographed every third frame, and each run is tiled into a contact sheet.
     * {cast, facing yaw, the hit, frames to film}. Facing pi/2 looks at the shooter (-x); -pi/2 has its back to it.
     */
    private static final Object[][] FALLS = {
            {"survivors", 1.5708f, "chest", 132}, {"survivors", -1.5708f, "head_from_behind", 132}, {"military", 1.5708f, "leg", 132}, {"raiders", 3.1416f, "buckshot", 132},
            {"survivors", -1.5708f, "running", 132}, {"military", 1.5708f, "blast", 132}, {"survivors", 1.5708f, "shove", 330}, {"mercenaries", -1.5708f, "shove_back", 330},
            {"walker", 1.5708f, "chest", 132}, {"walker", 1.5708f, "shove", 330}};

    private static void falls() {
        profile(null);
        raid(20, h -> {
            Raid r = h.raid().raid;
            r.god = true; r.populate = false; r.freezeAI = true;
            r.actors.removeIf(a -> !a.isPlayer);
            sx = r.player.x; sy = r.player.y; sz = r.player.z - 3.0f;
            place(r, sx + 0.8f, sy, sz + 3.0f, 0, -0.16f);
        });
        int f = 30;
        for (int k = 0; k < FALLS.length; k++) {
            final int n = k;
            final Object[] e = FALLS[k];
            final int frames = (Integer) e[3] > 200 ? 360 : 96, every = frames > 200 ? 15 : 4;
            raid(f, h -> {
                Raid r = h.raid().raid;
                r.actors.removeIf(a -> !a.isPlayer);
                subject = r.debugSpawn((String) e[0], sx, sz, sy);
                subject.yaw = (Float) e[1]; subject.hostileToPlayer = false; subject.homeX = sx; subject.homeZ = sz;
                place(r, sx + 0.8f, sy, sz + 3.0f, 0, -0.16f);
            });
            raid(f + 24, h -> strike(h.raid().raid, (String) e[2]));
            final String name = String.format("fall_%02d_%s_%s", n, e[0], e[2]);
            for (int i = 0; i * every < frames; i++) { final int idx = i; raid(f + 24 + i * every, h -> shot(h, String.format("%s_%03d", name, idx))); }
            raid(f + 24 + frames + 2, h -> sheet(name, 8, 300, 120, 1000, 700, 0.25f));
            f += 24 + frames + 6;
        }
    }

    /** Getting into a car and out of it again, in third person, photographed every fourth frame (the door should lead the body both ways). */
    private static void car() {
        profile(null);
        raid(20, h -> {
            Raid r = h.raid().raid;
            r.god = true; r.populate = false; r.freezeAI = true;
            r.actors.removeIf(a -> !a.isPlayer);
            h.raid().thirdPerson = true;
            h.console("vehicle car.volna");
        });
        raid(60, h -> {
            Raid r = h.raid().raid;
            if (r.vehicles.cars.isEmpty()) { System.out.println("[Scenario] no car"); return; }
            VehicleSystem.Car c = r.vehicles.cars.get(r.vehicles.cars.size() - 1);
            float[] o = new float[3];
            c.sim.origin(o);
            // stand off the driver's side, a few steps from the door
            place(r, o[0] - c.sim.body.rightX() * 2.1f - c.sim.body.fwdX() * 1.2f, r.player.y, o[2] - c.sim.body.rightZ() * 2.1f - c.sim.body.fwdZ() * 1.2f, (float) Math.atan2(c.sim.body.rightX(), c.sim.body.rightZ()), -0.1f);
        });
        raid(90, h -> { boolean ok = h.raid().raid.vehicles.enter(); System.out.println("[Scenario] enter " + ok); });
        for (int i = 0; i < 28; i++) { final int idx = i; raid(90 + i * 4, h -> { shot(h, String.format("car_enter_%03d", idx)); System.out.println(String.format("[Scenario] enter frame %d: progress %.2f door %.2f", idx, h.raid().raid.vehicles.phaseProgress(), h.raid().raid.vehicles.doorOpen())); }); }
        raid(206, h -> sheet("car_enter", 7, 250, 150, 1100, 650, 0.26f));
        // 0.8: the driver in the seat, looked at through the glass from the driver's side, from in front and from the far side
        float[] look = {2.25f, 3.1416f, -2.2f, 1.5708f};
        for (int i = 0; i < look.length; i++) {
            final int k = i;
            raid(210 + i * 16, h -> { Raid r = h.raid().raid; if (r.vehicles.driving != null) { r.player.yaw = VehicleSystem.playerYawOf(r.vehicles.driving.sim) + look[k]; r.player.pitch = -0.20f; } });
            raid(222 + i * 16, h -> { shot(h, "car_drive_" + k); Raid r = h.raid().raid; System.out.println("[Scenario] driver seated " + r.player.seated + " at the wheel " + r.player.atWheel + " seatW " + (r.player.anim == null ? -1 : r.player.anim.seatW) + " speed " + (r.player.anim == null ? -1 : r.player.anim.speed)); });
        }
        raid(280, h -> System.out.println("[Scenario] exit " + h.raid().raid.vehicles.exit()));
        for (int i = 0; i < 28; i++) { final int idx = i; raid(280 + i * 4, h -> { shot(h, String.format("car_exit_%03d", idx)); System.out.println(String.format("[Scenario] exit frame %d: progress %.2f door %.2f edge %.2f", idx, h.raid().raid.vehicles.phaseProgress(), h.raid().raid.vehicles.doorOpen(), h.raid().raid.vehicles.cars.get(0).visual.doorEdgeX())); }); }
        raid(396, h -> sheet("car_exit", 7, 250, 150, 1100, 650, 0.26f));
    }

    private static final java.util.List<Object[]> ROOMS = new java.util.ArrayList<>();

    /**
     * The interior survey (instructions.md rule 10): one room of every kind in every kind of building, photographed
     * from a corner at eye height looking across it, by day. ABS_ROOMS limits how many (default 60); ABS_ROOM_FILTER
     * keeps only rooms whose "archetype/type" contains the text. Each picture is named for what it shows.
     */
    private static void interiors() {
        profile(null);
        final int max = System.getenv("ABS_ROOMS") != null ? Integer.parseInt(System.getenv("ABS_ROOMS")) : 60;
        final String filter = System.getenv("ABS_ROOM_FILTER");
        raid(20, h -> {
            Raid r = h.raid().raid;
            r.god = true; r.populate = false; r.freezeAI = true;
            r.actors.removeIf(a -> !a.isPlayer);
            java.util.Set<String> seen = new java.util.LinkedHashSet<>();
            for (absentialis.world.MapData.Building b : r.world.map.buildings) for (absentialis.world.MapData.Room rm : b.rooms) {
                String key = (b.landmark.isEmpty() ? b.archetype : b.landmark) + "/" + rm.type;
                if (rm.circulation && !key.contains("hall") || (rm.x1 - rm.x0) < 2 || (rm.z1 - rm.z0) < 2) continue;
                if (filter != null) { boolean hit = false; for (String part : filter.split(",")) hit |= key.endsWith(part) || key.contains(part + "/"); if (!hit) continue; }
                if (!seen.add(System.getenv("ABS_ROOM_ONE") != null ? rm.type : key) || ROOMS.size() >= max) continue;
                ROOMS.add(new Object[]{key.replace('/', '_').replace(' ', '_'), rm, b});
            }
            System.out.println("[Scenario] interiors: " + ROOMS.size() + " rooms of " + seen.size() + " kinds");
        });
        for (int k = 0; k < max; k++) {
            final int n = k;
            raid(30 + k * 170, h -> {
                if (n >= ROOMS.size()) return;
                Raid r = h.raid().raid;
                absentialis.world.MapData.Room rm = (absentialis.world.MapData.Room) ROOMS.get(n)[1];
                // stand in the free corner cell furthest from the middle that has room to stand, and look at the middle
                float cx = (rm.x0 + rm.x1 + 1) / 2f, cz = (rm.z0 + rm.z1 + 1) / 2f, bx = cx, bz = cz, bd = -1;
                for (int x = rm.x0; x <= rm.x1; x++) for (int z = rm.z0; z <= rm.z1; z++) {
                    if (r.world.solid(x, rm.y + 1, z) || r.world.solid(x, rm.y + 2, z) || !r.world.solid(x, rm.y, z)) continue;
                    float d = (x + 0.5f - cx) * (x + 0.5f - cx) + (z + 0.5f - cz) * (z + 0.5f - cz);
                    if (d > bd) { bd = d; bx = x + 0.5f; bz = z + 0.5f; }
                }
                place(r, bx, rm.y + 1, bz, (float) Math.atan2(-(cx - bx), -(cz - bz)), -0.18f);
                h.raid().thirdPerson = false;
            });
            raid(30 + k * 170 + 164, h -> { if (n < ROOMS.size()) shot(h, String.format("room_%02d_%s", n, ROOMS.get(n)[0])); });
        }
    }

    /** The devmap, loaded the way a developer loads it (the console), and looked at from each of its four parts. */
    private static void devmap() {
        profile(null);
        for (int f = 8; f < 3000; f += 30) hideout(f, h -> { if (absentialis.world.gen.DevMap.mansion == null && h.worldReady()) h.console("devmap 0"); });
        raid(60, h -> { Raid r = h.raid().raid; r.god = true; place(r, absentialis.world.gen.DevMap.ROAD_X0 + 4, g(), (absentialis.world.gen.DevMap.ROAD_Z0 + absentialis.world.gen.DevMap.ROAD_Z1) / 2f + 0.5f, -1.5708f, -0.03f); });
        raid(150, h -> shot(h, "dev_00_road"));
        raid(152, h -> place(h.raid().raid, absentialis.world.gen.DevMap.mazeInX + 1, g(), absentialis.world.gen.DevMap.mazeInZ - 7, 3.1416f, -0.02f));
        raid(240, h -> shot(h, "dev_01_maze"));
        raid(242, h -> place(h.raid().raid, absentialis.world.gen.DevMap.mansion.entryX + 0.5f, g(), absentialis.world.gen.DevMap.mansion.entryZ - 9, 3.1416f, 0.12f));
        raid(330, h -> shot(h, "dev_02_mansion"));
        raid(332, h -> place(h.raid().raid, absentialis.world.gen.DevMap.YARD_X + 2, g(), absentialis.world.gen.DevMap.YARD_Z + 12, -1.35f, -0.05f));
        raid(420, h -> shot(h, "dev_03_yard"));
        raid(422, h -> place(h.raid().raid, absentialis.world.gen.DevMap.holesX + 8, g(), absentialis.world.gen.DevMap.holesZ + 7, 0f, 0.15f));
        raid(510, h -> shot(h, "dev_04_openings"));
    }

    /**
     * 0.8, Developer Mode on the devmap: the status bar and the inspector over a Gladiator and a Butcher that do not
     * know the camera is there, then the workbench open on each of its pages - and a laser, a stance icon and the
     * third-person reticle while the survivor is still a survivor.
     */
    private static void devmode() {
        profile(p -> { p.prog.addXp(absentialis.gameplay.progression.Progression.xpToReach(12)); });
        for (int f = 8; f < 3000; f += 30) hideout(f, h -> { if (absentialis.world.gen.DevMap.mansion == null && h.worldReady()) h.console("devmap 0"); });
        float rx = absentialis.world.gen.DevMap.ROAD_X0 + 6, rz = (absentialis.world.gen.DevMap.ROAD_Z0 + absentialis.world.gen.DevMap.ROAD_Z1) / 2f + 0.5f;
        raid(60, h -> { Raid r = h.raid().raid; r.god = true; place(r, rx, g(), rz, -1.5708f, -0.03f); var rifle = new absentialis.gameplay.items.ItemInstance("weapon.akr"); rifle.rounds = rifle.capacity(); rifle.ammoId = "ammo.assault"; absentialis.gameplay.inventory.InventoryService.equip(rifle, h.ctx().profile.loadout, "primary"); });
        raid(70, h -> h.raid().scenarioHold("primary"));
        // the survivor first: third person, aiming, with and without a laser
        raid(90, h -> { h.raid().thirdPerson = true; h.raid().scenarioAim = true; });
        raid(150, h -> shot(h, "devui_00_thirdperson_reticle"));
        raid(152, h -> { var gun = h.ctx().profile.loadout.slot("primary"); if (gun != null) absentialis.gameplay.weapons.Gunsmith.install(gun, "att.laser.5mw"); h.raid().raid.profile.zone.hour = 22; });
        raid(230, h -> shot(h, "devui_01_green_laser_night"));
        raid(232, h -> { h.raid().thirdPerson = false; });
        raid(290, h -> shot(h, "devui_02_laser_first_person"));
        raid(292, h -> { h.raid().scenarioAim = false; h.raid().raid.profile.zone.hour = 13; h.raid().raid.player.crouch = true; });
        raid(310, h -> shot(h, "devui_03_stance_icon"));
        raid(312, h -> { h.raid().raid.player.crouch = false; h.console("devmode"); });
        raid(330, h -> { Raid r = h.raid().raid; r.player.x = rx; r.player.z = rz; r.player.y = g() + 3.2f; r.player.yaw = -1.5708f; r.player.pitch = -0.32f; h.raid().dev.aimNow(); h.raid().dev.count = 1; h.raid().dev.frozen = false; });
        raid(334, h -> { DevMode d = h.raid().dev; d.target[0] = rx + 9; d.target[1] = g(); d.target[2] = rz - 2; d.spawnNpc("gladiator"); d.target[0] = rx + 11; d.target[2] = rz + 2.5f; d.spawnNpc("butcher"); d.target[0] = rx + 7; d.target[2] = rz + 5; d.spawnNpc("raiders"); });
        raid(520, h -> shot(h, "devui_04_ghost_inspector"));
        for (int t = 0; t < 5; t++) { final int tab = t; raid(524 + t * 40, h -> { h.raid().dev.panel = true; h.raid().dev.tab = tab; }); raid(556 + t * 40, h -> shot(h, "devui_1" + tab + "_workbench_" + DevMode.TABS[tab].toLowerCase())); }
        raid(730, h -> { h.raid().dev.panel = false; h.console("devmode"); });
        raid(760, h -> shot(h, "devui_20_back_as_survivor"));
    }

    /**
     * 0.9 in the city, as it is played: a knife and somebody's back (the prompt, the takedown, the notice), what is found on
     * the body (its equipment in equipment slots), a ledge pulled up onto, the field map zoomed out past the edge of the
     * sheet, and the district's hotspot said and marked.
     */
    private static void v09() {
        profile(null);
        Scenarios.hour = 13;
        final int F = org.lwjgl.glfw.GLFW.GLFW_KEY_F;
        raid(30, h -> { Raid r = h.raid().raid; r.god = true; r.populate = false; h.console("weather clear");
            for (absentialis.entity.Actor a : new java.util.ArrayList<>(r.actors)) if (!a.isPlayer) r.actors.remove(a);
            var knife = new absentialis.gameplay.items.ItemInstance("melee.knife");
            absentialis.gameplay.inventory.InventoryService.equip(knife, h.ctx().profile.loadout, "melee"); });
        raid(40, h -> { Raid r = h.raid().raid; absentialis.entity.Actor p = r.player;
            float fx = (float) -Math.sin(p.yaw), fz = (float) -Math.cos(p.yaw);
            float[] s = r.standSpot(p.x + fx * 1.5f, p.z + fz * 1.5f);
            v09Guard = r.debugSpawn("military", s[0], s[2], s[1]);
            v09Guard.hostileToPlayer = true; v09Guard.yaw = p.yaw; v09Guard.homeX = s[0]; v09Guard.homeZ = s[2]; r.freezeAI = true;
            p.crouch = true; p.pitch = -0.15f; p.yaw = (float) Math.atan2(-(s[0] - p.x), -(s[2] - p.z)); });
        raid(70, h -> { shot(h, "v09_00_takedown_prompt"); System.out.println("[Scenario] takedown on offer: " + (h.raid().raid.takedownTarget() != null) + " " + h.raid().raid.takedownWhy); });
        raid(72, h -> System.out.println("[Scenario] takedown started: " + h.raid().raid.startTakedown()));
        raid(110, h -> shot(h, "v09_01_takedown"));
        raid(200, h -> { Raid r = h.raid().raid; System.out.println("[Scenario] guard dead " + v09Guard.dead + ", stealth kills " + r.debrief.stealthKills + ", seen " + r.takedownsSeen + ", gear slots filled " + (v09Guard.corpseGear == null ? -1 : v09Guard.corpseGear.slots.values().stream().filter(x -> x != null).count()));
            absentialis.entity.Actor p = r.player; p.pitch = -0.9f; p.yaw = (float) Math.atan2(-(v09Guard.x - p.x), -(v09Guard.z - p.z)); });
        raid(260, h -> { shot(h, "v09_02_body"); h.ctx().in.inject(F, true); });
        raid(262, h -> h.ctx().in.inject(F, false));
        raid(300, h -> shot(h, "v09_03_searching_the_body"));
        raid(302, h -> { h.ctx().in.inject(org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE, true); });
        raid(304, h -> { h.ctx().in.inject(org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE, false); });
        // the hotspot of the district, brought on and marked; the map zoomed right out
        raid(320, h -> { h.console("hotspot go"); h.console("hotspot"); });
        raid(330, h -> { h.raid().debugMap(true, 0.6f); });
        raid(360, h -> shot(h, "v09_04_map_zoomed_out"));
        raid(362, h -> h.raid().debugMap(false, 1f));
        raid(380, h -> { Raid r = h.raid().raid; System.out.println("[Scenario] hotspots: " + r.events.hotspots.size() + ", announced " + r.events.announced + ", activated " + r.events.activated + ", mantles " + r.mantles); });
    }
    private static absentialis.entity.Actor v09Guard;

    /**
     * 0.9, the two hand-drawn landmarks - the power station as the Chernobyl plant, the big house as the Spencer mansion -
     * from outside and in their rooms. Each picture is taken after the light has had time to settle where the camera was
     * put (the GI probes take a couple of seconds). ABS_LANDMARK=plant or mansion takes only that one's pictures.
     */
    private static void landmarks() {
        profile(null);
        Scenarios.hour = 13;
        String only = System.getenv("ABS_LANDMARK") == null ? "" : System.getenv("ABS_LANDMARK");
        raid(30, h -> { Raid r = h.raid().raid; r.god = true; r.noclip = true; r.freezeAI = true; r.populate = false; h.raid().hudHidden = true; h.raid().photo = true; h.console("weather clear"); h.console("time 13");
            for (absentialis.entity.Actor a : new java.util.ArrayList<>(r.actors)) if (!a.isPlayer) r.actors.remove(a); });
        final int L1 = 6, F1 = 7;
        // {landmark, name, from a, b, y (above the street), look at a, b, y}
        Object[][] shots = {
                {"power_plant", "plant_00_front", 66f, -46f, 30f, 66f, 34f, 12f},
                {"power_plant", "plant_01_sarcophagus", 126f, -16f, 24f, 82f, 30f, 16f},
                {"power_plant", "plant_02_from_the_admin_end", -22f, -8f, 22f, 44f, 36f, 12f},
                {"power_plant", "plant_03_turbine_hall", 10f, 57f, 8f, 80f, 63f, 2f},
                {"power_plant", "plant_04_golden_corridor", 34f, 46.9f, L1 + 1.7f, 97f, 46.9f, L1 + 1.6f},
                {"power_plant", "plant_05_control_room_4", 72f, 49.4f, L1 + 3.2f, 94f, 52f, L1 + 0.8f},
                {"power_plant", "plant_06_reactor_hall_3", 35f, 21f, L1 + 11f, 46f, 32f, L1 + 1f},
                {"power_plant", "plant_07_unit_4", 71f, 21f, L1 + 10f, 85f, 33f, L1 + 0.5f},
                {"power_plant", "plant_08_long_corridor", 31.9f, 13f, L1 + 1.7f, 31.9f, 44f, L1 + 1.6f},
                {"mansion", "mansion_00_front", 49f, -6f, 9f, 49f, 30f, 7f},
                {"mansion", "mansion_01_corner", 4f, 2f, 15f, 46f, 36f, 6f},
                {"mansion", "mansion_02_main_hall", 44f, 26.6f, 2.2f, 50f, 41f, 5f},
                {"mansion", "mansion_03_hall_from_the_gallery", 41f, 27f, F1 + 2.2f, 51f, 40f, 2f},
                {"mansion", "mansion_04_dining_room", 37.4f, 31.9f, 2.4f, 20f, 31.9f, 2f},
                {"mansion", "mansion_05_corridor", 60f, 39.9f, 1.8f, 81f, 39.9f, 1.7f},
                {"mansion", "mansion_06_statue_gallery", 59.5f, 26.5f, 2.6f, 69f, 36f, 1f},
                {"mansion", "mansion_07_library", 17f, 40f, F1 + 2.6f, 37f, 48f, F1 + 0.8f},
        };
        int f = 60, n = 0;
        for (Object[] sh : shots) {
            if (!only.isEmpty() && !((String) sh[0]).startsWith(only) && !((String) sh[1]).startsWith(only)) continue;
            final Object[] q = sh;
            raid(f, h -> lookAt(h.raid().raid, (String) q[0], (Float) q[2], (Float) q[3], (Float) q[4], (Float) q[5], (Float) q[6], (Float) q[7]));
            raid(f + 2, h -> lookAt(h.raid().raid, (String) q[0], (Float) q[2], (Float) q[3], (Float) q[4], (Float) q[5], (Float) q[6], (Float) q[7]));
            for (int k = 20; k < 190; k += 20) raid(f + k, h -> lookAt(h.raid().raid, (String) q[0], (Float) q[2], (Float) q[3], (Float) q[4], (Float) q[5], (Float) q[6], (Float) q[7]));
            raid(f + 190, h -> shot(h, (String) q[1]));
            f += 200; n++;
        }
        raid(f + 10, h -> { Raid r = h.raid().raid; for (var lm : r.world.map.anchors) if (lm.id.equals("power_plant") || lm.id.equals("mansion")) { int rooms = 0, boxes = 0; for (int id : lm.buildings) { var bd = r.world.map.buildings.get(id); rooms += bd.rooms.size(); for (var rm : bd.rooms) if (!rm.reachable) System.out.println("[Scenario] UNREACHABLE " + bd.name + " " + rm.type + " floor " + rm.floor + " at " + rm.x0 + "," + rm.z0 + ".." + rm.x1 + "," + rm.z1 + " y" + rm.y); if (!bd.problems.isEmpty()) System.out.println("[Scenario] problems " + bd.name + ": " + bd.problems); } for (var l : r.world.map.loot) if (l.x >= lm.x0 && l.x <= lm.x1 && l.z >= lm.z0 && l.z <= lm.z1) boxes++; System.out.println("[Scenario] " + lm.name + ": " + lm.buildings.size() + " buildings, " + rooms + " rooms, " + boxes + " containers"); } });
    }

    /** Puts the camera at a place on a landmark's own grid (a along its front, b back from it, y above the street), looking at another. */
    private static void lookAt(Raid r, String landmark, float a, float b, float y, float ta, float tb, float ty) {
        for (var lm : r.world.map.anchors) {
            if (!lm.id.equals(landmark)) continue;
            var fr = new absentialis.world.gen.arch.Frame(lm.x0, lm.z0, lm.x1, lm.z1, lm.front);
            float[] from = local(fr, a, b), to = local(fr, ta, tb);
            float dx = to[0] - from[0], dz = to[1] - from[1], dy = ty - y, hl = (float) Math.sqrt(dx * dx + dz * dz);
            place(r, from[0], g() + y - 1.63f, from[1], (float) Math.atan2(-dx, -dz), (float) Math.atan2(dy, Math.max(0.01f, hl)));
            r.player.onGround = true; r.player.fallSpeed = 0;
            return;
        }
    }

    /** A point on a frame's local grid, in the world: the same mapping the generator uses, for whole and part cells alike. */
    private static float[] local(absentialis.world.gen.arch.Frame fr, float a, float b) {
        int ia = (int) Math.floor(a), ib = (int) Math.floor(b);
        float fa = a - ia, fb = b - ib;
        float x00 = fr.x(ia, ib), z00 = fr.z(ia, ib), x10 = fr.x(ia + 1, ib), z10 = fr.z(ia + 1, ib), x01 = fr.x(ia, ib + 1), z01 = fr.z(ia, ib + 1);
        return new float[]{x00 + (x10 - x00) * fa + (x01 - x00) * fb + 0.5f, z00 + (z10 - z00) * fa + (z01 - z00) * fb + 0.5f};
    }

    /**
     * 0.8, Director Mode in the city, end to end: the casting screen on three kinds of actor, into the world as a
     * Gladiator, the interaction menu and its settings, an orbit camera, a four-second recording, the editor with two
     * pieces on its timeline, an export - and out again, with the survivor as they were.
     */
    private static void director() {
        profile(null);
        final int W = org.lwjgl.glfw.GLFW.GLFW_KEY_W;
        raid(40, h -> { h.raid().raid.god = true; h.console("directormode"); });
        raid(70, h -> shot(h, "dir_00_casting"));
        // 0.9: the character creator inside Director Mode
        raid(72, h -> h.raid().director.beginCreate(-1));
        raid(100, h -> shot(h, "dir_01_character_creator"));
        raid(102, h -> { var d = h.raid().director; var app = new absentialis.character.Appearance(); app.sex(true); System.out.println("[Scenario] create: " + d.createCharacter("Vera", app) + " -> " + d.persistence.characters.size() + " character(s), selected " + d.actors.describe(d.chosen)); d.chosen.loadout = 4; d.openCastingPreview(); });
        raid(130, h -> shot(h, "dir_02_casting_own_character"));
        raid(132, h -> { var d = h.raid().director; System.out.println("[Scenario] enter: " + d.session.enterWorld()); d.world.setTime(4); d.world.freeze(true); d.population.setNpc(3); });
        // 0.9: the actor can look and move as soon as the curtain is up (0.8 held the controls until a menu had been opened once)
        raid(200, h -> { Raid r = h.raid().raid; dirFrom[0] = r.player.x; dirFrom[1] = r.player.z; dirFrom[2] = r.player.yaw; System.out.println("[Scenario] controls held after entering: " + h.raid().director.gui.locked()); h.ctx().in.inject(W, true); h.ctx().in.dx = 40; });
        for (int f = 201; f < 250; f++) raid(f, h -> h.ctx().in.dx = 6);
        raid(250, h -> { Raid r = h.raid().raid; h.ctx().in.inject(W, false); System.out.println(String.format("[Scenario] moved %.2f m and turned %.2f rad with the keys and the mouse", r.player.distXZ(dirFrom[0], dirFrom[1]), Math.abs(r.player.yaw - dirFrom[2]))); });
        raid(260, h -> shot(h, "dir_03_world_as_own_character"));
        raid(262, h -> h.raid().director.openMenu());
        raid(290, h -> { shot(h, "dir_04_interaction_menu"); System.out.println("[Scenario] pointer free while the menu is open: " + h.raid().director.wantsPointer()); });
        raid(292, h -> { var d = h.raid().director; d.gui.close(); System.out.println("[Scenario] record: " + d.recording.start()); h.ctx().in.inject(W, true); });
        for (int f = 293; f < 520; f++) raid(f, h -> h.ctx().in.dx = (dirTick++ / 45) % 2 == 0 ? 3 : -3);
        raid(400, h -> shot(h, "dir_05_recording"));
        raid(520, h -> h.ctx().in.inject(W, false));
        raid(560, h -> { var d = h.raid().director; var tape = d.recording.tape; System.out.println("[Scenario] clip: " + d.recording.stop() + " - " + d.recording.status + "; tape " + (tape == null ? 0 : tape.size()) + " frames" + (tape != null && tape.truncated ? " (truncated)" : "")); });
        raid(580, h -> { var d = h.raid().director; d.session.toEditor(); System.out.println("[Scenario] editor: " + d.editor.timeline.size() + " piece(s) on the timeline when it opens, " + absentialis.director.RecordingManager.clips().size() + " clip(s) on disk, tape " + (d.editor.timeline.isEmpty() ? "-" : d.editor.tapeOf(d.editor.timeline.get(0)) != null)); });
        raid(640, h -> shot(h, "dir_06_editor_footage"));
        // 0.9: perspective is chosen here - the same take from an orbiting camera, then from behind the actor
        raid(642, h -> { var e = h.raid().director.editor; if (!e.timeline.isEmpty()) { e.setCamera(e.timeline.get(0), absentialis.director.ClipEditor.CAM_ORBIT); e.seek(2.0f); } });
        raid(680, h -> shot(h, "dir_07_editor_orbit_camera"));
        raid(682, h -> { var e = h.raid().director.editor; if (!e.timeline.isEmpty()) { e.setCamera(e.timeline.get(0), absentialis.director.ClipEditor.CAM_THIRD); e.seek(5.0f); } });
        raid(720, h -> shot(h, "dir_08_editor_third_person_camera"));
        raid(722, h -> { var e = h.raid().director.editor; if (!e.timeline.isEmpty()) { e.setCamera(e.timeline.get(0), absentialis.director.ClipEditor.CAM_ORBIT); e.reshoot(e.timeline.get(0)); } });
        raid(800, h -> shot(h, "dir_09_reshooting"));
        for (int f = 740; f < 2400; f += 20) raid(f, h -> { var e = h.raid().director.editor; if (!e.shooting() && e.reshoots > 0 && !reshootLogged) { reshootLogged = true; var pc = e.timeline.get(0); System.out.println("[Scenario] re-shot: " + pc.clip.name() + " " + pc.clip.frames() + " frames, sound " + pc.clip.audio() + " - " + e.status); } });
        raid(2400, h -> { var e = h.raid().director.editor; if (!e.timeline.isEmpty()) { var a2 = e.timeline.get(0); var b2 = e.add(a2.clip); b2.in = Math.min(1f, b2.out * 0.3f); b2.effect = 2; b2.transition = 1; b2.zoom = 1.5f; b2.panX = 0.3f; b2.speed = 0.5f; e.seek(1.0f); } });
        raid(2440, h -> shot(h, "dir_10_editor_reshot_take"));
        raid(2442, h -> h.raid().director.editor.export());
        for (int f = 2460; f < 6000; f += 20) raid(f, h -> { var e = h.raid().director.editor; if (!e.exported.isEmpty() && !exportLogged) { exportLogged = true; java.io.File out = new java.io.File(e.exported); System.out.println("[Scenario] exported " + out.getName() + " " + out.length() + " bytes - " + e.status); } });
        raid(6000, h -> shot(h, "dir_11_editor_exported"));
        raid(6002, h -> { var d = h.raid().director; d.editor.closeRequested = true; });
        raid(6060, h -> { var d = h.raid().director; System.out.println("[Scenario] end: " + d.toggle()); });
        raid(6120, h -> { Raid r = h.raid().raid; shot(h, "dir_12_back_as_survivor"); System.out.println("[Scenario] restored: kind '" + r.playerKind + "' unwanted " + r.unwanted + " hp " + r.player.hp + "/" + r.player.maxHp + " saves suspended " + absentialis.persistence.SaveSystem.suspended + " look override " + (h.raid().lookOverride != null)); });
    }
    private static final float[] dirFrom = new float[3];
    private static boolean reshootLogged;
    private static int dirTick;
    private static boolean exportLogged;

    /** 0.8: the eighteen new pieces of equipment worn, three to a row - helmet, armour, pack of one rarity on each of six people. */
    private static void gear() {
        profile(null);
        for (int f = 8; f < 3000; f += 30) hideout(f, h -> { if (absentialis.world.gen.DevMap.mansion == null && h.worldReady()) h.console("devmap 0"); });
        float rx = absentialis.world.gen.DevMap.ROAD_X0 + 6, rz = (absentialis.world.gen.DevMap.ROAD_Z0 + absentialis.world.gen.DevMap.ROAD_Z1) / 2f + 0.5f;
        String[][] sets = {{"helmet.hardhat", "armor.scavenged", "bag.school"}, {"helmet.moto", "armor.rider", "bag.hiking"}, {"helmet.tactical", "armor.tactical_rig", "bag.tactical"},
                {"helmet.ballistic", "armor.full_ballistic", "bag.ballistic"}, {"helmet.sealed", "armor.advanced_suit", "bag.advanced"}, {"helmet.smart", "armor.powered", "bag.warbag"}};
        raid(60, h -> {
            Raid r = h.raid().raid;
            r.god = true; r.freezeAI = true;
            place(r, rx, g(), rz, -1.5708f, -0.05f);
            for (int i = 0; i < sets.length; i++) {
                absentialis.entity.Actor a = r.debugSpawn("survivors", rx + 5.5f, rz - 3.75f + i * 1.5f, g());
                a.hostileToPlayer = false; a.weapon = null; a.yaw = 1.5708f + (i < 3 ? 0 : 0);
                a.wornHead = sets[i][0]; a.wornArmor = sets[i][1]; a.wornPack = sets[i][2]; a.look = "gear08:" + i;
                posed[i] = a;
            }
        });
        raid(200, h -> shot(h, "gear_00_front"));
        raid(202, h -> { for (int i = 0; i < 6; i++) if (posed[i] != null) posed[i].yaw = -1.5708f; });
        raid(300, h -> shot(h, "gear_01_back"));
        raid(302, h -> { Raid r = h.raid().raid; place(r, rx + 3.2f, g(), rz - 3.2f, -1.5708f, -0.05f); for (int i = 0; i < 6; i++) if (posed[i] != null) posed[i].yaw = 1.5708f; });
        raid(400, h -> shot(h, "gear_02_close_left"));
        raid(402, h -> { Raid r = h.raid().raid; place(r, rx + 3.2f, g(), rz + 1.4f, -1.5708f, -0.05f); });
        raid(500, h -> shot(h, "gear_03_close_right"));
    }

    private static final absentialis.entity.Actor[] posed = new absentialis.entity.Actor[8];

    /**
     * 0.8, the poses nobody had looked at from outside: a row of people side-on to the camera on a bare floor - standing,
     * crouched, prone with a rifle, prone with nothing, down wounded - and then the same row from the front. A line is
     * drawn at floor level: nothing of anybody should be under it.
     */
    private static void poses() {
        profile(null);
        raid(20, h -> {
            Raid r = h.raid().raid;
            r.god = true; r.populate = false; r.freezeAI = true;
            r.actors.removeIf(a -> !a.isPlayer);
            absentialis.world.World w = r.world;
            gx = (int) r.player.x; gy = Math.round(r.player.y); gz = (int) r.player.z;
            for (int dx = -12; dx <= 12; dx++) for (int dz = -14; dz <= 4; dz++) { for (int dy = 0; dy <= 5; dy++) w.set(gx + dx, gy + dy, gz + dz, absentialis.world.Block.AIR); w.set(gx + dx, gy - 1, gz + dz, absentialis.world.Block.CONCRETE); }
            String[] who = {"military", "military", "military", "survivors", "military", "raiders"};
            for (int i = 0; i < who.length; i++) {
                absentialis.entity.Actor a = r.debugSpawn(who[i], gx - 6.25f + i * 2.5f + 0.5f, gz - 5 + 0.5f, gy);
                a.yaw = (float) -Math.PI / 2; a.hostileToPlayer = false; a.homeX = a.x; a.homeZ = a.z;      // facing +x: side-on to the camera
                posed[i] = a;
            }
            posed[1].crouch = true;
            posed[2].prone = true;
            posed[3].prone = true; posed[3].weapon = null;
            posed[4].vital = absentialis.entity.Vital.DOWNED; posed[4].bleedLeft = 9999;
            posed[5].prone = true; posed[5].yaw = (float) Math.PI;                                          // prone, feet to the camera... then head to it
            h.raid().thirdPerson = false;
            place(r, gx + 1.0f, gy, gz + 3.5f, 0, -0.10f);
        });
        raid(60, h -> { for (absentialis.entity.Actor a : posed) if (a != null) { a.vx = a.vz = 0; } });
        raid(170, h -> shot(h, "poses_00_side"));
        raid(172, h -> place(h.raid().raid, gx + 1.5f, gy, gz - 0.5f, 0, -0.22f));
        raid(260, h -> shot(h, "poses_01_prone_close"));
        raid(262, h -> place(h.raid().raid, gx + 12.5f, gy, gz - 4.5f, (float) Math.PI / 2, -0.12f));
        raid(350, h -> shot(h, "poses_02_from_the_end"));
    }

    private static int gx, gy, gz;

    /**
     * 0.8, "glass textures freak out when looking at glass through glass": three rows of different glass one behind the
     * other, straddling a chunk seam, in front of a plain wall - looked through from in front, walked past sideways (the
     * order the panes are drawn in changes as the camera crosses the seam) and looked along at a slant.
     */
    private static void glass() {
        profile(null);
        raid(20, h -> {
            Raid r = h.raid().raid;
            r.god = true; r.populate = false; r.freezeAI = true;
            r.actors.removeIf(a -> !a.isPlayer);
            absentialis.world.World w = r.world;
            gx = Math.round(r.player.x / 16f) * 16; gy = Math.round(r.player.y); gz = (int) r.player.z;
            for (int dx = -9; dx <= 9; dx++) for (int dz = -15; dz <= 3; dz++) { for (int dy = 0; dy <= 5; dy++) w.set(gx + dx, gy + dy, gz + dz, absentialis.world.Block.AIR); w.set(gx + dx, gy - 1, gz + dz, absentialis.world.Block.CONCRETE); }
            int[] kinds = {absentialis.world.Block.GLASS, absentialis.world.Block.GLASS_DIRTY, absentialis.world.Block.GLASS_CRACKED};
            for (int k = 0; k < 3; k++) for (int dx = -6; dx <= 6; dx++) for (int dy = 0; dy <= 3; dy++) w.set(gx + dx, gy + dy, gz - 4 - k * 3, kinds[k]);
            for (int dx = -9; dx <= 9; dx++) for (int dy = 0; dy <= 5; dy++) w.set(gx + dx, gy + dy, gz - 14, (dx + dy & 1) == 0 ? absentialis.world.Block.CONCRETE : absentialis.world.Block.SANDBAG);
            h.raid().thirdPerson = false;
            place(r, gx + 0.5f, gy, gz + 0.5f, 0, 0.02f);
        });
        raid(200, h -> shot(h, "glass_00_front"));
        for (int i = 0; i < 12; i++) { final int k = i; raid(204 + i * 6, h -> place(h.raid().raid, gx - 5.5f + k * 1.0f, gy, gz + 0.5f, 0.35f - k * 0.06f, 0.02f)); raid(208 + i * 6, h -> shot(h, String.format("glass_walk_%03d", k))); }
        raid(280, h -> sheet("glass_walk", 4, 300, 150, 1000, 600, 0.4f));
        raid(284, h -> place(h.raid().raid, gx - 7.5f, gy, gz - 2.5f, -1.15f, 0.0f));
        raid(380, h -> shot(h, "glass_01_slant"));
    }

    /** Every tab of the hideout, the shop departments and the deployment briefing. */
    private static void menus() {
        keepUnaligned = true;
        profile(p -> { p.scrip = 90000; p.prog.addXp(absentialis.gameplay.progression.Progression.xpToReach(9)); });
        hideout(5, h -> shot(h, "menu_00_allegiance"));
        hideout(7, h -> { absentialis.gameplay.Alliance.choose(h.ctx().profile, "survivors"); h.hideout().enter(); });
        int f = 12;
        for (int t = 0; t < HideoutScreen.TABS.length; t++) {
            final int tab = t;
            hideout(f, h -> h.hideout().tab = tab);
            hideout(f + 10, h -> shot(h, "menu_1" + tab + "_" + HideoutScreen.TABS[tab].toLowerCase()));
            f += 12;
        }
        for (int d = 0; d <= ShopPanel.RECRUITS; d++) {
            final int dept = d;
            hideout(f, h -> h.hideout().debugShow(dept, false));
            hideout(f + 10, h -> shot(h, "menu_2" + dept + "_shop"));
            f += 12;
        }
        hideout(f, h -> h.hideout().debugShow(-1, true));
        hideout(f + 10, h -> shot(h, "menu_30_briefing"));
        hideout(f + 12, h -> { h.hideout().debugShow(-1, false); h.hideout().unlocks.show(1, 9); });
        hideout(f + 70, h -> shot(h, "menu_31_unlocked"));
        hideout(f + 72, h -> h.hideout().unlocks.dismiss());
    }
}
