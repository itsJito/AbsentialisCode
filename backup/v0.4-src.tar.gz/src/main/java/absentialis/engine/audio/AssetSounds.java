package absentialis.engine.audio;

import java.io.BufferedInputStream;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import org.lwjgl.stb.STBVorbis;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;

/**
 * Recorded sound assets. Every .ogg or .wav in assets/audio replaces the synthesised sound of the same name
 * (assets/audio/shot_rifle.ogg replaces "shot_rifle"), or adds a new one. Files are decoded to mono at the mixer
 * rate; a file that cannot be read is reported and skipped, and the synthesised sound stays.
 * See assets/audio/README.txt for the names the game plays and the licences of what ships there.
 */
public final class AssetSounds {
    private AssetSounds() {}

    public static final Path DIR = Path.of("assets", "audio");

    /** Loads every asset over the bank. Returns how many were loaded. */
    public static int load(Map<String, float[]> out) {
        if (!Files.isDirectory(DIR)) return 0;
        int n = 0;
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(DIR)) {
            for (Path p : ds) {
                String f = p.getFileName().toString().toLowerCase();
                if (!f.endsWith(".ogg") && !f.endsWith(".wav")) continue;
                String name = f.substring(0, f.length() - 4);
                try {
                    float[] d = f.endsWith(".ogg") ? ogg(p) : wav(p);
                    if (d == null || d.length < 8) { System.err.println("[Audio] " + f + ": empty or unreadable, keeping the synthesised sound"); continue; }
                    tame(d, name);
                    out.put(name, d);
                    n++;
                } catch (Exception e) {
                    System.err.println("[Audio] " + f + ": " + e.getMessage());
                }
            }
        } catch (Exception e) {
            System.err.println("[Audio] assets: " + e.getMessage());
        }
        return n;
    }

    /** Peak-normalises a recording to the level the synthesised bank uses, and seals the ends against clicks. */
    private static void tame(float[] d, String name) {
        float m = 1e-6f;
        for (float v : d) m = Math.max(m, Math.abs(v));
        float target = name.startsWith("amb_") || name.startsWith("music_") ? 0.5f : 0.85f;
        float k = target / m;
        for (int i = 0; i < d.length; i++) d[i] *= k;
        int edge = Math.min(d.length / 8, 400);
        for (int i = 0; i < edge; i++) { float f = i / (float) edge; d[i] *= f; d[d.length - 1 - i] *= f; }
    }

    private static float[] ogg(Path p) throws Exception {
        byte[] raw = Files.readAllBytes(p);
        ByteBuffer in = MemoryUtil.memAlloc(raw.length);
        in.put(raw).flip();
        try (MemoryStack st = MemoryStack.stackPush()) {
            IntBuffer ch = st.mallocInt(1), rate = st.mallocInt(1);
            ShortBuffer pcm = STBVorbis.stb_vorbis_decode_memory(in, ch, rate);
            if (pcm == null) return null;
            int c = ch.get(0), frames = pcm.remaining() / Math.max(1, c);
            float[] mono = new float[frames];
            for (int i = 0; i < frames; i++) { float s = 0; for (int k = 0; k < c; k++) s += pcm.get(i * c + k); mono[i] = s / c / 32768f; }
            org.lwjgl.system.libc.LibCStdlib.free(pcm);
            return resample(mono, rate.get(0));
        } finally {
            MemoryUtil.memFree(in);
        }
    }

    private static float[] wav(Path p) throws Exception {
        try (AudioInputStream src = AudioSystem.getAudioInputStream(new BufferedInputStream(Files.newInputStream(p)))) {
            AudioFormat f = src.getFormat();
            AudioFormat want = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED, f.getSampleRate(), 16, f.getChannels(), f.getChannels() * 2, f.getSampleRate(), false);
            try (AudioInputStream pcm = AudioSystem.getAudioInputStream(want, src)) {
                byte[] b = pcm.readAllBytes();
                int c = f.getChannels(), frames = b.length / (2 * c);
                float[] mono = new float[frames];
                for (int i = 0; i < frames; i++) { float s = 0; for (int k = 0; k < c; k++) { int o = (i * c + k) * 2; s += (short) ((b[o] & 255) | (b[o + 1] << 8)); } mono[i] = s / c / 32768f; }
                return resample(mono, (int) f.getSampleRate());
            }
        }
    }

    /** Linear resampling to the mixer rate. */
    static float[] resample(float[] in, int rate) {
        if (rate == AudioEngine.RATE || rate <= 0 || in.length < 2) return in;
        double step = rate / (double) AudioEngine.RATE;
        int n = (int) ((in.length - 1) / step);
        float[] o = new float[Math.max(2, n)];
        for (int i = 0; i < n; i++) { double x = i * step; int i0 = (int) x; float fr = (float) (x - i0); o[i] = in[i0] + (in[i0 + 1] - in[i0]) * fr; }
        return o;
    }
}
