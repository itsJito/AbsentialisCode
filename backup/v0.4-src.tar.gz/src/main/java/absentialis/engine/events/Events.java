package absentialis.engine.events;

/** Typed domain events. Each is an immutable record of a validated fact. */
public final class Events {
    private Events() {}

    public record ShotFired(int shooterId, String faction, float x, float y, float z, float noise, String weaponId, boolean suppressed) {}
    public record SoundEmitted(int sourceId, float x, float y, float z, float intensity, String category, boolean infectedOnly) {}
    public record ActorInjured(int victimId, int attackerId, String region, float damage, boolean penetrated) {}
    public record ActorKilled(int victimId, int attackerId, String victimFaction, String attackerFaction, float x, float y, float z, boolean witnessed, String archetype) {}
    public record ItemTransferred(long uid, String defId, String from, String to, int qty) {}
    public record ItemConsumed(long uid, String defId, int qty, String reason) {}
    public record FactionStandingChanged(String faction, float delta, float now, String reason) {}
    public record DistrictControlChanged(String district, String faction, float influence, String reason) {}
    public record ExtractionStarted(String exitId, float duration) {}
    public record ExtractionCompleted(String exitId) {}
    public record RaidFailed(String reason) {}
    public record BlockDestroyed(int x, int y, int z, int blockId, int byActor) {}
    public record ContainerSearched(long spotId, String table, float x, float y, float z) {}
    public record DocumentRead(String docId) {}
    public record InfrastructureChanged(String site, String state) {}
    public record ObjectiveProgress(String missionId, String objective) {}
}
