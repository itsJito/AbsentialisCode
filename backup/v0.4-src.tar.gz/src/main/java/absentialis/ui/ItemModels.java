package absentialis.ui;

import absentialis.engine.render.Tex;
import absentialis.engine.voxel.VoxModel;
import absentialis.gameplay.items.ItemDef;
import absentialis.gameplay.items.ItemInstance;
import absentialis.gameplay.weapons.Gunsmith;
import java.util.HashMap;
import java.util.Map;

/**
 * Procedural voxel models for every item. Weapons are assembled from their platform body plus the
 * fitted gunsmith parts (muzzle, barrel, optic, stock, grip, light, magazine, finish) and
 * weathered by condition, so modifications visibly change the silhouette in the case, the
 * inspect view, the first-person viewmodel and on the character. Long axis = X.
 */
public final class ItemModels {
    private ItemModels() {}

    private static final Map<String, VoxModel> CACHE = new HashMap<>();

    static final int METAL = Tex.rgb(52, 54, 58), METAL_LT = Tex.rgb(96, 100, 106), POLY = Tex.rgb(34, 35, 37), WOOD = Tex.rgb(122, 74, 38),
            WOOD_DK = Tex.rgb(88, 52, 26), STEEL = Tex.rgb(140, 144, 150), BRASS = Tex.rgb(196, 160, 70), OLIVE = Tex.rgb(86, 96, 60),
            RED = Tex.rgb(170, 40, 36), WHITE = Tex.rgb(220, 218, 210), CLOTH = Tex.rgb(196, 190, 170), GLASS = 0xC060A0C0;

    public static VoxModel of(ItemInstance it) {
        String key = it.visualKey();
        VoxModel m = CACHE.get(key);
        if (m == null) {
            m = build(it);
            if (CACHE.size() > 600) CACHE.clear();
            CACHE.put(key, m);
        }
        return m;
    }

    public static VoxModel of(ItemDef d) {
        return CACHE.computeIfAbsent("def:" + d.id, k -> build(new ItemInstance(-9, d.id)));
    }

    private static VoxModel build(ItemInstance it) {
        ItemDef d = it.def();
        VoxModel m;
        if (d.weapon != null) m = weapon(it);
        else m = misc(d);
        return m.jitter(0.06f, d.id.hashCode());
    }

    // ------------------------------------------------------------------ weapons
    private static boolean has(ItemInstance it, String cat, String key) { ItemInstance a = it.attachments.get(cat); return a != null && a.defId.endsWith("." + key); }

    /**
     * The base model of each weapon is fixed; attachments add or swap geometry on it (suppressors and
     * barrels at the muzzle, optics on the top rail, stocks at the rear, grips and launchers under the
     * barrel, extended and drum magazines in the well), so a build is readable at a glance.
     */
    private static VoxModel weapon(ItemInstance it) {
        ItemDef d = it.def();
        String model = d.weapon.model;
        int tint = Gunsmith.finishTint(it);
        int body = tint != 0 ? tint : POLY, metal = tint != 0 ? Tex.shade(tint, 0.75f) : METAL;
        int wood = tint != 0 ? Tex.shade(tint, 0.88f) : WOOD, steel = tint != 0 ? Tex.shade(tint, 1.1f) : STEEL;
        boolean longB = has(it, "barrel", "long"), shortB = has(it, "barrel", "short"), heavyB = has(it, "barrel", "heavy");
        int bx = longB ? 5 : shortB ? -4 : 0;
        boolean noStock = has(it, "stock", "none"), heavyStock = has(it, "stock", "heavy"), skeleton = has(it, "stock", "skeleton");
        boolean drum = has(it, "magazine", "drum"), ext = has(it, "magazine", "ext");
        VoxModel m;
        int muzzleX, boreY, topY, opticX, gripX, magX, railZ = 2, stockY = 8;
        boolean pistolMag = false, drumBase = false;
        switch (model) {
            case "pistol", "punisher", "whitetail", "yellow9", "matilda", "deagle", "killer9" -> {
                int len = switch (model) { case "whitetail" -> 10; case "yellow9" -> 17; case "matilda" -> 23; case "deagle", "killer9" -> 19; default -> 13; };
                int thick = model.equals("deagle") || model.equals("killer9") ? 4 : 3;
                m = new VoxModel(len + 12, 16, 5);
                int sy = 8;
                m.box(2, sy, 1, len + bx / 2, sy + thick, 3, model.equals("punisher") ? Tex.rgb(70, 74, 82) : model.equals("killer9") ? steel : metal);   // slide
                m.box(2, sy + thick + 1, 2, 3, sy + thick + 1, 2, METAL_LT);                                    // rear sight
                m.box(len - 1 + bx / 2, sy + thick + 1, 2, len - 1 + bx / 2, sy + thick + 1, 2, METAL_LT);
                m.box(2, 2, 1, 6, sy, 3, model.equals("yellow9") ? wood : model.equals("whitetail") ? Tex.rgb(196, 190, 176) : body);   // grip
                m.box(6, sy - 2, 2, 8, sy - 1, 2, metal);                                                        // trigger guard
                if (model.equals("yellow9")) m.box(7, sy - 3, 1, 10, sy - 1, 3, metal);                          // fixed box magazine ahead of the guard
                if (model.equals("matilda")) { m.box(9, sy - 3, 2, 10, sy - 1, 2, body); }                       // fold-down foregrip
                muzzleX = len + 1 + bx / 2; boreY = sy + thick - 1; topY = sy + thick + 1; opticX = 5; gripX = 9; magX = 3; pistolMag = true; stockY = sy + 1;
            }
            case "revolver" -> {
                m = new VoxModel(30, 14, 6);
                m.box(8, 8, 1, 20 + bx / 2, 10, 3, steel);            // barrel
                m.box(8, 6, 2, 19 + bx / 2, 7, 2, steel);             // underlug
                m.cylX(6, 10, 8, 2.5f, 3f, steel);                     // cylinder
                m.box(3, 7, 1, 7, 11, 3, steel);                       // frame
                m.box(1, 1, 1, 5, 7, 3, wood);                         // grip
                muzzleX = 21 + bx / 2; boreY = 9; topY = 11; opticX = 10; gripX = 12; magX = -1;
            }
            case "mosin" -> {
                // a long, slim rifle: 1.2 m of it at 40 voxels to the metre, and no taller than the one grid row it occupies
                m = new VoxModel(60, 16, 5);
                if (!noStock) { m.box(0, 4, 1, 14, 7, 3, wood); m.box(0, 4, 1, 1, 7, 3, WOOD_DK); }
                m.box(15, 5, 1, 38, 7, 3, wood);                       // fore stock
                m.box(14, 7, 2, 46 + bx, 8, 2, metal);                 // barrel
                m.box(16, 7, 1, 24, 8, 3, metal);                      // receiver
                m.box(22, 8, 3, 22, 9, 4, steel);                      // bolt handle
                muzzleX = 47 + bx; boreY = 7; topY = 8; opticX = 18; gripX = 30; magX = -1; stockY = 6;
            }
            case "shotgun", "riot", "striker" -> {
                boolean striker = model.equals("striker"), riot = model.equals("riot");
                m = new VoxModel(56, 16, 7);
                railZ = 3;
                if (!noStock) { if (striker) { m.box(2, 9, 3, 11, 9, 3, METAL_LT); m.box(2, 5, 3, 2, 9, 3, METAL_LT); } else { m.box(0, 3, 2, 12, 8, 4, riot ? body : wood); m.box(0, 2, 2, 3, 3, 4, riot ? body : WOOD_DK); } }
                m.box(12, 5, 2, 22, 10, 4, metal);                     // receiver
                int end = (striker ? 34 : 44) + bx;
                m.box(22, 8, 3, end, 9, 3, metal);                     // barrel
                if (!striker) m.box(22, 6, 3, end - 4, 7, 3, METAL_LT); // tube
                if (!striker && !riot) m.box(27, 5, 2, 34, 7, 4, wood); // pump
                if (riot) m.box(24, 5, 2, 36, 7, 4, body);             // fixed fore-end
                if (striker) { m.cylX(20, 26, 4.5f, 3.5f, 3.4f, metal); m.box(28, 4, 3, 29, 8, 3, body); drumBase = true; }
                m.box(14, 1, 2, 16, 5, 4, striker || riot ? body : wood); // grip
                muzzleX = end + 1; boreY = 8; topY = 10; opticX = 15; gripX = 30; magX = -1;
            }
            case "smg" -> {
                m = new VoxModel(44, 16, 5);
                if (!noStock) { m.box(0, 9, 2, 9, 9, 2, METAL_LT); m.box(0, 5, 2, 0, 9, 2, METAL_LT); }
                m.box(10, 7, 1, 24, 11, 3, body);                      // receiver
                m.box(24, 8, 2, 30 + bx, 10, 2, metal);                // barrel shroud
                m.box(13, 2, 1, 15, 7, 3, body);                       // grip
                m.box(21, 3, 2, 22, 7, 2, body);                       // fore grip stub
                muzzleX = 31 + bx; boreY = 9; topY = 12; opticX = 13; gripX = 25; magX = 13; pistolMag = true; stockY = 9;
            }
            case "tommy" -> {
                m = new VoxModel(56, 16, 7);
                railZ = 3;
                if (!noStock) { m.box(0, 3, 2, 11, 8, 4, wood); m.box(0, 2, 2, 3, 3, 4, WOOD_DK); }
                m.box(12, 7, 2, 28, 11, 4, metal);                     // receiver
                m.box(28, 8, 3, 44 + bx, 10, 3, metal);                // barrel
                for (int k = 30; k < 40 + bx; k += 2) m.box(k, 7, 2, k, 11, 4, METAL_LT);   // cooling fins
                m.box(14, 2, 2, 16, 7, 4, wood);                       // rear grip
                m.box(30, 3, 3, 32, 7, 3, wood);                       // fore grip
                m.cylX(19, 24, 3.5f, 3.5f, 3.6f, metal);               // the drum it is known for
                muzzleX = 45 + bx; boreY = 9; topY = 12; opticX = 15; gripX = 34; magX = -1; drumBase = true;
            }
            case "crossbow" -> {
                m = new VoxModel(44, 14, 17);
                railZ = 8;
                if (!noStock) { m.box(0, 4, 7, 12, 8, 9, body); m.box(0, 3, 7, 3, 4, 9, body); }
                m.box(12, 6, 7, 38, 8, 9, body);                       // tiller
                m.box(12, 8, 8, 36, 8, 8, STEEL);                      // bolt on the rail
                m.box(34, 7, 0, 36, 8, 16, METAL);                     // limbs
                m.box(30, 7, 0, 33, 7, 1, METAL); m.box(30, 7, 15, 33, 7, 16, METAL);
                for (int k = 0; k < 8; k++) { m.set(33 - k * 2, 8, 1 + k, WHITE); m.set(33 - k * 2, 8, 15 - k, WHITE); }   // string drawn back
                m.box(15, 2, 7, 17, 6, 9, body);                       // grip
                muzzleX = 39; boreY = 8; topY = 9; opticX = 16; gripX = 26; magX = -1;
            }
            case "knife" -> {
                m = new VoxModel(16, 6, 3);
                m.box(0, 2, 1, 5, 3, 1, POLY); m.box(5, 1, 1, 5, 4, 1, METAL);
                m.box(6, 2, 1, 15, 3, 1, STEEL); m.box(6, 3, 1, 13, 3, 1, METAL_LT);
                return m.weather(1f - Math.max(0, it.durability), (int) it.uid);
            }
            case "crowbar" -> {
                m = new VoxModel(28, 8, 3);
                m.box(2, 3, 1, 25, 3, 1, Tex.rgb(150, 40, 34));
                m.box(0, 4, 1, 1, 5, 1, Tex.rgb(150, 40, 34)); m.box(25, 1, 1, 27, 2, 1, Tex.rgb(150, 40, 34));
                return m;
            }
            default -> { // akr (Full-Auto Rifle) / sr16 (Semi-Auto Rifle)
                boolean ar = model.equals("sr16");
                m = new VoxModel(56, 18, 5);
                int furn = ar ? body : wood;
                if (!it.attachments.containsKey("stock")) {
                    if (ar) { m.box(0, 6, 1, 3, 11, 3, body); m.box(4, 8, 2, 9, 10, 2, metal); }
                    else { m.box(0, 4, 1, 4, 10, 3, furn); m.box(5, 7, 1, 9, 10, 3, furn); }
                }
                m.box(10, 7, 1, 22, 11, 3, metal);                      // receiver
                if (ar) m.box(10, 12, 2, 30, 12, 2, METAL_LT);           // flat-top rail
                else m.box(11, 12, 2, 19, 12, 2, metal);                 // dust cover ridge
                m.box(23, 7, 1, 31, 11, 3, ar ? body : furn);           // handguard
                m.box(31, 9, 2, (ar ? 44 : 40) + bx, 10, 2, metal);     // barrel
                m.box(36, 10, 2, 36, 12, 2, metal);                     // front sight
                m.box(12, 2, 1, 14, 7, 3, body);                        // pistol grip
                muzzleX = (ar ? 45 : 41) + bx; boreY = 9; topY = 12; opticX = 14; gripX = 26; magX = 16;
            }
        }
        if (heavyB) m.box(muzzleX - 10, boreY - 1, railZ - 1, muzzleX - 1, boreY + 1, Math.min(m.sz - 1, railZ + 1), metal);
        // magazine well: standard, extended or drum
        if (magX >= 0) {
            int mc = model.equals("akr") ? Tex.rgb(150, 82, 40) : pistolMag ? METAL_LT : POLY;
            if (drum) m.cylX(magX - 1, magX + 4, 3.5f, railZ + 0.5f, 3.3f, METAL);
            else if (pistolMag) m.box(magX, ext ? 0 : 1, 1, magX + 2, 2, 3, mc);
            else for (int k = 0; k < (ext ? 7 : 5); k++) m.box(magX + (model.equals("akr") ? k / 2 : 0), 6 - k, 1, magX + 2 + (model.equals("akr") ? k / 2 : 0), 6 - k, 3, mc);
        } else if (ext && !drumBase) m.box(Math.max(0, muzzleX - 8), boreY - 2, railZ, muzzleX - 2, boreY - 2, railZ, METAL_LT);   // tube extension
        // parts
        for (Map.Entry<String, ItemInstance> e : it.attachments.entrySet()) {
            String s = e.getKey(), id = e.getValue().defId;
            int zr = Math.min(m.sz - 1, railZ + 1), zl = Math.max(0, railZ - 1);
            switch (s) {
                case "muzzle" -> {
                    if (id.contains("supp")) m.cylX(muzzleX, Math.min(m.sx - 1, muzzleX + (id.contains("mono") ? 10 : 6)), boreY + 0.5f, railZ + 0.5f, id.contains("mono") ? 1.9f : 1.5f, POLY);
                    else if (id.endsWith("choke")) m.box(muzzleX, boreY - 1, zl, Math.min(m.sx - 1, muzzleX + 3), boreY + 1, zr, METAL);
                    else { m.box(muzzleX, boreY - 1, zl, Math.min(m.sx - 1, muzzleX + 2), boreY + 1, zr, METAL_LT); if (id.endsWith("brake")) m.box(muzzleX + 1, boreY, zl, Math.min(m.sx - 1, muzzleX + 1), boreY, zr, 0); }
                }
                case "optic" -> {
                    if (id.contains("scope")) { int l = id.endsWith("6") ? 15 : 10; m.cylX(opticX, Math.min(m.sx - 1, opticX + l), topY + 2.5f, railZ + 0.5f, id.endsWith("6") ? 1.9f : 1.5f, POLY); m.box(opticX + 4, topY, railZ, opticX + 5, topY + 1, railZ, METAL); m.set(opticX, topY + 2, railZ, GLASS); }
                    else if (id.endsWith("holo")) { m.box(opticX, topY, zl, opticX + 4, topY, zr, POLY); m.box(opticX, topY + 1, zl, opticX, topY + 3, zr, POLY); m.box(opticX + 4, topY + 1, zl, opticX + 4, topY + 3, zr, POLY); m.box(opticX, topY + 4, zl, opticX + 4, topY + 4, zr, POLY); m.set(opticX + 2, topY + 2, railZ, GLASS); }
                    else { m.box(opticX, topY, zl, opticX + 3, topY + 1, zr, POLY); m.box(opticX + 1, topY + 2, zl, opticX + 2, topY + 3, zr, POLY); m.set(opticX + 1, topY + 2, railZ, Tex.rgb(220, 40, 40)); }
                }
                case "underbarrel" -> {
                    if (id.endsWith("launcher")) { m.cylX(gripX - 2, gripX + 7, boreY - 3.5f, railZ + 0.5f, 1.8f, METAL); m.box(gripX - 3, boreY - 6, railZ, gripX - 2, boreY - 3, railZ, POLY); }
                    else if (id.endsWith("bipod")) { m.box(gripX + 4, Math.max(0, boreY - 7), zl, gripX + 4, boreY - 2, zl, METAL_LT); m.box(gripX + 4, Math.max(0, boreY - 7), zr, gripX + 4, boreY - 2, zr, METAL_LT); }
                    else if (id.endsWith("angled")) { for (int k = 0; k < 4; k++) m.box(gripX + k, boreY - 3 - k / 2, railZ, gripX + k + 1, boreY - 2, railZ, POLY); }
                    else m.box(gripX, Math.max(0, boreY - 7), railZ, gripX + 1, boreY - 2, railZ, POLY);
                }
                case "laser" -> {
                    int ly = boreY - 1, lx = Math.min(m.sx - 4, gripX + 2);
                    m.box(lx, ly, zr, lx + 3, ly + 1, zr, id.endsWith("light") ? METAL_LT : POLY);
                    m.set(lx + 3, ly, zr, id.endsWith("light") ? Tex.rgb(240, 230, 160) : id.endsWith("5mw") ? Tex.rgb(60, 230, 80) : Tex.rgb(220, 50, 40));
                }
                case "stock" -> {
                    if (heavyStock) { m.box(0, stockY - 4, zl, 4, stockY + 3, zr, POLY); m.box(5, stockY - 1, zl, 9, stockY + 2, zr, POLY); }
                    else if (skeleton) { m.box(0, stockY + 1, railZ, 9, stockY + 1, railZ, METAL_LT); m.box(0, stockY - 3, railZ, 0, stockY + 1, railZ, METAL_LT); m.box(0, stockY - 3, railZ, 6, stockY - 3, railZ, METAL_LT); }
                }
                case "reargrip" -> { if (pistolMag || magX >= 0) m.box(Math.max(0, magX - 4), 1, zl, Math.max(0, magX - 4), 3, zr, id.endsWith("rubber") ? Tex.rgb(22, 22, 24) : Tex.rgb(96, 88, 70)); }
                default -> {}
            }
        }
        return m.weather(1f - it.condition() / 100f, (int) it.uid);
    }

    // ------------------------------------------------------------------ everything else
    private static VoxModel misc(ItemDef d) {
        String icon = d.icon == null ? d.category : d.icon;
        int h = Math.abs(d.id.hashCode());
        VoxModel m;
        switch (d.category) {
            case "magazine" -> {
                if (d.magazine.capacity >= 60 && d.magazine.magType.equals("stanag")) { m = new VoxModel(10, 10, 6); m.cylY(0, 4, 5, 3, 3.6f, POLY); m.cylY(5, 9, 5, 3, 3.6f, POLY); m.box(4, 7, 2, 6, 9, 3, METAL); }
                else if (d.magazine.magType.equals("belt")) { m = new VoxModel(10, 8, 7); m.box(0, 0, 0, 9, 6, 6, OLIVE); m.box(3, 7, 3, 6, 7, 3, METAL); }
                else if (d.magazine.magType.equals("pm9")) { m = new VoxModel(4, 10, 3); m.box(0, 0, 0, 3, 9, 2, METAL); m.box(0, 9, 1, 2, 9, 1, BRASS); }
                else { m = new VoxModel(8, 16, 4); int c = d.magazine.magType.equals("akr") ? Tex.rgb(150, 82, 40) : POLY;
                    for (int k = 0; k < 15; k++) m.box(k / 4, k, 0, k / 4 + 3, k, 3, c); m.box(3, 15, 1, 5, 15, 2, BRASS); }
            }
            case "ammo" -> {
                m = new VoxModel(14, 6, 8);
                int box = icon.contains("shell") ? Tex.rgb(150, 40, 30) : icon.contains("heavy") ? OLIVE : Tex.rgb(110, 98, 70);
                m.box(0, 0, 0, 13, 3, 7, box);
                for (int k = 0; k < 5; k++) m.box(1 + k * 2 + 1, 4, 2, 1 + k * 2 + 1, 5, 2, icon.contains("shell") ? RED : BRASS);
                m.box(2, 2, 0, 11, 2, 0, WHITE);
            }
            case "attachment" -> {
                if (d.attachment.socket.equals("finish")) { m = new VoxModel(8, 10, 4); m.box(1, 0, 0, 6, 7, 3, d.attachment.tint == 0 ? STEEL : d.attachment.tint); m.box(2, 8, 1, 5, 9, 2, METAL); }
                else if (d.attachment.socket.equals("muzzle")) { m = new VoxModel(14, 5, 5); if (d.id.contains("suppressor")) m.cylX(0, 13, 2.5f, 2.5f, 2.2f, POLY); else { m.cylX(0, 5, 2.5f, 2.5f, 1.8f, METAL_LT); m.box(1, 2, 0, 4, 2, 4, METAL); } }
                else if (d.attachment.socket.equals("optic")) { m = new VoxModel(14, 8, 5); if (d.id.contains("scope")) { m.cylX(0, 13, 5, 2.5f, 2.2f, POLY); m.box(5, 0, 2, 7, 2, 2, METAL); m.set(0, 5, 2, GLASS); } else { m.box(3, 0, 1, 9, 2, 3, POLY); m.box(4, 3, 1, 8, 6, 3, POLY); m.set(6, 5, 2, Tex.rgb(220, 40, 40)); } }
                else if (d.attachment.socket.equals("barrel")) { m = new VoxModel(20, 5, 5); m.cylX(0, d.id.contains("short") ? 9 : 19, 2.5f, 2.5f, 1.4f, d.id.contains("chrome") ? STEEL : METAL); }
                else if (d.attachment.socket.equals("stock")) { m = new VoxModel(14, 9, 4); if (d.id.contains("folding")) { m.box(0, 4, 1, 12, 5, 2, METAL_LT); m.box(0, 0, 1, 1, 8, 2, METAL_LT); } else { m.box(0, 0, 1, 4, 8, 2, POLY); m.box(5, 4, 1, 13, 6, 2, POLY); } }
                else if (d.attachment.socket.equals("grip")) { m = new VoxModel(6, 10, 4); m.box(1, 0, 1, 3, 9, 2, POLY); m.box(0, 9, 0, 5, 9, 3, METAL); }
                else { m = new VoxModel(8, 5, 5); m.cylX(0, 7, 2.5f, 2.5f, 2f, METAL_LT); m.box(7, 1, 1, 7, 3, 3, Tex.rgb(240, 230, 160)); }
            }
            case "medical" -> {
                if (icon.startsWith("herb")) { m = new VoxModel(8, 14, 8); int c = icon.contains("red") ? Tex.rgb(170, 40, 50) : Tex.rgb(60, 140, 60); m.box(1, 0, 1, 6, 3, 6, Tex.rgb(150, 92, 60)); m.box(3, 4, 3, 4, 8, 4, Tex.rgb(60, 90, 40)); m.sphere(4, 10, 4, 3.4f, c); m.sphere(2, 12, 3, 1.6f, c); m.sphere(5, 8, 5, 1.8f, d.id.contains("mixed_gr") ? Tex.rgb(170, 40, 50) : c); }
                else if (icon.contains("bandage")) { m = new VoxModel(8, 8, 8); m.cylY(0, 7, 4, 4, 3.6f, CLOTH); m.cylY(0, 7, 4, 4, 1.2f, 0); }
                else if (icon.contains("pills")) { m = new VoxModel(6, 10, 6); m.cylY(0, 7, 3, 3, 2.8f, icon.contains("green") ? Tex.rgb(70, 140, 70) : Tex.rgb(200, 130, 40)); m.cylY(8, 9, 3, 3, 2.8f, WHITE); }
                else if (icon.contains("injector")) { m = new VoxModel(16, 4, 4); m.box(0, 1, 1, 10, 2, 2, Tex.rgb(80, 160, 90)); m.box(11, 1, 1, 15, 1, 1, STEEL); m.box(0, 0, 0, 1, 3, 3, POLY); }
                else if (icon.contains("tourniquet")) { m = new VoxModel(10, 4, 10); for (int k = 0; k < 10; k++) { m.set(k, 1, 0, POLY); m.set(k, 1, 9, POLY); m.set(0, 1, k, POLY); m.set(9, 1, k, POLY); } m.box(3, 2, 3, 6, 3, 6, RED); }
                else if (icon.contains("splint")) { m = new VoxModel(14, 3, 6); m.box(0, 0, 0, 13, 0, 1, Tex.rgb(200, 120, 40)); m.box(0, 0, 4, 13, 0, 5, Tex.rgb(200, 120, 40)); m.box(3, 1, 0, 4, 2, 5, CLOTH); m.box(9, 1, 0, 10, 2, 5, CLOTH); }
                else if (icon.contains("spray")) { m = new VoxModel(6, 14, 6); m.cylY(0, 10, 3, 3, 2.8f, WHITE); m.box(2, 4, 0, 3, 6, 0, RED); m.cylY(11, 13, 3, 3, 1.4f, POLY); }
                else { m = new VoxModel(14, 8, 12); m.box(0, 0, 0, 13, 7, 11, Tex.rgb(170, 36, 32)); m.box(5, 2, 0, 8, 5, 0, WHITE); m.box(3, 3, 0, 10, 4, 0, WHITE); m.box(4, 8 - 1, 4, 9, 7, 7, METAL); }
            }
            case "food" -> {
                if (icon.contains("bottle")) { m = new VoxModel(6, 16, 6); int c = icon.contains("dirty") ? 0xD0807050 : 0xC080B0D0; m.cylY(0, 11, 3, 3, 2.8f, c); m.cylY(12, 13, 3, 3, 1.6f, c); m.cylY(14, 15, 3, 3, 1.4f, Tex.rgb(40, 90, 170)); m.box(1, 5, 0, 4, 8, 0, WHITE); }
                else if (icon.contains("can") || icon.contains("soda") || icon.contains("coffee")) { m = new VoxModel(8, 10, 8); int c = icon.contains("soda") ? RED : icon.contains("coffee") ? Tex.rgb(90, 60, 40) : Tex.rgb(160, 150, 130); m.cylY(0, 9, 4, 4, 3.6f, c); m.cylY(9, 9, 4, 4, 3.6f, STEEL); m.box(2, 3, 0, 5, 6, 0, WHITE); }
                else if (icon.contains("meat")) { m = new VoxModel(10, 5, 8); m.sphere(5, 2, 4, 4f, Tex.rgb(150, 60, 60)); m.box(8, 2, 3, 9, 3, 4, WHITE); }
                else { m = new VoxModel(12, 4, 14); m.box(0, 0, 0, 11, 3, 13, icon.contains("mre") ? Tex.rgb(130, 112, 70) : Tex.rgb(200, 170, 100)); m.box(3, 3, 3, 8, 3, 10, icon.contains("mre") ? Tex.rgb(90, 80, 50) : WHITE); }
            }
            case "armor" -> {
                if (d.slot.equals("head")) { m = new VoxModel(12, 9, 12); if (icon.contains("cap")) { m.sphere(6, 1, 6, 5f, OLIVE); m.box(0, 0, 0, 11, 8, 11, 0); m.sphere(6, 1, 6, 5f, OLIVE); m.box(0, 0, 6, 11, 1, 11, 0); m.box(3, 0, 10, 8, 1, 11, OLIVE); } else { m.sphere(6, 1, 6, 6f, Tex.rgb(80, 92, 64)); } }
                else if (d.slot.equals("face")) { m = new VoxModel(10, 10, 6); if (icon.contains("gas")) { m.box(1, 2, 0, 8, 8, 4, Tex.rgb(60, 64, 60)); m.cylX(0, 2, 4, 2, 1.4f, GLASS); m.cylX(7, 9, 4, 2, 1.4f, GLASS); m.cylY(0, 2, 5, 1, 2f, POLY); } else m.box(1, 1, 0, 8, 9, 3, POLY); }
                else { m = new VoxModel(14, 16, 6); int c = icon.contains("plate") ? Tex.rgb(70, 74, 66) : icon.contains("mil") ? OLIVE : Tex.rgb(46, 52, 70);
                    m.box(0, 0, 0, 13, 13, 5, c); m.box(3, 10, 0, 10, 15, 5, 0); m.box(0, 14, 1, 2, 15, 4, c); m.box(11, 14, 1, 13, 15, 4, c);
                    if (icon.contains("mil") || icon.contains("plate")) for (int k = 0; k < 3; k++) m.box(2 + k * 4, 2, 0, 4 + k * 4, 5, 0, Tex.shade(c, 0.7f)); }
            }
            case "backpack" -> { m = new VoxModel(12, 14, 8); m.box(0, 0, 1, 11, 12, 7, icon.contains("large") ? OLIVE : Tex.rgb(70, 60, 50)); m.box(2, 2, 0, 9, 6, 0, Tex.rgb(50, 44, 38)); m.box(4, 13, 3, 7, 13, 4, POLY); }
            case "explosive" -> {
                if (icon.equals("grenade")) { m = new VoxModel(8, 10, 8); m.sphere(4, 4, 4, 3.6f, OLIVE); m.box(3, 7, 3, 4, 9, 4, METAL); m.box(5, 8, 3, 6, 8, 3, STEEL); }
                else if (icon.equals("clock")) { m = new VoxModel(10, 10, 5); m.cylX(0, 0, 0, 0, 0, 0); m.sphere(5, 5, 2.5f, 4.2f, RED); m.box(1, 2, 0, 8, 8, 4, 0); m.sphere(5, 5, 2.5f, 4f, RED); m.box(3, 3, 0, 6, 6, 0, WHITE); m.box(2, 9, 2, 2, 9, 2, BRASS); m.box(7, 9, 2, 7, 9, 2, BRASS); }
                else { m = new VoxModel(5, 14, 5); m.cylY(0, 12, 2.5f, 2.5f, 2.2f, icon.contains("flare") ? RED : METAL); m.cylY(13, 13, 2.5f, 2.5f, 1.2f, icon.contains("flare") ? WHITE : POLY); }
            }
            case "charm" -> { m = new VoxModel(6, 10, 3); m.box(2, 8, 1, 3, 9, 1, BRASS); m.sphere(3, 4, 1.5f, 3f, h % 2 == 0 ? Tex.rgb(200, 190, 160) : BRASS); }
            case "treasure" -> {
                if (icon.contains("map")) { m = new VoxModel(12, 2, 10); m.box(0, 0, 0, 11, 0, 9, Tex.rgb(200, 180, 130)); m.box(2, 1, 2, 9, 1, 2, Tex.rgb(140, 90, 50)); m.box(4, 1, 5, 7, 1, 7, Tex.rgb(120, 70, 40)); }
                else if (icon.contains("gem")) { m = new VoxModel(6, 6, 6); m.sphere(3, 3, 3, 2.9f, Tex.rgb(200, 30, 60)); m.set(2, 4, 2, Tex.rgb(255, 160, 180)); }
                else { m = new VoxModel(8, 12, 8); m.cylY(0, 1, 4, 4, 3f, BRASS); m.cylY(2, 6, 4, 4, 1f, BRASS); m.cylY(7, 11, 4, 4, 3.5f, BRASS); m.cylY(8, 11, 4, 4, 2.4f, 0); if (icon.contains("gem")) m.set(4, 9, 0, RED); }
            }
            case "herb" -> { m = new VoxModel(8, 10, 8); int c = icon.contains("red") ? Tex.rgb(170, 40, 50) : Tex.rgb(60, 140, 60); m.box(3, 0, 3, 4, 5, 4, Tex.rgb(60, 90, 40)); m.sphere(4, 6, 4, 3.4f, c); m.sphere(2, 8, 3, 1.6f, c); }
            case "key" -> { m = new VoxModel(12, 6, 2); if (icon.contains("card")) { m.box(0, 0, 0, 11, 5, 0, WHITE); m.box(1, 3, 0, 4, 4, 0, Tex.rgb(40, 90, 170)); } else { m.box(0, 1, 0, 3, 4, 1, BRASS); m.box(4, 2, 0, 11, 3, 0, BRASS); m.box(9, 0, 0, 9, 1, 0, BRASS); m.box(11, 0, 0, 11, 1, 0, BRASS); } }
            case "document" -> { m = new VoxModel(10, 2, 12); m.box(0, 0, 0, 9, 0, 11, icon.contains("drive") ? POLY : WHITE); if (!icon.contains("drive")) for (int k = 2; k < 10; k += 2) m.box(1, 1, k, 8, 1, k, Tex.rgb(60, 60, 70)); }
            case "valuable" -> {
                if (icon.contains("cash")) { m = new VoxModel(12, 3, 6); m.box(0, 0, 0, 11, 2, 5, Tex.rgb(110, 140, 90)); m.box(5, 0, 0, 6, 3, 5, WHITE); }
                else if (icon.contains("gpu")) { m = new VoxModel(18, 4, 8); m.box(0, 0, 0, 17, 1, 7, Tex.rgb(30, 90, 50)); m.box(2, 2, 1, 15, 3, 6, POLY); m.cylY(2, 3, 6, 4, 2.2f, METAL); m.cylY(2, 3, 12, 4, 2.2f, METAL); }
                else if (icon.contains("chain") || icon.contains("watch")) { m = new VoxModel(10, 3, 10); for (int k = 0; k < 10; k++) { m.set(k, 0, 0, BRASS); m.set(k, 0, 9, BRASS); m.set(0, 0, k, BRASS); m.set(9, 0, k, BRASS); } if (icon.contains("watch")) { m.box(3, 0, 3, 6, 2, 6, STEEL); m.box(4, 2, 4, 5, 2, 5, WHITE); } }
                else if (icon.contains("artifact")) { m = new VoxModel(6, 14, 6); m.box(2, 0, 2, 3, 13, 3, Tex.rgb(120, 230, 200)); m.box(1, 3, 1, 4, 9, 4, 0xC060D0B0); m.box(2, 0, 2, 3, 13, 3, Tex.rgb(160, 250, 220)); }
                else if (icon.contains("icon_art")) { m = new VoxModel(14, 16, 2); m.box(0, 0, 0, 13, 15, 1, BRASS); m.box(2, 2, 0, 11, 13, 0, Tex.rgb(140, 40, 30)); m.box(5, 9, 0, 8, 12, 0, Tex.rgb(220, 190, 150)); }
                else { m = new VoxModel(8, 6, 6); m.box(0, 0, 0, 7, 5, 5, Tex.rgb(80 + h % 100, 80 + (h >> 3) % 80, 60 + (h >> 5) % 80)); m.box(2, 5, 2, 5, 5, 3, STEEL); }
            }
            case "quest" -> { m = new VoxModel(12, 10, 10); m.box(0, 0, 0, 11, 9, 9, Tex.rgb(150, 120, 80)); m.box(0, 4, 0, 11, 5, 9, Tex.rgb(200, 170, 60)); m.box(5, 0, 0, 6, 9, 9, Tex.rgb(200, 170, 60)); }
            default -> { // materials / tools
                if (icon.contains("fuel")) { m = new VoxModel(10, 14, 6); m.box(0, 0, 0, 9, 11, 5, RED); m.box(2, 12, 2, 7, 13, 3, POLY); }
                else if (icon.contains("oil")) { m = new VoxModel(6, 12, 6); m.cylY(0, 8, 3, 3, 2.6f, Tex.rgb(200, 160, 40)); m.cylY(9, 11, 3, 3, 1f, POLY); }
                else if (icon.contains("scrap") || icon.contains("parts")) { m = new VoxModel(14, 5, 8); m.box(0, 0, 0, 9, 1, 5, METAL_LT); m.box(5, 2, 2, 13, 3, 7, Tex.rgb(130, 80, 50)); m.box(2, 2, 1, 3, 4, 2, STEEL); }
                else if (icon.contains("tape")) { m = new VoxModel(8, 4, 8); m.cylY(0, 3, 4, 4, 3.8f, Tex.rgb(150, 150, 150)); m.cylY(0, 3, 4, 4, 1.8f, 0); }
                else if (icon.contains("circuit") || icon.contains("electrical")) { m = new VoxModel(12, 3, 10); m.box(0, 0, 0, 11, 0, 9, Tex.rgb(30, 110, 60)); m.box(2, 1, 2, 4, 2, 4, POLY); m.box(7, 1, 5, 9, 1, 8, BRASS); }
                else if (icon.contains("repairkit") || icon.contains("camera")) { m = new VoxModel(14, 10, 10); m.box(0, 0, 0, 13, 8, 9, icon.contains("camera") ? POLY : Tex.rgb(170, 50, 40)); m.box(4, 9, 4, 9, 9, 5, METAL); if (icon.contains("camera")) m.cylX(13, 13, 4, 5, 2, GLASS); }
                else { m = new VoxModel(10, 8, 10); int c = Tex.rgb(90 + h % 90, 90 + (h >> 4) % 70, 80 + (h >> 8) % 60); m.box(0, 0, 0, 9, 6, 9, c); m.box(0, 7, 0, 9, 7, 9, Tex.shade(c, 1.2f)); m.box(3, 3, 0, 6, 4, 0, Tex.shade(c, 0.6f)); }
            }
        }
        return m;
    }
}
