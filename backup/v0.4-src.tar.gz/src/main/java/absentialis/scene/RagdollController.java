package absentialis.scene;

import absentialis.anatomy.DamageProcessor;
import absentialis.character.Ragdoll;
import absentialis.character.Rig;
import absentialis.entity.Actor;
import java.util.ArrayList;
import java.util.List;

/**
 * How a body answers a blow, and the hand-over between authored animation and physics.
 *
 * The response is graded by the force of the hit, where it landed and what the character was doing - it is not
 * one flinch animation played on every hit:
 *   a light hit        an additive flinch away from the blow; nothing the character was doing is interrupted
 *   a solid hit        a stagger: movement and the current attack are interrupted for a moment
 *   a leg taken out    loss of balance: the character goes down
 *   a limb broken      partial ragdoll: that limb goes limp and hangs while the rest of the body keeps its animation
 *   a heavy hit        a full knock-down: the living body is handed to the ragdoll with the momentum of the blow,
 *                      lies where physics leaves it, and gets back up if it still can
 *   death              the ragdoll takes the body for good (Raid does this; the pose and wounds carry over)
 * A character already committed to something heavy (a giant winding up) shrugs off what would stagger anyone else.
 */
public final class RagdollController {
    private final Raid raid;
    /** Living characters currently on the ground under physics. */
    private final List<Actor> down = new ArrayList<>();
    public int flinches, staggers, knockdowns, recoveries;

    RagdollController(Raid raid) { this.raid = raid; }

    /** Force thresholds, in damage points of the hit as delivered (before health multipliers). */
    public static final float STAGGER = 24, KNOCKDOWN = 78;

    void react(Actor v, float dx, float dz, float force, int group, int type, Gore.Impact im) {
        if (v.dead || v.isPlayer) return;
        boolean giant = "tank".equals(v.archetype), heavy = giant || "boomer".equals(v.archetype);
        float mass = giant ? 5f : heavy ? 1.8f : 1f;
        // blasts and blunt blows shove; a bullet's push is small for the harm it does
        float shove = force * (type == DamageProcessor.BLAST ? 1.6f : type == DamageProcessor.BLUNT ? 1.25f : type == DamageProcessor.BULLET ? 0.75f : 0.6f) / mass;
        boolean leg = group >= Rig.L_THIGH;
        boolean committed = raid.telegraphing(v, "charge") || raid.telegraphing(v, "throw");
        if (v.ragdoll != null) return;     // already down
        if (shove >= KNOCKDOWN || leg && (im.severed || im.fractured) && !giant || im.severed && group == Rig.HEAD) {
            knockDown(v, dx, dz, shove, leg && (im.severed || im.fractured) ? 1.4f : 2.2f + Math.min(2.5f, shove / 60f));
            return;
        }
        if (shove >= STAGGER && !committed || leg && force > 14 && !heavy) {
            staggers++;
            v.staggerUntil = Math.max(v.staggerUntil, raid.time + (type == DamageProcessor.BLAST ? 1.6f : 0.75f));
            v.fireCooldown = Math.max(v.fireCooldown, 0.45f);            // the attack in progress is lost
            v.burstLeft = 0;
            if (v.anim != null && !v.anim.playing("stumble")) v.anim.play("stumble", type == DamageProcessor.BLAST ? 1.1f : 0.65f);
            // knocked a step in the direction of the blow
            v.vx += dx * Math.min(3f, shove * 0.04f); v.vz += dz * Math.min(3f, shove * 0.04f);
            raid.emitSound(v.x, v.y + 1, v.z, 6, "stagger", v.id, false);
            return;
        }
        flinches++;
        if (v.anim != null) v.anim.hit((float) Math.atan2(dx, dz));
    }

    /** Hands a living character to the ragdoll for a while. */
    public void knockDown(Actor v, float dx, float dz, float shove, float seconds) {
        if (v.dead || v.ragdoll != null || v.isPlayer) return;
        knockdowns++;
        v.hitDirX = dx; v.hitDirZ = dz;
        v.hitForce = Math.max(v.hitForce, shove);
        raid.startRagdoll(v);
        v.downUntil = raid.time + seconds;
        v.fireCooldown = Math.max(v.fireCooldown, seconds + 0.6f);
        v.burstLeft = 0;
        v.vx = v.vz = 0;
        down.add(v);
        raid.emitSound(v.x, v.y + 0.5f, v.z, 9, "body_fall", v.id, false);
    }

    public boolean isDown(Actor a) { return !a.dead && a.ragdoll != null; }

    /** Physics for the living who are down, and getting them back up. */
    void update(float dt) {
        for (int i = down.size() - 1; i >= 0; i--) {
            Actor a = down.get(i);
            if (a.dead || a.ragdoll == null) { down.remove(i); continue; }   // died on the ground: the ragdoll is the corpse now
            Ragdoll r = a.ragdoll;
            if (!r.settled) r.update(raid.world, dt);
            a.x = r.x[Ragdoll.PELVIS]; a.z = r.z[Ragdoll.PELVIS]; a.y = Math.max(0, r.lowestY());
            a.vx = a.vz = 0;
            boolean time = raid.time >= a.downUntil;
            if (!time || !r.settled && raid.time < a.downUntil + 2.5f) continue;
            // back to animation: stand where the body came to rest (or stay down and crawl if the legs will not carry it)
            int gy = raid.groundY((int) Math.floor(a.x), (int) Math.floor(a.z));
            if (gy >= 0 && Math.abs(gy - a.y) < 2.5f) a.y = gy;
            a.ragdoll = null;
            a.staggerUntil = raid.time + 1.1f;
            if (a.anat != null && !a.anat.canWalk) a.crawling = true;
            if (a.anim != null) a.anim.play("stumble", 1.1f);
            a.hasGoal = false; a.path = null;
            recoveries++;
            down.remove(i);
        }
    }
}
