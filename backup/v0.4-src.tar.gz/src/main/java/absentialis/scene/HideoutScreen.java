package absentialis.scene;

import absentialis.gameplay.economy.Economy;
import absentialis.gameplay.inventory.Container;
import absentialis.gameplay.inventory.InventoryService;
import absentialis.gameplay.inventory.Loadout;
import absentialis.gameplay.items.Content;
import absentialis.gameplay.items.ItemDef;
import absentialis.gameplay.items.ItemInstance;
import absentialis.gameplay.missions.Contracts;
import absentialis.gameplay.progression.Challenges;
import absentialis.gameplay.progression.Progression;
import absentialis.gameplay.weapons.Gunsmith;
import absentialis.gameplay.weapons.WeaponService;
import absentialis.persistence.Profile;
import absentialis.persistence.SaveSystem;
import absentialis.sim.ZoneState;
import absentialis.ui.InventoryUi;
import absentialis.ui.Ui;
import absentialis.world.District;
import absentialis.world.MapData;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Hideout menu (addendum P2.4): STAT (rank / challenges / prestige) - INV (stash + case, traders)
 * - MAP (influence) - WORKBENCH (gunsmith + clean, facilities) - CONTRACTS. Screens slide/fade in
 * over 120 ms; the same item instances appear identically in every view.
 */
public final class HideoutScreen {
    public static final String[] TABS = {"RANK", "INVENTORY", "SHOP", "WORKBENCH", "SQUAD", "MAP", "CONTRACTS", "OPERATOR"};
    private static final String[] GLYPHS = {"stat", "inv", "coin", "bench", "radio", "map", "contracts", "star"};
    private final RankPanel rank;
    private final ShopPanel shop;
    private final WorkbenchPanel workbench;
    private final SquadPanel squad;
    private CharacterCreator creator;
    private final Ctx c;
    private final LoadoutPanel panel;
    public int tab;
    private float tabAnim = 1, stashScroll;
    private boolean trade, deployOpen, prestigeOpen, upgradesOpen;
    private String traderId = "mara";
    private ItemInstance benchWeapon;
    private int insertion, minutes = 30;
    public String action;           // "deploy", "settings", "title" for GameApp
    public int deployInsertion;
    public float deployMinutes;

    public HideoutScreen(Ctx c) { this.c = c; this.panel = new LoadoutPanel(c); rank = new RankPanel(c); shop = new ShopPanel(c); workbench = new WorkbenchPanel(c); squad = new SquadPanel(c); }

    private Profile p() { return c.profile; }

    public void enter() {
        tabAnim = 0;
        c.win.setCursorLocked(false);
        p().applyCapacity();
        p().contracts.refill(p().seed ^ p().stat("raids"), p().prog.rank());
        if (c.map.ready()) c.map.rebuildHatch(p().zone);
    }

    public void render(float dt) {
        Ui ui = c.ui;
        int W = c.win.width, H = c.win.height;
        org.lwjgl.opengl.GL11.glViewport(0, 0, W, H);
        org.lwjgl.opengl.GL11.glClearColor(0.05f, 0.055f, 0.05f, 1);
        org.lwjgl.opengl.GL11.glClear(org.lwjgl.opengl.GL11.GL_COLOR_BUFFER_BIT | org.lwjgl.opengl.GL11.GL_DEPTH_BUFFER_BIT);
        ui.b.begin(W, H);
        ui.begin(dt, W, H);
        ui.showCursor = true;
        backdrop(ui);
        tabAnim = Math.min(1, tabAnim + dt / Ui.EASE);
        float ease = 1 - (1 - tabAnim) * (1 - tabAnim);
        boolean modal = deployOpen || rank.modal(p()) || upgradesOpen;
        ui.block = modal;
        header(ui);
        float top = ui.s(118) + (1 - ease) * ui.s(14);
        switch (tab) {
            case 0 -> rank.draw(ui, p(), top);
            case 1 -> inventory(ui, top);
            case 2 -> shop.draw(ui, p(), top);
            case 3 -> { workbench.draw(ui, p(), top); if (ui.button("upgrades", ui.s(36), ui.h - ui.s(24) - ui.s(52), ui.s(266), ui.s(40), "HIDEOUT FACILITIES", "cog", true)) upgradesOpen = true; }
            case 4 -> squad.draw(ui, p(), top);
            case 5 -> map(ui, top);
            case 6 -> contracts(ui, top);
            default -> operator(ui, top);
        }
        if (tabAnim < 1) ui.b.rect(0, top - ui.s(10), W, H, Ui.alpha(0xFF0A0B0A, 1 - ease));
        ui.block = false;
        if (rank.modal(p())) rank.drawModals(ui, p());
        else if (deployOpen) deployModal(ui);
        else if (upgradesOpen) upgradesModal(ui);
        if (tab != 1) { c.inv.flashTime -= dt; if (c.inv.flashTime > 0) { float a = Math.min(1, c.inv.flashTime), fw = ui.tw(c.inv.flash, 16); ui.b.rect(ui.w / 2f - fw / 2 - ui.s(12), ui.h - ui.s(96), fw + ui.s(24), ui.s(30), Ui.alpha(0xD0101010, a)); ui.textC(c.inv.flash, ui.w / 2f, ui.h - ui.s(90), 16, Ui.alpha(c.inv.flashColor, a)); } }
        ui.textR(absentialis.Version.LABEL, ui.w - ui.s(8), ui.h - ui.s(18), 11, Ui.TXT_DIM);
        if (rank.freshStartRequested) freshStart();
        c.console.draw(ui, dt);
        ui.end();
        ui.b.end();
    }

    /** Prestige Award "Fresh Start": the profile is replaced by a brand-new one that keeps only the callsign and the operator's look. */
    private void freshStart() {
        rank.freshStartRequested = false;
        Profile old = p(), np = new Profile();
        np.slot = old.slot; np.name = old.name; np.appearance = old.appearance.copy(); np.seed = old.seed;
        np.starterKit();
        np.contracts.refill(np.seed, 1);
        np.applyCapacity();
        c.profile = np;
        SaveSystem.save(np);
        enter();
        tab = 0;
        c.inv.say("Fresh Start: you are a Private again", Ui.AMBER);
    }

    private void backdrop(Ui ui) {
        // dim bunker: concrete panels and a hanging lamp glow, pixel-snapped bands
        for (int y = 0; y < ui.h; y += ui.s(48)) ui.b.rect(0, y, ui.w, ui.s(47), (y / ui.s(48)) % 2 == 0 ? 0xFF101210 : 0xFF0E100E);
        ui.b.rect(0, 0, ui.w, ui.s(100), 0xFF161816);
        ui.b.rect(0, ui.s(100), ui.w, ui.s(3), 0xFF8A6420);
    }

    private void header(Ui ui) {
        Profile p = p();
        ui.text("ABSENTIALIS", ui.s(24), ui.s(14), 26, Ui.TXT_HI);
        ui.text("v" + absentialis.Version.NUMBER, ui.s(206), ui.s(24), 12, Ui.AMBER);
        ui.text("HIDEOUT  -  Day " + p.zone.day + String.format("  %02d:00", (int) p.zone.hour % 24) + (p.zone.weatherRain > 0.5f ? "  -  Rain" : ""), ui.s(26), ui.s(48), 12, Ui.TXT_DIM);
        // rank chip
        float rx = ui.s(270);
        int g = Math.max(2, ui.s(2));
        ui.glyph(p.prog.master() ? "star" : "chevron", rx, ui.s(16), g, 0xFFFFFFFF);
        ui.text(p.name + "  -  " + p.prog.title(), rx + ui.s(32), ui.s(14), 16, Ui.TXT_HI);
        ui.bar(rx + ui.s(32), ui.s(38), ui.s(200), ui.s(8), p.prog.rankProgress(), 0xFFE2A034);
        ui.glyph("coin", rx + ui.s(250), ui.s(30), g, 0xFFFFFFFF);
        ui.text(absentialis.Version.coins(p.scrip), rx + ui.s(282), ui.s(31), 16, Ui.AMBER);
        ui.glyph("heart", rx + ui.s(420), ui.s(30), g, 0xFFFFFFFF);
        ui.text(Math.round(p.health) + "%", rx + ui.s(452), ui.s(31), 16, p.health < 60 ? Ui.RED : Ui.TXT);
        // tabs
        float tw = Math.min(ui.s(138), (ui.w - ui.s(380)) / TABS.length - ui.s(4)), tx = ui.s(24);
        for (int i = 0; i < TABS.length; i++) if (ui.tab("ht" + i, tx + i * (tw + ui.s(4)), ui.s(62), tw, ui.s(34), TABS[i], GLYPHS[i], tab == i) && tab != i) { tab = i; tabAnim = 0; }
        float bx = ui.w - ui.s(24);
        if (ui.button("deploy", bx - ui.s(170), ui.s(54), ui.s(170), ui.s(42), "DEPLOY", "flag", c.world != null)) { deployOpen = true; }
        if (ui.button("settings", bx - ui.s(170) - ui.s(56), ui.s(54), ui.s(48), ui.s(42), null, "cog", true)) action = "settings";
        if (ui.button("title", bx - ui.s(170) - ui.s(112), ui.s(54), ui.s(48), ui.s(42), null, "arrow", true)) { SaveSystem.save(p()); action = "title"; }
        if (c.world == null) ui.textR("Surveying the Zone...", bx, ui.s(20), 12, Ui.TXT_DIM);
    }

    // ================================================================== OPERATOR (customization)
    private void operator(Ui ui, float top) {
        if (creator == null) creator = new CharacterCreator(c);
        float x = ui.s(24), w = ui.w - ui.s(48), h = ui.h - top - ui.s(24);
        float cy = ui.window("Operator  -  " + p().name, "star", x, top, w, h);
        ui.text("Your look is a set of definition ids: head, hair, facial hair, torso, sleeves, legs, hands, feet and colours. Equipment you wear changes the silhouette on top of it.", x + ui.s(20), cy, 12, Ui.TXT_DIM);
        if (creator.draw(ui, p().appearance, p(), x + ui.s(20), cy + ui.s(30), w - ui.s(40), h - (cy - top) - ui.s(60))) SaveSystem.save(p());
    }

    // ================================================================== INV
    private void inventory(Ui ui, float top) {
        Profile p = p();
        var inv = c.inv;
        inv.begin(34);
        inv.fit(ui.h - top - ui.s(24) - ui.s(44) - ui.s(160), p.loadout.caseGrid.h + (p.loadout.packGrid() == null ? 0 : p.loadout.packGrid().h + 2));
        inv.quickA = p.stash;
        inv.quickB = p.loadout.caseGrid;
        inv.owner = p.loadout;
        inv.allowDrop = false;
        inv.extraActions.clear();
        inv.extraActions.add("quick");
        inv.onAction = (it, act) -> {
            String r = panel.act(p, it, act, p.stash);
            if (r != null) inv.say(r, Ui.TXT);
        };
        float h = ui.h - top - ui.s(24);
        float leftW = p.stash.w * inv.cell + ui.s(40);
        float x0 = ui.s(24);
        float cy = ui.window("Stash  " + p.stash.w + "x" + p.stash.h, "inv", x0, top, leftW, h);
        {
            float gh = h - (cy - top) - ui.s(96);
            int visRows = Math.max(4, (int) (gh / inv.cell));
            stashScroll = Math.max(0, Math.min(p.stash.h - visRows, stashScroll - (float) c.in.scroll * 2));
            float gy = cy + ui.s(26);
            ui.b.scissor((int) x0, (int) gy - 2, (int) leftW, (int) (visRows * inv.cell) + 4);
            inv.grid(p.stash, x0 + ui.s(18), gy - (int) stashScroll * inv.cell, null);
            ui.b.noScissor();
            ui.text("STASH  (scroll)  rows " + (int) stashScroll + "-" + Math.min(p.stash.h, (int) stashScroll + visRows) + " of " + p.stash.h, x0 + ui.s(18), cy, 12, Ui.TXT_DIM);
            float by = gy + visRows * inv.cell + ui.s(10);
            if (ui.button("sortStash", x0 + ui.s(18), by, ui.s(120), ui.s(30), "SORT", "sort", true)) { InventoryService.Result r = InventoryService.autoSort(p.stash); inv.say(r.ok() ? "Stash sorted" : r.msg(), r.ok() ? Ui.GREEN : Ui.RED); }
            boolean broke = p.scrip < 500 && !hasWeapon(p);
            if (ui.button("fallback", x0 + ui.s(146), by, leftW - ui.s(164), ui.s(30), "FALLBACK KIT", "radio", broke && p.lastFallbackDay != p.zone.day)) {
                for (ItemInstance i : Economy.fallbackKit()) InventoryService.add(i, p.stash);
                p.lastFallbackDay = p.zone.day;
                inv.say("Quartermaster issued a fallback kit (no resale value)", Ui.GREEN);
            }
            presets(ui, x0 + ui.s(18), by + ui.s(36), leftW - ui.s(36));
        }
        float rx = x0 + leftW + ui.s(16);
        float rw = panel.width(p.loadout);
        float ry = ui.window("Loadout", "inv", rx, top, rw + ui.s(24), h);
        panel.draw(p, rx + ui.s(12), ry, rw, h - (ry - top) - ui.s(16), p.stash);
        float ix = rx + rw + ui.s(40);
        if (ix + ui.s(260) < ui.w) inv.inspectPanel(ix, top, Math.min(ui.s(320), ui.w - ix - ui.s(24)), h);
        if (c.in.pressed("sort")) InventoryService.autoSort(p.loadout.caseGrid);
        inv.end();
        if (c.in.keyDown(org.lwjgl.glfw.GLFW.GLFW_KEY_F) && inv.hover != null) inv.fullInspect(inv.spin, 0.45f);
    }

    private static boolean hasWeapon(Profile p) {
        for (ItemInstance i : p.allItems()) if (i.def().weapon != null && !i.def().weapon.melee()) return true;
        return false;
    }

    /** Loadout presets: save equipped/case defs; apply pulls matching instances from the stash. */
    private void presets(Ui ui, float x, float y, float w) {
        Profile p = p();
        int n = p.prog.presets();
        float bw = Math.min(ui.s(110), (w - ui.s(8)) / Math.max(1, n));
        for (int i = 0; i < n; i++) {
            boolean has = i < p.presets.size() && p.presets.get(i) != null;
            if (ui.button("preset" + i, x + i * (bw + ui.s(4)), y, bw, ui.s(30), (has ? "LOAD " : "SAVE ") + (i + 1), null, true)) {
                if (ui.shift || !has) { savePreset(i); c.inv.say("Preset " + (i + 1) + " saved (shift+click to overwrite)", Ui.GREEN); }
                else c.inv.say(applyPreset(i), Ui.TXT);
            }
        }
    }

    private void savePreset(int i) {
        Profile p = p();
        Map<String, Object> m = new LinkedHashMap<>();
        for (String s : Loadout.SLOTS) if (p.loadout.slot(s) != null) m.put(s, p.loadout.slot(s).defId);
        List<Object> cs = new ArrayList<>();
        for (ItemInstance it : p.loadout.caseGrid.items) cs.add(it.defId);
        m.put("case", cs);
        while (p.presets.size() <= i) p.presets.add(null);
        p.presets.set(i, m);
    }

    private String applyPreset(int i) {
        Profile p = p();
        Map<String, Object> m = p.presets.get(i);
        int got = 0, miss = 0;
        for (String s : Loadout.SLOTS) {
            Object id = m.get(s);
            if (id == null || p.loadout.slot(s) != null && p.loadout.slot(s).defId.equals(id)) continue;
            ItemInstance found = null;
            for (ItemInstance it : p.stash.items) if (it.defId.equals(id)) { found = it; break; }
            if (found != null && InventoryService.equip(found, p.loadout, s).ok()) got++; else miss++;
        }
        @SuppressWarnings("unchecked") List<Object> cs = (List<Object>) m.getOrDefault("case", List.of());
        List<String> want = new ArrayList<>();
        for (Object o : cs) want.add(String.valueOf(o));
        for (ItemInstance it : p.loadout.caseGrid.items) want.remove(it.defId);
        for (String id : want) {
            ItemInstance found = null;
            for (ItemInstance it : p.stash.items) if (it.defId.equals(id)) { found = it; break; }
            if (found != null && InventoryService.store(found, p.loadout).ok()) got++; else miss++;
        }
        return "Preset applied: " + got + " moved" + (miss > 0 ? ", " + miss + " missing from stash" : "");
    }

    // ================================================================== MAP
    private void map(Ui ui, float top) {
        Profile p = p();
        float h = ui.h - top - ui.s(24), s = Math.min(h - ui.s(60), ui.w * 0.55f);
        float x = ui.s(24);
        float cy = ui.window("Zone Map  -  Influence", "map", x, top, s + ui.s(28), h);
        if (!c.map.ready()) { ui.text("Map is being drawn...", x + ui.s(20), cy, 14, Ui.TXT_DIM); return; }
        c.map.draw(ui, p, x + ui.s(14), cy, s, s, 0, 0, absentialis.world.World.W, null, Float.NaN, 0, 0, true);
        float x2 = x + s + ui.s(46), w2 = ui.w - x2 - ui.s(24);
        float cy2 = ui.window("District Intel", "radio", x2, top, w2, h);
        String[] fn = {"MIL", "RAI", "SUR", "CUL"};
        int[] fc = {0xFF7A8A5A, 0xFFB0503A, 0xFF5A80B0, 0xFF9A3A6A};
        for (District d : District.CITY) {
            String ctl = p.zone.controller(d);
            ui.text(d.display.toUpperCase(), x2 + ui.s(16), cy2, 14, Ui.TXT_HI);
            ui.textR(ctl == null ? "CONTESTED" : ctl.toUpperCase(), x2 + w2 - ui.s(16), cy2, 12, ctl == null ? Ui.AMBER : Ui.TXT);
            cy2 += ui.s(20);
            float bw = w2 - ui.s(32);
            float bx = x2 + ui.s(16);
            float tot = 0;
            for (int f = 0; f < 4; f++) tot += p.zone.influence[d.ordinal()][f];
            for (int f = 0; f < 4; f++) {
                float fw = bw * p.zone.influence[d.ordinal()][f] / Math.max(0.01f, tot);
                ui.b.rect(bx, cy2, fw, ui.s(10), fc[f]);
                if (fw > ui.s(30)) ui.text(fn[f], bx + ui.s(3), cy2 - ui.s(1), 9, 0xFF0A0A0A);
                bx += fw;
            }
            cy2 += ui.s(14);
            ui.text(String.format("Infected %d%%   Food %d%%   Medicine %d%%   Ammo %d%%   %s", Math.round(p.zone.infected[d.ordinal()] * 100),
                    Math.round(p.zone.supply[d.ordinal()][0] * 100), Math.round(p.zone.supply[d.ordinal()][2] * 100), Math.round(p.zone.supply[d.ordinal()][3] * 100),
                    p.zone.power[d.ordinal()] ? "POWER ON" : "no power"), x2 + ui.s(16), cy2, 11, Ui.TXT_DIM);
            cy2 += ui.s(26);
        }
        ui.text("NEWS", x2 + ui.s(16), cy2, 14, Ui.TXT_HI);
        cy2 += ui.s(22);
        if (p.zone.news.isEmpty()) ui.text("Quiet. For now.", x2 + ui.s(16), cy2, 12, Ui.TXT_DIM);
        for (String n : p.zone.news) { if (cy2 > top + h - ui.s(30)) break; ui.text(n, x2 + ui.s(16), cy2, 11, Ui.TXT); cy2 += ui.s(17); }
    }

    private static final String[][] FACILITIES = {
            {"workbench", "Workbench", "3", "Unlocks crafting tiers (ammo, repair kits, flares)"},
            {"medical", "Medical Bay", "3", "Cheaper treatment, medical crafting"},
            {"kitchen", "Kitchen", "2", "Water purification and cooking"},
            {"radio", "Radio Room", "2", "L1: exits on the map  L2: known infected nests"},
            {"stash", "Stash Racks", "3", "+4 stash rows per level"}};

    public static int upgradeCost(int nextLevel) { return (int) (1500 * Math.pow(nextLevel, 1.6)); }

    private void upgradesModal(Ui ui) {
        Profile p = p();
        ui.b.rect(0, 0, ui.w, ui.h, 0xC0000000);
        float w = ui.s(680), h = ui.s(120) + FACILITIES.length * ui.s(62), x = (ui.w - w) / 2, y = (ui.h - h) / 2;
        float cy = ui.window("Hideout Facilities", "cog", x, y, w, h);
        for (String[] f : FACILITIES) {
            int lvl = p.hideout.getOrDefault(f[0], 0), max = Integer.parseInt(f[2]);
            ui.text(f[1] + "  -  level " + p.level(f[0]) + (p.level(f[0]) != lvl ? " (token +1)" : ""), x + ui.s(20), cy, 14, Ui.TXT_HI);
            ui.text(f[3], x + ui.s(20), cy + ui.s(19), 11, Ui.TXT_DIM);
            int cost = upgradeCost(lvl + 1);
            boolean can = lvl < max && p.scrip >= cost;
            if (ui.button("up" + f[0], x + w - ui.s(210), cy, ui.s(190), ui.s(38), lvl >= max ? "MAXED" : "UPGRADE " + absentialis.Version.coins(cost), null, can)) {
                p.scrip -= cost;
                p.hideout.put(f[0], lvl + 1);
                p.applyCapacity();
                c.sfx("ui_buy", 0.7f);
                SaveSystem.save(p);
            }
            cy += ui.s(62);
        }
        // facility crafting
        if (ui.button("upclose", x + w - ui.s(150), y + h - ui.s(52), ui.s(130), ui.s(38), "CLOSE", "cross", true)) upgradesOpen = false;
        if (ui.button("upcraft", x + ui.s(20), y + h - ui.s(52), ui.s(300), ui.s(38), "CRAFT AT FACILITIES", "bench", true)) { upgradesOpen = false; craftOpen = !craftOpen; }
        if (c.in.keyPressed(org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE)) upgradesOpen = false;
    }

    private boolean craftOpen;

    // ================================================================== CONTRACTS
    private void contracts(Ui ui, float top) {
        Profile p = p();
        float h = ui.h - top - ui.s(24), w = (ui.w - ui.s(64)) / 2;
        float x = ui.s(24);
        float cy = ui.window("Contract Board", "contracts", x, top, w, h);
        for (Contracts.Contract k : new ArrayList<>(p.contracts.board)) {
            if (cy > top + h - ui.s(110)) break;
            contractCard(ui, k, x + ui.s(14), cy, w - ui.s(28), false);
            cy += ui.s(104);
        }
        float x2 = x + w + ui.s(16);
        float cy2 = ui.window("Active (" + p.contracts.active.size() + "/" + Contracts.MAX_ACTIVE + ")", "check", x2, top, w, h);
        if (p.contracts.active.isEmpty()) ui.text("No active contracts. Pay comes on extraction.", x2 + ui.s(16), cy2, 13, Ui.TXT_DIM);
        for (Contracts.Contract k : new ArrayList<>(p.contracts.active)) { contractCard(ui, k, x2 + ui.s(14), cy2, w - ui.s(28), true); cy2 += ui.s(104); }
        if (craftOpen) facilityCraft(ui, x2 + ui.s(14), cy2 + ui.s(10), w - ui.s(28));
    }

    private void contractCard(Ui ui, Contracts.Contract k, float x, float y, float w, boolean active) {
        ui.nine("slot", x, y, w, ui.s(96), 0xFFFFFFFF);
        ui.text(k.title, x + ui.s(12), y + ui.s(8), 15, Ui.TXT_HI);
        ui.textR(ZoneState.cap(k.giver), x + w - ui.s(12), y + ui.s(8), 12, Ui.AMBER);
        ui.text(k.desc, x + ui.s(12), y + ui.s(30), 12, Ui.TXT);
        ui.text("+" + absentialis.Version.coins(k.scrip) + "   +" + k.xp + " XP   +" + (int) k.rep + " rep", x + ui.s(12), y + ui.s(50), 12, Ui.GREEN);
        if (active) {
            ui.bar(x + ui.s(12), y + ui.s(74), w - ui.s(150), ui.s(10), k.have / (float) Math.max(1, k.need), 0xFFE2A034);
            ui.text(k.have + "/" + k.need, x + w - ui.s(132), y + ui.s(70), 12, Ui.TXT);
            if (ui.button("ab" + k.id, x + w - ui.s(90), y + ui.s(62), ui.s(80), ui.s(28), "DROP", null, true)) p().contracts.abandon(k.id);
        } else if (ui.button("ac" + k.id, x + w - ui.s(110), y + ui.s(58), ui.s(100), ui.s(30), "ACCEPT", "check", p().contracts.active.size() < Contracts.MAX_ACTIVE)) {
            String e = p().contracts.accept(k.id);
            if (e != null) c.inv.say(e, Ui.RED); else c.sfx("ui_click", 0.5f);
        }
    }

    private void facilityCraft(Ui ui, float x, float y, float w) {
        Profile p = p();
        ui.text("FACILITY CRAFTING (uses carried + stash materials moved to your case)", x, y, 13, Ui.TXT_HI);
        float ry = y + ui.s(22);
        for (Content.Recipe r : Content.RECIPES) {
            if (r.where.equals("field") || r.where.equals("treasure")) continue;
            if (ry > ui.h - ui.s(60)) break;
            boolean lvl = p.level(r.facility()) >= r.level();
            boolean can = lvl && LoadoutPanel.canCraft(p, r);
            ui.text(r.name + "  (" + r.facility() + " " + r.level() + ")", x, ry, 12, can ? Ui.TXT_HI : Ui.TXT_DIM);
            if (ui.button("fc" + r.id, x + w - ui.s(90), ry - ui.s(4), ui.s(86), ui.s(26), "CRAFT", null, can)) { String e = LoadoutPanel.craft(p, r); c.inv.say(e == null ? "Crafted " + r.name : e, e == null ? Ui.GREEN : Ui.RED); }
            ry += ui.s(30);
        }
    }

    /** Scripted visual verification: open a shop department, or the operation briefing. */
    public void debugShow(int shopDept, boolean briefing) { if (shopDept >= 0) { tab = 2; shop.show(shopDept); } deployOpen = briefing; }

    // ================================================================== DEPLOY
    private void deployModal(Ui ui) {
        Profile p = p();
        ui.b.rect(0, 0, ui.w, ui.h, 0xD8000000);
        List<MapData.Point> ins = c.world.map.insertions;
        if (insertion >= ins.size()) insertion = 0;
        float w = Math.min(ui.s(1040), ui.w - ui.s(40)), h = Math.min(ui.s(600), ui.h - ui.s(40)), x = (ui.w - w) / 2, y = (ui.h - h) / 2;
        float pad = ui.s(24);
        ui.shadow(x, y, w, h, 0xA0);
        ui.b.rect(x, y, w, h, 0xFF0E1011);
        ui.b.outline(x, y, w, h, 2, 0xFF8A6420);
        // ---- title strip
        ui.b.rect(x + 2, y + 2, w - 4, ui.s(58), 0xFF16181B);
        ui.b.rect(x + 2, y + ui.s(58), w - 4, ui.s(2), Ui.AMBER);
        ui.glyph("flag", x + pad, y + ui.s(16), Math.max(2, ui.s(2)), 0xFFFFFFFF);
        ui.text("OPERATION BRIEFING", x + pad + ui.s(36), y + ui.s(10), 24, Ui.TXT_HI);
        ui.text("Choose where you go in and how long you stay. Everything you carry is at risk.", x + pad + ui.s(38), y + ui.s(38), 11, Ui.TXT_DIM);
        float top = y + ui.s(78), bottom = y + h - ui.s(78);

        // ---- left: insertion points, one card each
        float lw = w * 0.56f - pad * 1.5f, lx = x + pad;
        ui.text("1   INSERTION POINT", lx, top, 12, Ui.AMBER);
        float cardH = Math.min(ui.s(74), (bottom - top - ui.s(24)) / Math.max(1, ins.size()) - ui.s(8)), cy = top + ui.s(24);
        for (int i = 0; i < ins.size(); i++) {
            MapData.Point pt = ins.get(i);
            String ctl = p.zone.controller(pt.district);
            float inf = p.zone.infected[pt.district.ordinal()];
            boolean sel = insertion == i, hov = ui.hover(lx, cy, lw, cardH);
            float k = ui.ease("depins" + i, hov || sel);
            ui.b.rect(lx, cy, lw, cardH, sel ? 0xFF2A2416 : Ui.mix(0xFF14161A, 0xFF1E2024, k));
            ui.b.rect(lx, cy, ui.s(4), cardH, sel ? Ui.AMBER : 0xFF4A4436);
            if (sel) ui.b.outline(lx, cy, lw, cardH, 1, 0xFF8A6420);
            ui.text(pt.name, lx + ui.s(18), cy + cardH * 0.5f - ui.s(22), 16, sel ? Ui.TXT_HI : Ui.TXT);
            ui.text(pt.district.display + "   -   " + (ctl == null ? "contested ground" : "held by " + ctl), lx + ui.s(18), cy + cardH * 0.5f + ui.s(4), 11, ctl == null ? Ui.TXT_DIM : Ui.TXT);
            // infection pressure: the one number that changes how the first minute goes
            float bw = ui.s(120), bx = lx + lw - bw - ui.s(18);
            int col = inf > 0.66f ? Ui.RED : inf > 0.33f ? Ui.AMBER : Ui.GREEN;
            ui.textR("INFECTED " + Math.round(inf * 100) + "%", lx + lw - ui.s(18), cy + cardH * 0.5f - ui.s(18), 11, col);
            ui.bar(bx, cy + cardH * 0.5f + ui.s(4), bw, ui.s(6), inf, col);
            if (hov && ui.click && !ui.consumed) { ui.consumed = true; insertion = i; if (ui.sound != null) ui.sound.accept("ui_tab"); }
            cy += cardH + ui.s(8);
        }

        // ---- right: length, vehicle, element, readiness
        float rx = x + w * 0.56f + pad * 0.5f, rw = x + w - pad - rx, ry = top;
        ui.b.rect(rx - pad * 0.5f, top, 1, bottom - top, 0xFF2E2A22);
        ui.text("2   TIME ON THE GROUND", rx, ry, 12, Ui.AMBER);
        ry += ui.s(24);
        int[] lens = {25, 30, 35, 45};
        float sw = (rw - ui.s(18)) / lens.length;
        for (int i = 0; i < lens.length; i++) if (ui.tab("len" + i, rx + i * (sw + ui.s(6)), ry, sw, ui.s(34), lens[i] + " MIN", null, minutes == lens[i])) minutes = lens[i];
        ry += ui.s(42);
        ui.text("The cordon closes when the clock runs out. Miss it and you are missing in action.", rx, ry, 11, Ui.TXT_DIM);
        ry += ui.s(30);

        ui.text("3   VEHICLE", rx, ry, 12, Ui.AMBER);
        ry += ui.s(24);
        List<String> rides = new java.util.ArrayList<>();
        rides.add("");
        for (String g : p.garage) if (absentialis.vehicle.CarHandlingData.get(g) != null) rides.add(g);
        int ri = Math.max(0, rides.indexOf(p.deployVehicle));
        boolean many = rides.size() > 1;
        if (ui.button("depvl", rx, ry, ui.s(34), ui.s(34), "<", null, many)) { p.deployVehicle = rides.get((ri + rides.size() - 1) % rides.size()); c.sfx("ui_tab", 0.5f); }
        if (ui.button("depvr", rx + rw - ui.s(34), ry, ui.s(34), ui.s(34), ">", null, many)) { p.deployVehicle = rides.get((ri + 1) % rides.size()); c.sfx("ui_tab", 0.5f); }
        ui.b.rect(rx + ui.s(40), ry, rw - ui.s(80), ui.s(34), 0xFF14161A);
        absentialis.vehicle.CarHandlingData ride = p.deployVehicle.isEmpty() ? null : absentialis.vehicle.CarHandlingData.get(p.deployVehicle);
        ui.textC(ride == null ? "ON FOOT" : ride.name.toUpperCase(), rx + rw / 2, ry + ui.s(8), 15, ride == null ? Ui.TXT : Ui.TXT_HI);
        ry += ui.s(42);
        ui.text(ride != null ? ride.family + " - parked by the insertion point. Lost if you do not come back." : many ? "Use the arrows to bring a vehicle from your garage." : "No vehicles owned. The SHOP sells them under VEHICLES.", rx, ry, 11, Ui.TXT_DIM);
        ry += ui.s(30);

        ui.text("4   ELEMENT", rx, ry, 12, Ui.AMBER);
        ry += ui.s(22);
        List<absentialis.gameplay.squad.Roster.Mate> act = p.squad.active();
        if (act.isEmpty()) { ui.text("You are going in alone. Squadmates are assigned on the SQUAD tab.", rx, ry, 11, Ui.TXT_DIM); ry += ui.s(20); }
        else {
            float nx = rx;
            for (absentialis.gameplay.squad.Roster.Mate m : act) {
                String nm = absentialis.gameplay.squad.Roster.shortName(m.name);
                float tw = ui.tw(nm, 12) + ui.s(26);
                if (nx + tw > rx + rw) { nx = rx; ry += ui.s(26); }
                ui.b.rect(nx, ry, tw - ui.s(6), ui.s(22), 0xFF16181B);
                ui.b.rect(nx, ry, ui.s(4), ui.s(22), "red".equals(m.team) ? Ui.RED : Ui.BLUE);
                ui.text(nm, nx + ui.s(10), ry + ui.s(4), 12, Ui.TXT);
                nx += tw;
            }
            ry += ui.s(30);
        }

        // readiness: the things people forget, said once, in one place
        boolean armed = p.loadout.slot("primary") != null || p.loadout.slot("sidearm") != null;
        int bandage = 0, antiviral = 0;
        for (absentialis.gameplay.items.ItemInstance it : p.loadout.all()) { if (it.defId.equals("med.antiviral")) antiviral += it.qty; else if (it.def().medical != null) bandage += it.qty; }
        ry += ui.s(4);
        ui.text("READINESS", rx, ry, 12, Ui.AMBER);
        ry += ui.s(22);
        ry = ready(ui, rx, ry, armed, armed ? "Firearm equipped" : "No firearm equipped");
        ry = ready(ui, rx, ry, p.health >= 50, p.health >= 50 ? "Fit to deploy (" + Math.round(p.health) + "%)" : "Deploying injured (" + Math.round(p.health) + "%)");
        ry = ready(ui, rx, ry, bandage > 0, bandage > 0 ? "Medical supplies packed" : "No medical supplies packed");
        ready(ui, rx, ry, antiviral > 0, antiviral > 0 ? "Antiviral Medicine x" + antiviral : "No Antiviral Medicine - a bite will turn you");

        // ---- footer
        ui.b.rect(x + 2, bottom + ui.s(14), w - 4, 1, 0xFF2E2A22);
        String sum = ins.get(insertion).name + "   -   " + minutes + " min   -   " + (act.isEmpty() ? "solo" : "you + " + act.size()) + (ride == null ? "" : "   -   " + ride.name) + (p.ironman ? "   -   IRONMAN: death is permanent" : "");
        ui.text(sum, x + pad, bottom + ui.s(36), 12, p.ironman ? Ui.RED : Ui.TXT);
        float bw2 = ui.s(230);
        if (ui.button("go", x + w - pad - bw2, bottom + ui.s(24), bw2, ui.s(42), "DEPLOY", "flag", true) || c.in.keyPressed(org.lwjgl.glfw.GLFW.GLFW_KEY_ENTER)) {
            deployOpen = false;
            action = "deploy";
            deployInsertion = insertion;
            deployMinutes = minutes;
            SaveSystem.save(p);
        }
        if (ui.button("dcancel", x + w - pad - bw2 - ui.s(150), bottom + ui.s(24), ui.s(140), ui.s(42), "CANCEL", "cross", true) || c.in.keyPressed(org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE)) deployOpen = false;
    }

    private float ready(Ui ui, float x, float y, boolean ok, String text) {
        ui.glyph(ok ? "check" : "cross", x, y - ui.s(2), Math.max(1, ui.s(1)), ok ? Ui.GREEN : Ui.RED);
        ui.text(text, x + ui.s(22), y, 12, ok ? Ui.TXT : Ui.RED);
        return y + ui.s(20);
    }
}
