package absentialis.ai;

import absentialis.entity.Actor;
import absentialis.entity.Physics;
import absentialis.scene.Raid;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * What a squad knows together - which is not what each of its members knows.
 *
 * The squad's picture of the fight is built only from what members report: a sighting (confirmed), a sound or a
 * body (suspected), a loss of contact. A report reaches the others when it can: at once for anyone in earshot of
 * the speaker, after a moment on the radio for factions that carry radios, and not at all for a raider on the far
 * side of a building. Until it reaches them, they act on what they personally know.
 *
 * The mind also keeps the things only a group can keep: who is doing what (roles), which ground has already been
 * searched and by whom, where the next places to look are, how many have gone down and how often the quarry has
 * slipped away - which is what makes a squad cautious, or frustrated.
 */
public final class SquadMind {
    // ---- the shared picture (last report)
    public float tx, ty, tz, tvx, tvz, tTime = -99, tConfidence;
    public boolean tConfirmed;
    public int targetId, reportedBy;
    /** When the squad as a whole last had eyes on, and when it lost them. */
    public float lastEyes = -99, lostAt = -99;
    public boolean inContact;
    /** Where the quarry has been staying put, and since when (a static target invites a flank and a grenade). */
    public float anchorX, anchorZ, staticSince = -99;
    // ---- group memory
    public int casualties, escapes, wounded;
    public float alertUntil = -99, rolesAt = -99, lastSpeech = -99, grenadeAt = -99, flankedAt = -99, lastCasualty = -99;
    public int meleeHolder;
    public float meleeUntil;
    /** Ground already looked at during this search: cell -> when. */
    public final Map<Long, Float> cleared = new HashMap<>();
    /** Places still to look: {x, z, score, claimedBy}. */
    public final List<float[]> searchPoints = new ArrayList<>();
    public float searchX, searchZ, searchRadius, searchBuilt = -99;
    /** Counters for tests and the debug overlay. */
    public int reports, relays, roleChanges, searchesBuilt;

    public static long cell(float x, float z) { return ((long) Math.floor(x / 4f) << 32) ^ ((long) Math.floor(z / 4f) & 0xFFFFFFFFL); }

    /** Factions whose members carry radios hear a report wherever they are, a moment later. */
    public static boolean radio(String faction) { return "military".equals(faction) || "mercenaries".equals(faction); }

    /** A member tells the squad where the target is (seen) or might be (heard, inferred). */
    public void report(Raid r, Actor by, float x, float y, float z, float vx, float vz, int target, boolean confirmed, float confidence) {
        // an unconfirmed guess never overwrites a fresh sighting
        if (!confirmed && tConfirmed && r.time - tTime < 3) return;
        if (confirmed) {
            if (!inContact) { inContact = true; staticSince = r.time; anchorX = x; anchorZ = z; }
            float moved = Math.abs(x - anchorX) + Math.abs(z - anchorZ);
            if (moved > 3.5f) { anchorX = x; anchorZ = z; staticSince = r.time; }
            lastEyes = r.time;
        }
        tx = x; ty = y; tz = z; tvx = vx; tvz = vz; tTime = r.time; tConfirmed = confirmed; tConfidence = confidence;
        targetId = target; reportedBy = by.id;
        reports++;
    }

    /** Can this member have heard the last report yet? */
    public boolean reaches(Raid r, Actor a) {
        if (a.id == reportedBy) return false;
        if (radio(a.faction)) return r.time - tTime > 1.1f;
        Actor by = r.actor(reportedBy);
        return by != null && !by.dead && a.dist(by) < 26;
    }

    public void clear(float x, float z, float time) { cleared.put(cell(x, z), time); }
    public boolean wasCleared(float x, float z, float time) { Float t = cleared.get(cell(x, z)); return t != null && time - t < 90; }

    /**
     * Works out where a target that vanished from (x, z) heading (vx, vz) could be hiding: standable places within
     * the radius that cannot be seen from where it was lost, favouring the way it was going, corners and doorways,
     * and ground nobody has checked.
     */
    public void buildSearch(Raid r, float x, float y, float z, float vx, float vz, float radius) {
        searchPoints.clear();
        searchX = x; searchZ = z; searchRadius = radius; searchBuilt = r.time;
        searchesBuilt++;
        float vl = (float) Math.sqrt(vx * vx + vz * vz);
        for (int k = 0; k < 46; k++) {
            float ang = k * 2.399963f + r.rng.nextFloat() * 0.4f, rad = 3.5f + (radius - 3.5f) * (float) Math.sqrt((k + 0.5f) / 46f);
            float px = (float) Math.floor(x + Math.sin(ang) * rad) + 0.5f, pz = (float) Math.floor(z + Math.cos(ang) * rad) + 0.5f;
            int gy = r.groundY((int) px, (int) pz);
            if (gy < 0 || Math.abs(gy - y) > 4.5f || !Physics.boxFree(r.world, px, gy, pz, 0.3f, 1.8f)) continue;
            float score = r.rng.nextFloat() * 0.6f;
            // out of sight of where they vanished: that is where someone hides
            if (!Physics.los(r.world, x, y + 1.5f, z, px, gy + 0.9f, pz)) score += 2.2f;
            // enclosed places: corners, doorways, between things
            int walls = 0;
            int ix = (int) Math.floor(px), iz = (int) Math.floor(pz);
            if (r.world.solid(ix + 1, gy + 1, iz)) walls++;
            if (r.world.solid(ix - 1, gy + 1, iz)) walls++;
            if (r.world.solid(ix, gy + 1, iz + 1)) walls++;
            if (r.world.solid(ix, gy + 1, iz - 1)) walls++;
            score += Math.min(2, walls) * 0.7f;
            if (vl > 0.5f) score += Math.max(0, ((px - x) * vx + (pz - z) * vz) / (rad * vl)) * 1.8f;
            if (wasCleared(px, pz, r.time)) score -= 3.5f;
            score -= rad * 0.05f;
            searchPoints.add(new float[]{px, pz, score, 0});
        }
        searchPoints.sort((p, q) -> Float.compare(q[2], p[2]));
        while (searchPoints.size() > 14) searchPoints.remove(searchPoints.size() - 1);
    }

    /** The best place to look that nobody else has taken, weighed against how far it is from this member. */
    public float[] claim(Raid r, Actor a) {
        float[] best = null;
        float bs = -1e9f;
        for (float[] p : searchPoints) {
            if (p[3] != 0 && p[3] != a.id) { Actor o = r.actor((int) p[3]); if (o != null && !o.dead && "search".equals(o.state)) continue; }
            if (wasCleared(p[0], p[1], r.time)) continue;
            float s = p[2] - a.distXZ(p[0], p[1]) * 0.07f;
            if (s > bs) { bs = s; best = p; }
        }
        if (best != null) best[3] = a.id;
        return best;
    }

    /** How wary the squad has become: casualties and near things make everyone slower to commit. */
    public float caution(float time) { return Math.min(1f, casualties * 0.3f + wounded * 0.1f + (time - lastCasualty < 20 ? 0.3f : 0)); }
}
