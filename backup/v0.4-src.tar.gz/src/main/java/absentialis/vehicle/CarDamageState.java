package absentialis.vehicle;

/**
 * Physical condition of one car: its four tyres, how far each part of the body has been pushed in, and what the
 * engine has left. Impacts arrive from the rigid body with a magnitude (the speed change they caused) and the
 * place on the chassis they landed; this class turns them into deformation of the zone that was hit. The visual
 * model is rebuilt from these numbers (see {@link CarVisualController}); the physics reads only the tyres and the
 * engine.
 */
public final class CarDamageState {
    public static final int FRONT = 0, REAR = 1, LEFT = 2, RIGHT = 3, ROOF = 4, ZONES = 5;
    public static final String[] ZONE = {"front", "rear", "left side", "right side", "roof"};

    public final CarWheel.Tyre[] tyres = {CarWheel.Tyre.INTACT, CarWheel.Tyre.INTACT, CarWheel.Tyre.INTACT, CarWheel.Tyre.INTACT};
    /** Deformation per zone, 0 (factory) .. 1 (crushed). */
    public final float[] deform = new float[ZONES];
    /** Engine condition 1 .. 0: below 0.5 it loses power, at 0 it will not run. */
    public float engine = 1;
    /** Strongest impact so far and the last one, in m/s of speed change (exposed for the wider condition system). */
    public float worstImpact, lastImpact;
    public int impacts, lastZone = -1;
    public boolean windscreen = true, rearGlass = true;
    public boolean lightL = true, lightR = true;
    /** Bumped whenever something the model shows has changed: the visual controller rebuilds on a new value. */
    public int version;

    /** Deformation as one of four visible steps (0 none .. 3 wrecked). */
    public int level(int zone) { return Math.min(3, (int) (deform[zone] * 3.999f)); }
    public int burstCount() { int n = 0; for (CarWheel.Tyre t : tyres) if (t == CarWheel.Tyre.BURST) n++; return n; }
    public float enginePower() { return engine <= 0 ? 0 : engine < 0.5f ? 0.45f + engine * 1.1f : 1f; }

    /** Which zone a point on the chassis belongs to, from where it sits relative to the car's half extents. */
    public static int zoneOf(float lx, float ly, float lz, float halfW, float halfL, float height) {
        float fx = Math.abs(lx) / Math.max(0.1f, halfW), fz = Math.abs(lz) / Math.max(0.1f, halfL);
        if (ly > height * 0.82f && fx < 0.9f && fz < 0.75f) return ROOF;
        if (fz >= fx * 0.92f) return lz > 0 ? FRONT : REAR;
        return lx < 0 ? LEFT : RIGHT;
    }

    /**
     * An impact that changed the car's speed by dv (m/s) at a chassis point. Scrapes and kerb strikes below
     * 2 m/s leave no mark. Returns the zone that took it, or -1.
     */
    public int impact(float dv, float lx, float ly, float lz, CarHandlingData d, float roll) {
        lastImpact = dv;
        if (dv < 2f) return -1;
        impacts++;
        worstImpact = Math.max(worstImpact, dv);
        int zone = zoneOf(lx, ly, lz, d.width / 2, d.length / 2, d.height);
        int before = level(zone);
        float add = (dv - 2f) * 0.055f * d.collisionDamage;
        deform[zone] = Math.min(1, deform[zone] + add);
        // a frontal hit reaches the engine; any heavy hit shakes it
        if (zone == FRONT) engine = Math.max(0, engine - add * 0.7f);
        else if (dv > 9) engine = Math.max(0, engine - add * 0.15f);
        boolean changed = level(zone) != before;
        if (zone == FRONT && deform[FRONT] > 0.3f && windscreen && roll > 0.5f) { windscreen = false; changed = true; }
        if (zone == FRONT && deform[FRONT] > 0.45f) { if (lx < 0 && lightL) { lightL = false; changed = true; } if (lx >= 0 && lightR) { lightR = false; changed = true; } }
        if (zone == REAR && deform[REAR] > 0.4f && rearGlass) { rearGlass = false; changed = true; }
        if (zone == ROOF && deform[ROOF] > 0.25f && windscreen) { windscreen = false; rearGlass = false; changed = true; }
        if (changed) version++;
        lastZone = zone;
        return zone;
    }

    public boolean burst(int wheel) {
        if (tyres[wheel] == CarWheel.Tyre.BURST) return false;
        tyres[wheel] = CarWheel.Tyre.BURST;
        version++;
        return true;
    }

    /** A bullet through the bodywork. Returns true when it mattered (glass, a lamp, the engine). */
    public boolean shot(float lx, float ly, float lz, CarHandlingData d, float damage) {
        int zone = zoneOf(lx, ly, lz, d.width / 2, d.length / 2, d.height);
        if (zone == FRONT && ly < d.height * 0.6f) { engine = Math.max(0, engine - damage * 0.0016f); return true; }
        if (ly > d.height * 0.6f && zone == FRONT && windscreen) { windscreen = false; version++; return true; }
        if (ly > d.height * 0.6f && zone == REAR && rearGlass) { rearGlass = false; version++; return true; }
        return false;
    }
}
