package absentialis.world.gen;

import static absentialis.world.gen.Gen.FLOOR_H;

import absentialis.engine.util.Rng;
import absentialis.world.Block;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Dresses generated rooms by type: floor finish, furniture against walls, centre pieces, ceiling
 * lights, decay (blood, cobwebs, debris) and loot containers placed by location logic
 * (kitchens -> food, clinics -> medicine, workshops -> parts, barracks -> military materiel).
 */
public final class Interiors {
    private final Gen g;
    public Interiors(Gen g) { this.g = g; }

    public void dress(Buildings.Room room, Buildings.Spec s, Rng r) {
        if (room.w() < 2 || room.d() < 2) return;
        if (room.type == null) room.type = pickType(room, s, r);
        int y = room.y;
        // floor finish
        int floorBlock = floorFor(room.type, r);
        if (floorBlock > 0) {
            for (int x = room.x0; x <= room.x1; x++) for (int z = room.z0; z <= room.z1; z++) {
                int c = g.get(x, y, z);
                if (c != Block.AIR && c != Block.STAIRS_CONCRETE && c != Block.STAIRS_WOOD && c != Block.LADDER && !Block.ALL[c].is(Block.STEP)) g.set(x, y, z, floorBlock);
            }
        }
        List<int[]> wallCells = wallCells(room);
        Collections.shuffle(wallCells, new java.util.Random(r.nextLong()));
        int cx = (room.x0 + room.x1) / 2, cz = (room.z0 + room.z1) / 2;

        switch (room.type) {
            case "living":
                place(wallCells, y, Block.SOFA, 2); place(wallCells, y, Block.TV, 1); place(wallCells, y, Block.BOOKSHELF, 1, "residential");
                place(wallCells, y, Block.CABINET, 1, "residential");
                if (free(cx, y, cz)) { g.set(cx, y + 1, cz, Block.TABLE); if (free(cx + 1, y, cz)) g.set(cx + 1, y + 1, cz, Block.CHAIR); }
                break;
            case "kitchen":
                place(wallCells, y, Block.COUNTER, 3); place(wallCells, y, Block.STOVE, 1); place(wallCells, y, Block.SINK, 1);
                place(wallCells, y, Block.FRIDGE, 1, "food"); place(wallCells, y, Block.CABINET, 2, "food");
                if (free(cx, y, cz) && room.area() > 12) { g.set(cx, y + 1, cz, Block.TABLE); if (free(cx, y, cz + 1)) g.set(cx, y + 1, cz + 1, Block.CHAIR); }
                break;
            case "bedroom":
                placeBed(wallCells, y, r);
                place(wallCells, y, Block.CABINET, 1, "residential"); place(wallCells, y, Block.BOOKSHELF, r.chance(0.4) ? 1 : 0);
                if (r.chance(0.15)) place(wallCells, y, Block.SAFE, 1, "safe");
                break;
            case "bathroom":
                place(wallCells, y, Block.TOILET, 1); place(wallCells, y, Block.SINK, 1); place(wallCells, y, Block.MED_CABINET, 1, "medical_home");
                break;
            case "storage":
                place(wallCells, y, Block.CRATE, 2 + r.nextInt(2), s.lootBias); place(wallCells, y, Block.SHELF, 1, s.lootBias);
                place(wallCells, y, Block.BARREL, 1);
                break;
            case "store":
                // aisle shelving + counter
                for (int x = room.x0 + 2; x <= room.x1 - 2; x += 3) for (int z = room.z0 + 2; z <= room.z1 - 2; z++) if (free(x, y, z) && r.chance(0.85)) g.container(x, y + 1, z, Block.SHELF, s.lootBias != null ? s.lootBias : "store");
                place(wallCells, y, Block.COUNTER, 3); place(wallCells, y, Block.CABINET, 1, "store"); place(wallCells, y, Block.FRIDGE, 1, "food");
                break;
            case "pharmacy":
                for (int x = room.x0 + 2; x <= room.x1 - 2; x += 3) for (int z = room.z0 + 1; z <= room.z1 - 1; z++) if (free(x, y, z) && r.chance(0.7)) g.container(x, y + 1, z, Block.SHELF, "medical");
                place(wallCells, y, Block.MED_CABINET, 3, "medical"); place(wallCells, y, Block.COUNTER, 2);
                break;
            case "office":
                for (int i = 0; i < Math.max(1, room.area() / 14); i++) {
                    int x = room.x0 + 1 + r.nextInt(Math.max(1, room.w() - 2)), z = room.z0 + 1 + r.nextInt(Math.max(1, room.d() - 2));
                    if (free(x, y, z)) { g.container(x, y + 1, z, Block.DESK, "office"); if (r.chance(0.6) && free(x, y, z + 1)) g.set(x, y + 1, z + 1, Block.CHAIR); if (r.chance(0.5)) g.setIfAir(x, y + 2, z, Block.COMPUTER); }
                }
                place(wallCells, y, Block.FILING, 2, "office"); place(wallCells, y, Block.BOOKSHELF, 1, "office");
                if (r.chance(0.25)) docOnDesk(room, y, r);
                break;
            case "meeting":
                for (int x = room.x0 + 2; x <= room.x1 - 2; x++) for (int z = cz; z <= cz + 1 && z <= room.z1 - 1; z++) if (free(x, y, z)) g.set(x, y + 1, z, Block.TABLE);
                place(wallCells, y, Block.MAP_BOARD, 0); place(wallCells, y, Block.CHAIR, 4);
                if (r.chance(0.35)) docOnDesk(room, y, r);
                break;
            case "server":
                for (int x = room.x0 + 1; x <= room.x1 - 1; x += 2) for (int z = room.z0 + 1; z <= room.z1 - 1; z++) if (free(x, y, z)) { g.set(x, y + 1, z, Block.MACHINE); g.set(x, y + 2, z, Block.COMPUTER); }
                place(wallCells, y, Block.RADIO_SET, 1, "tech");
                break;
            case "ward":
                for (int i = 0; i < wallCells.size() && i < room.area() / 5; i++) { int[] c = wallCells.get(i); if (free(c[0], y, c[1])) { g.set(c[0], y + 1, c[1], Block.HOSPITAL_BED); } }
                place(wallCells, y, Block.MED_CABINET, 1, "medical");
                if (r.chance(0.3)) g.container(cx, y + 1, cz, Block.BODYBAG, "body");
                break;
            case "exam":
                if (free(cx, y, cz)) g.set(cx, y + 1, cz, Block.HOSPITAL_BED);
                place(wallCells, y, Block.MED_CABINET, 2, "medical"); place(wallCells, y, Block.SINK, 1); place(wallCells, y, Block.DESK, 1, "office");
                if (r.chance(0.3)) docOnDesk(room, y, r);
                break;
            case "operating":
                if (free(cx, y, cz)) g.set(cx, y + 1, cz, Block.HOSPITAL_BED);
                place(wallCells, y, Block.MACHINE, 2); place(wallCells, y, Block.MED_CABINET, 2, "medical_rare");
                for (int i = 0; i < 4; i++) bloodAt(room.x0 + r.nextInt(room.w()), y, room.z0 + r.nextInt(room.d()));
                break;
            case "workshop":
                place(wallCells, y, Block.MACHINE, 2); place(wallCells, y, Block.TOOLBOX, 2, "industrial"); place(wallCells, y, Block.SHELF, 2, "industrial");
                place(wallCells, y, Block.COUNTER, 2); place(wallCells, y, Block.BARREL, 2);
                if (free(cx, y, cz)) g.set(cx, y + 1, cz, Block.TABLE);
                break;
            case "hall":
                for (int x = room.x0 + 2; x <= room.x1 - 2; x += 4) for (int z = room.z0 + 2; z <= room.z1 - 2; z++) {
                    if (!free(x, y, z) || z % 6 == 0) continue;
                    int h = 1 + r.nextInt(3);
                    g.container(x, y + 1, z, Block.SHELF, s.lootBias != null ? s.lootBias : "industrial");
                    for (int k = 2; k <= h; k++) g.setIfAir(x, y + k, z, Block.SHELF);
                }
                for (int i = 0; i < room.area() / 40; i++) {
                    int x = room.x0 + 1 + r.nextInt(Math.max(1, room.w() - 2)), z = room.z0 + 1 + r.nextInt(Math.max(1, room.d() - 2));
                    if (!free(x, y, z)) continue;
                    if (r.chance(0.5)) g.container(x, y + 1, z, Block.CRATE, s.lootBias); else { g.set(x, y + 1, z, Block.BARREL); }
                    if (r.chance(0.4)) g.setIfAir(x, y + 2, z, Block.CRATE);
                }
                break;
            case "dorm":
                for (int i = 0; i < wallCells.size() && i < room.area() / 4; i++) { int[] c = wallCells.get(i); if (free(c[0], y, c[1])) g.set(c[0], y + 1, c[1], Block.BED); }
                place(wallCells, y, Block.LOCKER, 3, "military_personal");
                break;
            case "armory":
                place(wallCells, y, Block.WEAPON_RACK, 2, "weapons"); place(wallCells, y, Block.CRATE_MIL, 3, "military"); place(wallCells, y, Block.LOCKER, 2, "military");
                break;
            case "lab":
                for (int x = room.x0 + 2; x <= room.x1 - 2; x += 3) for (int z = room.z0 + 2; z <= room.z1 - 2; z += 4) if (free(x, y, z)) { g.set(x, y + 1, z, Block.COUNTER); g.setIfAir(x, y + 2, z, Block.COMPUTER); }
                place(wallCells, y, Block.MED_CABINET, 2, "medical_rare"); place(wallCells, y, Block.BIOHAZARD, 1); place(wallCells, y, Block.FILING, 1, "lab");
                if (r.chance(0.5)) docOnDesk(room, y, r);
                if (r.chance(0.4)) g.set(cx, y, cz, Block.TOXIC);
                break;
            case "chapel":
                for (int x = room.x0 + 2; x <= room.x1 - 2; x += 2) for (int z = room.z0 + 3; z <= room.z1 - 3; z += 2) if (free(x, y, z)) g.set(x, y + 1, z, Block.PEW);
                break;
            case "basement":
                place(wallCells, y, Block.CRATE, 3, s.lootBias); place(wallCells, y, Block.SHELF, 2, "residential"); place(wallCells, y, Block.BARREL, 2);
                for (int x = room.x0; x <= room.x1; x += 4) g.setIfAir(x, y + 3, room.z0, Block.PIPE);
                break;
            default:
                place(wallCells, y, Block.CRATE, 1, s.lootBias); place(wallCells, y, Block.CABINET, 1, "residential");
        }
        // trash and decay
        if (r.chance(0.35)) place(wallCells, y, Block.TRASH, 1, "trash");
        if (r.chance(0.2)) bloodAt(room.x0 + r.nextInt(room.w()), y, room.z0 + r.nextInt(room.d()));
        if (r.chance(0.3)) cobweb(room, y, r);
        // ceiling light
        if (r.chance(s.lit ? 0.65 : 0.25) && room.area() >= 6) {
            int lx = cx, lz = cz;
            if (g.air(lx, y + FLOOR_H - 1, lz) && g.air(lx, y + 1, lz) && g.get(lx, y + FLOOR_H, lz) != 0) g.lamp(lx, y + FLOOR_H - 1, lz);
        }
    }

    private String pickType(Buildings.Room room, Buildings.Spec s, Rng r) {
        int a = room.area();
        switch (s.style) {
            case SHOP:
                if (room.floor == 0) return s.lootBias != null && s.lootBias.startsWith("medical") ? "pharmacy" : "store";
                // fallthrough to residential above shops
            case RESIDENTIAL:
            case HOUSE:
                if (a <= 9) return r.chance(0.6) ? "bathroom" : "storage";
                if (a <= 20) return r.pick(new String[]{"kitchen", "bedroom", "bedroom", "bathroom"});
                return r.pick(new String[]{"living", "living", "kitchen", "bedroom"});
            case OFFICE: return a < 10 ? "server" : (a > 50 ? "office" : r.pick(new String[]{"office", "office", "meeting", "office"}));
            case WAREHOUSE: return "hall";
            case WORKSHOP: return room.floor == 0 ? "workshop" : r.pick(new String[]{"office", "storage", "workshop"});
            case CLINIC: return a < 12 ? "exam" : r.pick(new String[]{"ward", "exam", "pharmacy"});
            case HOSPITAL: return a < 12 ? "exam" : (a > 60 ? "ward" : r.pick(new String[]{"ward", "ward", "exam", "operating", "office"}));
            case BARRACKS: return a < 14 ? "armory" : r.pick(new String[]{"dorm", "dorm", "armory", "office"});
            case LAB: return a < 10 ? "server" : r.pick(new String[]{"lab", "lab", "office", "storage"});
            case CHAPEL: return "chapel";
            default: return "storage";
        }
    }

    private static int floorFor(String type, Rng r) {
        switch (type) {
            case "kitchen": return Block.TILE_CHECKER;
            case "bathroom": return Block.TILE_WHITE;
            case "living": return r.chance(0.5) ? Block.PARQUET : Block.CARPET_RED;
            case "bedroom": return r.chance(0.5) ? Block.CARPET_BLUE : Block.PARQUET;
            case "office": case "meeting": return Block.CARPET_GRAY;
            case "server": return Block.TILE_GRAY;
            case "ward": case "exam": return Block.LINOLEUM;
            case "operating": case "lab": return Block.TILE_GREEN;
            case "pharmacy": case "store": return Block.LINOLEUM;
            case "hall": case "workshop": case "storage": case "basement": return Block.CONCRETE_FLOOR;
            case "dorm": case "armory": return Block.CONCRETE_FLOOR;
            case "chapel": return Block.STONE_BLOCK;
            default: return -1;
        }
    }

    /** Wall-adjacent interior cells (candidates for furniture). */
    private List<int[]> wallCells(Buildings.Room room) {
        List<int[]> l = new ArrayList<>();
        for (int x = room.x0; x <= room.x1; x++) for (int z = room.z0; z <= room.z1; z++) {
            if (x == room.x0 || x == room.x1 || z == room.z0 || z == room.z1) l.add(new int[]{x, z});
        }
        return l;
    }

    /** A cell is free if empty, floored, away from stairs/doors/openings. */
    private boolean free(int x, int y, int z) {
        if (!g.air(x, y + 1, z) || !g.air(x, y + 2, z)) return false;
        int below = g.get(x, y, z);
        if (below == 0 || Block.ALL[below].is(Block.STEP) || below == Block.LADDER) return false;
        for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) {
            int c = g.get(x + dx, y + 1, z + dz);
            Block b = Block.ALL[c];
            if (b.is(Block.DOOR) || b.is(Block.STEP) || c == Block.LADDER || c == Block.BARRICADE) return false;
            if (g.get(x + dx, y, z + dz) == 0) return false; // hole (stairwell) nearby
            if ((dx == 0) != (dz == 0)) {
                // gap in a wall line = doorway or broken window: keep clear
                int up = g.get(x + dx, y + 2, z + dz);
                if (c == 0 && up == 0 && isWallLine(x + dx, y, z + dz, dx, dz)) return false;
            }
        }
        return true;
    }

    private boolean isWallLine(int x, int y, int z, int dx, int dz) {
        // an opening is part of a wall if the cells beside it (perpendicular) are solid
        int px = dz != 0 ? 1 : 0, pz = dx != 0 ? 1 : 0;
        return Block.ALL[g.get(x + px, y + 1, z + pz)].solid() && Block.ALL[g.get(x - px, y + 1, z - pz)].solid();
    }

    private void place(List<int[]> cells, int y, int block, int count) { place(cells, y, block, count, null); }

    private void place(List<int[]> cells, int y, int block, int count, String loot) {
        int placed = 0;
        for (int i = 0; i < cells.size() && placed < count; i++) {
            int[] c = cells.get(i);
            if (!free(c[0], y, c[1])) continue;
            if (Block.ALL[block].is(Block.CONTAINER) || loot != null && Block.ALL[block].is(Block.CONTAINER)) g.container(c[0], y + 1, c[1], block, loot);
            else g.set(c[0], y + 1, c[1], block);
            cells.remove(i);
            i--;
            placed++;
        }
    }

    private void placeBed(List<int[]> cells, int y, Rng r) {
        for (int i = 0; i < cells.size(); i++) {
            int[] c = cells.get(i);
            if (!free(c[0], y, c[1])) continue;
            g.set(c[0], y + 1, c[1], Block.BED);
            for (int[] d : new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) if (free(c[0] + d[0], y, c[1] + d[1])) { g.set(c[0] + d[0], y + 1, c[1] + d[1], Block.BED); break; }
            cells.remove(i);
            return;
        }
    }

    private void docOnDesk(Buildings.Room room, int y, Rng r) {
        for (int k = 0; k < 8; k++) {
            int x = room.x0 + r.nextInt(room.w()), z = room.z0 + r.nextInt(room.d());
            if (free(x, y, z)) {
                g.container(x, y + 1, z, Block.DESK, "office");
                g.document("doc", x, y + 1, z);
                return;
            }
        }
    }

    private void bloodAt(int x, int y, int z) {
        int c = g.get(x, y, z);
        if (c == Block.CONCRETE_FLOOR || c == Block.TILE_WHITE || c == Block.LINOLEUM || c == Block.TILE_GREEN || c == Block.TILE_GRAY) g.set(x, y, z, Block.BLOOD_FLOOR);
    }

    private void cobweb(Buildings.Room room, int y, Rng r) {
        int x = r.chance(0.5) ? room.x0 : room.x1, z = r.chance(0.5) ? room.z0 : room.z1;
        g.setIfAir(x, y + FLOOR_H - 1, z, Block.COBWEB);
    }
}
