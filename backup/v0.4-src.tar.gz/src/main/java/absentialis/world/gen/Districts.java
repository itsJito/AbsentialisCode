package absentialis.world.gen;

import static absentialis.world.gen.Gen.FLOOR_H;
import static absentialis.world.gen.Gen.G;

import absentialis.engine.util.Rng;
import absentialis.world.Block;
import absentialis.world.gen.Buildings.Roof;
import absentialis.world.gen.Buildings.Spec;
import absentialis.world.gen.Buildings.Style;
import absentialis.world.gen.Streets.Rect;
import java.util.ArrayList;
import java.util.List;

/**
 * District layouts. Each district has its own street grain, building typology, materials,
 * damage state, faction footprint and landmark set so the five areas read and play differently.
 */
public final class Districts {
    private final Gen g;
    private final Streets st;
    private final Buildings b;
    private final Landmarks lm;

    interface SpecMaker { Spec make(int x0, int z0, int w, int d, boolean[] street, Rng r); }

    private final Authored au;

    public Districts(Gen g, Streets st) { this.g = g; this.st = st; this.b = new Buildings(g); this.lm = new Landmarks(g); this.au = new Authored(g, lm); }

    private static boolean overlaps(Rect a, Rect c) { return a.x0() < c.x1() && c.x0() < a.x1() && a.z0() < c.z1() && c.z0() < a.z1(); }
    private static boolean overlapsAny(Rect a, List<Rect> l) { for (Rect c : l) if (overlaps(a, c)) return true; return false; }

    /** Splits an area with a forced N-S street (aligned to a bridge) then grids both halves. */
    private List<Rect> gridWithForced(Rect area, int fx0, int fx1, int sw, int minB, int maxB, Streets.Style style, Rng r) {
        List<Rect> out = new ArrayList<>();
        if (fx0 > area.x0() && fx1 < area.x1()) {
            st.road(new Rect(fx0, area.z0(), fx1, area.z1()), false, Streets.Style.STREET);
            if (fx0 - area.x0() >= minB) out.addAll(CityGenerator.grid(g, st, new Rect(area.x0(), area.z0(), fx0, area.z1()), sw, minB, maxB, style, r));
            if (area.x1() - fx1 >= minB) out.addAll(CityGenerator.grid(g, st, new Rect(fx1, area.z0(), area.x1(), area.z1()), sw, minB, maxB, style, r));
        } else out.addAll(CityGenerator.grid(g, st, area, sw, minB, maxB, style, r));
        return out;
    }

    // ------------------------------------------------------------------ lot subdivision
    /** Lots around the block perimeter (row houses / perimeter blocks) leaving an inner courtyard. */
    private Rect perimeterLots(Rect blk, int minD, int maxD, int minW, int maxW, float gapChance, SpecMaker mk, Rng r) {
        int W = blk.w(), D = blk.d();
        if (W < minW + 2 || D < minW + 2) return null;
        int dn = Math.min(r.range(minD, maxD), D / 2), ds = Math.min(r.range(minD, maxD), D - dn);
        if (D < minD * 2 + 3) { ds = 0; dn = D; }
        // north & south rows span the full width
        List<int[]> tops = new ArrayList<>();
        row(blk.x0(), blk.z0(), blk.x1(), dn, true, 0, minW, maxW, gapChance, mk, r, tops);
        if (ds > 0) row(blk.x0(), blk.z1() - ds, blk.x1(), ds, true, 2, minW, maxW, gapChance, mk, r, tops);
        int cz0 = blk.z0() + dn, cz1 = blk.z1() - ds;
        if (ds > 0 && cz1 - cz0 >= minW) {
            int dw = Math.min(r.range(minD, maxD), W / 2), de = Math.min(r.range(minD, maxD), W - dw);
            if (W < minD * 2 + 3) { de = 0; dw = W; }
            col(blk.x0(), cz0, cz1, dw, 3, minW, maxW, gapChance, mk, r);
            if (de > 0) col(blk.x1() - de, cz0, cz1, de, 1, minW, maxW, gapChance, mk, r);
            if (de > 0 && W - dw - de >= 3) return new Rect(blk.x0() + dw, cz0, blk.x1() - de, cz1);
        }
        return null;
    }

    private void row(int x0, int z0, int x1, int depth, boolean horizontal, int side, int minW, int maxW, float gap, SpecMaker mk, Rng r, List<int[]> tops) {
        int x = x0;
        int prevTop = -1, prevEnd = -1;
        while (x1 - x >= minW) {
            int w = Math.min(r.range(minW, maxW), x1 - x);
            if (x1 - (x + w) < minW) w = x1 - x;
            if (r.chance(gap) && w < x1 - x - minW) { // alley gap
                int gw = 2 + r.nextInt(2);
                alley(x, z0, x + gw, z0 + depth, side == 0 ? 0 : 2, r);
                x += gw;
                continue;
            }
            boolean[] s = new boolean[4];
            s[side] = true;
            if (x == x0) s[3] = true;
            if (x + w == x1) s[1] = true;
            Spec sp = mk.make(x, z0, w, depth, s, r);
            if (sp != null) {
                b.build(sp);
                int top = G - 1 + sp.floors * FLOOR_H;
                if (prevEnd >= 0 && x - prevEnd >= 2 && x - prevEnd <= 3 && prevTop > 0 && r.chance(0.6)) plankBridge(prevEnd, x, z0 + depth / 2, Math.min(prevTop, top) + 1);
                prevTop = top; prevEnd = x + w;
            } else yard(x, z0, x + w, z0 + depth, r);
            x += w;
        }
    }

    private void col(int x0, int z0, int z1, int depth, int side, int minW, int maxW, float gap, SpecMaker mk, Rng r) {
        int z = z0;
        while (z1 - z >= minW) {
            int w = Math.min(r.range(minW, maxW), z1 - z);
            if (z1 - (z + w) < minW) w = z1 - z;
            if (r.chance(gap) && w < z1 - z - minW) {
                int gw = 2 + r.nextInt(2);
                alley(x0, z, x0 + depth, z + gw, side == 3 ? 3 : 1, r);
                z += gw;
                continue;
            }
            boolean[] s = new boolean[4];
            s[side] = true;
            Spec sp = mk.make(x0, z, depth, w, s, r);
            if (sp != null) b.build(sp); else yard(x0, z, x0 + depth, z + w, r);
            z += w;
        }
    }

    private void plankBridge(int xa, int xb, int z, int y) {
        for (int x = xa - 1; x <= xb; x++) for (int k = 0; k < 2; k++) if (g.air(x, y, z + k)) g.set(x, y - 1 + 0, z + k, g.air(x, y - 1, z + k) ? Block.WOOD_PLANKS : g.get(x, y - 1, z + k));
    }

    private void alley(int x0, int z0, int x1, int z1, int side, Rng r) {
        for (int x = x0; x < x1; x++) for (int z = z0; z < z1; z++) {
            g.set(x, G - 1, z, Rng.hash(x, 0, z, 9) < 0.2f ? Block.MUD : Block.CONCRETE_FLOOR);
            g.fill(x, G, z, x, G + 30, z, Block.AIR);
        }
        // one dumpster per alley, tucked against the wall at the back end - never in the walking line
        int cz = (z0 + z1) / 2;
        boolean deep = (z1 - z0) >= (x1 - x0);
        int dx = deep ? x0 : (side == 3 ? x1 - 1 : x0), dz = deep ? (side == 0 ? z1 - 1 : z0) : z0;
        if (g.air(dx, G, dz)) g.container(dx, G, dz, (x0 + z0) % 3 == 0 ? Block.TRASH : Block.DUMPSTER, "trash");
        if ((x0 + z0) % 4 == 0) g.setIfAir(x0, G + 6, cz, Block.LAUNDRY);
    }

    private void yard(int x0, int z0, int x1, int z1, Rng r) {
        // an empty lot: beaten earth with a grass verge round the edge; at most one parked wreck, square to the lot
        for (int x = x0; x < x1; x++) for (int z = z0; z < z1; z++) {
            boolean edge = x == x0 || z == z0 || x == x1 - 1 || z == z1 - 1;
            g.set(x, G - 1, z, edge ? Block.GRASS : Block.DIRT);
            g.fill(x, G, z, x, G + 30, z, Block.AIR);
            if (edge && (x + z) % 3 == 0) g.set(x, G, z, Block.TALL_GRASS);
        }
        if (x1 - x0 >= 6 && z1 - z0 >= 6 && r.chance(0.35)) g.car(x0 + 2, z0 + 2, (x1 - x0) > (z1 - z0), Block.CAR_RUST, true);
        else if (x1 - x0 >= 4 && z1 - z0 >= 4) g.tree((x0 + x1) / 2, G, (z0 + z1) / 2, 5, r.chance(0.3));
    }

    // ================================================================== OLD QUARTER
    public void oldQuarter(Rect a) {
        Rng r = g.rng("oldquarter");
        Rect cathedral = new Rect(176, 140, 230, 226);
        Rect cemetery = new Rect(240, 170, 300, 226);
        List<Rect> reserved = List.of(cathedral, cemetery);
        List<Rect> blocks = CityGenerator.grid(g, st, a, 7, 22, 34, Streets.Style.STREET, r);
        int[] walls = {Block.STONE_BLOCK, Block.PLASTER_OCHRE, Block.GRANITE, Block.PLASTER, Block.BRICK_BROWN, Block.CONCRETE_PANEL, Block.BRICK_YELLOW};
        SpecMaker mk = (x0, z0, w, d, s, rr) -> {
            if (w < 6 || d < 6) return null;
            Spec sp = new Spec(x0, z0, w, d);
            sp.street = s;
            // dense and vertical: shops and arcades under offices and flats, a few old houses left between
            boolean front = s[0] || s[1] || s[2] || s[3];
            sp.floors = rr.range(4, 9);
            sp.style = front && rr.chance(0.65) ? Style.SHOP : (rr.chance(0.5) ? Style.OFFICE : Style.RESIDENTIAL);
            sp.shopfront = sp.style == Style.SHOP;
            sp.wall = rr.pick(walls);
            sp.trim = rr.chance(0.5) ? Block.STONE_DARK : Block.CONCRETE;
            sp.roof = Block.ROOF_TAR;
            sp.roofType = sp.floors <= 4 && rr.chance(0.4) ? Roof.PITCHED : Roof.FLAT;
            if (sp.roofType == Roof.PITCHED) sp.roof = Block.ROOF_SLATE;
            sp.window = sp.style == Style.OFFICE ? Block.GLASS_BLUE : Block.GLASS_DIRTY;
            sp.windowSpacing = 2;
            sp.balconies = sp.style == Style.RESIDENTIAL && rr.chance(0.5);
            sp.fireEscape = rr.chance(0.5);
            sp.slab = Block.CONCRETE_FLOOR;
            sp.broken = 0.3f; sp.boarded = 0.15f;
            sp.damage = rr.chance(0.15) ? rr.range(0.2f, 0.5f) : 0;
            sp.burnt = rr.chance(0.04);
            sp.basement = rr.chance(0.3);
            sp.lootBias = sp.style == Style.SHOP ? (rr.chance(0.25) ? "antique" : "store") : sp.style == Style.OFFICE ? "office" : null;
            return sp;
        };
        // two authored commercial anchors take the first blocks big enough for them
        Rect store = null, north = null;
        for (Rect blk : blocks) {
            if (overlapsAny(blk, reserved)) continue;
            if (store == null && blk.w() >= 26 && blk.d() >= 24 && blk.x0() > 230) { store = blk; continue; }
            if (north == null && blk.w() >= 24 && blk.d() >= 24 && blk.x0() < 170 && blk.z0() < 170) north = blk;
        }
        if (store != null) au.departmentStore(store, r);
        if (north != null) { lm.tower(north, 14, false, r); g.landmark("Meridian North Tower", "tower", north.cx(), G, north.cz()); }
        final Rect storeF = store, northF = north;
        blocks.removeIf(blk -> blk == storeF || blk == northF);
        for (Rect blk : blocks) {
            if (overlapsAny(blk, reserved)) {
                // build only the parts outside the reserved landmark
                continue;
            }
            Rect court = perimeterLots(blk, 9, 13, 8, 14, 0.12f, mk, r);
            if (court != null) courtyard(court, r, true);
        }
        // fill the fringes of blocks that touch landmarks with small houses
        for (Rect blk : blocks) if (overlapsAny(blk, reserved)) {
            for (Rect res : reserved) if (overlaps(blk, res)) {
                if (blk.z0() < res.z0() - 8) rowSafe(new Rect(blk.x0(), blk.z0(), blk.x1(), Math.min(blk.z1(), res.z0() - 2)), mk, r);
                if (blk.z1() > res.z1() + 8) rowSafe(new Rect(blk.x0(), res.z1() + 2, blk.x1(), blk.z1()), mk, r);
            }
        }
        lm.cathedral(cathedral, r);
        lm.cemetery(cemetery, r);
        g.post("Downtown Patrol", "patrol", "mercenaries", 280, G, 120);
        g.post("Arcade Lanes", "patrol", "mercenaries", 140, G, 200);
        g.post("North Avenue Picket", "checkpoint", "military", 300, G, 240);
        au.roadblock(350, 180, false, 4, "military");
        g.landmark("Downtown", "district", 210, G, 120);
    }

    private void rowSafe(Rect r0, SpecMaker mk, Rng r) {
        if (r0.w() < 5 || r0.d() < 5) { yard(r0.x0(), r0.z0(), r0.x1(), r0.z1(), r); return; }
        List<int[]> tops = new ArrayList<>();
        row(r0.x0(), r0.z0(), r0.x1(), r0.d(), true, 0, 5, 9, 0.1f, mk, r, tops);
    }

    private void arch(Streets.Road rd, Rng r) {
        Rect rc = rd.r();
        int len = rd.alongX() ? rc.w() : rc.d();
        if (len < 14) return;
        int p = 5 + r.nextInt(len - 10);
        int y0 = G + 5;
        for (int k = -1; k < (rd.alongX() ? rc.d() : rc.w()) + 1; k++) {
            int x = rd.alongX() ? rc.x0() + p : rc.x0() + k, z = rd.alongX() ? rc.z0() + k : rc.z0() + p;
            for (int t = 0; t < 2; t++) {
                int xx = x + (rd.alongX() ? t : 0), zz = z + (rd.alongX() ? 0 : t);
                g.set(xx, y0, zz, Block.STONE_BLOCK);
                g.set(xx, y0 + 1, zz, Block.AIR); g.set(xx, y0 + 2, zz, Block.AIR);
                g.set(xx, y0 + 3, zz, Block.ROOF_TILES);
            }
            if (k == -1 || k == (rd.alongX() ? rc.d() : rc.w())) {
                // punch through into the facing buildings
                g.set(x, y0 + 1, z, Block.AIR); g.set(x, y0 + 2, z, Block.AIR);
            }
        }
        for (int t = 0; t < 2; t++) {
            int x = rd.alongX() ? rc.x0() + p + t : rc.x0(), z = rd.alongX() ? rc.z0() : rc.z0() + p + t;
            int x2 = rd.alongX() ? x : rc.x1() - 1, z2 = rd.alongX() ? rc.z1() - 1 : z;
            g.set(x, y0 + 1, z, Block.STONE_CARVED); g.set(x2, y0 + 1, z2, Block.STONE_CARVED);
        }
    }

    private void courtyard(Rect c, Rng r, boolean oldQuarter) {
        for (int x = c.x0(); x < c.x1(); x++) for (int z = c.z0(); z < c.z1(); z++) {
            g.fill(x, G, z, x, G + 30, z, Block.AIR);
            float h = Rng.hash(x, 4, z, 19);
            // courtyards read as designed spaces: a paved ring round a planted centre
            boolean ring = x == c.x0() || z == c.z0() || x == c.x1() - 1 || z == c.z1() - 1;
            g.set(x, G - 1, z, ring ? (oldQuarter ? Block.COBBLE : Block.CONCRETE_FLOOR) : Block.GRASS);
            if (!ring && h > 0.93f) g.set(x, G, z, Block.TALL_GRASS);
        }
        if (c.w() >= 5 && c.d() >= 5) {
            g.tree(c.cx(), G, c.cz(), 5 + r.nextInt(3), r.chance(0.5));
            g.container(c.x0(), G, c.z0(), Block.TRASH, null);                              // the bin by the entrance, every yard
            if (c.w() >= 7) { g.set(c.cx() - 2, G, c.cz(), Block.PEW); g.set(c.cx() + 2, G, c.cz(), Block.PEW); }   // benches face the tree
            if (oldQuarter && r.chance(0.2)) lm.shrine(c.x0() + 2, c.z1() - 2, r);
            if (!oldQuarter) for (int k = 0; k < 3; k++) { int y = G + 4 + k * FLOOR_H; for (int x = c.x0(); x < c.x1(); x++) if ((x + k) % 3 != 0) g.setIfAir(x, y, c.z0() + 1 + k * 2 % Math.max(1, c.d() - 2), Block.LAUNDRY); }
            if (!oldQuarter && r.chance(0.3)) g.nest(c.cx() + 1, G, c.cz() + 1);
        }
    }

    // ================================================================== MARKET WARD
    public void market(Rect north, Rect south) {
        Rng r = g.rng("market");
        int[] walls = {Block.BRICK_RED, Block.BRICK_YELLOW, Block.PLASTER, Block.BRICK_WHITE, Block.PLASTER_BLUE, Block.BRICK_BROWN, Block.PLASTER_OCHRE};
        SpecMaker mk = (x0, z0, w, d, s, rr) -> {
            if (w < 7 || d < 7) return null;
            Spec sp = new Spec(x0, z0, w, d);
            sp.street = s;
            // panel housing: five- and nine-storey slabs, a corner shop here and there at street level
            sp.floors = rr.chance(0.4) ? 9 : rr.range(5, 6);
            boolean streetFront = s[0] || s[1] || s[2] || s[3];
            sp.style = streetFront && rr.chance(0.22) ? Style.SHOP : Style.RESIDENTIAL;
            sp.shopfront = sp.style == Style.SHOP;
            if (sp.style == Style.SHOP && rr.chance(0.15)) sp.lootBias = "medical";
            sp.wall = sp.floors >= 9 ? Block.CONCRETE_PANEL : rr.pick(walls);
            sp.trim = rr.chance(0.6) ? Block.CONCRETE : Block.BRICK_WHITE;
            sp.window = Block.GLASS_DIRTY;
            sp.windowSpacing = 2;
            sp.balconies = rr.chance(0.75);
            sp.fireEscape = rr.chance(0.45);
            sp.broken = 0.25f; sp.boarded = 0.2f;
            sp.damage = rr.chance(0.18) ? rr.range(0.2f, 0.6f) : 0;
            sp.burnt = rr.chance(0.05);
            sp.basement = rr.chance(0.2);
            sp.slab = Block.CONCRETE_FLOOR;
            return sp;
        };
        List<Rect> blocks = new ArrayList<>();
        blocks.addAll(gridWithForced(north, 164, 176, 9, 28, 40, Streets.Style.STREET, r));
        blocks.addAll(gridWithForced(south, 164, 176, 9, 30, 44, Streets.Style.STREET, r));
        // authored civic blocks: bazaar and haven in the south, the school and the polyclinic in the north
        Rect bazaar = null, haven = null, school = null, clinic = null;
        for (Rect blk : blocks) {
            if (blk.z0() >= 400 && blk.z0() < 470 && blk.w() >= 26 && bazaar == null && blk.x0() > 170) { bazaar = blk; continue; }
            if (blk.z0() >= 500 && blk.w() >= 30 && blk.d() >= 30 && haven == null) { haven = blk; continue; }
            if (blk.z0() < 344 && blk.w() >= 28 && blk.d() >= 28 && school == null && blk.x0() < 164) { school = blk; continue; }
            if (blk.z0() >= 360 && blk.z0() < 400 && blk.w() >= 26 && blk.d() >= 26 && clinic == null && blk.x0() < 164) clinic = blk;
        }
        for (Rect blk : blocks) {
            if (blk == bazaar) { lm.bazaar(blk, r); continue; }
            if (blk == haven) { lm.haven(blk, r); continue; }
            if (blk == school) { au.school(blk, r); continue; }
            if (blk == clinic) { au.polyclinic(blk, r); continue; }
            Rect court = perimeterLots(blk, 10, 14, 9, 16, 0.12f, mk, r);
            if (court != null) courtyard(court, r, false);
        }
        // awnings + neon over shopfronts on carriageway-facing sidewalks
        awnings(new Rect(104, 256, 244, 600), r);
        // pharmacy landmark & market posts
        g.post("Microdistrict Watch", "patrol", "survivors", 200, G, 300);
        g.post("South Blocks Watch", "patrol", "survivors", 140, G, 450);
        g.post("Raider Lookout", "sniper", "raiders", 120, G + 20, 380);
        // fringe breach approach: barricaded western street with a burnt bus
        g.truck(108, 430, false, Block.CAR_RUST);
        g.landmark("Residential", "district", 170, G, 300);
    }

    private void awnings(Rect area, Rng r) {
        for (int x = area.x0(); x < area.x1(); x++) for (int z = area.z0(); z < area.z1(); z++) {
            if (g.get(x, G + 3, z) != Block.SIGN_SHOP) continue;
            for (int[] d : new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) {
                int ax = x + d[0], az = z + d[1];
                if (g.air(ax, G + 3, az) && g.air(ax, G, az) && st.isRoad(ax, az)) {
                    g.set(ax, G + 3, az, (x / 4 + z / 4) % 2 == 0 ? Block.AWNING_RED : Block.AWNING_GREEN);
                    if (Rng.hash(x, 9, z, 2) < 0.03f) g.set(ax, G + 4, az, r.pick(new int[]{Block.NEON_RED, Block.NEON_BLUE, Block.NEON_GREEN}));
                }
            }
        }
    }

    // ================================================================== INDUSTRIAL BELT
    public void industrial(Rect north, Rect se) {
        Rng r = g.rng("industrial");
        // authored landmark rects in the north part
        Rect substation = new Rect(362, 108, 424, 156);
        Rect factory = new Rect(430, 108, 506, 172);
        Rect purifier = new Rect(512, 108, 596, 162);
        Rect rail = new Rect(358, 196, 600, 244);
        Rect camp = new Rect(362, 160, 424, 192);
        lm.substation(substation, r);
        lm.factory(factory, r);
        lm.purifierStation(purifier, r);
        lm.railYard(rail, r);
        lm.raiderCamp(camp, r);
        st.road(new Rect(424, 104, 430, 196), false, Streets.Style.INDUSTRIAL);
        st.road(new Rect(506, 104, 512, 196), false, Streets.Style.INDUSTRIAL);
        st.road(new Rect(358, 156, 424, 160), true, Streets.Style.INDUSTRIAL);
        st.road(new Rect(358, 192, 600, 196), true, Streets.Style.INDUSTRIAL);
        // remaining north strip: warehouses
        warehouseRow(new Rect(430, 176, 600, 192), r);
        warehouseRow(new Rect(512, 166, 600, 176), r);
        // south-east: container terminal + workshops around the bridge street
        st.road(new Rect(524, 256, 538, 344), false, Streets.Style.STREET);
        lm.containerYard(new Rect(538, 262, 600, 340), r);
        List<Rect> blocks = CityGenerator.grid(g, st, new Rect(460, 256, 524, 344), 10, 26, 40, Streets.Style.INDUSTRIAL, r);
        for (Rect blk : blocks) warehouseRow(blk, r);
        g.post("Industrial Patrol", "patrol", "raiders", 470, G, 250);
        g.post("Container Ambush", "sniper", "raiders", 560, G + 9, 300);
        g.post("Siding Watch", "guard", "raiders", 590, G, 200);
        g.landmark("Industrial", "district", 480, G, 150);
    }

    private void warehouseRow(Rect blk, Rng r) {
        if (blk.w() < 10 || blk.d() < 8) { yard(blk.x0(), blk.z0(), blk.x1(), blk.z1(), r); return; }
        int x = blk.x0();
        while (blk.x1() - x >= 10) {
            int w = Math.min(blk.x1() - x, r.range(16, 30));
            if (blk.x1() - (x + w) < 10) w = blk.x1() - x;
            Spec sp = new Spec(x + 1, blk.z0() + 1, w - 2, blk.d() - 2);
            sp.style = r.chance(0.65) ? Style.WAREHOUSE : Style.WORKSHOP;
            sp.floors = sp.style == Style.WAREHOUSE ? r.range(1, 2) : r.range(2, 3);
            sp.wall = r.pick(new int[]{Block.CORRUGATED, Block.CORRUGATED_RUST, Block.CORRUGATED_BLUE, Block.BRICK_BROWN, Block.CONCRETE_PANEL});
            sp.trim = Block.STEEL_BEAM;
            sp.roof = Block.ROOF_METAL;
            sp.street[0] = true; sp.street[2] = true;
            sp.window = Block.GLASS_DIRTY; sp.windowSpacing = 3; sp.broken = 0.5f;
            sp.lootBias = "industrial";
            sp.damage = r.chance(0.25) ? r.range(0.2f, 0.6f) : 0;
            sp.fireEscape = sp.style == Style.WORKSHOP && r.chance(0.5);
            if (sp.w >= 6 && sp.d >= 6) b.build(sp);
            // loading-yard clutter
            for (int k = 0; k < 3; k++) { int cx = x + 1 + r.nextInt(Math.max(1, w - 2)); if (g.air(cx, G, blk.z0())) g.set(cx, G, blk.z0(), r.chance(0.5) ? Block.BARREL : Block.CRATE); }
            x += w;
        }
    }

    /**
     * The fairground: a Ferris wheel with its yellow cabins over a fenced lot, a ticket booth and benches -
     * the one silhouette everybody knows from the real exclusion zone. Gates face the square and the embankment.
     */
    private void funfair(int x0, int z0, int x1, int z1) {
        int cx = (x0 + x1) / 2, cz = (z0 + z1) / 2, hub = G + 10, R = 8;
        for (int x = x0; x < x1; x++) for (int z = z0; z < z1; z++) g.set(x, G - 1, z, Rng.hash(x, 2, z, 9) < 0.2f ? Block.DEAD_GRASS : (x + z) % 7 == 0 ? Block.ASPHALT_CRACKED : Block.CONCRETE_FLOOR);
        // rim, spokes and hub, standing across the lot
        for (int a = 0; a < 120; a++) { double t = a * Math.PI * 2 / 120; g.set(cx + (int) Math.round(Math.cos(t) * R), hub + (int) Math.round(Math.sin(t) * R), cz, Block.STEEL_BEAM); }
        for (int k = 0; k < 8; k++) { double t = k * Math.PI / 4; for (int q = 1; q < R; q++) g.set(cx + (int) Math.round(Math.cos(t) * q), hub + (int) Math.round(Math.sin(t) * q), cz, Block.LATTICE); }
        // A-frame towers either side of the wheel carry the axle
        for (int side = -1; side <= 1; side += 2) for (int y = G; y <= hub; y++) { int off = Math.round((hub - y) * 0.5f); g.set(cx - off, y, cz + side * 2, Block.STEEL_BEAM); g.set(cx + off, y, cz + side * 2, Block.STEEL_BEAM); }
        g.fill(cx, hub, cz - 2, cx, hub, cz + 2, Block.STEEL_BEAM);
        // the cabins: open yellow tubs hanging under the rim
        for (int k = 0; k < 8; k++) {
            double t = k * Math.PI / 4 + Math.PI / 8;
            int gx = cx + (int) Math.round(Math.cos(t) * R), gy = hub + (int) Math.round(Math.sin(t) * R);
            if (gy - 3 <= G) continue;
            g.fill(gx - 1, gy - 3, cz - 1, gx + 1, gy - 3, cz + 1, k % 4 == 3 ? Block.CORRUGATED_RUST : Block.PLASTER_OCHRE);
            g.fill(gx - 1, gy - 2, cz - 1, gx + 1, gy - 2, cz + 1, k % 4 == 3 ? Block.CORRUGATED_RUST : Block.PLASTER_OCHRE);
            g.set(gx, gy - 2, cz, Block.AIR);
            g.set(gx, gy - 1, cz, Block.STEEL_BEAM);
        }
        // fence with gates toward the square (west) and the embankment road (south)
        for (int x = x0; x < x1; x++) { g.set(x, G, z0, Block.IRON_FENCE); if (Math.abs(x - cx) > 2) g.set(x, G, z1 - 1, Block.IRON_FENCE); }
        for (int z = z0; z < z1; z++) { if (Math.abs(z - cz) > 1) g.set(x0, G, z, Block.IRON_FENCE); g.set(x1 - 1, G, z, Block.IRON_FENCE); }
        // ticket booth, benches, a bin
        g.fill(x0 + 3, G, z1 - 6, x0 + 5, G + 2, z1 - 4, Block.WOOD_GREEN);
        g.set(x0 + 4, G + 1, z1 - 4, Block.GLASS_DIRTY);
        g.fill(x0 + 2, G + 3, z1 - 7, x0 + 6, G + 3, z1 - 3, Block.ROOF_METAL);
        g.container(x0 + 6, G, z1 - 5, Block.CABINET, "store");
        for (int x = x0 + 9; x < x1 - 4; x += 6) if (Math.abs(x - cx) > 3) g.set(x, G, z0 + 2, Block.PEW);
        g.container(x1 - 4, G, z0 + 3, Block.TRASH, "trash");
        g.container(cx + 5, G, cz + 4, Block.CRATE, "crate");
        g.nest(cx + 7, G, cz - 3);
        g.landmark("Amusement Park", "funfair", cx, G, cz);
    }

    // ================================================================== CIVIC CORE
    public void civic(Rect north, Rect south) {
        Rng r = g.rng("civic");
        // ---- north bank: the power plant precinct (Industrial district) either side of the central avenue
        st.road(new Rect(316, 256, 332, 344), false, Streets.Style.AVENUE);
        st.road(new Rect(396, 318, 412, 344), false, Streets.Style.STREET);       // spur to the collapsed bridge
        st.road(new Rect(332, 334, 448, 344), true, Streets.Style.STREET);        // embankment road
        au.powerPlant(new Rect(256, 256, 316, 344), new Rect(332, 256, 448, 318), r);
        lm.plaza(new Rect(334, 319, 394, 334), r);
        // bus lay-by east of the square: the evacuation fleet, parked in a row and never driven again
        for (int x = 414; x < 446; x++) for (int z = 319; z < 334; z++) { g.set(x, G - 1, z, Block.ASPHALT); g.fill(x, G, z, x, G + 30, z, Block.AIR); }
        // v0.3: the lot east of the square is the amusement park that was due to open for May Day and never did
        funfair(414, 319, 446, 334);
        // ---- south bank: the Government quarter
        st.road(new Rect(316, 360, 332, 448), false, Streets.Style.AVENUE);
        st.road(new Rect(396, 360, 412, 448), false, Streets.Style.STREET);
        st.road(new Rect(256, 400, 316, 410), true, Streets.Style.STREET);
        st.road(new Rect(332, 404, 396, 414), true, Streets.Style.STREET);
        st.road(new Rect(412, 396, 448, 406), true, Streets.Style.STREET);
        lm.tower(new Rect(332, 360, 396, 404), 16, true, r);
        lm.garrison(new Rect(256, 360, 316, 400), r);
        lm.cityHall(new Rect(256, 410, 316, 448), r);
        office(new Rect(332, 414, 362, 448), 6, r);
        office(new Rect(362, 414, 396, 448), 8, r);
        lm.tower(new Rect(412, 360, 448, 396), 13, false, r);
        office(new Rect(412, 406, 448, 448), 5, r);
        // checkpoints on every approach: the quarter is cordoned, not merely patrolled
        au.roadblock(324, 370, false, 6, "military");
        au.roadblock(404, 372, false, 6, "military");
        au.roadblock(350, 454, true, 4, "military");
        g.post("Ministry Tower Doors", "restricted", "military", 364, G, 406);
        g.post("Government Patrol", "patrol", "military", 324, G, 420);
        g.post("Embassy Row Patrol", "patrol", "military", 404, G, 420);
        g.post("Tower Overwatch", "sniper", "military", 352, G - 1 + 16 * FLOOR_H + 1, 370);
        g.landmark("Government", "district", 352, G, 404);
    }

    private void office(Rect r0, int floors, Rng r) {
        Spec sp = new Spec(r0.x0() + 2, r0.z0() + 2, r0.w() - 4, r0.d() - 4);
        sp.floors = floors; sp.style = Style.OFFICE; sp.wall = r.pick(new int[]{Block.CONCRETE_PANEL, Block.GRANITE, Block.BRICK_WHITE}); sp.trim = Block.CONCRETE_PANEL;
        sp.window = Block.GLASS_BLUE; sp.windowSpacing = 2; sp.broken = 0.2f; sp.boarded = 0.05f; sp.lootBias = "office";
        sp.street[0] = sp.street[1] = sp.street[2] = sp.street[3] = true; sp.damage = r.chance(0.35) ? r.range(0.2f, 0.5f) : 0; sp.fireEscape = r.chance(0.4);
        for (int x = r0.x0(); x < r0.x1(); x++) for (int z = r0.z0(); z < r0.z1(); z++) { g.fill(x, G, z, x, G + 70, z, Block.AIR); g.set(x, G - 1, z, Block.SIDEWALK); }
        b.build(sp);
    }

    // ================================================================== REDLINE
    public void redline(Rect east, Rect south) {
        Rng r = g.rng("redline");
        Rect hospital = new Rect(262, 462, 380, 548);
        Rect containment = new Rect(440, 480, 596, 596);
        lm.hospital(hospital, r);
        lm.containment(containment, r);
        lm.crater(400, 575, 12, r);
        st.road(new Rect(380, 460, 390, 600), false, Streets.Style.STREET);
        st.road(new Rect(256, 548, 380, 556), true, Streets.Style.STREET);
        st.road(new Rect(390, 470, 440, 478), true, Streets.Style.STREET);
        int[] walls = {Block.BRICK_WHITE, Block.PLASTER, Block.BRICK_RED, Block.CONCRETE_STAINED, Block.PLASTER_PEEL};
        SpecMaker mk = (x0, z0, w, d, s, rr) -> {
            if (w < 6 || d < 6) return null;
            Spec sp = new Spec(x0, z0, w, d);
            sp.street = s;
            sp.floors = rr.range(2, 5);
            sp.style = rr.chance(0.3) ? Style.CLINIC : Style.RESIDENTIAL;
            sp.wall = rr.pick(walls);
            sp.trim = Block.CONCRETE;
            sp.window = Block.GLASS_DIRTY;
            sp.broken = 0.6f; sp.boarded = 0.3f;
            sp.damage = rr.range(0.3f, 0.9f);
            sp.burnt = rr.chance(0.35);
            sp.lootBias = sp.style == Style.CLINIC ? "medical" : null;
            sp.lit = false;
            return sp;
        };
        // east block and the strips around the landmarks
        st.road(new Rect(524, 360, 538, 448), false, Streets.Style.STREET);
        for (Rect blk : CityGenerator.grid(g, st, new Rect(460, 360, 524, 448), 8, 24, 36, Streets.Style.STREET, r)) { Rect c = perimeterLots(blk, 8, 12, 7, 12, 0.2f, mk, r); if (c != null) ruinCourt(c, r); }
        for (Rect blk : CityGenerator.grid(g, st, new Rect(538, 360, 600, 448), 8, 24, 36, Streets.Style.STREET, r)) { Rect c = perimeterLots(blk, 8, 12, 7, 12, 0.2f, mk, r); if (c != null) ruinCourt(c, r); }
        for (Rect blk : CityGenerator.grid(g, st, new Rect(390, 478, 440, 560), 8, 22, 34, Streets.Style.STREET, r)) { Rect c = perimeterLots(blk, 8, 11, 7, 11, 0.2f, mk, r); if (c != null) ruinCourt(c, r); }
        for (Rect blk : CityGenerator.grid(g, st, new Rect(256, 556, 380, 600), 8, 22, 40, Streets.Style.STREET, r)) { Rect c = perimeterLots(blk, 8, 11, 7, 12, 0.2f, mk, r); if (c != null) ruinCourt(c, r); }
        rowSafeGeneric(new Rect(380, 460, 440, 470), mk, r);
        rowSafeGeneric(new Rect(440, 460, 600, 478), mk, r);
        // abandoned military roadblocks
        g.sandbagWall(452, 470, 458, 470, 2);
        g.truck(470, 462, true, Block.CAR_OLIVE);
        g.container(462, G, 464, Block.CRATE_MIL, "military");
        g.post("Abandoned Roadblock", "checkpoint", "none", 455, G, 466);
        g.landmark("Abandoned Roadblock", "checkpoint", 455, G, 466);
        for (int i = 0; i < 6; i++) { int x = 470 + r.nextInt(120), z = 370 + r.nextInt(70); int y = g.groundY(x, z); lm.biomass(x, y, z, 2, r); g.nest(x, y, z); }
        g.landmark("Untamed", "district", 470, G, 500);
    }

    private void rowSafeGeneric(Rect r0, SpecMaker mk, Rng r) {
        if (r0.w() < 6 || r0.d() < 6) return;
        row(r0.x0(), r0.z0(), r0.x1(), r0.d(), true, 0, 7, 12, 0.15f, mk, r, new ArrayList<>());
    }

    private void ruinCourt(Rect c, Rng r) {
        for (int x = c.x0(); x < c.x1(); x++) for (int z = c.z0(); z < c.z1(); z++) {
            g.fill(x, G, z, x, G + 30, z, Block.AIR);
            g.set(x, G - 1, z, Rng.hash(x, 4, z, 19) < 0.5f ? Block.ASH : Block.DEAD_GRASS);
        }
        if (c.w() > 4 && c.d() > 4) {
            g.tree(c.cx(), G, c.cz(), 5, true);
            for (int i = 0; i < 3; i++) g.container(c.x0() + r.nextInt(c.w()), G, c.z0() + r.nextInt(c.d()), Block.BODYBAG, "body");
            if (r.chance(0.5)) g.nest(c.cx() + 1, G, c.cz());
        }
    }
}
