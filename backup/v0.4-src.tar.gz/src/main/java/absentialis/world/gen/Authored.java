package absentialis.world.gen;

import static absentialis.world.gen.Gen.FLOOR_H;
import static absentialis.world.gen.Gen.G;

import absentialis.engine.util.Rng;
import absentialis.world.Block;
import absentialis.world.gen.Buildings.Spec;
import absentialis.world.gen.Buildings.Style;
import absentialis.world.gen.Streets.Rect;

/**
 * Hand-authored landmarks of the iteration-P1 layout: the central power-plant complex in the
 * Chernobyl mould (reactor blocks on a long turbine hall, the banded vent stack between them, the
 * sarcophagus, cooling towers - one never finished - and the switchyard), and the civic pieces of a
 * Soviet microdistrict (school, polyclinic, department store). Everything is placed by rule and
 * coordinate, nothing by dice; only weathering detail is seeded.
 */
public final class Authored {
    private final Gen g;
    private final Buildings b;
    private final Landmarks lm;

    public Authored(Gen g, Landmarks lm) { this.g = g; this.b = new Buildings(g); this.lm = lm; }

    private void lot(Rect r, int ground) {
        g.fill(r.x0(), G, r.z0(), r.x1() - 1, absentialis.world.World.H - 1, r.z1() - 1, Block.AIR);
        g.fill(r.x0(), G - 1, r.z0(), r.x1() - 1, G - 1, r.z1() - 1, ground);
    }

    /** Perimeter wall with gate openings {x0, z0, x1, z1} (inclusive cells left open). */
    private void wall(Rect r, int block, int height, boolean barbed, int[]... gates) {
        for (int x = r.x0(); x < r.x1(); x++) for (int z = r.z0(); z < r.z1(); z++) {
            if (x != r.x0() && z != r.z0() && x != r.x1() - 1 && z != r.z1() - 1) continue;
            boolean open = false;
            for (int[] gt : gates) if (x >= gt[0] && x <= gt[2] && z >= gt[1] && z <= gt[3]) open = true;
            if (open) continue;
            g.fill(x, G, z, x, G + height - 1, z, block);
            if (barbed) g.set(x, G + height, z, Block.BARBED);
        }
    }

    /** Guard booth: a 3x3 hut with a window, a lamp and a barrier arm beside the gate. */
    private void booth(int x, int z, int barrierX, int barrierZ) {
        g.fill(x, G, z, x + 2, G + 2, z + 2, Block.CONCRETE_PANEL);
        g.fill(x + 1, G, z + 1, x + 1, G + 1, z + 1, Block.AIR);
        g.set(x + 1, G + 1, z, Block.GLASS_DIRTY); g.set(x + 1, G + 1, z + 2, Block.GLASS_DIRTY); g.set(x, G + 1, z + 1, Block.GLASS_DIRTY);
        g.set(x + 2, G, z + 1, Block.AIR); g.set(x + 2, G + 1, z + 1, Block.AIR);
        g.fill(x, G + 3, z, x + 2, G + 3, z + 2, Block.METAL_PLATE);
        g.lamp(x + 1, G + 2, z + 1);
        g.set(barrierX, G, barrierZ, Block.BARRIER);
    }

    // =================================================================== POWER PLANT
    /** west = cooling-tower parcel, east = reactor parcel. Both sit between the north avenue and the canal. */
    public void powerPlant(Rect west, Rect east, Rng rng) {
        lot(east, Block.CONCRETE_FLOOR);
        lot(west, Block.CONCRETE_FLOOR);
        int x0 = east.x0(), z0 = east.z0(), x1 = east.x1(), z1 = east.z1();
        // ---- perimeter: concrete wall, a west gate onto the central avenue and a south gate onto the square
        int[] westGate = {x0, z0 + 42, x0, z0 + 47}, southGate = {x0 + 68, z1 - 1, x0 + 75, z1 - 1};
        wall(east, Block.CONCRETE_PANEL, 3, true, westGate, southGate);
        booth(x0 + 2, z0 + 38, x0 + 1, z0 + 41);
        booth(x0 + 64, z1 - 5, x0 + 67, z1 - 2);
        for (int z = z0 + 42; z <= z0 + 47; z++) g.set(x0 + 3, G - 1, z, Block.HAZARD_STRIPE);
        for (int x = x0 + 68; x <= x0 + 75; x++) g.set(x, G - 1, z1 - 4, Block.HAZARD_STRIPE);

        // ---- turbine hall: one long glazed shed, the spine everything else hangs off
        int tx = x0 + 8, tz = z0 + 40, tw = 100, td = 16;
        Spec hall = new Spec(tx, tz, tw, td);
        hall.floors = 3; hall.style = Style.WAREHOUSE; hall.wall = Block.CONCRETE_PANEL; hall.trim = Block.STEEL_BEAM; hall.roof = Block.ROOF_METAL;
        hall.street[0] = hall.street[2] = true; hall.window = Block.GLASS_DIRTY; hall.windowSpacing = 2; hall.broken = 0.25f; hall.lootBias = "industrial"; hall.damage = 0;
        b.build(hall);
        // open the full height, keep a gallery along the north wall
        for (int f = 1; f <= 2; f++) {
            int y = G - 1 + f * FLOOR_H;
            for (int x = tx + 3; x < tx + tw - 3; x++) for (int z = tz + 4; z < tz + td - 2; z++) g.set(x, y, z, Block.AIR);
            for (int x = tx + 1; x < tx + tw - 1; x++) { g.set(x, y, tz + 2, Block.GRATE); g.set(x, y, tz + 3, Block.GRATE); if (g.air(x, y + 1, tz + 4)) g.set(x, y + 1, tz + 4, Block.IRON_FENCE); }
        }
        for (int y = G; y <= G - 1 + 2 * FLOOR_H; y++) { g.set(tx + 1, y, tz + 1, Block.LADDER); g.set(tx + tw - 2, y, tz + 1, Block.LADDER); }
        // four turbine-generator sets on a common axis
        for (int k = 0; k < 4; k++) {
            int ux = tx + 9 + k * 23, uz = tz + 7;
            g.fill(ux, G, uz, ux + 9, G + 2, uz + 3, Block.MACHINE);
            g.fill(ux + 10, G, uz, ux + 13, G + 3, uz + 3, Block.GENERATOR);
            g.fill(ux + 1, G + 3, uz + 1, ux + 8, G + 3, uz + 2, Block.PIPE);
            g.fill(ux - 1, G, uz + 1, ux - 1, G + 5, uz + 1, Block.PIPE);
            for (int x = ux; x <= ux + 13; x++) g.set(x, G - 1, uz + 5, Block.HAZARD_STRIPE);
            g.container(ux + 3, G, uz + 5, Block.TOOLBOX, "industrial");
            g.lamp(ux + 5, G - 2 + 3 * FLOOR_H, uz + 2);
        }
        g.namedCache(tx + tw - 4, G, tz + td - 3, "cache_rare", "turbine_hall");
        g.landmark("Turbine Hall", "plant", tx + tw / 2, G, tz + td / 2);
        g.post("Turbine Hall", "guard", "mercenaries", tx + tw / 2, G, tz + td - 4);

        // ---- reactor block 3 (intact) and block 4 (the sarcophagus), the control building between them
        int[] hall3 = reactorBlock(x0 + 20, z0 + 8, 9, false, rng);
        int[] hall4 = reactorBlock(x0 + 66, z0 + 8, 8, true, rng);
        int cbx = x0 + 54, cbz = z0 + 12;
        Spec ctl = new Spec(cbx, cbz, 10, 22);
        ctl.floors = 2; ctl.style = Style.OFFICE; ctl.wall = Block.CONCRETE_PANEL; ctl.trim = Block.CONCRETE_DARK; ctl.window = Block.GLASS_DIRTY; ctl.windowSpacing = 3;
        ctl.street[2] = true; ctl.lootBias = "office"; ctl.roofAccess = true;
        b.build(ctl);
        // unit control room: a wall of consoles on the first floor
        int cy = G + FLOOR_H;
        for (int x = cbx + 1; x <= cbx + 8; x++) { g.setIfAir(x, cy, cbz + 1, Block.CONSOLE); if (x % 2 == 0) g.setIfAir(x, cy + 1, cbz + 1, Block.COMPUTER); }
        g.container(cbx + 8, cy, cbz + 3, Block.SAFE, "safe");
        g.document("doc", cbx + 5, cy, cbz + 3);
        g.site("reactor_control", cbx + 5, cy, cbz + 3);
        g.post("Unit Control Room", "leader", "mercenaries", cbx + 5, cy, cbz + 5);
        // links: reactor blocks -> turbine hall at gallery level
        for (int[] lk : new int[][]{{x0 + 34, z0 + 38}, {x0 + 80, z0 + 38}}) {
            for (int z = lk[1]; z <= lk[1] + 1; z++) for (int x = lk[0]; x <= lk[0] + 3; x++) {
                g.set(x, G - 1 + FLOOR_H, z, Block.CONCRETE_FLOOR);
                boolean side = x == lk[0] || x == lk[0] + 3;
                for (int y = G + FLOOR_H; y <= G + FLOOR_H + 2; y++) g.set(x, y, z, side ? Block.GLASS_DIRTY : Block.AIR);
                g.set(x, G + FLOOR_H + 3, z, Block.METAL_PLATE);
            }
            for (int x = lk[0] + 1; x <= lk[0] + 2; x++) for (int y = G + FLOOR_H; y <= G + FLOOR_H + 2; y++) { g.set(x, y, lk[1] - 1, Block.AIR); g.set(x, y, lk[1] + 2, Block.AIR); }
        }
        ventStack(cbx + 5, cbz + 11, G - 1 + 2 * FLOOR_H);

        // ---- administration block with the glazed "golden corridor" to block 3
        Spec adm = new Spec(x0 + 4, z0 + 6, 12, 28);
        adm.floors = 5; adm.style = Style.OFFICE; adm.wall = Block.BRICK_WHITE; adm.trim = Block.CONCRETE_PANEL; adm.window = Block.GLASS_BLUE; adm.windowSpacing = 2;
        adm.street[1] = adm.street[2] = true; adm.lootBias = "office"; adm.broken = 0.2f;
        b.build(adm);
        for (int x = x0 + 16; x <= x0 + 19; x++) for (int z = z0 + 20; z <= z0 + 22; z++) {
            g.set(x, G - 1 + FLOOR_H, z, Block.PLASTER_OCHRE);
            boolean side = z != z0 + 21;
            for (int y = G + FLOOR_H; y <= G + FLOOR_H + 2; y++) g.set(x, y, z, side ? Block.GLASS : Block.AIR);
            g.set(x, G + FLOOR_H + 3, z, Block.METAL_PLATE);
        }
        for (int y = G + FLOOR_H; y <= G + FLOOR_H + 2; y++) { g.set(x0 + 15, y, z0 + 21, Block.AIR); g.set(x0 + 20, y, z0 + 21, Block.AIR); }
        g.landmark("Plant Administration", "plant", x0 + 10, G, z0 + 20);

        // ---- switchyard at the east end: transformers in a row, pylons marching out
        Rect yard = new Rect(x1 - 17, z0 + 4, x1 - 2, z0 + 36);
        for (int x = yard.x0(); x < yard.x1(); x++) for (int z = yard.z0(); z < yard.z1(); z++) g.set(x, G - 1, z, Block.GRAVEL);
        wall(yard, Block.CHAINLINK, 2, false, new int[]{yard.x0(), yard.cz() - 1, yard.x0(), yard.cz() + 1});
        for (int k = 0; k < 3; k++) {
            int ux = yard.x0() + 3, uz = yard.z0() + 3 + k * 9;
            g.fill(ux, G, uz, ux + 2, G + 2, uz + 2, Block.TRANSFORMER);
            g.set(ux + 1, G + 3, uz + 1, Block.PIPE); g.set(ux + 1, G + 4, uz + 1, Block.IRON_FENCE);
        }
        lm.pylon(yard.x1() - 5, yard.z0() + 6, 22);
        lm.pylon(yard.x1() - 5, yard.z0() + 24, 22);
        g.landmark("Switchyard", "substation", yard.cx(), G, yard.cz());

        // ---- service yard: pipe bridge along the north wall, trucks parked nose-out in a row
        for (int x = x0 + 18; x < x1 - 20; x++) { g.set(x, G + 3, z0 + 3, Block.PIPE); if ((x - x0) % 6 == 0) g.fill(x, G, z0 + 3, x, G + 2, z0 + 3, Block.STEEL_BEAM); }
        for (int k = 0; k < 3; k++) g.truck(x0 + 20 + k * 10, z1 - 5, true, Block.CAR_WHITE);
        for (int x = x0 + 12; x < x1 - 20; x += 18) g.streetLamp(x, z1 - 2, 0, -1);
        g.post("Plant West Gate", "checkpoint", "mercenaries", x0 + 5, G, z0 + 44);
        g.post("Plant South Gate", "checkpoint", "mercenaries", x0 + 71, G, z1 - 6);
        g.post("Reactor Hall 3", "guard", "mercenaries", hall3[0], hall3[1], hall3[2]);
        g.nest(hall4[0], hall4[1] - 2 * FLOOR_H, hall4[2]);
        g.nest(hall4[0] + 3, G, hall4[2] + 9);
        g.landmark("V.I. Lenin Power Plant", "plant", east.cx(), G, east.cz());

        // ---- cooling towers: one complete, one abandoned mid-pour, with the intake channel between
        wall(west, Block.CHAINLINK, 2, true, new int[]{west.x1() - 1, west.cz() - 2, west.x1() - 1, west.cz() + 2});
        coolingTower(west.cx(), west.z0() + 24, 42, true);
        coolingTower(west.cx(), west.z1() - 24, 23, false);
        for (int z = west.z0() + 4; z < west.z1() - 4; z++) for (int x = west.x0() + 4; x <= west.x0() + 9; x++) {
            boolean rim = x == west.x0() + 4 || x == west.x0() + 9;
            if (rim) { g.set(x, G - 1, z, Block.CURB); continue; }
            g.set(x, G - 3, z, Block.CONCRETE_DARK); g.set(x, G - 2, z, Block.WATER); g.set(x, G - 1, z, Block.AIR);
        }
        Spec pump = new Spec(west.x1() - 16, west.cz() - 5, 12, 10);
        pump.floors = 1; pump.style = Style.WORKSHOP; pump.wall = Block.BRICK_BROWN; pump.trim = Block.CONCRETE_DARK; pump.street[1] = true; pump.lootBias = "industrial";
        b.build(pump);
        for (int x = west.x0() + 10; x < west.x1() - 16; x++) g.set(x, G, west.cz(), Block.PIPE);
        g.landmark("Cooling Towers", "plant", west.cx(), G, west.cz());
        g.post("Cooling Towers", "patrol", "mercenaries", west.x1() - 6, G, west.cz() + 8);
    }

    /**
     * A reactor block: nine floors of labs and plant rooms round a central reactor hall. Intact, the
     * hall holds the lid and the refuelling gantry. Destroyed, it is a crater under a steel shell.
     * Returns a standable point on the hall floor {x, y, z}.
     */
    private int[] reactorBlock(int x0, int z0, int floors, boolean destroyed, Rng rng) {
        int w = 32, d = 30;
        Spec s = new Spec(x0, z0, w, d);
        s.floors = floors; s.style = Style.LAB; s.wall = Block.CONCRETE_PANEL; s.trim = Block.CONCRETE_DARK; s.window = Block.GLASS_DIRTY; s.windowSpacing = 4;
        s.street[2] = true; s.street[3] = !destroyed; s.broken = destroyed ? 0.8f : 0.3f; s.boarded = 0.1f; s.lootBias = "lab";
        s.damage = destroyed ? 0.55f : 0.05f; s.burnt = destroyed; s.lit = !destroyed; s.basement = false;
        b.build(s);
        int top = G - 1 + floors * FLOOR_H, hallFloor = G - 1 + (floors - 4) * FLOOR_H;
        int hx0 = x0 + 9, hx1 = x0 + w - 10, hz0 = z0 + 8, hz1 = z0 + d - 9, cx = (hx0 + hx1) / 2, cz = (hz0 + hz1) / 2;
        // the hall: everything between the hall floor and the roof slab goes
        for (int x = hx0; x <= hx1; x++) for (int z = hz0; z <= hz1; z++) {
            for (int y = hallFloor + 1; y < top; y++) g.set(x, y, z, Block.AIR);
            g.set(x, hallFloor, z, Block.TILE_GRAY);
        }
        // guard rails where the upper floors look into the void
        for (int f = floors - 3; f < floors; f++) {
            int y = G + f * FLOOR_H;
            for (int x = hx0 - 1; x <= hx1 + 1; x++) for (int z = hz0 - 1; z <= hz1 + 1; z++) {
                boolean ring = x == hx0 - 1 || x == hx1 + 1 || z == hz0 - 1 || z == hz1 + 1;
                if (ring && g.air(x, y, z) && g.get(x, y - 1, z) != 0) g.set(x, y, z, Block.IRON_FENCE);
            }
        }
        if (!destroyed) {
            // upper biological shield: the lid, ringed in hazard paint, with the channel caps as a grid
            for (int dx = -6; dx <= 6; dx++) for (int dz = -6; dz <= 6; dz++) {
                double r = Math.sqrt(dx * dx + dz * dz);
                if (r <= 4.6) g.set(cx + dx, hallFloor, cz + dz, (dx + dz) % 2 == 0 ? Block.METAL_PLATE : Block.GRATE);
                else if (r <= 5.8) g.set(cx + dx, hallFloor, cz + dz, Block.HAZARD_STRIPE);
            }
            // refuelling machine on its gantry
            for (int x = hx0; x <= hx1; x++) { g.set(x, top - 3, cz - 2, Block.STEEL_BEAM); g.set(x, top - 3, cz + 2, Block.STEEL_BEAM); }
            g.fill(cx - 1, top - 6, cz - 1, cx + 1, top - 3, cz + 1, Block.MACHINE);
            g.fill(cx, top - 9, cz, cx, top - 7, cz, Block.PIPE);
            g.lamp(cx - 4, top - 1, cz - 4); g.lamp(cx + 4, top - 1, cz + 4);
            g.namedCache(hx1 - 1, hallFloor + 1, hz0 + 1, "cache_rare", "reactor_hall");
            g.container(hx0 + 1, hallFloor + 1, hz1 - 1, Block.LOCKER, "tech");
            g.landmark("Reactor Block 3", "plant", x0 + w / 2, G, z0 + d / 2);
        } else {
            // the crater: two floors punched out, slag and glowing debris at the bottom, twisted steel above
            for (int dx = -6; dx <= 6; dx++) for (int dz = -6; dz <= 6; dz++) {
                double r = Math.sqrt(dx * dx + dz * dz) + Rng.hash(cx + dx, 3, cz + dz, 77) * 1.2;
                if (r > 6.2) continue;
                for (int y = hallFloor - 2 * FLOOR_H + 1; y <= hallFloor; y++) g.set(cx + dx, y, cz + dz, Block.AIR);
                int by = hallFloor - 2 * FLOOR_H;
                g.set(cx + dx, by, cz + dz, r < 2.5 ? Block.TOXIC_GROUND : r < 4.5 ? Block.RUBBLE : Block.CONCRETE_DARK);
                if (r < 4 && Rng.hash(cx + dx, 4, cz + dz, 77) < 0.2f) g.set(cx + dx, by + 1, cz + dz, Block.EMBER);
            }
            for (int k = 0; k < 7; k++) { int bx = hx0 + 1 + k * 2, bz = hz0 + 1 + (k * 5) % (hz1 - hz0 - 1); for (int y = top - 8; y < top - 1; y++) g.set(bx + (y % 3 == 0 ? 1 : 0), y, bz, Block.STEEL_BEAM); }
            g.namedCache(hx0 + 1, hallFloor + 1, hz0 + 1, "cache_rare", "sarcophagus");
            // the shelter: rusted steel cladding over the walls and roof, a stepped buttress on the north face
            for (int x = x0 - 1; x <= x0 + w; x++) for (int z = z0 - 1; z <= z0 + d; z++) {
                boolean shell = x == x0 - 1 || x == x0 + w || z == z0 - 1 || z == z0 + d;
                if (shell) { for (int y = G + 5; y <= top + 2; y++) if (g.air(x, y, z)) g.set(x, y, z, (y / 4) % 2 == 0 ? Block.METAL_RUST : Block.CORRUGATED_RUST); }
                else g.set(x, top + 2, z, (x - x0) % 6 == 0 ? Block.STEEL_BEAM : Block.METAL_PLATE);
            }
            for (int k = 0; k < 3; k++) {
                int z = z0 - 2 - k, h = top - 2 - k * 7;
                for (int x = x0 - 1; x <= x0 + w; x++) for (int y = G; y <= h; y++) if (g.air(x, y, z)) g.set(x, y, z, (x - x0) % 4 == 0 ? Block.STEEL_BEAM : Block.METAL_PLATE);
            }
            for (int x = x0 + 3; x < x0 + w - 2; x += 5) g.fill(x, top + 3, z0 + 4, x, top + 5, z0 + 4, Block.PIPE);
            g.set(x0 + w + 1, G + 1, z0 + d / 2, Block.BIOHAZARD); g.set(x0 + w / 2, G + 1, z0 + d + 1, Block.BIOHAZARD);
            g.landmark("Sarcophagus (Block 4)", "plant", x0 + w / 2, G, z0 + d / 2);
        }
        return new int[]{hx0 + 2, hallFloor + 1, hz1 - 2};
    }

    /** The red-and-white ventilation stack in its lattice frame, standing on the control building. */
    private void ventStack(int cx, int cz, int roofY) {
        int base = roofY + 1, top = Math.min(absentialis.world.World.H - 5, G + 66);
        for (int y = base; y <= top; y++) {
            int band = ((y - base) / 5) % 2 == 0 ? Block.BRICK_RED : Block.BRICK_WHITE;
            for (int dx = -3; dx <= 3; dx++) for (int dz = -3; dz <= 3; dz++) {
                int dd = dx * dx + dz * dz;
                if (dd >= 5 && dd <= 10) g.set(cx + dx, y, cz + dz, band);
                else if (dd < 5) g.set(cx + dx, y, cz + dz, Block.AIR);
            }
            for (int[] c : new int[][]{{-4, -4}, {4, -4}, {-4, 4}, {4, 4}}) if (y <= top - 6) g.set(cx + c[0], y, cz + c[1], Block.LATTICE);
            g.set(cx, y, cz + 4, Block.LADDER);
            if ((y - base) % 14 == 13 && y <= top - 6) {
                for (int dx = -5; dx <= 5; dx++) for (int dz = -5; dz <= 5; dz++) {
                    int dd = dx * dx + dz * dz;
                    if (dd > 10 && Math.max(Math.abs(dx), Math.abs(dz)) <= 5 && !(dx == 0 && dz == 4)) { g.set(cx + dx, y, cz + dz, Block.GRATE); if (Math.max(Math.abs(dx), Math.abs(dz)) == 5) g.set(cx + dx, y + 1, cz + dz, Block.IRON_FENCE); }
                }
            }
        }
        g.set(cx + 3, top + 1, cz, Block.RED_LIGHT); g.set(cx - 3, top + 1, cz, Block.RED_LIGHT);
        int perch = base + 13;
        g.post("Vent Stack Overwatch", "sniper", "mercenaries", cx + 4, perch + 1, cz + 2);
        g.landmark("Vent Stack", "plant", cx, G, cz);
    }

    /** Hyperboloid natural-draught tower. Unfinished ones stop mid-pour, still wrapped in scaffold. */
    private void coolingTower(int cx, int cz, int height, boolean finished) {
        float rmin = 8, yt = 30, a = 23.4f;
        for (int dx = -14; dx <= 14; dx++) for (int dz = -14; dz <= 14; dz++) {
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d < 12.5) { g.set(cx + dx, G - 2, cz + dz, Block.CONCRETE_DARK); g.set(cx + dx, G - 1, cz + dz, d < 10.5 ? Block.WATER : Block.CONCRETE_DARK); }
        }
        for (int y = 0; y < height; y++) {
            double r = rmin * Math.sqrt(1 + ((y - yt) / a) * ((y - yt) / a));
            for (int dx = -15; dx <= 15; dx++) for (int dz = -15; dz <= 15; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > r + 0.5 || d <= r - 0.75) continue;
                int sector = (int) Math.floor((Math.atan2(dz, dx) + Math.PI) / (Math.PI * 2) * 24);
                if (y < 4 && (sector & 1) == 0) continue;                         // open colonnade at the base: the air inlet
                boolean streak = sector % 5 == 0 && y > height * 0.35;          // rain streaks run down fixed lines, not speckle
                g.set(cx + dx, G + y, cz + dz, streak ? Block.CONCRETE_STAINED : Block.CONCRETE);
            }
        }
        if (finished) return;
        double r = rmin * Math.sqrt(1 + ((height - yt) / a) * ((height - yt) / a));
        for (int y = height - 5; y <= height; y++) for (int dx = -16; dx <= 16; dx++) for (int dz = -16; dz <= 16; dz++) {
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d > r + 0.9 && d <= r + 1.9 && (y == height - 5 || y == height - 1 || (dx + dz) % 3 == 0)) g.setIfAir(cx + dx, G + y, cz + dz, Block.SCAFFOLD);
        }
        for (int k = 0; k < 24; k += 2) { double ang = k * Math.PI / 12; g.setIfAir(cx + (int) Math.round(Math.cos(ang) * r), G + height, cz + (int) Math.round(Math.sin(ang) * r), Block.STEEL_BEAM); }
    }

    // =================================================================== MICRODISTRICT CIVICS
    /** School No. 3: a three-storey teaching bar with two wings round a fenced yard. */
    public void school(Rect r, Rng rng) {
        lot(r, Block.ASPHALT);
        int x0 = r.x0() + 2, z0 = r.z0() + 2, w = r.w() - 4;
        int[][] parts = {{x0, z0, w, 11}, {x0, z0 + 11, 10, Math.min(12, r.d() - 17)}, {x0 + w - 10, z0 + 11, 10, Math.min(12, r.d() - 17)}};
        for (int i = 0; i < parts.length; i++) {
            int[] q = parts[i];
            if (q[3] < 6) continue;
            Spec s = new Spec(q[0], q[1], q[2], q[3]);
            s.floors = 3; s.style = Style.OFFICE; s.wall = Block.BRICK_YELLOW; s.trim = Block.BRICK_WHITE; s.window = Block.GLASS_DIRTY; s.windowSpacing = 2;
            s.street[2] = true; s.street[0] = i == 0; s.lootBias = "office"; s.broken = 0.3f; s.boarded = 0.15f; s.basement = i == 0;
            b.build(s);
        }
        // yard: sandpit, benches in a row, flagpole, a low fence with one gate
        int yz = z0 + 13, yx = x0 + 12;
        g.fill(yx + 1, G - 1, yz + 2, yx + 6, G - 1, yz + 7, Block.SAND);
        for (int x = yx + 9; x < x0 + w - 12; x += 4) g.set(x, G, yz + 2, Block.PEW);
        for (int y = G; y < G + 7; y++) g.set(r.cx(), y, yz + 1, Block.IRON_FENCE);
        g.set(r.cx() + 1, G + 6, yz + 1, Block.AWNING_RED);
        for (int x = r.x0(); x < r.x1(); x++) if (Math.abs(x - r.cx()) > 2) g.setIfAir(x, G, r.z1() - 1, Block.IRON_FENCE);
        for (int x = r.x0() + 3; x < r.x1() - 2; x += 6) if (Math.abs(x - r.cx()) > 3 && g.air(x, G, r.z1() - 3)) g.tree(x, G, r.z1() - 3, 5, false);
        g.landmark("School No. 3", "school", r.cx(), G, r.cz());
        g.post("School Yard", "camp", "survivors", r.cx(), G, yz + 6);
    }

    /** District polyclinic: white brick, red crosses over the door, an ambulance bay on the street side. */
    public void polyclinic(Rect r, Rng rng) {
        lot(r, Block.SIDEWALK);
        int x0 = r.x0() + 3, z0 = r.z0() + 3, w = r.w() - 6, d = Math.min(18, r.d() - 12);
        Spec s = new Spec(x0, z0, w, d);
        s.floors = 3; s.style = Style.CLINIC; s.wall = Block.BRICK_WHITE; s.trim = Block.CONCRETE_PANEL; s.window = Block.GLASS_DIRTY; s.windowSpacing = 2;
        s.street[2] = true; s.lootBias = "medical"; s.broken = 0.3f; s.boarded = 0.2f; s.basement = true;
        b.build(s);
        int fz = z0 + d;
        for (int k = -1; k <= 1; k++) g.set(r.cx() + k * 3, G + 4, fz, Block.RED_CROSS);
        g.fill(r.cx() - 4, G + 3, fz, r.cx() + 4, G + 3, fz + 2, Block.METAL_PLATE);          // entrance canopy
        g.set(r.cx() - 4, G, fz + 2, Block.STEEL_BEAM); g.set(r.cx() - 4, G + 1, fz + 2, Block.STEEL_BEAM); g.set(r.cx() - 4, G + 2, fz + 2, Block.STEEL_BEAM);
        g.set(r.cx() + 4, G, fz + 2, Block.STEEL_BEAM); g.set(r.cx() + 4, G + 1, fz + 2, Block.STEEL_BEAM); g.set(r.cx() + 4, G + 2, fz + 2, Block.STEEL_BEAM);
        for (int x = x0; x < x0 + 8; x++) g.set(x, G - 1, fz + 4, Block.HAZARD_STRIPE);
        g.truck(x0 + 1, fz + 5, true, Block.CAR_WHITE);
        for (int x = x0 + w - 12; x < x0 + w; x += 2) g.set(x, G, r.z1() - 2, Block.HEDGE);
        g.container(r.cx() + 6, G, fz + 1, Block.CRATE, "medical");
        g.landmark("District Polyclinic", "clinic", r.cx(), G, r.cz());
    }

    /** Univermag: four trading floors behind a glass front, neon along the cornice. */
    public void departmentStore(Rect r, Rng rng) {
        lot(r, Block.SIDEWALK);
        Spec s = new Spec(r.x0() + 2, r.z0() + 2, r.w() - 4, r.d() - 4);
        s.floors = 4; s.style = Style.SHOP; s.shopfront = true; s.wall = Block.CONCRETE_PANEL; s.trim = Block.GRANITE; s.window = Block.GLASS_BLUE; s.windowSpacing = 2;
        s.street[0] = s.street[1] = s.street[2] = s.street[3] = true; s.lootBias = "store"; s.broken = 0.35f; s.boarded = 0.1f; s.basement = true; s.fireEscape = true;
        b.build(s);
        int top = G - 1 + 4 * FLOOR_H;
        int[] neon = {Block.NEON_RED, Block.NEON_BLUE, Block.NEON_GREEN};
        for (int x = r.x0() + 6; x < r.x1() - 6; x += 3) g.setIfAir(x, top + 1, r.z1() - 3, neon[((x - r.x0()) / 3) % 3]);
        g.namedCache(r.x0() + 4, top + 1, r.z0() + 4, "cache_rare", "univermag_roof");
        g.landmark("Univermag Department Store", "store", r.cx(), G, r.cz());
        g.post("Univermag Doors", "guard", "mercenaries", r.cx(), G, r.z1() + 1);
    }

    /** Authored roadblock: two staggered sandbag walls forming a chicane across a street. */
    public void roadblock(int x, int z, boolean alongX, int halfWidth, String faction) {
        for (int k = -halfWidth; k <= halfWidth; k++) {
            int ax = alongX ? x - 3 : x + k, az = alongX ? z + k : z - 3, bx = alongX ? x + 3 : x + k, bz = alongX ? z + k : z + 3;
            if (k <= 1 && g.air(ax, G, az)) { g.set(ax, G, az, Block.SANDBAG); if (k % 2 == 0) g.set(ax, G + 1, az, Block.SANDBAG); }
            if (k >= -1 && g.air(bx, G, bz)) { g.set(bx, G, bz, Block.SANDBAG); if (k % 2 == 0) g.set(bx, G + 1, bz, Block.SANDBAG); }
        }
        if (g.air(x, G, z)) g.set(x, G, z, Block.BARRIER);
        if (!faction.isEmpty()) g.post("Roadblock", "checkpoint", faction, alongX ? x - 5 : x, G, alongX ? z : z - 5);
    }
}
