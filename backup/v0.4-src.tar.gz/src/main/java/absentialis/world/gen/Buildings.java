package absentialis.world.gen;

import static absentialis.world.gen.Gen.FLOOR_H;
import static absentialis.world.gen.Gen.G;

import absentialis.engine.util.Rng;
import absentialis.world.Block;
import java.util.ArrayList;
import java.util.List;

/**
 * Procedural multi-storey building generator: slabs, facades with window rhythm, switchback
 * stairwells to the roof, BSP-partitioned interiors with doors, roofs with props and access huts,
 * balconies, fire escapes, jettied overhangs and damage/burn states.
 */
public final class Buildings {
    public enum Style { RESIDENTIAL, SHOP, OFFICE, WAREHOUSE, CLINIC, HOSPITAL, WORKSHOP, BARRACKS, LAB, HOUSE, CHAPEL }
    public enum Roof { FLAT, PITCHED, NONE }

    /** Street-facing sides: 0 = north(-z), 1 = east(+x), 2 = south(+z), 3 = west(-x). */
    public static final class Spec {
        public int x0, z0, w, d, floors = 3;
        public int wall = Block.BRICK_RED, trim = Block.CONCRETE, slab = Block.CONCRETE_FLOOR, roof = Block.ROOF_TAR, window = Block.GLASS_DIRTY;
        public int interiorWall = -1;
        public Style style = Style.RESIDENTIAL;
        public Roof roofType = Roof.FLAT;
        public boolean[] street = new boolean[4];
        public float broken = 0.3f, boarded = 0.1f, damage = 0f;
        public boolean burnt, basement, balconies, fireEscape, jetty, shopfront, curtainWall, lit = true, roofAccess = true, ground = true;
        public int windowSpacing = 3;
        public String lootBias = null;
        public Spec(int x0, int z0, int w, int d) { this.x0 = x0; this.z0 = z0; this.w = w; this.d = d; }
    }

    public static final class Room {
        public final int x0, z0, x1, z1, y, floor;
        public String type;
        public Room(int x0, int z0, int x1, int z1, int y, int floor) { this.x0 = x0; this.z0 = z0; this.x1 = x1; this.z1 = z1; this.y = y; this.floor = floor; }
        public int w() { return x1 - x0 + 1; }
        public int d() { return z1 - z0 + 1; }
        public int area() { return w() * d(); }
    }

    private final Gen g;
    public Buildings(Gen g) { this.g = g; }

    /** Builds the structure; returns the generated rooms. */
    public List<Room> build(Spec s) {
        Rng r = g.rng(s.x0 * 31 + s.z0, s.w * 7 + s.d);
        List<Room> rooms = new ArrayList<>();
        int x0 = s.x0, z0 = s.z0, x1 = s.x0 + s.w - 1, z1 = s.z0 + s.d - 1;
        int top = G - 1 + s.floors * FLOOR_H;
        int iw = s.interiorWall >= 0 ? s.interiorWall : defaultInteriorWall(s.style, r);

        // clear volume (keeps whatever is below street level)
        int jx = s.jetty ? 1 : 0;
        g.fill(x0 - (s.street[3] ? jx : 0), G, z0 - (s.street[0] ? jx : 0), x1 + (s.street[1] ? jx : 0), top + 6, z1 + (s.street[2] ? jx : 0), Block.AIR);

        if (s.basement) basement(s, r, rooms);

        // stair core geometry
        boolean runZ = s.d >= s.w;
        int coreLen = 6;
        boolean hasStairs = s.floors > 1 || s.roofAccess;
        int cx, cz;
        if (runZ) { cx = x0 + 1 + (r.chance(0.5) ? 0 : Math.max(0, s.w - 4)); cz = z0 + 1 + Math.max(0, (s.d - 2 - coreLen) / 2 * (r.chance(0.5) ? 0 : 1)); }
        else { cz = z0 + 1 + (r.chance(0.5) ? 0 : Math.max(0, s.d - 4)); cx = x0 + 1 + Math.max(0, (s.w - 2 - coreLen) / 2 * (r.chance(0.5) ? 0 : 1)); }
        if (s.w < 5 || s.d < 5 || (runZ ? s.d < coreLen + 2 : s.w < coreLen + 2)) hasStairs = false;

        for (int f = 0; f < s.floors; f++) {
            int y0 = G - 1 + f * FLOOR_H;
            int ex0 = x0, ez0 = z0, ex1 = x1, ez1 = z1;
            if (s.jetty && f >= 1) {
                if (s.street[0]) ez0--;
                if (s.street[1]) ex1++;
                if (s.street[2]) ez1++;
                if (s.street[3]) ex0--;
            }
            // floor slab: trim ring + interior floor material
            g.fill(ex0, y0, ez0, ex1, y0, ez1, s.slab);
            ring(ex0, y0, ez0, ex1, ez1, s.trim);
            // exterior walls
            g.walls(ex0, y0 + 1, ez0, ex1, y0 + FLOOR_H - 1, ez1, s.wall);
            // corner pillars
            for (int y = y0 + 1; y < y0 + FLOOR_H; y++) {
                g.set(ex0, y, ez0, s.trim); g.set(ex1, y, ez0, s.trim); g.set(ex0, y, ez1, s.trim); g.set(ex1, y, ez1, s.trim);
            }
            facade(s, r, f, y0, ex0, ez0, ex1, ez1);
            // interior partitions
            List<Room> fr = new ArrayList<>();
            if (noPartitions(s.style, f)) fr.add(new Room(ex0 + 1, ez0 + 1, ex1 - 1, ez1 - 1, y0, f));
            else split(s, r, ex0 + 1, ez0 + 1, ex1 - 1, ez1 - 1, y0, f, iw, fr, maxRoom(s.style), 0);
            rooms.addAll(fr);
        }
        // roof slab
        int rx0 = x0, rz0 = z0, rx1 = x1, rz1 = z1;
        if (s.jetty && s.floors > 1) { if (s.street[0]) rz0--; if (s.street[1]) rx1++; if (s.street[2]) rz1++; if (s.street[3]) rx0--; }
        if (s.roofType == Roof.PITCHED) pitchedRoof(s, r, rx0, rz0, rx1, rz1, top);
        else if (s.roofType == Roof.FLAT) {
            g.fill(rx0, top, rz0, rx1, top, rz1, s.roof);
            for (int x = rx0; x <= rx1; x++) for (int z = rz0; z <= rz1; z++) if (x == rx0 || x == rx1 || z == rz0 || z == rz1) g.set(x, top + 1, z, s.trim);
        }

        // stairwell carved through all floors
        if (hasStairs) stairs(s, r, runZ, cx, cz, top);

        // exterior doors
        doors(s, r, x0, z0, x1, z1);

        // dress rooms
        Interiors in = new Interiors(g);
        for (Room room : rooms) in.dress(room, s, r);

        if (s.roofType == Roof.FLAT) roofProps(s, r, rx0, rz0, rx1, rz1, top, hasStairs, runZ, cx, cz);
        if (s.balconies && s.floors > 1) balconies(s, r, x0, z0, x1, z1);
        if (s.fireEscape && s.floors > 1) fireEscape(s, r, x0, z0, x1, z1, top);
        if (s.damage > 0) damage(s, r, x0, z0, x1, z1, top);
        if (s.burnt) burn(s, r, x0, z0, x1, z1, top);
        return rooms;
    }

    private void ring(int x0, int y, int z0, int x1, int z1, int id) {
        for (int x = x0; x <= x1; x++) { g.set(x, y, z0, id); g.set(x, y, z1, id); }
        for (int z = z0; z <= z1; z++) { g.set(x0, y, z, id); g.set(x1, y, z, id); }
    }

    private static int defaultInteriorWall(Style st, Rng r) {
        switch (st) {
            case OFFICE: return Block.OFFICE_PANEL;
            case CLINIC: case HOSPITAL: case LAB: return Block.TILE_WHITE;
            case WAREHOUSE: case WORKSHOP: return Block.CONCRETE_DARK;
            case BARRACKS: return Block.CONCRETE;
            case CHAPEL: return Block.STONE_BLOCK;
            default: return r.pick(new int[]{Block.WALLPAPER_FLORAL, Block.WALLPAPER_STRIPE, Block.PLASTER, Block.WALLPAPER_TORN});
        }
    }

    private static boolean noPartitions(Style st, int floor) {
        return st == Style.WAREHOUSE || st == Style.CHAPEL || (st == Style.SHOP && floor == 0) || (st == Style.WORKSHOP && floor == 0);
    }

    private static int maxRoom(Style st) {
        switch (st) {
            case OFFICE: return 12;
            case HOSPITAL: return 10;
            case BARRACKS: return 11;
            default: return 8;
        }
    }

    // ------------------------------------------------------------------ facade / windows
    private void facade(Spec s, Rng r, int f, int y0, int ex0, int ez0, int ex1, int ez1) {
        for (int side = 0; side < 4; side++) {
            int len = (side % 2 == 0) ? (ex1 - ex0 + 1) : (ez1 - ez0 + 1);
            boolean shop = s.shopfront && f == 0 && s.street[side];
            for (int i = 1; i < len - 1; i++) {
                int x, z;
                switch (side) {
                    case 0: x = ex0 + i; z = ez0; break;
                    case 1: x = ex1; z = ez0 + i; break;
                    case 2: x = ex0 + i; z = ez1; break;
                    default: x = ex0; z = ez0 + i;
                }
                if (shop) {
                    boolean pillar = i % 5 == 0;
                    if (pillar) continue;
                    for (int y = y0 + 1; y <= y0 + 2; y++) g.set(x, y, z, windowState(s, r, Block.GLASS, true));
                    g.set(x, y0 + 3, z, Block.SIGN_SHOP);
                    continue;
                }
                if (s.curtainWall) {
                    boolean mullion = i % 4 == 0;
                    for (int y = y0 + 1; y < y0 + FLOOR_H; y++) g.set(x, y, z, mullion ? s.trim : windowState(s, r, s.window, f == 0));
                    continue;
                }
                if (i % s.windowSpacing != 1 % s.windowSpacing) continue;
                if (i == len - 2 && len > 4 && s.windowSpacing > 1 && (len - 2) % s.windowSpacing == 0) continue;
                int wb = windowState(s, r, s.window, f == 0);
                g.set(x, y0 + 2, z, wb);
                if (s.style == Style.OFFICE || s.style == Style.HOSPITAL || s.style == Style.CHAPEL || (s.style == Style.WAREHOUSE && f == 0 && r.chance(0.2)))
                    g.set(x, y0 + 3, z, wb == Block.BOARDED ? Block.BOARDED : windowState(s, r, s.window, false));
            }
        }
    }

    private int windowState(Spec s, Rng r, int glass, boolean groundFloor) {
        float boarded = s.boarded * (groundFloor ? 2.2f : 1f);
        if (r.chance(boarded)) return Block.BOARDED;
        if (r.chance(s.broken)) return Block.AIR;
        if (r.chance(0.18)) return glass == Block.GLASS_BLUE ? Block.GLASS_BLUE : Block.GLASS_CRACKED;
        return glass;
    }

    // ------------------------------------------------------------------ partitions
    private void split(Spec s, Rng r, int ax, int az, int bx, int bz, int y0, int f, int iw, List<Room> out, int max, int depth) {
        int wdt = bx - ax + 1, dep = bz - az + 1;
        boolean canX = wdt > max && wdt >= 7, canZ = dep > max && dep >= 7;
        if ((!canX && !canZ) || depth > 7) {
            out.add(new Room(ax, az, bx, bz, y0, f));
            return;
        }
        boolean splitX = canX && (!canZ || wdt >= dep);
        if (splitX) {
            int sx = ax + 3 + r.nextInt(Math.max(1, wdt - 6));
            g.fill(sx, y0 + 1, az, sx, y0 + FLOOR_H - 1, bz, iw);
            int door = az + 1 + r.nextInt(Math.max(1, dep - 2));
            interiorDoor(s, r, sx, y0, door);
            split(s, r, ax, az, sx - 1, bz, y0, f, iw, out, max, depth + 1);
            split(s, r, sx + 1, az, bx, bz, y0, f, iw, out, max, depth + 1);
        } else {
            int sz = az + 3 + r.nextInt(Math.max(1, dep - 6));
            g.fill(ax, y0 + 1, sz, bx, y0 + FLOOR_H - 1, sz, iw);
            int door = ax + 1 + r.nextInt(Math.max(1, wdt - 2));
            interiorDoor(s, r, door, y0, sz);
            split(s, r, ax, az, bx, sz - 1, y0, f, iw, out, max, depth + 1);
            split(s, r, ax, sz + 1, bx, bz, y0, f, iw, out, max, depth + 1);
        }
    }

    private void interiorDoor(Spec s, Rng r, int x, int y0, int z) {
        float roll = r.nextFloat();
        int door = roll < 0.35f ? Block.DOOR_WOOD : (roll < 0.75f ? Block.DOOR_WOOD_OPEN : Block.AIR);
        if (s.style == Style.HOSPITAL || s.style == Style.LAB || s.style == Style.BARRACKS) door = roll < 0.4f ? Block.DOOR_METAL_OPEN : (roll < 0.6f ? Block.DOOR_METAL : Block.AIR);
        g.set(x, y0 + 1, z, door);
        g.set(x, y0 + 2, z, door == Block.DOOR_WOOD ? Block.DOOR_WOOD : (door == Block.DOOR_METAL ? Block.DOOR_METAL : (door == Block.AIR ? Block.AIR : door)));
    }

    // ------------------------------------------------------------------ stairs
    private void stairs(Spec s, Rng r, boolean runZ, int cx, int cz, int top) {
        int step = s.style == Style.HOUSE || s.style == Style.CHAPEL ? Block.STAIRS_WOOD : Block.STAIRS_CONCRETE;
        int support = step == Block.STAIRS_WOOD ? Block.WOOD_DARK : Block.CONCRETE;
        int floorsWithStairs = s.roofAccess && s.roofType == Roof.FLAT ? s.floors : s.floors - 1;
        for (int f = 0; f < floorsWithStairs; f++) {
            int y0 = G - 1 + f * FLOOR_H;
            // clear core volume on this floor
            for (int a = 0; a < 2; a++) for (int l = 0; l < 6; l++) {
                int[] p = cell(runZ, cx, cz, a, l);
                for (int y = y0 + 1; y < y0 + FLOOR_H; y++) g.set(p[0], y, p[1], Block.AIR);
                // make sure the landing floor exists
                if (g.get(p[0], y0, p[1]) == Block.AIR && f > 0) {} else g.set(p[0], y0, p[1], g.get(p[0], y0, p[1]) == 0 ? s.slab : g.get(p[0], y0, p[1]));
            }
            int c = f % 2;
            for (int k = 1; k <= 3; k++) {
                int along = c == 0 ? k : 5 - k;
                int[] p = cell(runZ, cx, cz, c, along);
                for (int y = y0 + 1; y < y0 + k; y++) g.set(p[0], y, p[1], support);
                g.set(p[0], y0 + k, p[1], step);
                g.set(p[0], y0 + FLOOR_H, p[1], Block.AIR); // opening in slab above
            }
            // last step coincides with upper slab: ensure solid landing tile
            int[] land = cell(runZ, cx, cz, c, c == 0 ? 4 : 1);
            g.set(land[0], y0 + FLOOR_H, land[1], s.slab);
        }
        if (s.roofAccess && s.roofType == Roof.FLAT) {
            // stair hut on the roof
            int[] a = cell(runZ, cx, cz, 0, 0), b = cell(runZ, cx, cz, 1, 5);
            int hx0 = Math.min(a[0], b[0]) - 1, hx1 = Math.max(a[0], b[0]) + 1, hz0 = Math.min(a[1], b[1]) - 1, hz1 = Math.max(a[1], b[1]) + 1;
            g.walls(hx0, top + 1, hz0, hx1, top + 3, hz1, s.trim == Block.CONCRETE ? Block.CONCRETE_DARK : s.trim);
            g.fill(hx0, top + 4, hz0, hx1, top + 4, hz1, Block.ROOF_TAR);
            // door on the end where the last step arrives
            int lastC = (s.floors - 1) % 2;
            int[] arrive = cell(runZ, cx, cz, lastC, lastC == 0 ? 5 : 0);
            int dx = runZ ? arrive[0] : (lastC == 0 ? hx1 : hx0), dz = runZ ? (lastC == 0 ? hz1 : hz0) : arrive[1];
            g.set(dx, top + 1, dz, Block.DOOR_METAL_OPEN);
            g.set(dx, top + 2, dz, Block.DOOR_METAL_OPEN);
            g.lamp(runZ ? hx0 + 1 : (hx0 + hx1) / 2, top + 3, runZ ? (hz0 + hz1) / 2 : hz0 + 1);
        }
    }

    private static int[] cell(boolean runZ, int cx, int cz, int across, int along) {
        return runZ ? new int[]{cx + across, cz + along} : new int[]{cx + along, cz + across};
    }

    // ------------------------------------------------------------------ doors
    private void doors(Spec s, Rng r, int x0, int z0, int x1, int z1) {
        boolean any = false;
        for (int side = 0; side < 4; side++) {
            if (!s.street[side]) continue;
            any = true;
            placeDoor(s, r, side, x0, z0, x1, z1, true);
            if ((side % 2 == 0 ? s.w : s.d) > 22) placeDoor(s, r, side, x0, z0, x1, z1, false);
        }
        if (!any) placeDoor(s, r, r.nextInt(4), x0, z0, x1, z1, true);
        // a back/side door for flanking options
        if (r.chance(0.5)) {
            int side = r.nextInt(4);
            if (!s.street[side]) placeDoor(s, r, side, x0, z0, x1, z1, false);
        }
    }

    private void placeDoor(Spec s, Rng r, int side, int x0, int z0, int x1, int z1, boolean main) {
        int len = (side % 2 == 0) ? (x1 - x0 + 1) : (z1 - z0 + 1);
        int i = main ? len / 2 : 2 + r.nextInt(Math.max(1, len - 4));
        int x, z, ix, iz;
        switch (side) {
            case 0: x = x0 + i; z = z0; ix = 0; iz = 1; break;
            case 1: x = x1; z = z0 + i; ix = -1; iz = 0; break;
            case 2: x = x0 + i; z = z1; ix = 0; iz = -1; break;
            default: x = x0; z = z0 + i; ix = 1; iz = 0;
        }
        float roll = r.nextFloat();
        int door;
        if (s.style == Style.WAREHOUSE || s.style == Style.WORKSHOP) {
            // large roller opening
            int half = main ? 2 : 1;
            for (int k = -half; k <= half; k++) for (int y = G; y < G + 3; y++) g.set(x + (side % 2 == 0 ? k : 0), y, z + (side % 2 == 0 ? 0 : k), roll < 0.3f ? Block.CORRUGATED_RUST : Block.AIR);
            return;
        }
        door = roll < 0.35f ? Block.DOOR_WOOD : (roll < 0.6f ? Block.DOOR_WOOD_OPEN : (roll < 0.8f ? Block.AIR : Block.BARRICADE));
        if (s.style == Style.OFFICE || s.style == Style.HOSPITAL || s.style == Style.LAB) door = roll < 0.4f ? Block.GLASS : (roll < 0.7f ? Block.AIR : Block.DOOR_METAL);
        if (s.style == Style.BARRACKS) door = Block.DOOR_METAL;
        g.set(x, G, z, door);
        g.set(x, G + 1, z, door == Block.BARRICADE ? Block.BARRICADE : door);
        if (door == Block.BARRICADE) g.map.barricades.add(new absentialis.world.MapData.Point("barricade", "barricade", x, G, z, g.district(x, z)));
        // keep the entry clear
        for (int k = 1; k <= 2; k++) for (int y = G; y < G + 3; y++) {
            int c = g.get(x + ix * k, y, z + iz * k);
            if (c != Block.AIR && c != Block.STAIRS_CONCRETE && c != Block.STAIRS_WOOD) g.set(x + ix * k, y, z + iz * k, Block.AIR);
        }
        // step / threshold outside
        g.set(x - ix, G - 1, z - iz, s.trim == Block.CONCRETE ? Block.CONCRETE : g.get(x - ix, G - 1, z - iz));
    }

    // ------------------------------------------------------------------ basement
    private void basement(Spec s, Rng r, List<Room> rooms) {
        int x0 = s.x0, z0 = s.z0, x1 = s.x0 + s.w - 1, z1 = s.z0 + s.d - 1;
        int y0 = G - 1 - FLOOR_H;
        g.fill(x0, y0, z0, x1, G - 2, z1, Block.CONCRETE_DARK);
        g.fill(x0 + 1, y0 + 1, z0 + 1, x1 - 1, G - 2, z1 - 1, Block.AIR);
        g.fill(x0 + 1, y0, z0 + 1, x1 - 1, y0, z1 - 1, Block.CONCRETE_FLOOR);
        // ladder down from ground floor corner
        int lx = x1 - 1, lz = z1 - 1;
        for (int y = y0 + 1; y <= G - 1; y++) g.set(lx, y, lz, Block.LADDER);
        g.set(lx, G - 1, lz, Block.LADDER);
        Room b = new Room(x0 + 1, z0 + 1, x1 - 1, z1 - 1, y0, -1);
        b.type = "basement";
        rooms.add(b);
    }

    // ------------------------------------------------------------------ roofs
    private void pitchedRoof(Spec s, Rng r, int x0, int z0, int x1, int z1, int top) {
        boolean ridgeX = (x1 - x0) >= (z1 - z0);
        int span = ridgeX ? (z1 - z0) : (x1 - x0);
        g.fill(x0, top, z0, x1, top, z1, s.slab);
        for (int k = 0; k <= span / 2 + 1; k++) {
            int y = top + k;
            if (ridgeX) {
                int a = z0 - 1 + k, b = z1 + 1 - k;
                if (a > b) break;
                for (int x = x0 - 1; x <= x1 + 1; x++) { g.set(x, y, a, s.roof); g.set(x, y, b, s.roof); }
                if (a + 1 <= b - 1) { // gable ends
                    for (int z = a + 1; z <= b - 1; z++) { g.set(x0, y, z, s.wall); g.set(x1, y, z, s.wall); }
                    if (k == 2 && b - a > 3) { g.set(x0, y, (a + b) / 2, s.window); g.set(x1, y, (a + b) / 2, s.window); }
                }
            } else {
                int a = x0 - 1 + k, b = x1 + 1 - k;
                if (a > b) break;
                for (int z = z0 - 1; z <= z1 + 1; z++) { g.set(a, y, z, s.roof); g.set(b, y, z, s.roof); }
                if (a + 1 <= b - 1) for (int x = a + 1; x <= b - 1; x++) { g.set(x, y, z0, s.wall); g.set(x, y, z1, s.wall); }
            }
        }
        // chimney
        if (r.chance(0.6)) {
            int cx = x0 + 1 + r.nextInt(Math.max(1, x1 - x0 - 1)), cz = z0 + 1 + r.nextInt(Math.max(1, z1 - z0 - 1));
            for (int y = top + 1; y < top + span / 2 + 3; y++) g.set(cx, y, cz, Block.BRICK_BROWN);
        }
    }

    private void roofProps(Spec s, Rng r, int x0, int z0, int x1, int z1, int top, boolean hut, boolean runZ, int cx, int cz) {
        int y = top + 1;
        int n = (s.w * s.d) / 60 + 1;
        for (int i = 0; i < n; i++) {
            int x = x0 + 2 + r.nextInt(Math.max(1, s.w - 4)), z = z0 + 2 + r.nextInt(Math.max(1, s.d - 4));
            if (g.get(x, y, z) != 0 || g.get(x, top, z) == 0) continue;
            if (hut && Math.abs(x - cx) < 4 && Math.abs(z - cz) < 8) continue;
            float roll = r.nextFloat();
            if (roll < 0.3f) { g.set(x, y, z, Block.AC_UNIT); if (g.air(x + 1, y, z)) g.set(x + 1, y, z, Block.AC_UNIT); }
            else if (roll < 0.45f) g.set(x, y, z, Block.VENT);
            else if (roll < 0.55f && s.w > 8 && s.d > 8) { // water tank on legs
                if (x + 1 < x1 && z + 1 < z1) {
                    for (int dx = 0; dx < 2; dx++) for (int dz = 0; dz < 2; dz++) { g.set(x + dx, y, z + dz, Block.STEEL_BEAM); g.fill(x + dx, y + 1, z + dz, x + dx, y + 2, z + dz, Block.WATER_TANK); }
                }
            } else if (roll < 0.62f) { for (int k = 0; k < 5; k++) g.set(x, y + k, z, Block.IRON_FENCE); }
            else if (roll < 0.72f) g.container(x, y, z, Block.CRATE, s.lootBias);
            else if (roll < 0.78f) { // rooftop sniper/lookout nest
                g.set(x, y, z, Block.SANDBAG); if (g.air(x + 1, y, z)) g.set(x + 1, y, z, Block.SANDBAG); if (g.air(x, y, z + 1)) g.set(x, y, z + 1, Block.SANDBAG);
            } else if (roll < 0.86f) g.set(x, y, z, Block.PIPE);
        }
        // parapet gaps facing neighbours for rooftop traversal
        for (int k = 0; k < 2; k++) {
            int side = r.nextInt(4);
            int gx = side % 2 == 0 ? x0 + 1 + r.nextInt(Math.max(1, s.w - 2)) : (side == 1 ? x1 : x0);
            int gz = side % 2 == 1 ? z0 + 1 + r.nextInt(Math.max(1, s.d - 2)) : (side == 2 ? z1 : z0);
            g.set(gx, y, gz, Block.AIR);
        }
    }

    // ------------------------------------------------------------------ balconies / fire escapes
    private void balconies(Spec s, Rng r, int x0, int z0, int x1, int z1) {
        for (int side = 0; side < 4; side++) {
            if (!s.street[side]) continue;
            int len = (side % 2 == 0) ? s.w : s.d;
            for (int f = 1; f < s.floors; f++) {
                int y0 = G - 1 + f * FLOOR_H;
                for (int i = 2; i < len - 3; i += 6) {
                    if (!r.chance(0.55)) continue;
                    int ox = side == 1 ? 1 : (side == 3 ? -1 : 0), oz = side == 2 ? 1 : (side == 0 ? -1 : 0);
                    int bx = side % 2 == 0 ? x0 + i : (side == 1 ? x1 : x0), bz = side % 2 == 1 ? z0 + i : (side == 2 ? z1 : z0);
                    for (int k = 0; k < 3; k++) {
                        int px = bx + (side % 2 == 0 ? k : 0) + ox, pz = bz + (side % 2 == 1 ? k : 0) + oz;
                        if (!g.air(px, y0, pz)) continue;
                        g.set(px, y0, pz, Block.CONCRETE);
                        g.set(px + ox, y0 + 1, pz + oz, Block.AIR);
                        g.set(px, y0 + 1, pz, k == 1 ? Block.AIR : Block.IRON_FENCE);
                        g.set(px + ox, y0, pz + oz, Block.AIR);
                    }
                    for (int k = 0; k < 3; k++) {
                        int px = bx + (side % 2 == 0 ? k : 0) + ox * 2, pz = bz + (side % 2 == 1 ? k : 0) + oz * 2;
                        if (g.air(px, y0 + 1, pz) && g.air(px, y0, pz)) g.set(px - ox, y0 + 1, pz - oz, Block.IRON_FENCE);
                    }
                    int mx = bx + (side % 2 == 0 ? 1 : 0), mz = bz + (side % 2 == 1 ? 1 : 0);
                    g.set(mx, y0 + 1, mz, Block.DOOR_WOOD_OPEN);
                    g.set(mx, y0 + 2, mz, Block.DOOR_WOOD_OPEN);
                    if (r.chance(0.3)) g.set(mx + ox, y0 + 1, mz + oz, Block.LAUNDRY);
                }
            }
        }
    }

    private void fireEscape(Spec s, Rng r, int x0, int z0, int x1, int z1, int top) {
        int side = -1;
        for (int k = 0; k < 4; k++) { int sd = (k + r.nextInt(4)) % 4; if (!s.street[sd]) { side = sd; break; } }
        if (side < 0) side = r.nextInt(4);
        int len = (side % 2 == 0) ? s.w : s.d;
        if (len < 7) return;
        int i = 2 + r.nextInt(len - 6);
        int ox = side == 1 ? 1 : (side == 3 ? -1 : 0), oz = side == 2 ? 1 : (side == 0 ? -1 : 0);
        int bx = side % 2 == 0 ? x0 + i : (side == 1 ? x1 : x0), bz = side % 2 == 1 ? z0 + i : (side == 2 ? z1 : z0);
        int lx = bx + ox, lz = bz + oz;
        // ladder from street to roof
        for (int y = G + 1; y <= top + 1; y++) if (g.air(lx, y, lz)) g.set(lx, y, lz, Block.LADDER);
        for (int f = 1; f < s.floors; f++) {
            int y0 = G - 1 + f * FLOOR_H;
            for (int k = 1; k <= 3; k++) {
                int px = lx + (side % 2 == 0 ? k : 0), pz = lz + (side % 2 == 1 ? k : 0);
                if (!g.air(px, y0, pz)) continue;
                g.set(px, y0, pz, Block.GRATE);
                g.set(px + ox, y0 + 1, pz + oz, Block.IRON_FENCE);
            }
            int wx = bx + (side % 2 == 0 ? 2 : 0), wz = bz + (side % 2 == 1 ? 2 : 0);
            g.set(wx, y0 + 1, wz, Block.AIR);
            g.set(wx, y0 + 2, wz, Block.AIR);
        }
        g.set(bx, top + 1, bz, Block.AIR); // parapet gap above ladder
        g.set(lx, top + 1, lz, Block.LADDER);
    }

    // ------------------------------------------------------------------ damage
    private void damage(Spec s, Rng r, int x0, int z0, int x1, int z1, int top) {
        int holes = (int) (s.damage * (s.floors + 2) * 1.5f);
        for (int i = 0; i < holes; i++) {
            int side = r.nextInt(4);
            float x = side % 2 == 0 ? x0 + r.nextInt(s.w) : (side == 1 ? x1 : x0);
            float z = side % 2 == 1 ? z0 + r.nextInt(s.d) : (side == 2 ? z1 : z0);
            float y = G + 2 + r.nextInt(Math.max(1, top - G));
            float rad = 1.5f + r.nextFloat() * (1.5f + s.damage * 2.5f);
            g.sphere(x, y, z, rad, Block.AIR, true);
            g.rubblePile((int) x + (side == 1 ? 2 : side == 3 ? -2 : 0), (int) z + (side == 2 ? 2 : side == 0 ? -2 : 0), (int) rad, (int) rad, Block.RUBBLE);
        }
        if (s.damage > 0.6f && s.floors > 2) {
            // collapsed corner section
            int cx = r.chance(0.5) ? x0 : x1 - Math.min(6, s.w / 2), cz = r.chance(0.5) ? z0 : z1 - Math.min(6, s.d / 2);
            int fromY = G + FLOOR_H * (1 + r.nextInt(Math.max(1, s.floors - 1)));
            g.fill(cx, fromY, cz, cx + Math.min(6, s.w / 2), top + 2, cz + Math.min(6, s.d / 2), Block.AIR);
            g.rubblePile(cx + 3, cz + 3, 5, 4, Block.RUBBLE);
            // exposed rebar / beams
            for (int k = 0; k < 4; k++) { int bx = cx + r.nextInt(6), bz = cz + r.nextInt(6); for (int y = fromY; y < fromY + 3; y++) g.setIfAir(bx, y, bz, Block.STEEL_BEAM); }
        }
    }

    private void burn(Spec s, Rng r, int x0, int z0, int x1, int z1, int top) {
        for (int x = x0 - 1; x <= x1 + 1; x++) for (int z = z0 - 1; z <= z1 + 1; z++) for (int y = G - 1; y <= top + 6; y++) {
            int id = g.get(x, y, z);
            if (id == 0) continue;
            float h = Rng.hash(x, y, z, 99);
            if (h > 0.85f) continue;
            if (id == Block.WOOD_PLANKS || id == Block.WOOD_DARK || id == Block.PARQUET || id == Block.DOOR_WOOD || id == Block.ROOF_TILES || id == Block.WOOD_GREEN) g.set(x, y, z, Block.CHAR_WOOD);
            else if (id == Block.CARPET_RED || id == Block.CARPET_BLUE || id == Block.CARPET_GRAY || id == Block.LINOLEUM) g.set(x, y, z, Block.ASH);
            else if (id == Block.BRICK_RED || id == Block.BRICK_BROWN || id == Block.PLASTER || id == Block.PLASTER_OCHRE || id == Block.PLASTER_BLUE || id == Block.WALLPAPER_FLORAL || id == Block.WALLPAPER_STRIPE || id == Block.BRICK_YELLOW || id == Block.BRICK_WHITE) g.set(x, y, z, Block.BRICK_BURNT);
            else if (id == Block.GLASS || id == Block.GLASS_DIRTY || id == Block.GLASS_CRACKED) g.set(x, y, z, Block.AIR);
            else if (id == Block.SOFA || id == Block.BED || id == Block.TABLE || id == Block.CHAIR) g.set(x, y, z, h < 0.4f ? Block.ASH : Block.AIR);
        }
        for (int i = 0; i < 3; i++) { int x = x0 + r.nextInt(s.w), z = z0 + r.nextInt(s.d); if (g.air(x, G, z)) g.set(x, G, z, Block.EMBER); }
    }
}
