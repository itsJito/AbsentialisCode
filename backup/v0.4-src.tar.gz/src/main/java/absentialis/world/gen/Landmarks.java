package absentialis.world.gen;

import static absentialis.world.gen.Gen.FLOOR_H;
import static absentialis.world.gen.Gen.G;

import absentialis.engine.util.Rng;
import absentialis.world.Block;
import absentialis.world.gen.Buildings.Spec;
import absentialis.world.gen.Buildings.Style;
import absentialis.world.gen.Streets.Rect;

/** Authored set-pieces: the readable landmarks that anchor each district's identity. */
public final class Landmarks {
    private final Gen g;
    private final Buildings b;

    public Landmarks(Gen g) { this.g = g; this.b = new Buildings(g); }

    private void clearLot(Rect r, int ground) {
        g.fill(r.x0(), G, r.z0(), r.x1() - 1, World_H(), r.z1() - 1, Block.AIR);
        g.fill(r.x0(), G - 1, r.z0(), r.x1() - 1, G - 1, r.z1() - 1, ground);
    }

    private static int World_H() { return absentialis.world.World.H - 1; }

    // =================================================================== OLD QUARTER
    /** Gothic cathedral with nave, aisles, stained glass, spire, crypt and catacombs. */
    public void cathedral(Rect r, Rng rng) {
        clearLot(r, Block.COBBLE);
        int x0 = r.x0() + 3, z0 = r.z0() + 3, x1 = r.x1() - 4, z1 = r.z1() - 4;
        int wall = Block.STONE_BLOCK, dark = Block.STONE_DARK;
        int nh = 18; // nave wall height
        int cx = (x0 + x1) / 2;
        // floor
        g.fill(x0, G - 1, z0, x1, G - 1, z1, Block.MARBLE);
        // outer walls (aisles) and inner nave walls
        g.walls(x0, G, z0, x1, G + 9, z1, wall);
        g.walls(cx - 8, G, z0, cx + 8, G + nh, z1, wall);
        // arcade openings in nave walls
        for (int z = z0 + 4; z < z1 - 3; z += 5) for (int y = G; y < G + 6; y++) {
            int h = y - G;
            for (int k = -1; k <= 1; k++) if (h < 5 || k == 0) { g.set(cx - 8, y, z + k, Block.AIR); g.set(cx + 8, y, z + k, Block.AIR); }
        }
        // buttresses and pointed windows
        for (int z = z0 + 2; z < z1; z += 5) {
            for (int y = G; y < G + 9; y++) { g.set(x0 - 1, y, z, dark); g.set(x1 + 1, y, z, dark); }
            for (int y = G + 2; y < G + 7; y++) { g.set(x0, y, z + 2, Block.GLASS_STAINED); g.set(x1, y, z + 2, Block.GLASS_STAINED); }
            for (int y = G + 11; y < G + nh - 2; y++) { g.set(cx - 8, y, z + 2, Block.GLASS_STAINED); g.set(cx + 8, y, z + 2, Block.GLASS_STAINED); }
        }
        // aisle roofs (sloped slate) + nave pitched roof
        for (int x = x0; x <= x1; x++) {
            int dx = Math.min(Math.abs(x - (cx - 8)), Math.abs(x - (cx + 8)));
            if (x > cx - 8 && x < cx + 8) continue;
            int y = G + 10 + Math.max(0, 4 - (Math.abs(x - cx) - 8) / 2);
            g.fill(x, y, z0, x, y, z1, Block.ROOF_SLATE);
        }
        for (int k = 0; k <= 9; k++) {
            int y = G + nh + 1 + k;
            for (int z = z0 - 1; z <= z1 + 1; z++) { g.set(cx - 9 + k, y, z, Block.ROOF_SLATE); g.set(cx + 9 - k, y, z, Block.ROOF_SLATE); }
            if (k < 9) for (int x = cx - 8 + k; x <= cx + 8 - k; x++) { g.set(x, y, z0, wall); g.set(x, y, z1, wall); }
        }
        g.fill(cx - 8, G + nh, z0, cx + 8, G + nh, z1, Block.STONE_DARK);
        // rose window and portal (north facade z0)
        for (int dx = -4; dx <= 4; dx++) for (int dy = -4; dy <= 4; dy++) if (dx * dx + dy * dy <= 17) g.set(cx + dx, G + nh - 5 + dy, z0, Block.GLASS_STAINED);
        for (int dx = -2; dx <= 2; dx++) for (int y = G; y < G + 5 - (Math.abs(dx) == 2 ? 1 : 0); y++) g.set(cx + dx, y, z0, Block.AIR);
        g.set(cx - 2, G + 4, z0, Block.STONE_CARVED); g.set(cx + 2, G + 4, z0, Block.STONE_CARVED);
        // pews, altar with cult desecration
        for (int z = z0 + 6; z < z1 - 12; z += 2) for (int x = cx - 6; x <= cx + 6; x++) if (Math.abs(x - cx) > 1) g.set(x, G, z, Block.PEW);
        int az = z1 - 7;
        g.fill(cx - 4, G, az - 1, cx + 4, G, z1 - 1, Block.STONE_BLOCK);
        g.fill(cx - 2, G + 1, az + 1, cx + 2, G + 1, az + 2, Block.ALTAR);
        for (int x = cx - 4; x <= cx + 4; x += 2) g.set(x, G + 1, az - 1, Block.CANDLES);
        g.set(cx - 5, G + 3, z1 - 1, Block.BANNER_CULT); g.set(cx + 5, G + 3, z1 - 1, Block.BANNER_CULT);
        g.set(cx, G + 6, z1 - 1, Block.BANNER_CULT);
        for (int i = 0; i < 6; i++) g.set(cx - 6 + rng.nextInt(13), G - 1, az - 4 + rng.nextInt(4), Block.BLOOD_FLOOR);
        g.container(cx + 3, G + 1, az + 3, Block.COFFIN, "cult");
        g.container(cx - 3, G + 1, az + 3, Block.CRATE, "cult");
        g.post("Cathedral Altar", "guard", "mercenaries", cx, G, az - 3);
        g.post("Cathedral Nave", "guard", "mercenaries", cx, G, z0 + 10);
        g.landmark("Cathedral of St. Absalom", "cathedral", cx, G, (z0 + z1) / 2);
        // bell tower / spire at the portal end
        int sx = cx - 3, sz = z0 - 1;
        for (int y = G; y < G + 40; y++) g.walls(sx, y, sz - 6, sx + 6, y, sz, (y % 9 == 0) ? dark : wall);
        g.fill(sx + 1, G, sz - 5, sx + 5, G + 38, sz - 1, Block.AIR);
        for (int y = G; y < G + 38; y++) g.set(sx + 1, y, sz - 5, Block.LADDER);
        for (int y = G + 10; y < G + 38; y += 9) { g.fill(sx + 1, y, sz - 5, sx + 5, y, sz - 1, Block.WOOD_DARK); g.set(sx + 1, y, sz - 5, Block.LADDER); }
        for (int y = G + 31; y < G + 36; y++) { g.set(sx + 3, y, sz - 6, Block.AIR); g.set(sx + 3, y, sz, Block.AIR); g.set(sx, y, sz - 3, Block.AIR); g.set(sx + 6, y, sz - 3, Block.AIR); }
        for (int k = 0; k < 4; k++) g.fill(sx + k, G + 40 + k * 3, sz - 6 + k, sx + 6 - k, G + 42 + k * 3, sz - k, Block.ROOF_SLATE);
        for (int y = G + 52; y < G + 62; y++) g.set(sx + 3, y, sz - 3, y > G + 58 ? Block.IRON_FENCE : Block.STONE_DARK);
        g.container(sx + 3, G + 38 + 1, sz - 3, Block.STASH_CACHE, "cache");
        g.post("Bell Tower Lookout", "sniper", "mercenaries", sx + 3, G + 38, sz - 3);
        // door into tower from nave
        g.set(sx + 3, G, sz, Block.AIR); g.set(sx + 3, G + 1, sz, Block.AIR);
        // crypt stair (behind altar) down to catacombs
        int csx = cx + 6, csz = z1 - 3;
        for (int s = 0; s < 8; s++) {
            int y = G - 1 - s;
            g.fill(csx - s, y + 1, csz, csx - s, y + 3, csz, Block.AIR);
            g.set(csx - s, y, csz, Block.STAIRS_CONCRETE);
            g.set(csx - s, y + 4, csz, Block.STONE_DARK);
        }
        g.set(csx, G - 1, csz, Block.AIR);
        catacombs(cx, z1, csx - 10, csz, rng);
    }

    /** Catacomb maze from the crypt: north to the crypt exit, south to the avenue sewer. */
    private void catacombs(int cx, int zEnd, int sx, int sz, Rng rng) {
        int y0 = 15; // floor
        // crypt chamber
        g.fill(sx - 8, y0 - 1, sz - 6, sx + 2, y0 + 4, sz + 6, Block.CATACOMB);
        g.fill(sx - 7, y0, sz - 5, sx + 1, y0 + 3, sz + 5, Block.AIR);
        for (int z = sz - 4; z <= sz + 4; z += 2) { g.container(sx - 7, y0, z, Block.COFFIN, "crypt"); }
        g.set(sx - 3, y0, sz, Block.ALTAR); g.set(sx - 3, y0 + 1, sz, Block.CANDLES);
        g.fill(sx + 1, y0, sz, sx + 2, y0 + 2, sz, Block.AIR);
        g.document("doc", sx - 3, y0, sz);
        g.post("Crypt", "guard", "mercenaries", sx - 3, y0, sz + 2);
        // tunnel north to the wall
        int tx = sx - 3;
        tunnel(tx, sz - 6, tx, 99, y0, rng);
        g.fill(tx - 3, y0, 96, tx + 3, y0 + 3, 100, Block.AIR);
        g.walls(tx - 4, y0, 95, tx + 4, y0 + 3, 101, Block.CATACOMB);
        g.fill(tx - 1, y0, 101, tx + 1, y0 + 2, 101, Block.AIR);
        g.set(tx, y0, 96, Block.GATE_METAL); g.set(tx, y0 + 1, 96, Block.GATE_METAL);
        g.site("crypt_exit", tx, y0, 98);
        // tunnel south to the north-avenue sewer (z 247..253)
        tunnel(tx, sz + 6, tx, 251, y0, rng);
        // side galleries with ossuaries
        for (int k = 0; k < 5; k++) {
            int gz = 110 + rng.nextInt(Math.max(1, sz - 120));
            int len = 8 + rng.nextInt(10);
            int dir = rng.chance(0.5) ? 1 : -1;
            tunnel(tx, gz, tx + dir * len, gz, y0, rng);
            g.container(tx + dir * len, y0, gz, rng.chance(0.5) ? Block.COFFIN : Block.CRATE, "crypt");
            if (rng.chance(0.4)) g.nest(tx + dir * len, y0, gz);
        }
    }

    private void tunnel(int xa, int za, int xb, int zb, int y0, Rng rng) {
        int x = xa, z = za;
        while (x != xb || z != zb) {
            for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) {
                for (int y = y0 - 1; y <= y0 + 3; y++) {
                    boolean inner = Math.abs(dx) <= 1 && Math.abs(dz) <= 1 && y >= y0 && y <= y0 + 2;
                    int c = g.get(x + dx, y, z + dz);
                    if (inner) g.set(x + dx, y, z + dz, Block.AIR);
                    else if (c == Block.DIRT || c == Block.STONE_DARK || c == 0 && y < y0) g.set(x + dx, y, z + dz, Rng.hash(x + dx, y, z + dz, 5) < 0.15f ? Block.BONES : Block.CATACOMB);
                }
            }
            if (Rng.hash(x, y0, z, 9) < 0.04f) g.set(x, y0, z, Block.CANDLES);
            if (x != xb) x += Integer.signum(xb - x); else z += Integer.signum(zb - z);
        }
    }

    public void cemetery(Rect r, Rng rng) {
        clearLot(r, Block.GRASS);
        for (int x = r.x0(); x < r.x1(); x++) for (int z = r.z0(); z < r.z1(); z++) {
            if (x == r.x0() || z == r.z0() || x == r.x1() - 1 || z == r.z1() - 1) { g.set(x, G, z, Block.IRON_FENCE); g.set(x, G - 1, z, Block.STONE_BLOCK); continue; }
            float h = Rng.hash(x, 3, z, 13);
            if (h < 0.08f) g.set(x, G - 1, z, Block.DEAD_GRASS);
            if ((x - r.x0()) % 3 == 1 && (z - r.z0()) % 4 == 2 && h < 0.8f) { g.set(x, G, z, Block.TOMBSTONE); if (h < 0.1f) g.set(x, G - 1, z + 1, Block.MUD); }
            else if (h > 0.985f) g.tree(x, G, z, 5 + rng.nextInt(3), true);
        }
        // gate
        for (int k = -1; k <= 1; k++) g.set(r.cx() + k, G, r.z0(), Block.AIR);
        // mausoleum with a named cache
        int mx = r.x1() - 12, mz = r.z1() - 12;
        g.fill(mx, G, mz, mx + 7, G + 4, mz + 7, Block.MARBLE);
        g.fill(mx + 1, G, mz + 1, mx + 6, G + 3, mz + 6, Block.AIR);
        g.fill(mx - 1, G + 5, mz - 1, mx + 8, G + 5, mz + 8, Block.STONE_DARK);
        g.set(mx + 3, G, mz, Block.AIR); g.set(mx + 3, G + 1, mz, Block.AIR);
        g.namedCache(mx + 3, G, mz + 5, "cache_rare", "mausoleum");
        g.set(mx + 1, G, mz + 5, Block.CANDLES); g.set(mx + 5, G, mz + 5, Block.CANDLES);
        g.post("Cemetery", "guard", "mercenaries", r.cx(), G, r.cz());
        g.landmark("Old Cemetery", "cemetery", r.cx(), G, r.cz());
        g.nest(r.x0() + 6, G, r.z1() - 6);
    }

    /** Small cult shrine in a lane or courtyard. */
    public void shrine(int x, int z, Rng rng) {
        g.set(x, G, z, Block.ALTAR);
        g.set(x, G + 1, z, Block.CANDLES);
        g.setIfAir(x - 1, G, z, Block.CANDLES);
        g.setIfAir(x + 1, G, z, Block.CANDLES);
        g.setIfAir(x, G + 2, z, Block.BANNER_CULT);
        for (int i = 0; i < 4; i++) { int bx = x + rng.range(-2, 2), bz = z + rng.range(-2, 2); if (g.get(bx, G - 1, bz) != 0) g.set(bx, G - 1, bz, Block.BLOOD_FLOOR); }
        g.post("Shrine", "guard", "mercenaries", x, G, z + 2);
    }

    // =================================================================== MARKET
    public void bazaar(Rect r, Rng rng) {
        clearLot(r, Block.SIDEWALK);
        for (int x = r.x0() + 2; x < r.x1() - 3; x += 6) for (int z = r.z0() + 2; z < r.z1() - 3; z += 7) {
            if (rng.chance(0.15)) continue;
            // stall: counter row + poles + awning
            int aw = rng.chance(0.5) ? Block.AWNING_RED : Block.AWNING_GREEN;
            for (int k = 0; k < 3; k++) g.container(x + k, G, z, Block.MARKET_STALL, "market");
            g.set(x, G, z + 2, Block.STEEL_BEAM); g.set(x + 2, G, z + 2, Block.STEEL_BEAM);
            g.set(x, G + 1, z + 2, Block.STEEL_BEAM); g.set(x + 2, G + 1, z + 2, Block.STEEL_BEAM);
            g.fill(x - 1, G + 2, z - 1, x + 3, G + 2, z + 2, aw);
            if (rng.chance(0.3)) g.set(x + 1, G, z + 1, Block.CRATE);
        }
        // tarp canopy strung across
        for (int x = r.x0(); x < r.x1(); x++) if (x % 9 < 6) g.setIfAir(x, G + 5, r.cz(), Block.TARP);
        g.barrelFire(r.cx(), r.cz());
        g.barrelFire(r.x0() + 3, r.z1() - 3);
        g.post("Bazaar", "trade", "survivors", r.cx(), G, r.cz() + 2);
        g.post("Bazaar Guard", "guard", "survivors", r.x0() + 2, G, r.z0() + 2);
        g.landmark("Bazaar Square", "bazaar", r.cx(), G, r.cz());
    }

    /** Fortified survivor compound with trader, tents, gardens and a watchtower. */
    public void haven(Rect r, Rng rng) {
        clearLot(r, Block.DIRT);
        int x0 = r.x0() + 1, z0 = r.z0() + 1, x1 = r.x1() - 2, z1 = r.z1() - 2;
        // wall of containers / sandbags / barricades
        for (int x = x0; x <= x1; x++) for (int z = z0; z <= z1; z++) {
            if (x != x0 && x != x1 && z != z0 && z != z1) continue;
            float h = Rng.hash(x, 7, z, 3);
            int id = h < 0.4f ? Block.CORRUGATED_RUST : (h < 0.7f ? Block.SANDBAG : Block.WOOD_PLANKS);
            g.fill(x, G, z, x, G + 2, z, id);
            g.setIfAir(x, G + 3, z, Block.BARBED);
        }
        int gx = r.cx();
        for (int k = -1; k <= 1; k++) for (int y = G; y <= G + 3; y++) g.set(gx + k, y, z0, Block.AIR);
        g.set(gx - 2, G, z0 - 1, Block.BARREL_FIRE);
        g.set(gx + 2, G, z0 - 1, Block.BARRIER);
        // tents
        for (int i = 0; i < 6; i++) {
            int tx = x0 + 3 + (i % 3) * ((x1 - x0 - 6) / 3), tz = z0 + 4 + (i / 3) * ((z1 - z0) / 2);
            tent(tx, tz, rng.chance(0.5) ? Block.TARP : Block.CANVAS, rng);
        }
        // garden plots
        for (int x = x1 - 9; x < x1 - 2; x++) for (int z = z1 - 8; z < z1 - 2; z++) { g.set(x, G - 1, z, Block.DIRT); if ((x + z) % 2 == 0) g.set(x, G, z, Block.TALL_GRASS); }
        // trader shack
        int sx = x0 + 3, sz = z1 - 9;
        Spec s = new Spec(sx, sz, 9, 7);
        s.floors = 1; s.style = Style.SHOP; s.wall = Block.WOOD_PLANKS; s.trim = Block.WOOD_DARK; s.roof = Block.ROOF_METAL; s.street[0] = true; s.lootBias = "store"; s.roofAccess = false;
        b.build(s);
        g.post("Haven Trader", "trader", "survivors", sx + 4, G, sz - 1);
        // watchtower
        int tx = x1 - 4, tz = z0 + 2;
        for (int y = G; y < G + 8; y++) { g.set(tx, y, tz, Block.LOG); g.set(tx + 2, y, tz, Block.LOG); g.set(tx, y, tz + 2, Block.LOG); g.set(tx + 2, y, tz + 2, Block.LOG); g.set(tx + 1, y, tz, Block.LADDER); }
        g.fill(tx, G + 8, tz, tx + 2, G + 8, tz + 2, Block.WOOD_PLANKS);
        g.set(tx + 1, G + 8, tz, Block.LADDER);
        g.fill(tx, G + 9, tz, tx + 2, G + 9, tz + 2, Block.SANDBAG);
        g.set(tx + 1, G + 9, tz + 1, Block.AIR); g.set(tx + 1, G + 9, tz, Block.AIR);
        g.fill(tx - 1, G + 11, tz - 1, tx + 3, G + 11, tz + 3, Block.ROOF_METAL);
        g.post("Haven Watchtower", "tower", "survivors", tx + 1, G + 9, tz + 1);
        g.post("Haven Gate", "guard", "survivors", gx, G, z0 + 2);
        g.post("Haven Yard", "camp", "survivors", r.cx(), G, r.cz());
        g.barrelFire(r.cx(), r.cz());
        g.set(r.cx() + 4, G, r.cz(), Block.WATER_TANK); g.set(r.cx() + 4, G + 1, r.cz(), Block.WATER_TANK);
        g.container(r.cx() - 4, G, r.cz(), Block.CRATE, "food");
        g.landmark("Haven (Survivor Compound)", "haven", r.cx(), G, r.cz());
    }

    public void tent(int x, int z, int cloth, Rng rng) {
        for (int k = 0; k < 3; k++) {
            int y = G + 2 - k;
            g.fill(x - k, y, z, x - k, y, z + 4, cloth);
            g.fill(x + k, y, z, x + k, y, z + 4, cloth);
        }
        g.fill(x - 2, G, z + 4, x + 2, G + 2, z + 4, cloth);
        g.set(x, G, z + 4, Block.AIR); g.set(x, G + 1, z + 4, Block.AIR);
        g.set(x - 1, G, z + 1, Block.BED);
        if (rng.chance(0.6)) g.container(x + 1, G, z + 1, rng.chance(0.5) ? Block.CRATE : Block.LOCKER, null);
    }

    // =================================================================== INDUSTRIAL
    public void substation(Rect r, Rng rng) {
        clearLot(r, Block.GRAVEL);
        fence(r, Block.CHAINLINK, true);
        for (int x = r.x0() + 4; x < r.x1() - 16; x += 6) for (int z = r.z0() + 4; z < r.z1() - 4; z += 7) {
            g.fill(x, G, z, x + 2, G + 2, z + 2, Block.TRANSFORMER);
            g.set(x + 1, G + 3, z + 1, Block.PIPE); g.set(x + 1, G + 4, z + 1, Block.IRON_FENCE);
        }
        // lattice pylons
        for (int z = r.z0() + 3; z < r.z1(); z += 18) pylon(r.x1() - 8, z, 22);
        // control building with the console
        int bx = r.x1() - 15, bz = r.z0() + 3;
        Spec s = new Spec(bx, bz, 12, 10);
        s.floors = 2; s.style = Style.WORKSHOP; s.wall = Block.CONCRETE_PANEL; s.trim = Block.CONCRETE_DARK; s.street[2] = true; s.window = Block.GLASS_DIRTY; s.lootBias = "industrial";
        b.build(s);
        g.set(bx + 6, G, bz + 2, Block.CONSOLE);
        g.site("substation", bx + 6, G, bz + 3);
        g.set(bx + 3, G, bz + 2, Block.GENERATOR);
        g.landmark("North Substation", "substation", r.cx(), G, r.cz());
        g.post("Substation", "guard", "raiders", r.cx(), G, r.cz());
    }

    public void pylon(int x, int z, int h) {
        for (int y = G; y < G + h; y++) {
            int k = (h - (y - G)) / 8;
            g.set(x - k, y, z - k, Block.LATTICE); g.set(x + 1 + k, y, z - k, Block.LATTICE);
            g.set(x - k, y, z + 1 + k, Block.LATTICE); g.set(x + 1 + k, y, z + 1 + k, Block.LATTICE);
        }
        g.fill(x - 4, G + h, z, x + 5, G + h, z + 1, Block.LATTICE);
        for (int dx : new int[]{-4, 5}) g.set(x + dx, G + h - 1, z, Block.WIRES);
    }

    public void factory(Rect r, Rng rng) {
        clearLot(r, Block.CONCRETE_FLOOR);
        int x0 = r.x0() + 2, z0 = r.z0() + 2, w = r.w() - 4, d = r.d() - 4;
        Spec s = new Spec(x0, z0, w, d);
        s.floors = 3; s.style = Style.WAREHOUSE; s.wall = Block.BRICK_BROWN; s.trim = Block.STEEL_BEAM; s.roof = Block.ROOF_METAL;
        s.street[0] = s.street[1] = s.street[2] = s.street[3] = true; s.windowSpacing = 2; s.broken = 0.5f; s.lootBias = "industrial"; s.damage = 0.3f;
        // high hall: remove intermediate slabs to make a double-height floor with catwalks
        b.build(s);
        int yMid = G - 1 + FLOOR_H;
        for (int x = x0 + 4; x < x0 + w - 4; x++) for (int z = z0 + 4; z < z0 + d - 4; z++) g.set(x, yMid, z, Block.AIR);
        for (int x = x0 + 1; x < x0 + w - 1; x++) { g.set(x, yMid, z0 + 2, Block.GRATE); g.set(x, yMid, z0 + 3, Block.GRATE); g.set(x, yMid + 1, z0 + 4, Block.IRON_FENCE); }
        for (int x = x0 + 6; x < x0 + w - 6; x += 7) for (int z = z0 + 7; z < z0 + d - 6; z += 8) { g.fill(x, G, z, x + 2, G + 1, z + 3, Block.MACHINE); g.set(x + 1, G + 2, z + 1, Block.PIPE); }
        for (int y = G; y <= yMid; y++) g.set(x0 + 1, y, z0 + 1, Block.LADDER);
        // smokestacks
        for (int k = 0; k < 2; k++) {
            int cx = x0 + w / 3 + k * w / 3, cz = z0 + d - 1;
            for (int y = G; y < G + 52; y++) for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) {
                int dd = dx * dx + dz * dz;
                if (dd <= 5 && dd >= 2) g.set(cx + dx, y, cz + dz + 3, y % 12 == 0 ? Block.CONCRETE : Block.BRICK_RED);
                else if (dd < 2) g.set(cx + dx, y, cz + dz + 3, Block.AIR);
            }
            for (int y = G; y < G + 50; y++) g.set(cx, y, cz + 1, Block.LADDER);
        }
        g.landmark("Kovalenko Works", "factory", r.cx(), G, r.cz());
        g.post("Factory Floor", "guard", "raiders", r.cx(), G, r.cz());
    }

    public void purifierStation(Rect r, Rng rng) {
        clearLot(r, Block.CONCRETE_FLOOR);
        fence(r, Block.CHAINLINK, true);
        // settling tanks (round open basins)
        for (int k = 0; k < 2; k++) {
            int cx = r.x0() + 10 + k * 16, cz = r.z1() - 12;
            for (int dx = -6; dx <= 6; dx++) for (int dz = -6; dz <= 6; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d <= 6.4 && d >= 5.4) g.fill(cx + dx, G, cz + dz, cx + dx, G + 2, cz + dz, Block.CONCRETE);
                else if (d < 5.4) { g.set(cx + dx, G - 1, cz + dz, Block.CONCRETE); g.fill(cx + dx, G, cz + dz, cx + dx, G + 1, cz + dz, k == 0 ? Block.WATER : Block.SEWAGE); }
            }
        }
        int bx = r.x1() - 20, bz = r.z0() + 3;
        Spec s = new Spec(bx, bz, 17, 12);
        s.floors = 2; s.style = Style.WORKSHOP; s.wall = Block.CONCRETE_PANEL; s.trim = Block.CONCRETE_DARK; s.window = Block.GLASS_DIRTY; s.street[2] = true; s.street[3] = true; s.lootBias = "industrial";
        b.build(s);
        g.fill(bx + 3, G, bz + 3, bx + 5, G + 2, bz + 5, Block.WATER_TANK);
        g.set(bx + 8, G, bz + 4, Block.PURIFIER);
        g.set(bx + 9, G, bz + 4, Block.CONSOLE);
        g.site("purifier", bx + 8, G, bz + 5);
        for (int x = r.x0() + 3; x < bx; x++) { g.set(x, G + 3, bz + 6, Block.PIPE); }
        g.landmark("Waterline Utility Station", "purifier", r.cx(), G, r.cz());
        g.post("Waterline", "guard", "raiders", bx + 8, G, bz + 13);
    }

    public void railYard(Rect r, Rng rng) {
        clearLot(r, Block.GRAVEL);
        int tracks = Math.max(2, (r.d() - 6) / 6);
        for (int t = 0; t < tracks; t++) {
            int z = r.z0() + 3 + t * 6;
            for (int x = r.x0(); x < r.x1(); x++) { g.set(x, G - 1, z, Block.RAIL_SLEEPER); g.set(x, G - 1, z + 1, Block.RAIL); g.set(x, G - 1, z + 2, Block.RAIL_SLEEPER); }
            // boxcars
            int x = r.x0() + 6 + rng.nextInt(20);
            while (x < r.x1() - 12) {
                if (rng.chance(0.65)) boxcar(x, z, rng);
                x += 12 + rng.nextInt(10);
            }
        }
        // signal box
        Spec s = new Spec(r.x0() + 4, r.z1() - 9, 8, 7);
        s.floors = 2; s.style = Style.WORKSHOP; s.wall = Block.BRICK_RED; s.trim = Block.CONCRETE; s.street[0] = true; s.lootBias = "industrial";
        b.build(s);
        // freight train exit at the east end (time window)
        int ez = r.z0() + 3 + (tracks - 1) * 6;
        for (int x = r.x1() - 30; x < r.x1() - 6; x += 10) boxcar(x, ez, rng);
        g.site("rail_exit", r.x1() - 4, G, ez + 1);
        g.landmark("Rail Yard", "railyard", r.cx(), G, r.cz());
        g.post("Rail Yard", "patrol", "raiders", r.cx(), G, r.cz());
    }

    private void boxcar(int x, int z, Rng rng) {
        if (true) return; // v0.3: rolling stock removed with the other vehicles
        int c = rng.pick(new int[]{Block.CONTAINER_RED, Block.CONTAINER_BLUE, Block.CONTAINER_GREEN, Block.CONTAINER_ORANGE, Block.CORRUGATED_RUST});
        g.fill(x, G + 1, z, x + 9, G + 3, z + 2, c);
        g.fill(x + 1, G, z, x + 1, G, z + 2, Block.CAR_TIRE); g.fill(x + 8, G, z, x + 8, G, z + 2, Block.CAR_TIRE);
        if (rng.chance(0.6)) { // open door + loot inside
            g.fill(x + 1, G + 2, z + 1, x + 8, G + 2, z + 1, Block.AIR);
            g.fill(x + 1, G + 1, z + 1, x + 8, G + 1, z + 1, Block.AIR);
            g.set(x + 4, G + 1, z, Block.AIR); g.set(x + 4, G + 2, z, Block.AIR); g.set(x + 5, G + 1, z, Block.AIR); g.set(x + 5, G + 2, z, Block.AIR);
            g.container(x + 2, G + 1, z + 1, Block.CRATE, "industrial");
        }
    }

    public void containerYard(Rect r, Rng rng) {
        clearLot(r, Block.CONCRETE_FLOOR);
        int[] cols = {Block.CONTAINER_RED, Block.CONTAINER_BLUE, Block.CONTAINER_GREEN, Block.CONTAINER_ORANGE};
        for (int x = r.x0() + 2; x < r.x1() - 10; x += 11) for (int z = r.z0() + 2; z < r.z1() - 4; z += 5) {
            if (rng.chance(0.18)) continue;
            int stack = 1 + rng.nextInt(3);
            for (int s = 0; s < stack; s++) {
                int y = G + s * 3;
                int c = rng.pick(cols);
                g.fill(x, y, z, x + 8, y + 2, z + 2, c);
                if (rng.chance(0.35)) { g.fill(x + 1, y, z + 1, x + 7, y + 1, z + 1, Block.AIR); g.set(x, y, z + 1, Block.AIR); g.set(x, y + 1, z + 1, Block.AIR); { boolean mil = rng.chance(0.3); g.container(x + 6, y, z + 1, mil ? Block.CRATE_MIL : Block.CRATE, mil ? "military" : "industrial"); }; }
            }
            if (stack > 1 && rng.chance(0.5)) for (int y = G; y < G + stack * 3; y++) g.setIfAir(x - 1, y, z + 1, Block.LADDER);
        }
        // gantry crane
        int cx = r.cx();
        for (int y = G; y < G + 18; y++) { g.set(cx, y, r.z0() + 1, Block.LATTICE); g.set(cx, y, r.z1() - 2, Block.LATTICE); g.set(cx + 1, y, r.z0() + 1, Block.LADDER); }
        g.fill(cx, G + 18, r.z0() + 1, cx + 1, G + 18, r.z1() - 2, Block.STEEL_BEAM);
        g.fill(cx - 1, G + 19, r.z0() + 1, cx + 2, G + 19, r.z0() + 3, Block.HAZARD_STRIPE);
        g.landmark("Container Terminal", "containers", r.cx(), G, r.cz());
    }

    public void raiderCamp(Rect r, Rng rng) {
        clearLot(r, Block.GRAVEL);
        for (int x = r.x0(); x < r.x1(); x++) for (int z = r.z0(); z < r.z1(); z++) {
            if (x != r.x0() && z != r.z0() && x != r.x1() - 1 && z != r.z1() - 1) continue;
            if (Rng.hash(x, 1, z, 77) < 0.12f) continue;
            float h = Rng.hash(x, 2, z, 7);
            g.fill(x, G, z, x, G + 2, z, h < 0.5f ? Block.CORRUGATED_RUST : (h < 0.75f ? Block.TIRE : Block.METAL_RUST));
            if (h < 0.3f) g.set(x, G + 3, z, Block.BARBED);
        }
        for (int i = 0; i < 4; i++) tent(r.x0() + 6 + i * ((r.w() - 12) / 4), r.z0() + 5, Block.TARP, rng);
        g.barrelFire(r.cx(), r.cz());
        g.barrelFire(r.cx() - 6, r.cz() + 4);
        g.set(r.cx() + 2, G, r.cz() + 2, Block.TIRE); g.set(r.cx() + 2, G + 1, r.cz() + 2, Block.TIRE);
        for (int i = 0; i < 5; i++) g.container(r.x0() + 3 + rng.nextInt(r.w() - 6), G, r.z1() - 3 - rng.nextInt(3), Block.CRATE, "raider");
        // leader shack
        int sx = r.x1() - 12, sz = r.z1() - 11;
        Spec s = new Spec(sx, sz, 9, 8);
        s.floors = 1; s.style = Style.WORKSHOP; s.wall = Block.CORRUGATED_RUST; s.trim = Block.STEEL_BEAM; s.roof = Block.ROOF_METAL; s.street[3] = true; s.lootBias = "raider"; s.roofAccess = false;
        b.build(s);
        g.container(sx + 4, G, sz + 5, Block.SAFE, "raider_boss");
        g.document("ledger", sx + 3, G, sz + 5);
        g.post("Kessler's Shack", "leader", "raiders", sx + 4, G, sz + 3);
        g.post("Raider Camp", "camp", "raiders", r.cx(), G, r.cz());
        g.post("Raider Gate", "guard", "raiders", r.x0() + 2, G, r.cz());
        for (int k = 0; k < 6; k++) { int x = r.x0() + rng.nextInt(r.w()), z = r.z0() + rng.nextInt(r.d()); if (g.get(x, G - 1, z) == Block.GRAVEL) g.set(x, G - 1, z, k % 2 == 0 ? Block.OIL_FLOOR : Block.BLOOD_FLOOR); }
        g.landmark("Scrapyard Camp", "raidercamp", r.cx(), G, r.cz());
    }

    public void fence(Rect r, int id, boolean barbed) {
        for (int x = r.x0(); x < r.x1(); x++) for (int z = r.z0(); z < r.z1(); z++) {
            if (x != r.x0() && z != r.z0() && x != r.x1() - 1 && z != r.z1() - 1) continue;
            g.fill(x, G, z, x, G + 1, z, id);
            if (barbed) g.set(x, G + 2, z, Block.BARBED);
        }
        // gates on two sides
        for (int k = -1; k <= 1; k++) for (int y = G; y <= G + 2; y++) { g.set(r.cx() + k, y, r.z1() - 1, Block.AIR); g.set(r.x0(), y, r.cz() + k, Block.AIR); }
    }

    // =================================================================== CIVIC
    public void cityHall(Rect r, Rng rng) {
        clearLot(r, Block.GRANITE);
        int x0 = r.x0() + 3, z0 = r.z0() + 3, w = r.w() - 6, d = r.d() - 6;
        Spec s = new Spec(x0, z0, w, d);
        s.floors = 4; s.style = Style.OFFICE; s.wall = Block.MARBLE; s.trim = Block.GRANITE; s.window = Block.GLASS; s.windowSpacing = 2; s.street[2] = true; s.street[0] = true; s.lootBias = "office"; s.damage = 0.25f;
        b.build(s);
        int top = G - 1 + 4 * FLOOR_H;
        // colonnade on the south (plaza) side
        for (int x = x0; x < x0 + w; x += 3) for (int y = G; y < G + 8; y++) g.set(x, y, z0 + d + 2, Block.MARBLE);
        g.fill(x0 - 1, G + 8, z0 + d, x0 + w, G + 8, z0 + d + 3, Block.GRANITE);
        g.fill(x0 - 1, G - 1, z0 + d, x0 + w, G - 1, z0 + d + 3, Block.MARBLE);
        // stepped dome
        int cx = x0 + w / 2, cz = z0 + d / 2;
        for (int k = 0; k < 7; k++) {
            int rr = 8 - k;
            for (int dx = -rr; dx <= rr; dx++) for (int dz = -rr; dz <= rr; dz++) if (dx * dx + dz * dz <= rr * rr && dx * dx + dz * dz > (rr - 1.5) * (rr - 1.5)) g.set(cx + dx, top + 1 + k, cz + dz, k < 2 ? Block.MARBLE : Block.ROOF_METAL);
        }
        for (int y = top + 8; y < top + 12; y++) g.set(cx, y, cz, Block.IRON_FENCE);
        g.landmark("City Hall", "cityhall", cx, G, cz);
        g.post("City Hall Steps", "guard", "military", cx, G, z0 + d + 4);
        g.document("doc", x0 + 3, G + FLOOR_H, z0 + 3);
        g.container(x0 + 3, G + FLOOR_H, z0 + 3, Block.SAFE, "safe");
    }

    public void plaza(Rect r, Rng rng) {
        clearLot(r, Block.GRANITE);
        for (int x = r.x0(); x < r.x1(); x++) for (int z = r.z0(); z < r.z1(); z++) if ((x + z) % 6 == 0 || (x - z + 600) % 6 == 0) g.set(x, G - 1, z, Block.MARBLE);
        int cx = r.cx(), cz = r.cz();
        // fountain
        for (int dx = -5; dx <= 5; dx++) for (int dz = -5; dz <= 5; dz++) {
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d <= 5.4 && d >= 4.5) g.set(cx + dx, G, cz + dz, Block.MARBLE);
            else if (d < 4.5) { g.set(cx + dx, G - 1, cz + dz, Block.MARBLE); g.set(cx + dx, G - 2, cz + dz, Block.MARBLE); g.set(cx + dx, G - 1, cz + dz, Block.WATER); }
        }
        // statue
        g.fill(cx - 1, G - 1, cz - 1, cx + 1, G + 1, cz + 1, Block.GRANITE);
        g.fill(cx, G + 2, cz, cx, G + 5, cz, Block.STATUE);
        g.set(cx - 1, G + 4, cz, Block.STATUE); g.set(cx + 1, G + 5, cz, Block.STATUE); g.set(cx, G + 6, cz, Block.STATUE);
        // planters & benches & military roadblock remains
        for (int x = r.x0() + 3; x < r.x1() - 3; x += 9) { g.set(x, G, r.z0() + 2, Block.HEDGE); g.tree(x, G + 1, r.z0() + 2, 4, rng.chance(0.5)); g.set(x, G, r.z1() - 3, Block.PEW); }
        g.sandbagWall(cx - 10, cz + 8, cx - 6, cz + 8, 2);
        g.truck(cx + 8, cz + 6, true, Block.CAR_OLIVE);
        g.container(cx + 12, G, cz + 3, Block.CRATE_MIL, "military");
        g.landmark("Energetik Square", "plaza", cx, G, cz);
        g.post("Plaza Roadblock", "checkpoint", "military", cx - 8, G, cz + 10);
    }

    public void collapsedTower(Rect r, Rng rng) {
        clearLot(r, Block.RUBBLE);
        int x0 = r.x0() + 4, z0 = r.z0() + 4, w = Math.min(20, r.w() - 8), d = Math.min(20, r.d() - 8);
        // standing stump: 4 floors of skeleton
        for (int f = 0; f < 5; f++) {
            int y = G - 1 + f * FLOOR_H;
            for (int x = x0; x < x0 + w; x++) for (int z = z0; z < z0 + d; z++) {
                boolean edge = x == x0 || z == z0 || x == x0 + w - 1 || z == z0 + d - 1;
                float h = Rng.hash(x, y, z, 21);
                if (h < 0.75f - f * 0.12f) g.set(x, y, z, Block.CONCRETE_DARK);
                if (edge && (x - x0) % 4 == 0 && (z - z0) % 4 == 0 || edge && ((x - x0) % 4 == 0 && (z == z0 || z == z0 + d - 1) || (z - z0) % 4 == 0 && (x == x0 || x == x0 + w - 1)))
                    for (int yy = y + 1; yy < y + FLOOR_H; yy++) if (Rng.hash(x, yy, z, 3) < 0.85f - f * 0.1f) g.set(x, yy, z, Block.CONCRETE_PANEL);
                if (edge && h > 0.85f) g.set(x, y + 1, z, Block.GLASS_CRACKED);
            }
        }
        // twisted beams
        for (int k = 0; k < 10; k++) { int x = x0 + rng.nextInt(w), z = z0 + rng.nextInt(d); for (int y = G + 18; y < G + 18 + rng.nextInt(10); y++) g.set(x + (y % 3 == 0 ? 1 : 0), y, z, Block.STEEL_BEAM); }
        // rubble mountain spilling into the street
        g.rubblePile(r.x1() - 10, r.cz(), 12, 11, Block.RUBBLE);
        g.rubblePile(r.cx(), r.z1() - 6, 9, 7, Block.RUBBLE);
        for (int i = 0; i < 30; i++) { int x = r.x0() + rng.nextInt(r.w()), z = r.z0() + rng.nextInt(r.d()); int y = g.groundY(x, z); g.setIfAir(x, y, z, rng.chance(0.3) ? Block.GLASS_BLUE : Block.CONCRETE_PANEL); }
        for (int i = 0; i < 4; i++) { int x = r.x0() + 3 + rng.nextInt(r.w() - 6), z = r.z0() + 3 + rng.nextInt(r.d() - 6); g.container(x, g.groundY(x, z), z, Block.FILING, "office"); }
        g.landmark("Fallen Meridian Tower", "ruin", r.cx(), G, r.cz());
    }

    /** Tall office tower; optional helipad roof (signaled extraction). */
    public void tower(Rect r, int floors, boolean helipad, Rng rng) {
        Spec s = new Spec(r.x0() + 2, r.z0() + 2, r.w() - 4, r.d() - 4);
        s.floors = floors; s.style = Style.OFFICE; s.curtainWall = true; s.window = Block.GLASS_BLUE; s.wall = Block.CONCRETE_PANEL; s.trim = Block.CONCRETE_PANEL; s.broken = 0.12f; s.boarded = 0.02f;
        s.street[0] = s.street[1] = s.street[2] = s.street[3] = true; s.lootBias = "office"; s.basement = true; s.damage = rng.chance(0.4) ? 0.2f : 0f;
        clearLot(r, Block.GRANITE);
        b.build(s);
        int top = G - 1 + floors * FLOOR_H;
        if (helipad) {
            int cx = r.cx(), cz = r.cz();
            for (int dx = -5; dx <= 5; dx++) for (int dz = -5; dz <= 5; dz++) if (g.get(cx + dx, top, cz + dz) != 0) g.set(cx + dx, top, cz + dz, Block.CONCRETE_PANEL);
            for (int dz = -3; dz <= 3; dz++) { g.set(cx - 2, top, cz + dz, Block.HAZARD_STRIPE); g.set(cx + 2, top, cz + dz, Block.HAZARD_STRIPE); }
            for (int dx = -2; dx <= 2; dx++) g.set(cx + dx, top, cz, Block.HAZARD_STRIPE);
            for (int dx = -5; dx <= 5; dx++) for (int dz = -5; dz <= 5; dz++) if (g.get(cx + dx, top + 1, cz + dz) != Block.AIR && !(Math.abs(dx) <= 1 && Math.abs(dz) <= 1)) { int c = g.get(cx + dx, top + 1, cz + dz); if (c != Block.DOOR_METAL_OPEN && c != Block.CONCRETE_DARK && c != Block.ROOF_TAR) g.set(cx + dx, top + 1, cz + dz, Block.AIR); }
            g.set(cx + 6, top + 1, cz + 6, Block.RED_LIGHT); g.set(cx - 6, top + 1, cz - 6, Block.RED_LIGHT);
            g.site("helipad", cx + 4, top + 1, cz + 4);
            g.landmark("Meridian Helipad", "helipad", cx, top + 1, cz);
        }
    }

    public void garrison(Rect r, Rng rng) {
        clearLot(r, Block.CONCRETE_FLOOR);
        // HESCO perimeter
        for (int x = r.x0(); x < r.x1(); x++) for (int z = r.z0(); z < r.z1(); z++) {
            if (x != r.x0() && z != r.z0() && x != r.x1() - 1 && z != r.z1() - 1) continue;
            g.fill(x, G, z, x, G + 2, z, Block.HESCO);
        }
        for (int k = -2; k <= 2; k++) for (int y = G; y <= G + 2; y++) g.set(r.cx() + k, y, r.z0(), Block.AIR);
        g.set(r.cx() - 3, G, r.z0() - 1, Block.BARRIER); g.set(r.cx() + 3, G, r.z0() - 1, Block.BARRIER);
        Spec s = new Spec(r.x0() + 4, r.z0() + 12, r.w() - 8, Math.min(18, r.d() - 16));
        s.floors = 2; s.style = Style.BARRACKS; s.wall = Block.CONCRETE; s.trim = Block.CONCRETE_DARK; s.window = Block.GLASS_DIRTY; s.boarded = 0.25f; s.street[0] = true; s.lootBias = "military";
        b.build(s);
        g.truck(r.x0() + 4, r.z0() + 4, true, Block.CAR_OLIVE);
        g.truck(r.x0() + 14, r.z0() + 4, true, Block.CAR_OLIVE);
        for (int i = 0; i < 4; i++) g.container(r.x1() - 6 - i * 2, G, r.z0() + 4, Block.CRATE_MIL, "military");
        g.lamp(r.cx(), G + 4, r.z0() + 2);
        g.post("Garrison Gate", "checkpoint", "military", r.cx(), G, r.z0() + 3);
        g.post("Garrison Yard", "camp", "military", r.cx(), G, r.z0() + 8);
        g.post("Garrison HQ", "leader", "military", r.cx(), G, r.z0() + 14);
        g.landmark("Civic Garrison", "garrison", r.cx(), G, r.cz());
        g.post("Garrison Perimeter", "restricted", "military", r.cx(), G, r.cz());
    }

    public void parkingGarage(Rect r, Rng rng) {
        clearLot(r, Block.CONCRETE_FLOOR);
        int x0 = r.x0() + 2, z0 = r.z0() + 2, x1 = r.x1() - 3, z1 = r.z1() - 3;
        int levels = 4;
        for (int f = 0; f <= levels; f++) {
            int y = G - 1 + f * FLOOR_H;
            g.fill(x0, y, z0, x1, y, z1, f == 0 ? Block.CONCRETE_FLOOR : Block.CONCRETE);
            if (f == levels) break;
            for (int x = x0; x <= x1; x += 6) for (int z = z0; z <= z1; z += 6) g.fill(x, y + 1, z, x, y + FLOOR_H - 1, z, Block.CONCRETE_DARK);
            for (int x = x0; x <= x1; x++) { g.set(x, y + 1, z0, Block.CONCRETE); g.set(x, y + 1, z1, Block.CONCRETE); }
            for (int z = z0; z <= z1; z++) { g.set(x0, y + 1, z, Block.CONCRETE); g.set(x1, y + 1, z, Block.CONCRETE); }
            for (int x = x0 + 2; x < x1 - 4; x += 6) for (int z : new int[]{z0 + 2, z1 - 4}) if (rng.chance(0.55)) {
                if (g.air(x, y + 1, z) && g.air(x + 3, y + 1, z + 1)) g.car(x, z, true, rng.pick(new int[]{Block.CAR_RED, Block.CAR_BLUE, Block.CAR_WHITE}), rng.chance(0.5));
            }
        }
        // move the car rows up into each level (car() builds at street level; replicate)
        for (int f = 1; f < levels; f++) {
            int dy = f * FLOOR_H;
            for (int x = x0 + 1; x < x1; x++) for (int z = z0 + 1; z < z1; z++) for (int y = G; y <= G + 1; y++) {
                int c = g.get(x, y, z);
                if (c == Block.CAR_RED || c == Block.CAR_BLUE || c == Block.CAR_WHITE || c == Block.CAR_RUST || c == Block.CAR_WINDOW) if (g.air(x, y + dy, z) && Rng.hash(x, f, z, 4) < 0.7f) g.set(x, y + dy, z, c);
            }
        }
        // stair tower in a corner
        for (int f = 0; f < levels; f++) {
            int y0 = G - 1 + f * FLOOR_H;
            for (int k = 1; k <= 3; k++) { g.set(x0 + 1 + (f % 2), y0 + k, z0 + 1 + (f % 2 == 0 ? k : 5 - k), Block.STAIRS_CONCRETE); g.set(x0 + 1 + (f % 2), y0 + FLOOR_H, z0 + 1 + (f % 2 == 0 ? k : 5 - k), Block.AIR); }
        }
        // openings to the street
        for (int k = -2; k <= 2; k++) for (int y = G; y < G + 3; y++) { g.set(r.cx() + k, y, z0, Block.AIR); g.set(r.cx() + k, y, z1, Block.AIR); }
        g.post("Garage Roof", "sniper", "military", r.cx(), G - 1 + levels * FLOOR_H + 1, r.cz());
        g.landmark("Parking Structure", "garage", r.cx(), G, r.cz());
    }

    // =================================================================== REDLINE
    public void hospital(Rect r, Rng rng) {
        clearLot(r, Block.SIDEWALK);
        int x0 = r.x0() + 4, z0 = r.z0() + 12;
        int mw = Math.min(56, r.w() - 30), md = Math.min(36, r.d() - 20);
        Spec main = new Spec(x0, z0, mw, md);
        main.floors = 6; main.style = Style.HOSPITAL; main.wall = Block.BRICK_WHITE; main.trim = Block.CONCRETE_PANEL; main.window = Block.GLASS_DIRTY; main.windowSpacing = 2;
        main.street[0] = true; main.lootBias = "medical"; main.damage = 0.35f; main.basement = true; main.fireEscape = true;
        b.build(main);
        Spec wing = new Spec(x0 + mw + 2, z0 + 4, Math.min(22, r.x1() - (x0 + mw + 2) - 3), md + 8);
        wing.floors = 4; wing.style = Style.HOSPITAL; wing.wall = Block.BRICK_WHITE; wing.trim = Block.CONCRETE_PANEL; wing.window = Block.GLASS_DIRTY; wing.windowSpacing = 2;
        wing.street[0] = true; wing.street[1] = true; wing.lootBias = "medical"; wing.burnt = true; wing.damage = 0.5f;
        if (wing.w >= 8) b.build(wing);
        // skybridge between main and wing at floor 2
        int by = G - 1 + 2 * FLOOR_H;
        for (int x = x0 + mw - 1; x <= x0 + mw + 2; x++) for (int z = z0 + 8; z <= z0 + 10; z++) { g.set(x, by, z, Block.CONCRETE); g.set(x, by + 3, z, Block.CONCRETE); g.set(x, by + 1, z, Block.AIR); g.set(x, by + 2, z, Block.AIR); }
        for (int x = x0 + mw - 1; x <= x0 + mw + 2; x++) { g.set(x, by + 1, z0 + 7, Block.GLASS_CRACKED); g.set(x, by + 2, z0 + 7, Block.GLASS_CRACKED); g.set(x, by + 1, z0 + 11, Block.GLASS_CRACKED); g.set(x, by + 2, z0 + 11, Block.GLASS_CRACKED); }
        // signage
        for (int x = x0 + mw / 2 - 2; x <= x0 + mw / 2 + 2; x++) g.set(x, G + 5, z0 - 1, Block.RED_CROSS);
        // ambulance bay canopy + ambulances
        int ax = x0 + 6, az = r.z0() + 2;
        for (int x = ax - 2; x < ax + 16; x++) for (int z = az; z < z0; z++) g.set(x, G + 4, z, Block.CONCRETE_PANEL);
        for (int x = ax - 2; x < ax + 16; x += 6) for (int y = G; y < G + 4; y++) { g.set(x, y, az, Block.STEEL_BEAM); }
        g.car(ax, az + 2, true, Block.CAR_WHITE, true);
        g.car(ax + 7, az + 3, true, Block.CAR_WHITE, true);
        g.set(ax + 1, G + 1, az + 2, Block.RED_LIGHT);
        g.site("ambulance_bay", ax + 12, G, az + 3);
        // triage tents + bodybags in the forecourt
        for (int i = 0; i < 3; i++) new Landmarks(g).tent(x0 + mw - 10 + i * 6, r.z0() + 2, Block.CANVAS, rng);
        for (int i = 0; i < 8; i++) { int x = x0 + rng.nextInt(mw), z = r.z0() + 1 + rng.nextInt(8); if (g.air(x, G, z)) g.container(x, G, z, Block.BODYBAG, "body"); }
        g.nest(x0 + mw / 2, G + FLOOR_H * 2, z0 + md / 2);
        g.nest(x0 + 5, G - FLOOR_H, z0 + 5);
        g.landmark("St. Mercy Hospital", "hospital", x0 + mw / 2, G, z0 + md / 2);
        g.document("doc", x0 + 4, G + FLOOR_H * 3, z0 + 4);
    }

    public void containment(Rect r, Rng rng) {
        clearLot(r, Block.CONCRETE_FLOOR);
        // tall wall with chain-link crown
        for (int x = r.x0(); x < r.x1(); x++) for (int z = r.z0(); z < r.z1(); z++) {
            if (x != r.x0() && z != r.z0() && x != r.x1() - 1 && z != r.z1() - 1) continue;
            g.fill(x, G, z, x, G + 4, z, Block.CONCRETE);
            g.set(x, G + 5, z, Block.CHAINLINK); g.set(x, G + 6, z, Block.BARBED);
            if ((x + z) % 12 == 0) g.set(x, G + 2, z, Block.BIOHAZARD);
        }
        // breached gate (north)
        for (int k = -3; k <= 3; k++) for (int y = G; y <= G + 6; y++) g.set(r.cx() + k, y, r.z0(), Block.AIR);
        g.set(r.cx() - 4, G, r.z0() - 1, Block.BARRIER);
        g.rubblePile(r.x1() - 2, r.cz(), 4, 4, Block.RUBBLE);
        g.fill(r.x1() - 1, G, r.cz() - 2, r.x1() - 1, G + 4, r.cz() + 2, Block.AIR); // second breach
        // labs
        Spec lab = new Spec(r.x0() + 4, r.z1() - 26, Math.min(36, r.w() - 10), 20);
        lab.floors = 3; lab.style = Style.LAB; lab.wall = Block.CONCRETE_PANEL; lab.trim = Block.METAL_PLATE; lab.window = Block.GLASS_DIRTY; lab.street[0] = true; lab.lootBias = "lab"; lab.damage = 0.3f; lab.basement = true;
        b.build(lab);
        g.document("doc", lab.x0 + 3, G, lab.z0 + 3);
        g.document("doc", lab.x0 + 6, G + FLOOR_H * 2, lab.z0 + 4);
        // quarantine tents
        for (int i = 0; i < 6; i++) tent(r.x0() + 6 + (i % 3) * 10, r.z0() + 6 + (i / 3) * 9, Block.CANVAS, rng);
        // toxic pools & nests
        for (int k = 0; k < 3; k++) {
            int px = r.x1() - 14 - k * 9, pz = r.z0() + 8 + rng.nextInt(Math.max(1, r.d() - 40));
            for (int dx = -3; dx <= 3; dx++) for (int dz = -3; dz <= 3; dz++) if (dx * dx + dz * dz <= 9) { g.set(px + dx, G - 1, pz + dz, Block.TOXIC); g.set(px + dx, G - 2, pz + dz, Block.TOXIC_GROUND); }
            for (int dx = -5; dx <= 5; dx++) for (int dz = -5; dz <= 5; dz++) if (dx * dx + dz * dz <= 25 && dx * dx + dz * dz > 9 && g.get(px + dx, G - 1, pz + dz) == Block.CONCRETE_FLOOR) g.set(px + dx, G - 1, pz + dz, Block.TOXIC_GROUND);
        }
        for (int i = 0; i < 5; i++) {
            int x = r.x0() + 5 + rng.nextInt(r.w() - 10), z = r.z0() + 5 + rng.nextInt(r.d() - 10);
            biomass(x, g.groundY(x, z), z, 2 + rng.nextInt(2), rng);
            g.nest(x, g.groundY(x, z), z);
        }
        for (int i = 0; i < 10; i++) { int x = r.x0() + 2 + rng.nextInt(r.w() - 4), z = r.z0() + 2 + rng.nextInt(r.d() - 4); if (g.air(x, G, z)) g.container(x, G, z, Block.BODYBAG, "body"); }
        g.landmark("Containment Site K-7", "containment", r.cx(), G, r.cz());
    }

    public void biomass(int x, int y, int z, int rad, Rng rng) {
        for (int dx = -rad; dx <= rad; dx++) for (int dy = -1; dy <= rad; dy++) for (int dz = -rad; dz <= rad; dz++) {
            if (dx * dx + dy * dy + dz * dz > rad * rad + 1) continue;
            if (Rng.hash(x + dx, y + dy, z + dz, 17) < 0.55f) g.setIfAir(x + dx, y + dy, z + dz, Block.BIOMASS);
        }
    }

    public void crater(int cx, int cz, int rad, Rng rng) {
        for (int dx = -rad - 3; dx <= rad + 3; dx++) for (int dz = -rad - 3; dz <= rad + 3; dz++) {
            double d = Math.sqrt(dx * dx + dz * dz);
            int x = cx + dx, z = cz + dz;
            if (d < rad) {
                int depth = (int) ((1 - d / rad) * 6) + 1;
                g.fill(x, G - depth, z, x, G + 20, z, Block.AIR);
                g.set(x, G - depth - 1, z, d < rad * 0.35 ? Block.TOXIC_GROUND : Block.ASH);
                if (d < rad * 0.25) g.set(x, G - depth, z, Block.TOXIC);
            } else if (d < rad + 3) {
                int top = g.groundY(x, z);
                g.set(x, top, z, Rng.hash(x, 1, z, 3) < 0.5f ? Block.RUBBLE : Block.ASH);
            }
        }
        g.landmark("Impact Crater", "crater", cx, G, cz);
    }
}
