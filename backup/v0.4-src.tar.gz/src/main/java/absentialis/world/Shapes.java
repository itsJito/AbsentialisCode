package absentialis.world;

/**
 * Sub-block geometry for everything that is not a perfect cube (v0.3): ladders, doors, fences,
 * lamp posts, chairs, tables, beds, shelving. A shape is a list of boxes in sixteenths of a block;
 * the chunk mesher rotates them to the orientation it reads from the neighbouring blocks (a ladder
 * hugs its wall, a door lies in its wall line, a chair faces its table), so no per-block metadata
 * is stored.
 *
 * Box layout: {x0, y0, z0, x1, y1, z1, tex}. tex: 0 = natural (top / side / bottom texture by
 * face), 1 = side texture on every face, 2 = top texture, 3 = bottom texture; +{@link #PLANE} emits
 * only the two large faces of a thin box (cut-out textures such as rungs and wire mesh).
 */
public final class Shapes {
    private Shapes() {}

    public static final int CUBE = 0, LADDER = 1, DOOR = 2, DOOR_OPEN = 3, FENCE = 4, POST = 5, ARM = 6, CHAIR = 7, TABLE = 8,
            BED = 9, SOFA = 10, TOILET = 11, PEW = 12, TOMBSTONE = 13, SHELF = 14, BARREL = 15, TIRE = 16, FIXTURE = 17, SLAB_LOW = 18, FENCE_Z = 19;
    public static final int PLANE = 8;

    private static final int[][][] BOXES = new int[20][][];

    static {
        BOXES[LADDER] = new int[][]{{1, 0, 0, 15, 16, 1, 1 | PLANE}};
        BOXES[DOOR] = new int[][]{{0, 0, 6, 16, 16, 9, 0}};
        BOXES[DOOR_OPEN] = new int[][]{{0, 0, 0, 3, 16, 16, 0}};
        BOXES[FENCE] = new int[][]{{0, 0, 7, 16, 16, 9, 1 | PLANE}};
        BOXES[POST] = new int[][]{{6, 0, 6, 10, 16, 10, 1}};
        BOXES[ARM] = new int[][]{{0, 10, 6, 16, 14, 10, 1}};
        BOXES[CHAIR] = new int[][]{{2, 6, 2, 14, 8, 14, 1}, {2, 0, 2, 4, 6, 4, 1}, {12, 0, 2, 14, 6, 4, 1}, {2, 0, 12, 4, 6, 14, 1}, {12, 0, 12, 14, 6, 14, 1}, {2, 8, 2, 14, 16, 4, 1}};
        BOXES[TABLE] = new int[][]{{0, 13, 0, 16, 16, 16, 2}, {1, 0, 1, 3, 13, 3, 3}, {13, 0, 1, 15, 13, 3, 3}, {1, 0, 13, 3, 13, 15, 3}, {13, 0, 13, 15, 13, 15, 3}};
        BOXES[BED] = new int[][]{{0, 4, 0, 16, 9, 16, 0}, {0, 0, 0, 16, 4, 16, 3}};
        BOXES[SOFA] = new int[][]{{0, 0, 0, 16, 7, 16, 0}, {0, 7, 0, 16, 14, 4, 1}};
        BOXES[TOILET] = new int[][]{{4, 0, 5, 12, 7, 14, 3}, {4, 7, 2, 12, 14, 5, 3}, {3, 7, 5, 13, 8, 14, 3}};
        BOXES[PEW] = new int[][]{{0, 6, 3, 16, 8, 13, 2}, {0, 8, 3, 16, 15, 5, 2}, {0, 0, 3, 2, 6, 13, 2}, {14, 0, 3, 16, 6, 13, 2}};
        BOXES[TOMBSTONE] = new int[][]{{3, 0, 6, 13, 14, 10, 0}, {2, 0, 5, 14, 2, 11, 2}};
        BOXES[SHELF] = new int[][]{{0, 0, 0, 16, 1, 16, 2}, {0, 5, 0, 16, 6, 16, 2}, {0, 10, 0, 16, 11, 16, 2}, {0, 15, 0, 16, 16, 16, 2},
                {0, 1, 0, 1, 15, 1, 2}, {15, 1, 0, 16, 15, 1, 2}, {0, 1, 15, 1, 15, 16, 2}, {15, 1, 15, 16, 15, 16, 2},
                {2, 1, 3, 7, 4, 13, 1}, {9, 1, 4, 14, 5, 12, 1}, {3, 6, 3, 8, 9, 12, 1}, {10, 6, 2, 14, 10, 14, 1}, {2, 11, 4, 12, 14, 12, 1}};
        BOXES[BARREL] = new int[][]{{2, 0, 2, 14, 16, 14, 0}};
        BOXES[TIRE] = new int[][]{{1, 0, 1, 15, 6, 15, 0}};
        BOXES[FIXTURE] = new int[][]{{4, 9, 4, 12, 16, 12, 1}};
        BOXES[FENCE_Z] = new int[][]{{7, 0, 0, 9, 16, 16, 1 | PLANE}};
        BOXES[SLAB_LOW] = new int[][]{{0, 0, 0, 16, 8, 16, 0}};
    }

    public static int[][] boxes(int shape) { return shape <= 0 || shape >= BOXES.length ? null : BOXES[shape]; }

    /** Rotates a box a quarter turn (x,z) -> (16-z, x), 'rot' times, writing the normalised result to out. */
    public static void rotate(int[] box, int rot, int[] out) {
        int x0 = box[0], z0 = box[2], x1 = box[3], z1 = box[5];
        for (int r = 0; r < (rot & 3); r++) {
            int nx0 = 16 - z1, nx1 = 16 - z0, nz0 = x0, nz1 = x1;
            x0 = nx0; x1 = nx1; z0 = nz0; z1 = nz1;
        }
        out[0] = x0; out[1] = box[1]; out[2] = z0; out[3] = x1; out[4] = box[4]; out[5] = z1; out[6] = box[6];
    }

    /** Quarter turns that put a shape's back (base: -z) against the given side: 0 -z, 1 +x, 2 +z, 3 -x. */
    public static int orientation(World w, int id, int x, int y, int z) {
        Block b = Block.ALL[id];
        switch (b.shape) {
            case LADDER: case SOFA: case TOILET: case TOMBSTONE: {
                if (backing(w, x, y, z - 1)) return 0;
                if (backing(w, x + 1, y, z)) return 1;
                if (backing(w, x, y, z + 1)) return 2;
                if (backing(w, x - 1, y, z)) return 3;
                return (x * 31 + z * 17) & 3;
            }
            case DOOR: case DOOR_OPEN: {
                // the wall line: solid neighbours on the x axis mean the leaf spans x
                boolean wx = wall(w, x - 1, y, z) || wall(w, x + 1, y, z), wz = wall(w, x, y, z - 1) || wall(w, x, y, z + 1);
                return wz && !wx ? 1 : 0;
            }
            case FENCE: case ARM: {
                boolean ax = joins(w, id, x - 1, y, z) || joins(w, id, x + 1, y, z), az = joins(w, id, x, y, z - 1) || joins(w, id, x, y, z + 1);
                return az && !ax ? 1 : az ? 4 : 0;   // 4 = both runs (corner / crossing)
            }
            case CHAIR: {
                if (seatFor(w, x, y, z + 1)) return 0;
                if (seatFor(w, x - 1, y, z)) return 1;
                if (seatFor(w, x, y, z - 1)) return 2;
                if (seatFor(w, x + 1, y, z)) return 3;
                return (x * 13 + z * 7 + y) & 3;
            }
            case PEW: return w.get(x, y, z - 1) == id || w.get(x, y, z + 1) == id ? 1 : 0;
            default: return 0;
        }
    }

    private static boolean backing(World w, int x, int y, int z) { Block n = w.block(x, y, z); return n != null && n.solid() && n.shape == CUBE; }
    private static boolean wall(World w, int x, int y, int z) { Block n = w.block(x, y, z); return n != null && n.solid() && n.shape == CUBE && !n.is(Block.DOOR); }
    private static boolean joins(World w, int id, int x, int y, int z) {
        int n = w.get(x, y, z);
        if (n == id) return true;
        Block b = Block.ALL[n];
        return b != null && (b.shape == POST || b.shape == FIXTURE || b.shape == ARM || b.shape == FENCE || b.solid() && b.shape == CUBE);
    }
    private static boolean seatFor(World w, int x, int y, int z) { int n = w.get(x, y, z); return n == Block.TABLE || n == Block.DESK || n == Block.COUNTER || n == Block.COMPUTER; }
}
