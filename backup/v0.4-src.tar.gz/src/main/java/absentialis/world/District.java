package absentialis.world;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * The six districts of the Zone (iteration P7). The layout is a Pripyat-style town wrapped round a
 * central power-plant complex, fused with Moscow's density: panel-housing microdistricts, wide
 * boulevards, a metro line and a government quarter across the canal.
 *
 * Each district carries its atmosphere (fog / tint / ambience) and a definition: landmark list,
 * loot-table weighting, faction influence baseline, patrol density, infected baseline and its
 * extraction points by type. Enum constant names are the stable save keys; {@link #display} is
 * what the player reads.
 */
public enum District {
    //            display        fogR  fogG  fogB  density tintR tintG tintB  ambience
    WILDERNESS   ("Wilderness",  0.62f, 0.64f, 0.58f, 1.25f, 1.00f, 1.00f, 0.92f, "wind", new Def(
            "Outskirts: forest, fields, the eastern highway and the metro's outer cuttings. Thin loot, thin patrols, a way out when the city closes.",
            "none", 0.30f, 0.25f, 0.10f, false)
            .landmarks("Eastern Highway", "Abandoned Farmstead", "Hunter Camp", "Fringe Breach")
            .loot("food", 1.3f, "water", 0.9f, "medicine", 0.6f, "ammo", 0.6f, "fuel", 0.8f, "materials", 0.9f, "tech", 0.4f)
            .influence("military", 0.10f, "raiders", 0.10f, "survivors", 0.12f, "mercenaries", 0.04f)
            .exits("east_road:PERMANENT", "west_track:PERMANENT")),
    OLD_QUARTER  ("Downtown",    0.50f, 0.54f, 0.62f, 1.05f, 0.92f, 0.95f, 1.06f, "bells", new Def(
            "Dense commerce round the old cathedral: department stores, office towers, arcades. Vertical, cover-rich, loud - and where the valuables are.",
            "mercenaries", 0.40f, 0.85f, 0.85f, false)
            .landmarks("Cathedral of St. Absalom", "Old Cemetery", "Univermag Department Store", "Meridian North Tower")
            .loot("food", 1.0f, "water", 1.0f, "medicine", 1.0f, "ammo", 0.9f, "fuel", 0.6f, "materials", 0.8f, "tech", 1.45f)
            .influence("military", 0.24f, "raiders", 0.10f, "survivors", 0.14f, "mercenaries", 0.42f)
            .exits("north_underpass:PERMANENT", "crypt_exit:CONDITIONAL")),
    INDUSTRIAL   ("Industrial",  0.60f, 0.55f, 0.46f, 1.20f, 1.06f, 0.98f, 0.88f, "machines", new Def(
            "The V.I. Lenin power plant at the heart of the city and the belt that fed it: turbine hall, reactor blocks, cooling towers, rail yard, warehouses. Fuel and parts, machinery and drops, bandit country.",
            "raiders", 0.42f, 1.00f, 0.55f, false)
            .landmarks("V.I. Lenin Power Plant", "Reactor Block 3", "Sarcophagus (Block 4)", "Turbine Hall", "Vent Stack", "Cooling Towers", "Switchyard", "Energetik Square", "Kovalenko Works", "Rail Yard", "Container Terminal", "Waterline Utility Station")
            .loot("food", 0.7f, "water", 0.8f, "medicine", 0.7f, "ammo", 1.0f, "fuel", 1.6f, "materials", 1.6f, "tech", 1.1f)
            .influence("military", 0.08f, "raiders", 0.46f, "survivors", 0.08f, "mercenaries", 0.30f)
            .exits("rail_freight:TIME_WINDOW", "metro_line:CONDITIONAL", "bridge_checkpoint:CONDITIONAL")),
    MARKET       ("Residential", 0.66f, 0.60f, 0.52f, 0.85f, 1.06f, 1.00f, 0.92f, "city", new Def(
            "Panel-housing microdistricts: nine-storey blocks round courtyards, School No. 3, the polyclinic, the bazaar. Food and personal goods, tight stairwells, people still living here.",
            "survivors", 0.38f, 0.70f, 0.40f, false)
            .landmarks("School No. 3", "District Polyclinic", "Bazaar Square", "Haven (Survivor Compound)")
            .loot("food", 1.5f, "water", 1.3f, "medicine", 1.15f, "ammo", 0.7f, "fuel", 0.7f, "materials", 0.9f, "tech", 0.8f)
            .influence("military", 0.10f, "raiders", 0.16f, "survivors", 0.50f, "mercenaries", 0.06f)
            .exits("fringe_breach:PERMANENT", "sewer_outfall:PERMANENT")),
    REDLINE      ("Untamed",     0.48f, 0.56f, 0.44f, 1.40f, 0.94f, 1.04f, 0.88f, "drone", new Def(
            "Overgrown and abandoned first: the hospital, the containment camp, the crater. Collapsed blocks, contaminated interiors, nests. Little to take and a lot to lose.",
            "none", 0.80f, 0.35f, 0.25f, false)
            .landmarks("St. Mercy Hospital", "Containment Site K-7", "Impact Crater", "Abandoned Roadblock")
            .loot("food", 0.5f, "water", 0.5f, "medicine", 1.35f, "ammo", 0.6f, "fuel", 0.5f, "materials", 0.7f, "tech", 0.7f)
            .influence("military", 0.08f, "raiders", 0.08f, "survivors", 0.06f, "mercenaries", 0.05f)
            .exits("ambulance_bay:PERMANENT", "canal_boat:TIME_WINDOW", "cordon_gate:EMERGENCY")),
    CIVIC        ("Government",  0.58f, 0.62f, 0.68f, 0.80f, 0.96f, 1.00f, 1.05f, "wind", new Def(
            "The administrative quarter south of the canal: ministry towers, the garrison, checkpoints on every bridge. Intelligence and documents under military control - go where you are cleared to go.",
            "military", 0.28f, 1.25f, 0.35f, true)
            .landmarks("Meridian Helipad", "Civic Garrison", "City Hall", "Collapsed Bridge")
            .loot("food", 0.8f, "water", 0.9f, "medicine", 1.0f, "ammo", 1.3f, "fuel", 0.8f, "materials", 0.7f, "tech", 1.35f)
            .influence("military", 0.66f, "raiders", 0.04f, "survivors", 0.06f, "mercenaries", 0.12f)
            .exits("helipad:SIGNALED", "ministry_convoy:TIME_WINDOW"));

    /** Data-driven identity of a district. */
    public static final class Def {
        public final String role, home;
        /** Infected pressure baseline 0..1, patrol density multiplier, ambient noise 0..1. */
        public final float infected, patrol, noise;
        /** Restricted areas inside are enforced (permit = standing). */
        public final boolean permits;
        public String[] landmarks = {};
        public String[] exits = {};
        private final Map<String, Float> loot = new LinkedHashMap<>(), influence = new LinkedHashMap<>();

        Def(String role, String home, float infected, float patrol, float noise, boolean permits) {
            this.role = role; this.home = home; this.infected = infected; this.patrol = patrol; this.noise = noise; this.permits = permits;
        }
        Def landmarks(String... l) { landmarks = l; return this; }
        Def exits(String... e) { exits = e; return this; }
        Def loot(Object... kv) { for (int i = 0; i < kv.length; i += 2) loot.put((String) kv[i], (Float) kv[i + 1]); return this; }
        Def influence(Object... kv) { for (int i = 0; i < kv.length; i += 2) influence.put((String) kv[i], (Float) kv[i + 1]); return this; }

        /** Loot-table weight for a supply category here (1 = neutral). */
        public float lootWeight(String category) { return loot.getOrDefault(category, 1f); }
        public Map<String, Float> lootWeights() { return loot; }
        /** Baseline influence a faction holds here with nothing disturbing it. */
        public float influence(String faction) { return influence.getOrDefault(faction, 0.05f); }
        public boolean homeOf(String faction) { return home.equals(faction); }
        /** Extraction ids of one type ("PERMANENT", "CONDITIONAL", "TIME_WINDOW", "SIGNALED", "EMERGENCY"). */
        public java.util.List<String> exitsOf(String type) {
            java.util.List<String> l = new java.util.ArrayList<>();
            for (String e : exits) if (e.endsWith(":" + type)) l.add(e.substring(0, e.indexOf(':')));
            return l;
        }
    }

    public final String display;
    public final float fogR, fogG, fogB, fogDensity, tintR, tintG, tintB;
    public final String ambience, faction, resources;
    public final Def def;

    District(String d, float fr, float fg, float fb, float den, float tr, float tg, float tb, String amb, Def def) {
        display = d; fogR = fr; fogG = fg; fogB = fb; fogDensity = den; tintR = tr; tintG = tg; tintB = tb;
        ambience = amb; this.def = def; faction = def.home;
        StringBuilder b = new StringBuilder();
        def.lootWeights().entrySet().stream().filter(e -> e.getValue() >= 1.25f).forEach(e -> b.append(b.length() > 0 ? ", " : "").append(e.getKey()));
        resources = b.length() == 0 ? "Scrap" : Character.toUpperCase(b.charAt(0)) + b.substring(1);
    }

    public static final District[] CITY = {OLD_QUARTER, INDUSTRIAL, MARKET, REDLINE, CIVIC};

    public static District byName(String s) {
        for (District d : values()) if (d.name().equalsIgnoreCase(s) || d.display.equalsIgnoreCase(s)) return d;
        return null;
    }
}
