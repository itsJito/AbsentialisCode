package absentialis.entity;

import absentialis.world.Block;
import absentialis.world.World;

/**
 * Voxel collision for upright AABB actors: per-axis sweep against solid blocks, 1-block auto-step
 * when grounded (curbs, stairs), ladder climbing, and line-of-sight / ray queries.
 */
public final class Physics {
    private Physics() {}

    public static final float GRAVITY = 22f;

    public static boolean boxFree(World w, float x, float y, float z, float r, float h) {
        int x0 = (int) Math.floor(x - r), x1 = (int) Math.floor(x + r - 1e-4f);
        int y0 = (int) Math.floor(y), y1 = (int) Math.floor(y + h - 1e-4f);
        int z0 = (int) Math.floor(z - r), z1 = (int) Math.floor(z + r - 1e-4f);
        for (int bx = x0; bx <= x1; bx++) for (int by = y0; by <= y1; by++) for (int bz = z0; bz <= z1; bz++) if (w.solid(bx, by, bz)) return false;
        return true;
    }

    public static boolean inClimb(World w, float x, float y, float z) {
        // feet, waist and a little below the feet: the climb continues until the body has cleared the top rung,
        // so a ladder that ends at a roof edge delivers you onto the roof instead of dropping you back down it
        for (float dy : new float[]{-0.6f, 0f, 0.9f}) {
            Block b = w.block((int) Math.floor(x), (int) Math.floor(y + dy), (int) Math.floor(z));
            if (b != null && b.is(Block.CLIMB)) return true;
        }
        return false;
    }

    /**
     * Moves the actor by its velocity * dt with collision; updates onGround. Large steps are split
     * so no axis advances more than 0.4 blocks per sub-step (no tunnelling through 1-block floors
     * at terminal velocity or under coarse regional-tier ticks). Returns true if blocked horizontally.
     */
    public static boolean move(World w, Actor a, float dt) {
        float vmax = Math.max(Math.abs(a.vx), Math.max(Math.abs(a.vz), Math.abs(a.vy) + GRAVITY * dt));
        int n = Math.max(1, Math.min(64, (int) Math.ceil(vmax * dt / 0.4f)));
        boolean blocked = false;
        boolean ground = false;
        for (int i = 0; i < n; i++) { blocked |= step(w, a, dt / n); ground |= a.onGround; }
        a.onGround = ground && a.vy <= 0;
        return blocked;
    }

    private static boolean step(World w, Actor a, float dt) {
        float h = a.height(), r = a.radius;
        boolean blocked = false;
        // ladders: holding forward while inside a climbable column moves up
        boolean onLadder = inClimb(w, a.x, a.y, a.z);
        a.climbing = onLadder && a.wantClimb;
        if (a.climbing) {
            a.vy = a.climbDir * 3.2f;
            // going down stops at the floor instead of grinding into it
            if (a.climbDir < 0 && !boxFree(w, a.x, a.y - 0.1f, a.z, r, h)) a.vy = 0;
            a.vx *= 0.55f; a.vz *= 0.55f;
        } else if (onLadder && !a.onGround && a.vy <= 0) {
            a.vy = Math.max(a.vy - GRAVITY * dt, -1.4f);   // hands on the rails: a controlled slide, never a free fall
            a.fallSpeed = 0;
        } else a.vy -= GRAVITY * dt;
        a.vy = Math.max(a.vy, -40);
        // X
        float nx = a.x + a.vx * dt;
        if (boxFree(w, nx, a.y, a.z, r, h)) a.x = nx;
        else if (a.onGround && boxFree(w, nx, a.y + 1.01f, a.z, r, h) && boxFree(w, a.x, a.y + 1.01f, a.z, r, h)) { a.y += 1.01f; a.x = nx; a.stepped += 1.01f; }
        else { blocked = true; a.vx = 0; }
        // Z
        float nz = a.z + a.vz * dt;
        if (boxFree(w, a.x, a.y, nz, r, h)) a.z = nz;
        else if (a.onGround && boxFree(w, a.x, a.y + 1.01f, nz, r, h) && boxFree(w, a.x, a.y + 1.01f, a.z, r, h)) { a.y += 1.01f; a.z = nz; a.stepped += 1.01f; }
        else { blocked = true; a.vz = 0; }
        // Y
        float ny = a.y + a.vy * dt;
        a.onGround = false;
        if (boxFree(w, a.x, ny, a.z, r, h)) a.y = ny;
        else {
            if (a.vy < 0) {
                a.onGround = true;
                a.fallSpeed = -a.vy;
                a.y = (float) Math.floor(ny) + 1f;
                if (!boxFree(w, a.x, a.y, a.z, r, h)) a.y = (float) Math.ceil(ny);
            }
            a.vy = 0;
        }
        // settle tiny penetration
        if (!boxFree(w, a.x, a.y, a.z, r, h)) a.y += 0.05f;
        return blocked;
    }

    /** True when no opaque block lies between the points (sight checks). */
    public static boolean los(World w, float ax, float ay, float az, float bx, float by, float bz) {
        float dx = bx - ax, dy = by - ay, dz = bz - az;
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 0.5f) return true;
        int steps = (int) (len * 2.5f);
        for (int i = 1; i < steps; i++) {
            float t = i / (float) steps;
            int x = (int) Math.floor(ax + dx * t), y = (int) Math.floor(ay + dy * t), z = (int) Math.floor(az + dz * t);
            Block b = w.block(x, y, z);
            if (b != null && b.opaque()) return false;
        }
        return true;
    }

    /** Fraction of the path that is clear (0..1) - used for sound occlusion. */
    public static float openness(World w, float ax, float ay, float az, float bx, float by, float bz) {
        float dx = bx - ax, dy = by - ay, dz = bz - az;
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        int steps = Math.max(2, (int) (len / 1.5f)), solid = 0;
        for (int i = 1; i < steps; i++) {
            float t = i / (float) steps;
            if (w.solid((int) Math.floor(ax + dx * t), (int) Math.floor(ay + dy * t), (int) Math.floor(az + dz * t))) solid++;
        }
        return 1f - Math.min(1f, solid / 6f);
    }

    /** Voxel ray cast: returns {x,y,z,face} of the first solid/interactive block within maxDist, or null. */
    public static int[] ray(World w, float ox, float oy, float oz, float dx, float dy, float dz, float maxDist, boolean interactOnly) {
        int x = (int) Math.floor(ox), y = (int) Math.floor(oy), z = (int) Math.floor(oz);
        int sx = dx > 0 ? 1 : -1, sy = dy > 0 ? 1 : -1, sz = dz > 0 ? 1 : -1;
        float tdx = Math.abs(1 / (dx == 0 ? 1e-6f : dx)), tdy = Math.abs(1 / (dy == 0 ? 1e-6f : dy)), tdz = Math.abs(1 / (dz == 0 ? 1e-6f : dz));
        float tmx = (dx > 0 ? (x + 1 - ox) : (ox - x)) * tdx, tmy = (dy > 0 ? (y + 1 - oy) : (oy - y)) * tdy, tmz = (dz > 0 ? (z + 1 - oz) : (oz - z)) * tdz;
        int face = -1;
        float t = 0;
        while (t <= maxDist) {
            int id = w.get(x, y, z);
            if (id != 0) {
                Block b = Block.ALL[id];
                if (interactOnly ? b.is(Block.INTERACT) || b.is(Block.CONTAINER) : b.solid()) return new int[]{x, y, z, face};
                if (interactOnly && b.opaque()) return null;
            }
            if (tmx < tmy && tmx < tmz) { x += sx; t = tmx; tmx += tdx; face = sx > 0 ? 1 : 0; }
            else if (tmy < tmz) { y += sy; t = tmy; tmy += tdy; face = sy > 0 ? 3 : 2; }
            else { z += sz; t = tmz; tmz += tdz; face = sz > 0 ? 5 : 4; }
        }
        return null;
    }
}
