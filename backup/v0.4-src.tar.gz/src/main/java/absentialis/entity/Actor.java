package absentialis.entity;

import absentialis.gameplay.inventory.Container;
import absentialis.gameplay.items.ItemInstance;

/**
 * A physical agent in a raid: the player, a faction member or an infected. Holds body state,
 * hit regions, perception memory and the voxel appearance description. AI logic lives in
 * {@link absentialis.ai.Brain}; this class is plain state shared by every system.
 */
public final class Actor {
    private static int nextId = 1;

    public final int id = nextId++;
    public String faction;        // player, military, raiders (bandits), survivors (loners), mercenaries, infected
    public String archetype;      // rifleman, marksman, shotgunner, walker, shambler, sprinter, screecher, boomer, tank
    public boolean isPlayer;

    // ----- body
    public float x, y, z, vx, vy, vz, yaw, pitch, radius = 0.3f;
    public float stand = 1.8f;
    public boolean onGround, crouch, climbing, wantClimb, sprinting;
    public int climbDir = 1;
    public float stepped, fallSpeed;
    public float hp = 100, maxHp = 100, armorDur, armorMax;
    /** Body Armor protection that absorbs damage before health does. */
    public float shield, shieldMax;
    /** Blinded by a flash grenade until this raid time. */
    public float blindUntil;
    public int armorClass;
    public boolean helmet;
    public boolean dead;
    public float deadTime, hurtFlash, walkPhase;
    public int lastAttacker;
    public float speedMul = 1;

    // ----- equipment / corpse
    public ItemInstance weapon;
    public Container corpse;      // lootable inventory (created on death)
    public String look = "";      // appearance key for the voxel model cache

    // ----- AI state (see ai.Brain)
    public String state = "idle";
    public float stateTime, thinkTimer, fireCooldown, burstLeft, alertness, awareness;
    public float memX, memY, memZ, memTime = -999, memConfidence; // last known target position
    public int targetId;
    public float goalX, goalZ, homeX, homeZ;
    public boolean hasGoal;
    public float stuckTime, specialTimer;
    public boolean hostileToPlayer, sawPlayerAggress;
    public boolean aggressor;     // hostile to the player before the player harmed it (self-defence context)
    public int cell = -1;         // strategic cell owning this actor (tier transitions)
    public int tier = 0;          // 0 = active, 1 = regional
    public float regionalAccum;
    public int squad;

    // ----- animation / ragdoll (character package; evaluated by the renderer and the camera)
    public absentialis.character.Animator anim;
    public absentialis.character.Ragdoll ragdoll;
    /** Renderer-owned cached look (appearance + gear model key). */
    public Object visual;
    public float hitDirX, hitDirZ;            // direction the last damaging hit travelled
    public String hitRegion = "torso";
    public float hitForce;

    // ----- doctrine state (see ai.Brain): shared by every human archetype
    public float morale = 1, risk = 0.5f;     // morale 0..1, risk tolerance 0..1
    public float memErr;                      // uncertainty radius (m) of the remembered position
    public String role = "";                  // suppress, flank, hold, leader ...
    public float coverX, coverZ, coverUntil;  // chosen cover position
    public boolean hasCover;
    public float orderX, orderZ, orderUntil;  // squad / dispatch order (respond to noise, reinforce)
    public boolean hasOrder;
    public float warnTimer, extortTimer, lootTimer, talkTimer, suppressUntil, lastSeenTime = -999;
    public boolean warned, paidOff, needsHelp, helped, looted, calledBackup, restricted;
    public int routeIndex = -1;
    public long squadUid;                     // persistent A-Life squad id (0 = ambient)
    public float lastSay = -99;
    public boolean burst;                     // fat infected: already ruptured
    public float staggerUntil;                // slowed by a hit / acid
    /** Items taken off corpses during the raid (dropped with the rest when this agent dies). */
    public final java.util.List<ItemInstance> carried = new java.util.ArrayList<>();

    // ----- navigation (see ai.Brain.goTo / world.Nav)
    public int[] path;                        // packed cells {x, y, z, ...} toward pathTX/pathTZ
    public int pathI;
    public float pathTX, pathTZ, pathAt = -99, routeAt = -99, viaX, viaZ;
    public boolean hasVia;

    // ----- anatomical damage (see scene.Gore and package anatomy)
    /** Layered voxel anatomy (created on the first hit) and what the body can still do. */
    public absentialis.anatomy.VoxelBody body;
    public absentialis.anatomy.AnatomicalState anat;
    /** Rig groups that hang limp (broken, not gone); impairments as AIInjuryAdapter bits. */
    public int limpMask, impaired;
    /** A living character knocked down under physics gets up after this raid time. */
    public float downUntil;
    /** The injury event the AI acts on: how bad (0..1, fading), which region, when, and who did it. */
    public float injurySeverity, injuryTime = -99, lastCritical = -99;
    public int injuryGroup = -1, injuryFrom;
    /** Rig groups that have been severed and are no longer drawn on the body. */
    public int severed;
    /** Open wounds: blood lost per second, the drip counter of the trail, and what a corpse has yet to drain. */
    public float bleed, trail, poolLeft, slipUntil, aimPenalty = 1;
    public boolean crawling;
    /** Blood pools this agent has already examined (ids), so a trail is followed forward. */
    public java.util.Set<Integer> evidenceSeen;

    // ----- A-Life identity and routine (see sim.Agents)
    public long agentId;                      // persistent agent this body belongs to (0 = none)
    public String name = "";
    public boolean nightShift;
    public String routine = "";               // what the schedule says right now: guard, patrol, scavenge, rest, sleep ...
    public boolean light;                     // carrying a lit torch (night duty)
    public float flashUntil, wakeUntil = -99;  // muzzle flash gives the shooter away; woken sleepers stay up for a while
    public String duty = "patrol";            // on-shift role

    // ----- squad (the player's AI element, see gameplay.squad.Roster)
    public long mateId;
    public String team = "";
    public absentialis.character.Appearance appearance;
    /** Standing order (follow, hold, move, sweep) and an order queued to run on Initiate. */
    public String sqOrder = "follow", qOrder;
    public float sqX, sqZ, qX, qZ;

    public float evidenceTimer;

    // ----- tactical knowledge and state (see ai.Tactics, ai.SquadMind, ai.CloseCombat)
    /** 0 unaware, 1 suspicious, 2 threat aware, 3 engaged, 4 searching. */
    public int awareLevel;
    /** The remembered position was seen by this agent itself (false: heard, inferred or told). */
    public boolean memConfirmed;
    /** How the target was moving when last seen, and where the agent now assumes it is. */
    public float memVX, memVZ, suspX, suspZ, suspTime = -99;
    /** Rounds landing close: 0 .. 1, and pinned (head down) until this raid time. */
    public float suppression, pinnedUntil;
    /** Current tactical role and the position chosen for it: when it was taken, which way it faces, when to reconsider. */
    public String tacRole = "";
    public float coverSince, coverDirX, coverDirZ = 1, relocateAt, positionAt, flankedAt = -99;
    /** Searching: the place this agent has claimed, when it set off, how many it has cleared. */
    public boolean hasSearch;
    public float searchX, searchZ, searchAt, scanT, lastTold = -99, selfAidAt, selfAidUntil = -99;
    public int searched;
    /** Close combat: an attack being wound up (seconds left), which one, and when it last grabbed someone. */
    public float meleeWind, lastGrab = -99;
    public String meleeMove = "";
    /** Velocity last frame (movement has weight: it does not change direction in one tick). */
    public float pvx, pvz;

    // ----- infection (see scene.InfectionSystem)
    /** 0 = clean; a bite starts it and it climbs to 100, where a human turns. (The player's own level lives on Survivor and is mirrored here.) */
    public float infection;
    /** Raid time at which this agent will use the antiviral it carries (-1 = it has none). */
    public float infectTreatAt = -1;
    /** A human who turned: an infected in the body, clothes and kit they had. */
    public boolean turned;
    public String turnedFrom = "";

    public boolean mate() { return mateId != 0; }

    public float height() { return crouch || crawling ? stand * (crawling ? 0.45f : 0.68f) : stand; }
    public float eyeY() { return y + height() - 0.17f; }
    public boolean infected() { return "infected".equals(faction); }
    public boolean alive() { return !dead; }

    public float dist(Actor o) { float dx = x - o.x, dy = y - o.y, dz = z - o.z; return (float) Math.sqrt(dx * dx + dy * dy + dz * dz); }
    public float distXZ(float ox, float oz) { float dx = x - ox, dz = z - oz; return (float) Math.sqrt(dx * dx + dz * dz); }

    /** Hit region for a world-space hit height. */
    public String regionAt(float hy) {
        float rel = (hy - y) / height();
        if (rel > 0.83f) return "head";
        if (rel > 0.45f) return "torso";
        return rel > 0.38f ? "arms" : "legs";
    }

    /** Ray-vs-upright-capsule (approximated as AABB). Returns entry t along the segment or -1. */
    public float intersect(float ox, float oy, float oz, float dx, float dy, float dz, float maxT) {
        if (dead) return -1;
        float r = radius + 0.05f, h = height();
        float[] lo = {x - r, y, z - r}, hi = {x + r, y + h, z + r}, o = {ox, oy, oz}, d = {dx, dy, dz};
        float t0 = 0, t1 = maxT;
        for (int a = 0; a < 3; a++) {
            if (Math.abs(d[a]) < 1e-7f) { if (o[a] < lo[a] || o[a] > hi[a]) return -1; continue; }
            float ta = (lo[a] - o[a]) / d[a], tb = (hi[a] - o[a]) / d[a];
            if (ta > tb) { float t = ta; ta = tb; tb = t; }
            t0 = Math.max(t0, ta); t1 = Math.min(t1, tb);
            if (t0 > t1) return -1;
        }
        return t0;
    }
}
