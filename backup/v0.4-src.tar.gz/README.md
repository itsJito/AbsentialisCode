# ABSENTIALIS — Version 0.4

Single-player voxel extraction survival shooter set in the quarantined city of Absentialis
(Java 21 + LWJGL 3.3.3). Prepare at the hideout, deploy with your squad, scavenge, and get out.

## Build & run

```powershell
.\gradlew.bat run --no-daemon        # play
.\gradlew.bat selftest --no-daemon   # 313 quality gates, no window (exit code != 0 on failure)
```

The build pins a **Java 21 toolchain** (LWJGL 3.3.3 does not support Java 24); Gradle provisions one
if needed. Fatal errors are printed and written to `crash.log`.

Version 0.2 saves load directly: the old 12x16 case is repacked into the Rank-sized grid (overflow goes
to the stash), magazines become the rounds they held, retired ammunition ids map to the six new types.
The pre-0.3 source and saves are archived in `backup/v0.2-src.tar.gz`.

## Controls (rebindable in Settings unless marked fixed)

| Action | Key | Action | Key |
|---|---|---|---|
| Move / sprint / walk | WASD / LShift / LAlt | Fire / aim | LMB / RMB |
| Crouch / jump | C / Space | Reload | R |
| Lean | Q / E | Fire mode | B |
| Interact (doors, loot, bodies, locked drawers) | F | Primary / sidearm / melee | 1 / 2 / 3 |
| Inventory | I | Quick-use slots | 4-7 |
| Weapon wheel (hold) | Tab | Throw (or launch, with a Grenade Launcher) | G |
| Map | M | Flashlight | L |
| First / third person | V | Console | ~ |

**Driving:** **F** beside a vehicle gets in (and out). **W / S** throttle and brake-then-reverse, **A / D** steer,
**Space** handbrake, **H** horn, **L** headlights, **J** light bar (emergency vehicles), **V** chase / driver's-seat
camera.

**Bitten?** Use Antiviral Medicine from a quick slot or the inventory. **F** on a bitten squadmate or friendly
stranger gives them a dose.

**Ladders:** forward climbs, back descends; letting go is a slow slide, not a fall.

**Inventory:** drag to move, **R** rotates, **Shift+click** sends an item to the other side, right-click
for actions, **Z** sorts. Drag a Green Herb onto another herb to mix them. Hover an item and press **F**
to inspect it full-screen.

**Squad (fixed keys):**

| Key | Order |
|---|---|
| T | Choose who the next order goes to: **Gold** (everyone deployed), **Red**, **Blue** |
| F1 / F2 | Follow me / Hold where you are |
| F3 / F4 | Move to the crosshair / Sweep the crosshair |
| Left Ctrl + order | Queue the order for that team instead of issuing it |
| F5 | **Initiate** (Gold): every team runs its queued order at once |
| F6 | Move the squadmate in front of you to the other team |

## What Version 0.4 changed

### Fixed
- **No audio.** The game's audio output was fine; the Windows Volume Mixer entry for the Java runtime on the
  output device was at 0%. The game now checks its own mixer session at start-up and restores it
  (`engine/audio/WinAudioSession`), the title screen and Settings > Audio show the device and mixer level, and
  there is a test-sound button with live meters. The mixer thread also survives a device fault instead of dying.
- **Crash** (`crash.log`: `ConcurrentModificationException` in the blood system) - the gore, projectile, thrown
  and zone loops no longer mutate a list while iterating it.
- **F** only plays the interact animation when something was actually interacted with.
- **Weapon icons** are fitted to the model's occupied voxels and rendered side-on, so every gun fills the tile
  footprint it occupies (gated: >= 80% one way, >= 60% the other).
- A **container closes itself** a moment after the last item is taken.

### Removed
- The fire **voxel**. Fire is now `scene/FireSystem`: pooled flame, smoke and ember particles, flickering
  light, heat that burns whoever stands in it, rain that beats it down, and a looped crackle.

### Changed
| System | Where | Summary |
|---|---|---|
| Infection | `scene/InfectionSystem` | Bites from the infected can break the skin. The infection runs BITTEN > FEVER > SICK > CRITICAL with symptoms on the HUD and screen; **Antiviral Medicine** (common loot, in the starter kit, sold in the shop) cures it at any stage. Untreated, the player dies and rises; NPCs turn in the body, clothes and name they had, with green skin and the infected animation set. Organised factions often carry a dose and treat themselves. |
| Death | `scene/RaidScreen`, `scene/Raid` | Third-person view of the body while the picture drains to grainy black and white, then RESPAWN / MAIN MENU / QUIT. **Ironman** (chosen at profile creation) makes death permanent: the profile is deleted. |
| Squad | `scene/SquadPanel` | Every squadmate can be renamed (click the name; Enter confirms, Esc cancels, or roll a random one). |
| Lighting | `engine/render/HybridRenderer` | OpenGL 4.5 deferred PBR in HDR: cascaded sun shadows, tiled GPU light culling, shadowed local lights, irradiance probes updated by compute-shader voxel rays with visibility weighting and per-region caching, GTAO, screen-space reflections, volumetric fog and shafts, TAA, bloom, auto-exposure, ACES. Four quality presets and per-effect toggles in Settings > Graphics. Falls back to the 0.3 forward renderer if GL 4.5 is unavailable (`ABS_LEGACY_GL=1` forces it). |
| Damage | `anatomy/*`, `scene/Gore` | Each body is layered voxels (skin, fat, muscle, bone, joint, organ, armour). Hits are traced against the posed body and remove what they pass through; wounds are meshed from what is left and persist; a limb comes away when the structure joining it fails; ragdoll reactions, blood and what the AI can still do all follow from the same state. |
| Enemy AI | `ai/Tactics`, `ai/SquadMind`, `ai/CloseCombat` | Five awareness levels driven by sight and sound only; memory of a last known position that goes stale; squads share information by voice or radio with delay and range; roles (aggressor, flanker, suppressor, searcher, defender); scored cover and flank positions; suppression from near misses; coordinated search of cleared and uncleared ground; close combat with turn-taking, shoves and grabs. |
| Vehicles | `vehicle/*`, `scene/VehicleSystem` | Force-driven four-wheel rigid-body simulation at a fixed 50 Hz: suspension rays, adhesion-limited tyres, automatic gearbox, per-surface grip, zone deformation, burst tyres, entry and exit animations, chase and seat cameras. Eight vehicles in seven families, all data in `content/vehicles.json`. Bought in the SHOP under VEHICLES; one can be brought per operation and is lost if you die. At most four vehicles exist in an operation. |
| Deployment | `scene/HideoutScreen` | The deploy dialog is now a one-page Operation Briefing: insertion cards with who holds the district and how infected it is, time on the ground, vehicle, element, a readiness checklist and a one-line summary beside DEPLOY. |

### Added
- **Version numbers**: this build is Version 0.4 (title screen, hideout, HUD footer, saves).

## Console (`~`, Tab autocompletes)

`help`, `god`, `noclip`, `thirdperson`, `give <item> [qty]`, `tp <district|exit>`, `setrep <faction> <value>`,
`econ audit`, `skip hour [n]`, `ai debug`, `noise debug`, `alife`, `freeze`, `save`, `load`, `xp <n>`, `heal`,
`extract`, `time <minutesLeft>`, `spawn <archetype|faction>`, `selftest`.

## Test hooks (environment variables)

| Variable | Effect |
|---|---|
| `ABS_SELFTEST=all` or any of `inventory weapon progress econ save death extraction noise ballistic tier character anim ragdoll audio alife ai zombie district v03` | run gates headless and exit |
| `ABS_SAVES=<dir>` | use another save directory (automated runs never touch real profiles); with `ABS_SELFTEST=save` every profile there is load-checked |
| `ABS_AUTOSHOT=<dir>` | scripted pass saved as PNGs: menus, raid, squad contact, death camera, debrief |
| `ABS_PREVIEW=<dir>` | fixed map preview renders |
| `ABS_SELFTEST=v04` / `vehicle` / `system` / `icon` | the 0.4 gates: vehicle handling validation, infection, death, fire, anatomy, combat AI, audio bank |
| `ABS_NOVSYNC=1`, `ABS_GPUPROF=1` | uncapped frame rate; per-pass GPU timings in the log |
| `ABS_LEGACY_GL=1` | force the 0.3 forward renderer |
| `ABS_TEST_NOVEHICLES=1` | operations start without vehicles |

**Recorded audio:** drop `.ogg` or `.wav` files named after a sound (for example `engine_loop.ogg`) into
`assets/audio/` and they replace the synthesised version at start-up.

## Notes on the brief

- The Squad section gives two sets of numbers. The detailed list is implemented: **4** starting squadmates,
  **5** unlockable, roster **9**, **8** deployed (Red 4 + Blue 4).
- The Diamond's worth was left blank; it is set to ₡20,000.
- Inventory sizes are rows x columns (6x10 = 6 rows of 10), so every listed weapon fits lying flat.
- Every firearm loads loose rounds of its ammunition type; physical magazines no longer exist. The
  Magazine attachment category changes capacity and reload speed instead.

## Known limits

- All audio is still synthesised at start-up; no recorded assets ship with the game (the override folder above
  is the way to add them).
- Measured on a GTX 1050 Ti at 1600x900, High preset: about 64 fps in the scripted city pass. 1080p on the same
  card was not measured.
- Ambient occlusion runs at half resolution and TAA uses a simple neighbourhood clamp; fast motion can ghost.
- The first wound mesh for a body is built on the frame of the hit; later ones are built off-thread.
- Limp limbs are animated procedurally, not simulated.
- NPCs do not drive. Vehicles collide with the voxel world and with people, not yet with each other.
- From the driver's seat the car's own glass is not drawn (so you can see out); side windows on the door still are.
- Player limbs are injured but never severed. Agents do not climb ladders.
- Vehicle prices, handling numbers, infection timings and AI thresholds are first-pass values.
