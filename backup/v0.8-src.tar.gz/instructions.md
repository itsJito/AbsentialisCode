# CLAUDE CODE MASTER IMPLEMENTATION PROMPT — GAME VERSION 0.8

> **PRIMARY DIRECTIVE** You are a senior game-engine engineer, technical director, AI systems architect, physics programmer, gameplay designer, and quality-assurance lead. Utilize the most advanced **appropriate, proven, maintainable, and performant** techniques available within this repository and its existing engine to deliver an exceptionally polished, production-quality **Version 0.8**. Do not settle for superficial fixes, stub implementations, visual fakery, or merely writing a plan. **Refine the execution of the ideas; do not alter, replace, dilute, or reinterpret their creative intent.** The detailed requirements below are the product specification. Inspect the actual project before deciding how to implement anything. Make changes in the codebase, verify them, and clearly report what is complete versus unverified.

## Non-negotiable project rules

1. **Preserve the existing world.** Do not regenerate, replace, resize, rearrange, or redesign the world map, geography, district layout, or established locations.
2. **Preserve the game's identity.** Maintain the voxel aesthetic, current item and model identities, existing working gameplay, established faction roles besides renames, and core game loop. Improve textures, animation, collision, presentation, systems, and polish as specified and when noticing it can be improved; do not silently swap art direction or mechanics.
3. **Refinement is not redesign.** When a requirement is underspecified, first examine current game conventions and choose the smallest coherent implementation that fulfills its intended player experience. Make tuning values configurable. If a decision would materially change game design, record the options and ask the creator rather than inventing a new design.
4. **Reuse existing infrastructure.** Extend the actual engine, AI, navigation, inventory, audio, UI, physics, doors, save system, and content pipelines. Avoid duplicate managers, parallel game systems, or wholesale rewrites unless there is demonstrated necessity and approval.
5. **Use advanced methods where they help.** Apply deterministic simulation, utility AI, event-sourced persistent memory, robust state machines, animation blending, physically constrained controllers, fixed-timestep simulation, profiling, automated regression tests, data-driven configuration, and safe persistence migration where appropriate. Do not introduce complexity for its own sake.
6. **Deliver integrated behavior.** A feature is not complete until it works in actual gameplay, interacts with adjacent systems, survives relevant save/load scenarios, and has meaningful tests or a documented manual verification procedure.
7. **Never misrepresent progress.** Do not mark tasks as complete when they are conceptual, stubbed, untested, blocked, or only partially integrated. Report concrete files modified, tests run, results, and remaining risks.
8. **Keep performance under control.** Profile CPU, allocations, physics stability, pathfinding, AI tick costs, rendering, and save/load; prefer scalable simulation over full-fidelity offscreen actors.
9. **Version and documentation.** Set the game version to **0.8** in the project's authoritative version source and update/clean `CHANGELOG.md` with truthful major and minor changes, grouped clearly. Do not claim unreleased work shipped.

Bugs to be fixed:
  Glass textures freak out when looking at glass through glass.
  Game crashed while downtown, check the crashlog. Happened multiple times.
  Game crashed multiple different times during multiple instances even on devmap.
  When prone in third person, the the character goes under the floor. Also, when in prone the player follows the camera. They should naturally move.
  When on the second floor of a building, the prompt to loot corposes on the floor below is shown.
  Regular infected AI runs away from player when spawned using devcommands (check neuralAI)
  Car doors open backwards.
  When corpses are near doors, doors can not be opened.
  Infected don't eat players/npc's corpse
  Players face still does not display properly on the GUI HUD.
  When the player is driving a vehicle, their model is not properly rigged/alligned to the car. Polish this, as currently it shows the running animation playing in the car.
  Players shouldn't be able to slip in blood while in a vehicle.
  Vehicles should deform based on where the damage was actually struck.
  AI Squadmates should stay behind the actual player character, not the player camera. Check the NeuralAI engine.
  When sending the squadmates to a location, the location should be physically shown as a physical checkpoint that fades out after a few seconds to see physically where exactly you sent them. (check with NeuralAI)
  Gladiator NPC's should be completely blind (no vision cones, can not detect NPC's via sight) and must only rely on sound.
  Leaning left and right is slightly slanted and should be fixed.
  Player characters and NPC characters still have trouble contextually covering and aiming around blocks. Polish this.
  NPC's (squadmates especially) start firing at targets that are too far away and shouldn't do this. Give squadmates the toggle of holding fire or not via command (check NeuralAI)

Things to remove:
  The old AI is dense, messy, static, coupled, magic-number-heavy. Make sure the old AI is completely removed and we rely solely on NeuralAI for all the AI types, including squad, infected, and other NPC types.

Changes to make:
  While we are creating this in java/gradle, we need to make sure that this evolves into it's own game engine beyond the game to perserve the technology, this engine shall be known as the Astratto Engine, copyright of Astratto North of LudusValley Recreations under VEIN Enterprises. The engines logo should be a silhouette of a human brain.
  When no profiles are created/detected, only show "New Game", "Settings" and "Quit" on the main menu screen; only prompt continue if there is a profile that can be read.
  Polish the butcher and gladiator animations.
  Prompt the player to lock into a difficulty when creating their profile; this can not be changed after.
  On every death the player should only lose their entire inventory only if they're on hard mode only. Change the difficulties to Easy, Normal, and Hard, with Ironman mode being toggleable for all. Deaths on normal implement a "Pick 3" system, allowing the player to choose 3 items that will not despawn after their death, this includes jewelry. Pick 3 system is upped to a pick 5 system on standard. There is no pick system on hard difficulty and players risk losing their entire inventory. Upon death players also lose a % of money. On easy this is 5%, on Normal this is 10%, and on Hard this is 20%.
  third person sprinting animations look a tad stiff, especially whilst holding a pistol. When holding the pistol it should look more similar to running without.
  Baseball hat model looks too much like a miners hat.
  give command should have a command for every item in the game.
  add more commands to the devcommand list for feature testing.
  Change the faction name "Government" to "Military".
  The laser attachment on guns should come in either Red (Default), Green or Blue, and should be a physical object in the world that only becomes active when aiming, emits real light, and replaces the players reticle. 
  When a player or squadmate ranks up, a short riff or masculine sound effect should play.
  The chainsaw, claws, hammer, casings and spray sound effects are synthesised, and must be replaced with high quality sound effects.
  Third Person aiming should still have a reticle displayed when aiming unless theres a laser attachment in the weapon.
  When prone, crounch, or standing, there should be a small icon on the hud to display which stance the player is in for a short duration.
  When in third person, the camera should be closer to the character and even closer when aiming. When the character aims in third person, the player should never go transparent unless truly obstructing the camera. Otherwise keep the camera framed off to the right over the players shoulder to reveal whats infront of the player.
  The purchase SFX in the shop from the deployment page should also be changed to a proper pleasing sound effect found online, high quality.
  Any synthesized sound besides those in the UI must be replaced with a high quality version found online and properly implemented in the audio engine.
  Gun sounds still don't sound punchy enough, make sure you find high quality real gun sounds that match the guns in the game and run them through the audio engine.
  XP progression is too readily accessible during gameplay and the progress bar and xp notifications should only appear when actions warranting it have occured. Rank insignias visually communicate status. Rank-ups trigger graphically pleasing temporary GUI notifications. Notifications, insignias, and progress bars communicate advancement. Players should understand how close they are to their next milestone. Earning XP should feel immediately rewarding. Progression should be understandable without navigating multiple menus. Detailed progression information should not overwhelm the combat HUD.
  I have added my own audio that should all be added into the game. I have named them, so apply them logically based on their name and make sure they work. I replaced some UI sfx so make sure those get placed in. Integrate all audio to the audio engine and ensure it replaces any synthesized audio possible.
  When the player spawns in, no matter where they deploy, the spawn location should always be in a tuck away location that makes the most sense and gives the player the most options.
  Replace the "Allegience" screen with a more simple, user-friendly screen asking what the person is looking for; Profit, Stability, Peace or Chaos. Depending on what the player chooses, it will influence the starting district for the player aswell as the available contracts at the start, along with permanently boosting friendliness with that faction, (Profit is mercenaries, stability is military, peace is loner and Chaos is bandit.) the GUI should be simple, with each choice being represented by a stylized glyph (E.G the scales of justice for stability, jolly roger for chaos, singular person outline for peace, and and profit is a dollar sign)
  Make sure all audio files can work properly (.mp3, .ogg and .wav) and rename our audio engine to UltraEngine.

Things to add:
  Spinels should be placed on certain cielings of interiors and exteriors and able to be shot down and picked up by the player.
  Implement and create the 5 missions for the 5 factions, which can be done in any order (each factions mission is sequential but any can be done in any order) and progress can be tracked in the deployment tab. Missions have no time limit and progress can be tracked per deployments and progress saves even after death. As such, redo the current contracts in the game to be 10 non-overlapping distinct contracts that fit the theme of the surrounding missions i've supplied in. Derive all narrative information from lore.md. 
  Developer Mode:
    A seperate and true developer mode, enabled via console command 'devmode', eliminates the player character and transforms the game into a user-friendly yet professional looking interface full of everything the development team will need, such as an easy GUI for spawning entitites, weapons, vehicles, NPC's etc. The controls should essentially be noclip and the NPC AI do not react to the user in control in devmode. Developer mode should also show the player/users current coordinates.
  Director Mode:
    Director Mode is an interactive cinematic sandbox that allows the developer to select characters, control world conditions, modify gameplay mechanics, stage performances, and record scenes without traditional gameplay restrictions.

    The system consists of two primary interfaces: the Casting Screen for character selection/creation and the Interaction Menu for controlling the active session.

    1. Character selection/creation
    ------------------
    The character selection/creation is the character-selection hub displayed when entering Director Mode.

    FEATURES:
    - Preview character models.
    - Cycle supported outfits and appearances.
    - Access unlocked and special characters.
    - Spawn weapons/loadouts
    - Save up to 10 favorite actors to a shortlist.
    - Configure initial settings.
    - Enter Director Mode with the selected actor.

    GUI STRUCTURE:

    DIRECTOR MODE
    ----------------------------------------
    > Actors
      Shortlist
      Settings
      Enter Director Mode
      Exit Director Mode
    ----------------------------------------

    Selecting "Actors" opens the individual characters. Highlighting a character displays its preview. Confirming selects the actor.

    2. INTERACTION MENU
    -------------------
    The Interaction Menu is accessible during active gameplay and allows real-time control of Director Mode.

    GUI STRUCTURE:

    DIRECTOR MODE
    ----------------------------------------
    > Settings
      Location
      Dialogue
      Shortlist Actors
      Return to character selection/creation
      Quit Director Mode
    ----------------------------------------

    CONTROLS:
    - Up/Down: Navigate options.
    - Left/Right: Adjust values.
    - Select: Confirm or activate.
    - Back: Return to previous menu.
    - Close: Resume unobstructed gameplay.

    The menu uses a compact overlay with highlighted selections, adjustable values, nested submenus, and confirmation dialogs.


    3. WORLD SETTINGS
    -----------------
    The Settings menu controls environmental conditions and gameplay modifiers.

    GUI STRUCTURE:

    SETTINGS
    ----------------------------------------
    > Time of Day         < Midday >
      Freeze Time         < Off >
      Weather             < Clear >
      Wanted Status       < Disabled >
      NPC Density         < Normal >
      Vehicle Density     < Normal >
      Invincibility       < Off >
      Noclip              < Off >
    ----------------------------------------

    TIME:
    - Select preset times from midnight through evening.
    - Freeze or resume the world clock.

    WEATHER:
    - Currently only Clear until we create the weather system.
    - Maintain the selected weather during the session.

    POPULATION:
    - Adjust ambient Human and Infected density.
    - Adjust ambient vehicle density.
    - Reduce or disable ambient population generation.

    GAMEPLAY MODIFIERS:
    - Enable character invincibility.
    - Enable noclip.


    4. ACTOR SYSTEM
    ---------------
    The Actor System manages character selection, appearance, abilities, and switching.

    FEATURES:
    - Load and control supported character models.
    - Switch actors during a session.
    - Preserve appropriate world settings when switching.
    - Apply compatible outfits and appearance variations.
    - Support human, infected and special infected types.
      - Maintain a persistent actor shortlist.

    ACTOR SWITCHING PROCESS:
    1. Validate selected actor.
    2. Load required model assets.
    3. Preserve position and orientation.
    4. Replace the controlled character.
    5. Apply appearance and capabilities.
    6. Restore player controls and camera.
    7. Release unused assets.

    5. LOCATION SYSTEM
    ------------------
    Allows instant travel to predefined world locations.

    FEATURES:
    - Browse location presets.
    - Teleport the active actor.
    - Preserve appropriate session settings.
    - Load destination assets.
    - Place the actor at safe coordinates.

    GUI STRUCTURE:

    LOCATION
    ----------------------------------------
    > Airport
      Jail
      City Center
      Wilderness
      Desert
      Industrial District
      Mountains
      Downtown
    ----------------------------------------

    Location definitions contain coordinates, heading, and optional spawn restrictions.


    6. VEHICLE INTERACTION
    ----------------------
    Compatible actors can interact with vehicles normally.

    FEATURES:
    - Enter and exit vehicles.
    - Drive supported vehicles.
    - Interact with ambient traffic.
    - Apply relevant gameplay modifiers.
    - Preserve compatible vehicle behavior during the session.

    Optional extensions may provide vehicle spawning, repair, customization, and positioning.


    7. CAMERA & RECORDING
    ---------------------
    Director Mode supports cinematic scene capture through a recording system of up to three minutes.

    FEATURES:
    - Standard gameplay camera controls.
    - Actor-specific camera behavior.
    - Manual recording.
    - Action replay where supported.
    - Start and stop recording.
    - Save recorded clips.
    - Display recording status.
    - Transfer clips to a cinematic editor.

    EDITOR CAPABILITIES:
    - Timeline editing
    - Clip sequencing
    - Camera positioning
    - Camera transitions
    - Playback adjustment
    - Visual effects
    - Audio management
    - Video export

    Recording and editing are separate systems: Director Mode stages the scene, while the editor processes captured footage.


    8. SESSION MANAGEMENT
    ---------------------
    Director Mode operates independently from normal gameplay.

    SESSION FLOW:

    Normal Gameplay
          |
          v
    Activate Director Mode (currently only via devmode command 'directormode')
          |
          v
    Save Original Player State
          |
          v
    character selection/creation
          |
          v
    Select Actor
          |
          v
    Enter Director World
          |
          +-- Change Settings
          +-- Switch Actors
          +-- Teleport
          +-- Perform Actions
          +-- Record Scenes
          |
          v
    Exit Director Mode
          |
          v
    Restore Original State
          |
          v
    Normal Gameplay

    EXIT REQUIREMENTS:
    - Stop active actions and recordings.
    - Close Director Mode interfaces.
    - Restore original character and equipment.
    - Restore camera and gameplay controls.
    - Remove temporary modifiers.
    - Restore environmental settings.
    - Clean up temporary entities and assets.

    9. GUI DESIGN
    --------------
    Director Mode uses a hierarchical, user-friendly menu system.

    GUI COMPONENTS:
    - Menu title/header
    - Highlighted selection
    - Scrollable option list
    - Left/right value selectors
    - On/off toggles
    - Nested submenus
    - Disabled option states
    - Confirmation prompts
    - Navigation hints

    MENU BEHAVIOR:
    - Settings update immediately when changed.
    - Menus reflect actual active settings.
    - Back navigation preserves previous selection.
    - Menus remain usable while the world is active.
    - Character previews update when selection changes.
    - Input is temporarily restricted during transitions.

    10. TECHNICAL ARCHITECTURE
    --------------------------
    The system is divided into specialized controllers.

    CORE MODULES:

    SessionManager
    - Activation, transitions, cleanup, restoration.

    GUIManager
    - Menus, navigation, input, visual state.

    ActorManager
    - Character registry, models, appearances, switching.

    WorldManager
    - Time, weather, environmental settings.

    PopulationManager
    - NPC and vehicle density.

    ModifierManager
    - Invincibility, gameplay effects.

    LocationManager
    - Location presets and teleportation.

    PerformanceManager
    - Animations, gestures, dialogue.

    VehicleManager
    - Vehicle compatibility and interactions.

    CameraManager
    - Camera behavior and transitions.

    RecordingManager
    - Capture, clip management, editor integration.

    PersistenceManager
    - Shortlists, preferences, saved configuration.


    11. IMPLEMENTATION REQUIREMENTS
    -------------------------------
    - Centralized session state management.
    - Reliable character loading and switching.
    - Actor-specific capability validation.
    - Real-time environmental manipulation.
    - Persistent session settings.
    - Responsive, nested GUI navigation.
    - Safe location teleportation.
    - Compatible animation and dialogue playback.
    - Recording integration.
    - Proper resource loading and cleanup.
    - Complete restoration of normal gameplay on exit.

    SYSTEM SUMMARY
    --------------
    Director Mode is a self-contained cinematic sandbox controlled through two main interfaces:

    Character selection/creation:
    Select actors, customize appearances, and manage favorites.

    INTERACTION MENU:
    Control environment, control NeuralAI (turn off thinking, etc), gameplay modifiers, locations, performances, and session behavior.
    These interfaces communicate with centralized managers that control the player, world simulation, camera, and recording systems.
    The result is a flexible environment for directing characters, staging scenes, manipulating gameplay conditions, and capturing cinematic content.

  New Items:
    These new items do not replace any old items, they coexisst with them. Translate the protection scale into the games system and balance them;

    Uncommon
      Hardhat — Cracked construction hard hat | Protection: 1/5 [$1,000] | Rank 3
      Scavenged Armor — Magazine vest, duct-tape sleeves, and knee pads | Protection: 1/5 [$3,000] | Rank 3
      Schoolbag — Fraying school backpack | Protection: 0/5 [$1,500] | Rank 3

    Common
      Motorcycle Helmet — Used motorcycle helmet | Protection: 2/5 [$2,500] | Rank 5
      Reinforced Rider Kit — Leather riding jacket, elbow pads, and cargo pants with shin guards | Protection: 2/5 [$6,000] | Rank 5
      Hiking Bag — Civilian hiking pack | Protection: 0/5 [$3,000] | Rank 5

    Rare
      Tactical Helmet — Tactical bump helmet with goggles | Protection: 3/5 [$5,000] | Rank 10
      Tactical Combat Rig — Lightweight plate carrier, cut-resistant sleeves and tactical gloves, and reinforced combat trousers | Protection: 3/5 [$14,000] | Rank 10
      Tactical Bag — Modular assault backpack | Protection: 1/5 [$6,000] | Rank 10

    Epic
      Ballistic Helmet — Ballistic helmet with face shield | Protection: 4/5 [$10,000] | Rank 20
      Full Ballistic Armor — Heavy plate carrier with side protection, shoulder and forearm guards, and tactical pants with knee protection | Protection: 4/5 [$26,000] | Rank 20
      Ballistic Equipment Pack — Compact ballistic equipment pack | Protection: 2/5 [$10,000] | Rank 20

    Legendary
      Sealed Ballistic Helmet — Sealed ballistic helmet with respirator | Protection: 5/5 [$18,000] | Rank 30
      Advanced Ballistic Suit — Advanced ballistic vest over chemical-resistant suit, sealed gauntlets with rigid protection, and reinforced contamination-resistant trousers | Protection: 5/5 [$42,000] | Rank 30
      Advanced ballistic bag — larger ballistic equipment pack | Protection: 5/5 [$18,000] | Rank 30

    Mythic
      Smart Ballistic Helmet — Smart ballistic helmet with thermal imaging | Protection: 5/5 [$35,000] | Rank 40
      Powered Composite Armor — Composite armor with powered load-bearing frame and powered braces with reinforced boots | Protection: 5/5 [$75,000] | Rank 40
      Military warbag — Largest bag in the game | Protection: 4/5 [$30,000] | Rank 40

  New profile backgrounds:
    Thunder Card - Stormy card with lightning bolt. Rank 10 required.
    Prestige Card - Gold skull with crossed bones. Prestige 1 required.
    Operator Card - Skull-masked soldier in tactical gear. Rank 20 required.
    Jail Card - Interlocked chain links. Rank 4 required.
    Prestigious I Card - Gold cross with star. Prestige 2 required.

### Special Instructions:
  Update the CHANGELOG.md when finished to succinctly explain every minor and major addition you made to create version 0.8 added follow the format of the previous changelog entries. Dont remove previous entries, add to it.
