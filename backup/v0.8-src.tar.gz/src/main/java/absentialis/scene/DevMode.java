package absentialis.scene;

import static org.lwjgl.glfw.GLFW.*;

import absentialis.engine.Input;
import absentialis.entity.Actor;
import absentialis.gameplay.items.Content;
import absentialis.gameplay.items.ItemDef;
import absentialis.gameplay.items.ItemInstance;
import absentialis.neuralai.integration.Archetypes;
import absentialis.neuralai.integration.NeuralHost;
import absentialis.sim.ZoneState;
import absentialis.ui.Ui;
import absentialis.vehicle.CarHandlingData;
import absentialis.world.District;
import absentialis.world.MapData;
import java.util.ArrayList;
import java.util.List;

/**
 * Developer Mode (0.8; console: {@code devmode}). It takes the player character out of the game and leaves a
 * camera: no body, no weapon, no health, no survival HUD - the user flies through the world (noclip), and nothing in
 * it knows they are there. Nobody sees them, hears them, touches them or shoots at them.
 *
 * What is on screen instead is a tool:
 *
 *   a status bar, always: coordinates, district, facing, the hour, how many actors and minds are running, the frame rate;
 *   the workbench ([Tab]): a panel for putting things in the world - people and infected, weapons, every item,
 *     vehicles - where the camera is looking, with a search box, a count and options; and a World page for the clock,
 *     the weather, freezing or clearing the AI, and going to any landmark;
 *   the inspector: whatever is under the middle of the screen - a body's kind, faction, health, what its mind is doing.
 *
 * Leaving it ({@code devmode} again) puts the survivor back on their feet under the camera with everything they had.
 */
public final class DevMode {
    public static final String[] TABS = {"NPCS", "WEAPONS", "ITEMS", "VEHICLES", "WORLD"};
    /** Flying speed in metres a second, and how much faster with [Shift]. */
    public static float FLY = 12f, FLY_FAST = 4f;

    private final RaidScreen screen;
    public boolean active, panel;
    private boolean godWas, noclipWas, thirdWas;
    public int tab, count = 1;
    public boolean hostile = true, frozen;
    private final StringBuilder search = new StringBuilder();
    private float scroll;
    private String status = "";
    private float statusAt = -99;
    /** Things put in the world from here this session (the status bar shows it; tests read it). */
    public int spawned;
    /** Where the middle of the screen is looking: the spot things are put. */
    public final float[] target = new float[3];
    public boolean targetKnown;
    public Actor inspected;

    public DevMode(RaidScreen screen) { this.screen = screen; }

    private Raid raid() { return screen.raid; }

    /** Turns the mode on or off. Returns what to tell the console. */
    public String toggle() {
        Raid r = raid();
        if (!active) {
            active = true; panel = false;
            godWas = r.god; noclipWas = r.noclip; thirdWas = screen.thirdPerson;
            r.god = true; r.noclip = true; r.devGhost = true;
            screen.thirdPerson = false;
            r.player.prone = false; r.player.crouch = false; r.player.vx = r.player.vy = r.player.vz = 0;
            r.player.y += 1.2f;                                    // lift off: the camera is nobody's eyes now
            return "Developer Mode ON - you are a camera. [Tab] workbench, [WASD] fly, [Space]/[Ctrl] up and down, [Shift] fast. 'devmode' again to leave.";
        }
        active = false; panel = false;
        r.god = godWas; r.noclip = noclipWas; r.devGhost = false;
        screen.thirdPerson = thirdWas;
        // back on their feet, under where the camera was
        int gy = r.groundY((int) Math.floor(r.player.x), (int) Math.floor(r.player.z));
        if (gy >= 0 && !noclipWas) r.player.y = gy;
        r.player.vx = r.player.vy = r.player.vz = 0;
        return "Developer Mode OFF - the survivor is back where the camera was.";
    }

    private void say(String s) { status = s; statusAt = raid().time; }

    /** Each frame while active, before the world updates: the panel's keys, and flying when it is closed. Returns true if the panel has the keyboard. */
    public boolean update(Input in, float dt) {
        Raid r = raid();
        if (in.keyPressed(GLFW_KEY_TAB) || in.pressed("inventory")) { panel = !panel; in.typed.clear(); screen.c.sfx(panel ? "inv_select" : "ui_back", 0.4f); }
        if (panel && in.keyPressed(GLFW_KEY_ESCAPE)) panel = false;
        aim();
        if (!panel) {
            fly(in, dt);
            // quick keys with the panel shut: repeat the last spawn, delete what is looked at
            if (in.keyPressed(GLFW_KEY_DELETE) && inspected != null) { remove(inspected); say("Removed " + label(inspected)); }
            return false;
        }
        // the search box takes what is typed
        while (!in.typed.isEmpty()) { char ch = in.typed.poll(); if (ch >= 32 && ch < 127 && ch != '`' && search.length() < 24) search.append(ch); }
        if (in.keyPressed(GLFW_KEY_BACKSPACE) && search.length() > 0) search.setLength(search.length() - 1);
        r.player.vx = r.player.vy = r.player.vz = 0;
        return true;
    }

    private void fly(Input in, float dt) {
        Actor p = raid().player;
        float f = (in.down("forward") ? 1 : 0) - (in.down("back") ? 1 : 0), s = (in.down("right") ? 1 : 0) - (in.down("left") ? 1 : 0);
        float fx = (float) (-Math.sin(p.yaw) * Math.cos(p.pitch)), fy = (float) Math.sin(p.pitch), fz = (float) (-Math.cos(p.yaw) * Math.cos(p.pitch));
        float sp = FLY * (in.down("sprint") ? FLY_FAST : 1) * dt;
        p.x += (fx * f + (float) Math.cos(p.yaw) * s) * sp;
        p.y += fy * f * sp + (in.down("jump") ? sp : 0) - (in.down("crouch") ? sp : 0);
        p.z += (fz * f - (float) Math.sin(p.yaw) * s) * sp;
        p.x = Math.max(1, Math.min(absentialis.world.World.W - 2, p.x)); p.z = Math.max(1, Math.min(absentialis.world.World.D - 2, p.z)); p.y = Math.max(2, Math.min(absentialis.world.World.H + 40, p.y));
        p.vx = p.vy = p.vz = 0; p.onGround = false;
    }

    public void aimNow() { aim(); }

    /** Works out what the middle of the screen is on: a spot on a surface (where things are put) and the body nearest that line (what is inspected). */
    private void aim() {
        Raid r = raid();
        Actor p = r.player;
        float ox = p.x, oy = p.eyeY(), oz = p.z;
        float dx = (float) (-Math.sin(p.yaw) * Math.cos(p.pitch)), dy = (float) Math.sin(p.pitch), dz = (float) (-Math.cos(p.yaw) * Math.cos(p.pitch));
        targetKnown = false;
        float reach = 80;
        for (float t = 0.5f; t <= 80; t += 0.2f) {
            if (r.world.solid((int) Math.floor(ox + dx * t), (int) Math.floor(oy + dy * t), (int) Math.floor(oz + dz * t))) {
                float b = t - 0.25f;
                target[0] = ox + dx * b; target[1] = oy + dy * b; target[2] = oz + dz * b;
                // onto the floor under that point, so a thing put there stands on something
                int gx = (int) Math.floor(target[0]), gz = (int) Math.floor(target[2]), gy = (int) Math.floor(target[1]);
                while (gy > 1 && !r.world.solid(gx, gy - 1, gz)) gy--;
                target[1] = gy;
                targetKnown = true; reach = t;
                break;
            }
        }
        if (!targetKnown) { target[0] = ox + dx * 10; target[2] = oz + dz * 10; int gy = r.groundY((int) target[0], (int) target[2]); target[1] = gy < 0 ? oy : gy; targetKnown = gy >= 0; }
        inspected = null;
        // the nearest body the line passes through: a body is as tall as it is, not a point at its waist
        float best = reach + 1;
        for (Actor a : r.actors) {
            if (a.isPlayer) continue;
            float ax = a.x - ox, az = a.z - oz, hl = (float) Math.sqrt(dx * dx + dz * dz);
            float along = hl < 1e-3f ? (a.y - oy) / dy : (ax * dx + az * dz) / (hl * hl);
            if (along < 0.5f || along > best) continue;
            float px = ox + dx * along - a.x, pz = oz + dz * along - a.z, py = oy + dy * along;
            float top = a.y + (a.dead ? 0.5f : a.height() + 0.25f), wide = Math.max(0.45f, a.radius * 1.6f);
            if (px * px + pz * pz < wide * wide && py > a.y - 0.2f && py < top) { best = along; inspected = a; }
        }
    }

    private static String label(Actor a) { return a.infected() ? Archetypes.displayName(a.archetype) + " infected" : ZoneState.cap(a.faction) + (a.name == null || a.name.isEmpty() ? "" : " \"" + a.name + "\""); }

    public void remove(Actor a) {
        Raid r = raid();
        r.neural.remove(a.id, true); r.neuralBody.forget(a.id); r.actors.remove(a); r.mates.remove(a);
        inspected = null;
    }

    // ------------------------------------------------------------------ putting things in the world
    public String spawnNpc(String kind) {
        Raid r = raid();
        int made = 0;
        for (int i = 0; i < count; i++) {
            double ang = i * 2.399963;                                      // spread round the spot, not stacked on it
            float rad = i == 0 ? 0 : 0.9f * (float) Math.sqrt(i);
            Actor a = r.debugSpawn(kind, target[0] + (float) Math.cos(ang) * rad, target[2] + (float) Math.sin(ang) * rad, target[1]);
            if (a == null) return "No such kind: " + kind;
            if (!a.infected()) a.hostileToPlayer = hostile;
            if (frozen) r.freezeOnly(a);
            a.yaw = (float) Math.atan2(-(r.player.x - a.x), -(r.player.z - a.z));
            made++; spawned++;
        }
        return "Spawned " + made + " x " + kind + (frozen ? " (frozen)" : "");
    }

    public String spawnItem(ItemDef d) {
        Raid r = raid();
        for (int i = 0; i < count; i++) {
            ItemInstance it = new ItemInstance(d.id);
            it.origin = "devmode";
            if (d.maxStack > 1) it.qty = d.maxStack;
            if (d.weapon != null && !d.weapon.melee() && Content.ammoFor(d.weapon.caliber) != null) { it.rounds = it.capacity(); it.ammoId = Content.ammoFor(d.weapon.caliber).id; }
            r.dropItem(it, target[0] + (i % 4) * 0.35f - 0.5f, target[1] + 0.3f, target[2] + (i / 4) * 0.35f);
            spawned++;
        }
        return "Dropped " + count + " x " + d.name;
    }

    public String spawnCar(String id) {
        Raid r = raid();
        VehicleSystem.Car car = r.vehicles.spawn(id, target[0], target[1], target[2], r.player.yaw, spawned * 31 + 7);
        if (car == null) return "No such vehicle: " + id;
        spawned++;
        return "Parked a " + car.sim.data.name;
    }

    // ------------------------------------------------------------------ what is drawn
    /** The whole of the mode's interface: called in place of the game's HUD. */
    public void draw(Ui ui, float dt) {
        Raid r = raid();
        Actor p = r.player;
        float W = ui.w, H = ui.h;
        // ---- status bar
        float bh = ui.s(30);
        ui.b.rect(0, 0, W, bh, 0xE00C0E10);
        ui.b.rect(0, bh, W, ui.s(2), 0xFF4A90E2);
        ui.text("DEVELOPER MODE", ui.s(12), ui.s(8), 13, 0xFF7AB4F0);
        District d = r.world.district(p.x, p.z);
        String coords = String.format("X %.1f   Y %.1f   Z %.1f", p.x, p.y, p.z);
        ui.text(coords, ui.s(170), ui.s(8), 13, Ui.TXT_HI);
        double hr = r.hour() % 24;
        String rest = String.format("%s    facing %03.0f°  pitch %+03.0f°    %02d:%02d    actors %d  minds %d    %d fps", d == null ? "-" : d.display, (Math.toDegrees(-p.yaw) % 360 + 360) % 360, Math.toDegrees(p.pitch), (int) hr, (int) (hr * 60) % 60, r.actors.size() - 1, r.neural.minds().size(), Math.round(1 / Math.max(1e-4f, dt)));
        ui.text(rest, ui.s(170) + ui.tw(coords, 13) + ui.s(28), ui.s(8), 12, Ui.TXT);
        ui.textR((r.freezeAI ? "AI FROZEN   " : "") + absentialis.Version.SHORT + "  " + absentialis.engine.Astratto.NAME, W - ui.s(12), ui.s(9), 11, r.freezeAI ? Ui.AMBER : Ui.TXT_DIM);
        // ---- the spot things are put, and the middle of the screen
        ui.b.rect(W / 2f - ui.s(7), H / 2f, ui.s(14), 1, 0xC07AB4F0); ui.b.rect(W / 2f, H / 2f - ui.s(7), 1, ui.s(14), 0xC07AB4F0);
        if (targetKnown) ui.textC(String.format("%.1f, %.1f, %.1f", target[0], target[1], target[2]), W / 2f, H / 2f + ui.s(14), 10, 0xB07AB4F0);
        // ---- inspector
        if (inspected != null && !panel) inspector(ui, inspected, W - ui.s(330), bh + ui.s(14), ui.s(316));
        // ---- last thing said
        if (r.time - statusAt < 4 && !status.isEmpty()) { float sw = ui.tw(status, 13) + ui.s(24); ui.b.rect(W / 2f - sw / 2, H - ui.s(92), sw, ui.s(26), 0xD00C0E10); ui.textC(status, W / 2f, H - ui.s(86), 13, Ui.GREEN); }
        // ---- hints
        String hint = panel ? "[Tab] close    type to search    click to put it where the camera is looking    [Esc] close"
                : "[Tab] workbench    [WASD] fly    [Space] up  [Ctrl] down    [Shift] fast    [Del] remove what you are looking at    [`] console  -  'devmode' to leave";
        ui.b.rect(0, H - ui.s(24), W, ui.s(24), 0xC00C0E10);
        ui.textC(hint, W / 2f, H - ui.s(19), 11, Ui.TXT_DIM);
        if (panel) workbench(ui, ui.s(14), bh + ui.s(14), Math.min(ui.s(520), W * 0.42f), H - bh - ui.s(52));
    }

    private void inspector(Ui ui, Actor a, float x, float y, float w) {
        Raid r = raid();
        String[][] rows = {
                {"Kind", a.infected() ? Archetypes.displayName(a.archetype) : a.archetype}, {"Faction", ZoneState.cap(a.faction)}, {"Id", String.valueOf(a.id)},
                {"Health", a.dead ? "dead" : Math.round(a.hp) + " / " + Math.round(a.maxHp)}, {"Position", String.format("%.1f, %.1f, %.1f", a.x, a.y, a.z)},
                {"State", a.state + "  (" + NeuralHost.describe(a) + ")"}, {"Mind", r.neural.mind(a.id) == null ? "none" : r.neural.mind(a.id).state + (r.neural.mind(a.id).action == null ? "" : " / " + r.neural.mind(a.id).action.name())},
                {"Weapon", a.weapon == null ? "-" : a.weapon.name()}, {"Hostile to you", a.infected() ? "would be" : String.valueOf(a.hostileToPlayer)}, {"Frozen", String.valueOf(r.frozen.contains(a.id) || r.freezeAI)}};
        float h = ui.s(34) + rows.length * ui.s(19) + ui.s(10);
        ui.b.rect(x, y, w, h, 0xE00C0E10);
        ui.b.rect(x, y, ui.s(3), h, 0xFF4A90E2);
        ui.text("INSPECTOR  -  " + label(a), x + ui.s(12), y + ui.s(8), 12, 0xFF7AB4F0);
        float ry = y + ui.s(32);
        for (String[] row : rows) { ui.text(row[0], x + ui.s(12), ry, 11, Ui.TXT_DIM); absentialis.ui.Layout.fit(ui, row[1], x + ui.s(120), ry, w - ui.s(132), 11, 9, Ui.TXT_HI); ry += ui.s(19); }
    }

    private boolean matches(String a, String b) { String f = search.toString().toLowerCase().trim(); return f.isEmpty() || a.toLowerCase().contains(f) || b.toLowerCase().contains(f); }

    private void workbench(Ui ui, float x, float y, float w, float h) {
        Raid r = raid();
        ui.b.rect(x, y, w, h, 0xEE0C0E10);
        ui.b.outline(x, y, w, h, 1, 0xFF2A4A70);
        float tw = (w - ui.s(16)) / TABS.length;
        for (int i = 0; i < TABS.length; i++) if (ui.tab("dev_tab" + i, x + ui.s(8) + i * tw, y + ui.s(8), tw - ui.s(4), ui.s(28), TABS[i], null, tab == i)) { tab = i; scroll = 0; search.setLength(0); }
        float cy = y + ui.s(46);
        if (tab == 4) { world(ui, x + ui.s(12), cy, w - ui.s(24)); return; }
        // search, count and options
        ui.b.rect(x + ui.s(10), cy, w - ui.s(170), ui.s(26), 0xFF16191D);
        ui.b.outline(x + ui.s(10), cy, w - ui.s(170), ui.s(26), 1, 0xFF2A4A70);
        ui.text(search.length() == 0 ? "type to search..." : search + ((int) (r.time * 2) % 2 == 0 ? "_" : ""), x + ui.s(18), cy + ui.s(6), 12, search.length() == 0 ? Ui.TXT_DIM : Ui.TXT_HI);
        int[] counts = {1, 5, 10};
        for (int i = 0; i < counts.length; i++) if (ui.tab("dev_n" + i, x + w - ui.s(152) + i * ui.s(48), cy, ui.s(44), ui.s(26), "x" + counts[i], null, count == counts[i])) count = counts[i];
        cy += ui.s(34);
        if (tab == 0) {
            hostile = ui.toggle("dev_host", x + ui.s(10), cy, (w - ui.s(30)) / 2, "People hostile to the survivor", hostile);
            frozen = ui.toggle("dev_frz", x + ui.s(20) + (w - ui.s(30)) / 2, cy, (w - ui.s(30)) / 2, "Spawn frozen (no thinking)", frozen);
            cy += ui.s(32);
        }
        // the list
        List<String[]> rows = new ArrayList<>();                // {id, name, detail}
        switch (tab) {
            case 0 -> {
                for (var ar : Archetypes.all()) if (ar.infected() && matches(ar.id(), Archetypes.displayName(ar.id()))) rows.add(new String[]{ar.id(), Archetypes.displayName(ar.id()), "infected  -  " + Math.round(ar.hp()) + " hp" + (ar.blind() ? "  -  blind" : "")});
                for (String f : ZoneState.FACTIONS) if (matches(f, absentialis.gameplay.Alliance.name(f))) rows.add(new String[]{f, absentialis.gameplay.Alliance.name(f), "faction member, armed"});
            }
            case 1 -> { for (ItemDef d : Content.ITEMS.values()) if (d.weapon != null && matches(d.id, d.name)) rows.add(new String[]{d.id, d.name, d.weapon.melee() ? "melee" : d.weapon.family + "  -  " + d.weapon.caliber}); }
            case 2 -> { for (ItemDef d : Content.ITEMS.values()) if (d.weapon == null && d.attachment == null && (matches(d.id, d.name) || search.toString().equalsIgnoreCase(d.category))) rows.add(new String[]{d.id, d.name, d.category + "  -  " + d.tierName()}); }
            default -> { for (CarHandlingData d : CarHandlingData.all()) if (matches(d.id, d.name)) rows.add(new String[]{d.id, d.name, d.family}); }
        }
        float listH = y + h - cy - ui.s(10), rowH = ui.s(30);
        float maxScroll = Math.max(0, rows.size() * rowH - listH);
        if (ui.hover(x, cy, w, listH)) scroll = Math.max(0, Math.min(maxScroll, scroll - (float) screen.c.in.scroll * rowH * 2));
        scroll = Math.min(scroll, maxScroll);
        ui.b.scissor((int) x, (int) cy, (int) w, (int) listH);
        for (int i = 0; i < rows.size(); i++) {
            float ry = cy + i * rowH - scroll;
            if (ry + rowH < cy || ry > cy + listH) continue;
            String[] row = rows.get(i);
            boolean hov = ui.hover(x + ui.s(8), ry, w - ui.s(22), rowH - ui.s(3)) && ui.my >= cy && ui.my <= cy + listH;
            ui.b.rect(x + ui.s(8), ry, w - ui.s(22), rowH - ui.s(3), hov ? 0xFF1C2836 : 0xFF14171B);
            if (hov) ui.b.rect(x + ui.s(8), ry, ui.s(3), rowH - ui.s(3), 0xFF4A90E2);
            ui.text(row[1], x + ui.s(20), ry + ui.s(6), 12, hov ? Ui.TXT_HI : Ui.TXT);
            ui.textR(row[2], x + w - ui.s(24), ry + ui.s(7), 10, Ui.TXT_DIM);
            if (hov && ui.click && !ui.consumed) {
                ui.consumed = true;
                if (!targetKnown) { say("Look at somewhere to put it"); continue; }
                say(switch (tab) { case 0 -> spawnNpc(row[0]); case 3 -> spawnCar(row[0]); default -> spawnItem(Content.def(row[0])); });
                screen.c.sfx("ui_confirm", 0.4f);
            }
        }
        ui.b.noScissor();
        if (maxScroll > 0) { float sbh = listH * listH / (rows.size() * rowH); ui.b.rect(x + w - ui.s(8), cy + (listH - sbh) * (scroll / maxScroll), ui.s(3), sbh, 0xFF4A90E2); }
        if (rows.isEmpty()) ui.text("Nothing matches '" + search + "'", x + ui.s(20), cy + ui.s(8), 12, Ui.TXT_DIM);
    }

    private void world(Ui ui, float x, float y, float w) {
        Raid r = raid();
        float cy = y;
        double hourNow = r.hour() % 24;
        float h2 = ui.slider("dev_hour", x, cy, w, "Hour of the day", (float) hourNow, 0, 23.99f, "%.1f");
        if (Math.abs(h2 - hourNow) > 0.02) r.profile.zone.hour = ((h2 - r.time / 120.0) % 24 + 24) % 24;
        cy += ui.s(52);
        boolean rain = ui.toggle("dev_rain", x, cy, w / 2 - ui.s(6), "Rain", r.profile.zone.weatherRain > 0.5f);
        r.profile.zone.weatherRain = rain ? 1 : 0;
        r.freezeAI = ui.toggle("dev_freeze", x + w / 2 + ui.s(6), cy, w / 2 - ui.s(6), "Freeze all AI", r.freezeAI);
        cy += ui.s(32);
        r.aiDebug = ui.toggle("dev_aidbg", x, cy, w / 2 - ui.s(6), "AI overlay (cones, states)", r.aiDebug);
        FLY = ui.toggle("dev_fast", x + w / 2 + ui.s(6), cy, w / 2 - ui.s(6), "Fast camera", FLY > 20) ? 30 : 12;
        cy += ui.s(40);
        float bw = (w - ui.s(16)) / 3;
        if (ui.button("dev_kill", x, cy, bw, ui.s(32), "KILL ALL", "skull", true)) { int n = 0; for (Actor a : new ArrayList<>(r.actors)) if (!a.isPlayer && !a.dead && !a.mate()) { r.damageActor(a, null, 99999, null, "head", a.x, a.y + 1.6f, a.z); n++; } say("Killed " + n); }
        if (ui.button("dev_clear", x + bw + ui.s(8), cy, bw, ui.s(32), "REMOVE ALL", "cross", true)) { int n = 0; for (Actor a : new ArrayList<>(r.actors)) if (!a.isPlayer && !a.mate()) { remove(a); n++; } say("Removed " + n); }
        if (ui.button("dev_cars", x + (bw + ui.s(8)) * 2, cy, bw, ui.s(32), "SPINEL: GO TO", "search", r.spinels != null && r.spinels.remaining() > 0)) { CeilingSpinels.Stone s = r.spinels.nearest(r.player.x, r.player.y, r.player.z, 3000); if (s != null) { r.player.x = s.x + 1.5f; r.player.y = s.floorY + 0.4f; r.player.z = s.z + 1.5f; say("Under a spinel - look up"); } }
        cy += ui.s(46);
        ui.text("GO TO", x, cy, 12, 0xFF7AB4F0);
        cy += ui.s(20);
        List<MapData.Landmark> lms = r.world.map.anchors;
        int cols = 2;
        float lw = (w - ui.s(8)) / cols;
        for (int i = 0; i < lms.size(); i++) {
            MapData.Landmark lm = lms.get(i);
            if (ui.button("dev_go" + i, x + (i % cols) * (lw + ui.s(8)), cy + (i / cols) * ui.s(32), lw - ui.s(4), ui.s(28), lm.name, null, true)) {
                r.player.x = lm.cx() + 0.5f; r.player.z = Math.min(lm.z0, lm.z1) - 6; r.player.y = absentialis.world.World.GROUND + 14;
                r.player.yaw = (float) Math.PI; r.player.pitch = -0.5f;
                say(lm.name + "  (" + lm.district.display + ")");
            }
        }
    }
}
