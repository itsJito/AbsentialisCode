package absentialis.scene;

import absentialis.gameplay.items.ItemInstance;
import absentialis.ui.Ui;
import java.util.ArrayList;
import java.util.List;

/**
 * In-raid HUD (addendum P1): minimal and contextual. Health / Stamina / Focus cores appear only
 * when they change; ammo only on fire or reload; the hour of the day sits top-centre (0.7: there is no
 * extraction countdown - operations have no time limit); hit feedback is directional with optional (scaled) shake;
 * captions describe sounds with a direction tag.
 */
public final class Hud {
    private final Ctx c;
    public float ammoShown = -99;
    private final List<Object[]> captions = new ArrayList<>(); // {text, until, color}
    private final List<Object[]> messages = new ArrayList<>();
    private float coreAlphaH, coreAlphaS, coreAlphaF, ammoAlpha;

    public Hud(Ctx c) { this.c = c; }

    public void message(String s, int col, float now) {
        messages.add(new Object[]{s, now + 5f, col});
        while (messages.size() > 5) messages.remove(0);
    }

    public void caption(String category, float bearingDeg, float loud, float now) {
        if (!c.settings.subtitles) return;
        String name = switch (category) {
            case "shot" -> "Gunfire"; case "shot_suppressed" -> "Suppressed shots"; case "explosion" -> "Explosion"; case "glass_break" -> "Glass breaking";
            case "groan" -> "Infected groan"; case "screech" -> "SCREECHER ALARM"; case "gurgle" -> "Fat infected swelling"; case "roar" -> "GIANT ROAR";
            case "shriek" -> "Fast infected shriek"; case "retch" -> "Fat infected retching"; case "splash" -> "Acid splash"; case "stomp" -> "Heavy footfalls";
            case "shout" -> "Shouting"; case "whistle" -> "Whistle"; case "radio_chatter" -> "Radio chatter";
            case "door_open", "door_close" -> "Door"; case "reload" -> "Reloading"; case "flare" -> "Flare"; case "alarm_clock" -> "Alarm clock ringing";
            case "impact" -> "Bullet impacts"; case "debris" -> "Debris"; case "melee" -> "Struggle"; case "search" -> "Rummaging"; case "bounce" -> "Clatter";
            default -> null;
        };
        if (name == null) return;
        String dir = bearing(bearingDeg);
        String dist = loud > 0.7f ? "close" : loud > 0.35f ? "near" : "distant";
        String text = "[" + name + " - " + dist + ", " + dir + "]";
        for (Object[] o : captions) if (o[0].equals(text)) { o[1] = now + 3f; return; }
        captions.add(new Object[]{text, now + 3f, category.equals("screech") || category.equals("roar") || category.equals("shriek") || category.equals("retch") || category.equals("stomp") ? Ui.RED : Ui.TXT});
        while (captions.size() > 4) captions.remove(0);
    }

    public static String bearing(float deg) {
        deg = ((deg % 360) + 360) % 360;
        if (deg < 30 || deg > 330) return "ahead";
        if (deg < 150) return deg < 60 ? "front-right" : deg < 120 ? "right" : "behind-right";
        if (deg < 210) return "behind";
        return deg > 300 ? "front-left" : deg > 240 ? "left" : "behind-left";
    }

    /** 0.8: set by the screen each frame - a laser is on (it is the reticle), and the weapon is being aimed in third person. */
    public boolean laserOn, thirdPersonAim;
    /** The stance last shown (0 standing, 1 crouched, 2 prone) and when it was taken up; how long the icon stays. */
    public int stance;
    public float stanceAt = -99;
    public static float STANCE_SECONDS = 1.8f;

    /** True while the stance icon is on screen (tests). */
    public boolean stanceShowing(float now) { return now - stanceAt < STANCE_SECONDS; }

    /** A small figure in a square of the given size: upright, folded at the knees, or flat on the ground. */
    static void stanceIcon(Ui ui, int stance, float x, float y, float size, float alpha) {
        int col = Ui.alpha(0xFFF4F0E4, alpha), back = Ui.alpha(0xA0101214, alpha);
        float u = size / 12f;
        ui.b.rect(x - u, y - u, size + 2 * u, size + 2 * u, back);
        if (stance == 0) {
            ui.b.rect(x + 5 * u, y + 0.5f * u, 2 * u, 2 * u, col);                                 // head
            ui.b.rect(x + 4.5f * u, y + 3 * u, 3 * u, 4 * u, col);                                 // body
            ui.b.rect(x + 4.5f * u, y + 7 * u, 1.2f * u, 4.5f * u, col); ui.b.rect(x + 6.3f * u, y + 7 * u, 1.2f * u, 4.5f * u, col);   // legs
        } else if (stance == 1) {
            ui.b.rect(x + 5.5f * u, y + 3 * u, 2 * u, 2 * u, col);
            ui.b.rect(x + 4.5f * u, y + 5.5f * u, 3 * u, 3 * u, col);
            ui.b.rect(x + 3.5f * u, y + 8.5f * u, 4 * u, 1.2f * u, col); ui.b.rect(x + 3.5f * u, y + 8.5f * u, 1.2f * u, 3 * u, col); ui.b.rect(x + 6.8f * u, y + 9.7f * u, 1.2f * u, 1.8f * u, col);   // folded legs
        } else {
            ui.b.rect(x + 0.5f * u, y + 7.5f * u, 2 * u, 2 * u, col);
            ui.b.rect(x + 3 * u, y + 8 * u, 4.5f * u, 2 * u, col);
            ui.b.rect(x + 7.5f * u, y + 8.6f * u, 4 * u, 1.3f * u, col);
        }
        ui.b.rect(x, y + size - 0.4f * u, size, Math.max(1, 0.4f * u), Ui.alpha(0xFF8A6420, alpha));     // the ground
    }

    public void draw(Raid r, ItemInstance held, float reloadT, float reloadMax, String interact, boolean ads, float dt) {
        Ui ui = c.ui;
        float t = r.time;
        var s = r.body;
        // ---- cores (show on change, fade out after 3.5s)
        coreAlphaH = fade(coreAlphaH, t - s.healthChanged < 3.5f || r.player.hp < 35 || s.bleedLight || s.bleedHeavy, dt);
        coreAlphaS = fade(coreAlphaS, t - s.staminaChanged < 2.5f && s.stamina < 99, dt);
        coreAlphaF = fade(coreAlphaF, t - s.focusChanged < 2.5f && s.focus < 99, dt);
        float bx = ui.s(28), by = ui.h - ui.s(64);
        // health, armour, stamina, focus and ammunition are the status module's (scene.StatusHud, lower right);
        // what stays here are the conditions that need words: wounds, bleeding, hunger, radiation, the infection
        float sy = ui.h - ui.s(40);
        if (s.bleedHeavy || s.bleedLight || s.fracture) { ui.text(s.bleedHeavy ? "HEAVY BLEEDING" : s.bleedLight ? "BLEEDING" : "FRACTURE", bx, sy, 13, Ui.RED); sy -= ui.s(18); }
        if (s.exhausted > 0) { ui.text("WINDED", bx, sy, 13, Ui.AMBER); sy -= ui.s(18); }
        if (s.armInjury > 0.25f) { ui.text("ARM WOUNDED", bx, sy, 13, s.armInjury > 0.6f ? Ui.RED : Ui.AMBER); sy -= ui.s(18); }
        if (s.legInjury > 0.25f) { ui.text("LEG WOUNDED", bx, sy, 13, s.legInjury > 0.6f ? Ui.RED : Ui.AMBER); sy -= ui.s(18); }
        if (s.rad > 5) { ui.text(String.format("RAD %.0f", s.rad), bx, sy, 13, s.rad > 60 ? Ui.RED : Ui.AMBER); sy -= ui.s(18); }
        if (s.energy < 20) { ui.text("HUNGRY", bx, sy, 13, Ui.AMBER); sy -= ui.s(18); }
        if (s.hydration < 20) { ui.text("THIRSTY", bx, sy, 13, Ui.AMBER); sy -= ui.s(18); }
        if (s.infection > 0) {
            // the infection is never hidden: stage, how far along, and whether antibiotics are holding it
            String stage = InfectionSystem.stage(s.infection);
            int col = s.infection >= InfectionSystem.CRITICAL ? Ui.RED : s.infection >= InfectionSystem.FEVER ? 0xFFB8D048 : Ui.AMBER;
            boolean heldBack = t < s.suppressUntil;
            ui.text(stage + (heldBack ? "  (held)" : "") + "   -   Antiviral Medicine cures it", bx, sy, 13, col);
            ui.b.rect(bx, sy + ui.s(17), ui.s(128), ui.s(4), 0xFF1A1C1B);
            ui.b.rect(bx, sy + ui.s(17), ui.s(128) * Math.min(1, s.infection / 100f), ui.s(4), col);
        }

        // ---- ammunition is drawn by the status module; the 0.4 box is kept only as a fallback for screens without one
        boolean showAmmo = false;
        ammoAlpha = fade(ammoAlpha, showAmmo, dt);
        if (held != null && ammoAlpha > 0.01f && held.def().weapon != null && !held.def().weapon.melee()) {
            float ax = ui.w - ui.s(250), ay = ui.h - ui.s(78);
            int a = Math.round(ammoAlpha * 255);
            ui.b.rect(ax - ui.s(10), ay - ui.s(6), ui.s(238), ui.s(60), (a * 170 / 255) << 24 | 0x0E0F0E);
            ui.glyph("bullet", ax, ay + ui.s(6), Math.max(2, ui.s(2)), Ui.alpha(0xFFFFFFFF, ammoAlpha));
            String rounds = String.valueOf(held.loadedRounds());
            ui.text(rounds, ax + ui.s(34), ay, 30, Ui.alpha(held.loadedRounds() == 0 ? Ui.RED : Ui.TXT_HI, ammoAlpha));
            ui.text(held.fireModeName().toUpperCase(), ax + ui.s(110), ay + ui.s(4), 13, Ui.alpha(Ui.TXT_DIM, ammoAlpha));
            ui.text(held.def().name, ax + ui.s(110), ay + ui.s(22), 12, Ui.alpha(Ui.TXT, ammoAlpha));
            float cond = held.condition() / 100f;
            ui.b.rect(ax + ui.s(34), ay + ui.s(40), ui.s(180) * cond, ui.s(3), Ui.alpha(cond < 0.25f ? Ui.RED : cond < 0.5f ? Ui.AMBER : Ui.GREEN, ammoAlpha));
            if (held.jammed) ui.text("JAMMED - [R] CLEAR", ax, ay - ui.s(24), 15, Ui.RED);
            if (reloadT > 0) {
                float f = 1 - reloadT / Math.max(0.01f, reloadMax);
                ui.b.rect(ax + ui.s(34), ay - ui.s(8), ui.s(180), ui.s(4), 0x80000000);
                ui.b.rect(ax + ui.s(34), ay - ui.s(8), ui.s(180) * f, ui.s(4), 0xFFE2A034);
            }
        }

        // ---- the hour (top-centre). 0.7: nothing counts down any more - there is no window to miss - but with operations
        // that can start at dusk or run through the night, the time of day is worth a glance.
        double hr = ((r.hour() % 24) + 24) % 24;
        String ts = String.format("%02d:%02d", (int) hr, (int) (hr * 60) % 60);
        float tw = ui.tw(ts, 15);
        ui.b.rect(ui.w / 2f - tw / 2 - ui.s(10), ui.s(10), tw + ui.s(20), ui.s(24), 0x800E0F0E);
        ui.textC(ts, ui.w / 2f, ui.s(13), 15, r.night() ? 0xFF9FB4D8 : Ui.TXT);

        // ---- extraction progress
        if (r.extracting != null) {
            float f = r.extractProgress / 8f;
            float w = ui.s(320);
            ui.b.rect(ui.w / 2f - w / 2, ui.h * 0.62f, w, ui.s(10), 0xA0000000);
            ui.b.rect(ui.w / 2f - w / 2, ui.h * 0.62f, w * f, ui.s(10), 0xFF7DBA5C);
            ui.textC("EXTRACTING - " + r.extracting.exit.name.toUpperCase() + String.format("  %.0fs", Math.max(0, 8 - r.extractProgress)), ui.w / 2f, ui.h * 0.62f - ui.s(22), 15, Ui.GREEN);
        } else {
            Raid.ExitState here = r.exitAt(r.player.x, r.player.y, r.player.z);
            if (here != null) ui.textC(here.exit.name.toUpperCase() + " - " + here.requirement, ui.w / 2f, ui.h * 0.62f - ui.s(22), 14, Ui.RED);
        }

        // ---- directional hit feedback
        if (c.settings.hitDirection) for (float[] hm : r.hitMarkers) {
            float age = t - hm[1];
            float rel = hm[0] - r.player.yaw;
            float a = Math.max(0, 1 - age / 1.6f);
            float cx = ui.w / 2f, cy = ui.h / 2f, rad = ui.s(120);
            float R = (float) -Math.sin(rel), F = (float) Math.cos(rel); // attacker in player-local right/forward
            float px = cx + R * rad, py = cy - F * rad, tx = F, ty = R;  // arc tangent on screen
            ui.b.line(px - tx * ui.s(26), py - ty * ui.s(26), px + tx * ui.s(26), py + ty * ui.s(26), ui.s(5), Ui.alpha(0xFFD8483A, a));
        }
        if (r.player.hp < 30) ui.b.rect(0, 0, ui.w, ui.h, Ui.alpha(0x60800000, (30 - r.player.hp) / 30f * (0.6f + 0.4f * (float) Math.sin(t * 4))));

        // ---- crosshair (minimal dot, hidden while aiming)
        if (!ads && interact == null && !laserOn) ui.b.rect(ui.w / 2f - 1, ui.h / 2f - 1, 2, 2, 0xC0FFFFFF);
        // 0.8: aiming in third person there are no sights to look through, so there is a reticle - four ticks and a
        // point, where the round will go. A laser replaces it: with a laser on, its dot in the world is the reticle.
        if (thirdPersonAim && !laserOn && interact == null) {
            float cx = Math.round(ui.w / 2f), cy = Math.round(ui.h / 2f), gap = ui.s(5), len = ui.s(6), th = Math.max(1, Math.round(ui.s(1.5f)));
            int out = 0xB0000000, in = 0xF0FFFFFF;
            for (int pass = 0; pass < 2; pass++) {
                float g = pass == 0 ? 1 : 0;
                int col = pass == 0 ? out : in;
                ui.b.rect(cx - gap - len - g, cy - th / 2f - g, len + 2 * g, th + 2 * g, col); ui.b.rect(cx + gap - g, cy - th / 2f - g, len + 2 * g, th + 2 * g, col);
                ui.b.rect(cx - th / 2f - g, cy - gap - len - g, th + 2 * g, len + 2 * g, col); ui.b.rect(cx - th / 2f - g, cy + gap - g, th + 2 * g, len + 2 * g, col);
                ui.b.rect(cx - 1 - g, cy - 1 - g, 2 + 2 * g, 2 + 2 * g, col);
            }
        }
        // ---- stance: said once, when it changes, by a small figure - standing, crouched or prone - and then gone
        int stanceNow = r.player.prone ? 2 : r.player.crouch ? 1 : 0;
        if (stanceNow != stance) { stance = stanceNow; stanceAt = t; }
        float sAge = t - stanceAt;
        if (sAge < STANCE_SECONDS && !r.player.dead && r.vehicles.driving == null) {
            float a = Math.min(1, sAge / 0.12f) * Math.min(1, (STANCE_SECONDS - sAge) / 0.5f);
            stanceIcon(ui, stance, ui.w / 2f - ui.s(17), ui.h - ui.s(150), ui.s(34), a);
        }
        // ---- the squad's orders: while they are holding fire, it says so
        if (!r.mates.isEmpty() && r.holdFire("gold") && !r.player.dead) {
            String hf = "SQUAD HOLDING FIRE  [F7]";
            float hw = ui.tw(hf, 11) + ui.s(18);
            ui.b.rect(ui.w / 2f - hw / 2, ui.s(10), hw, ui.s(20), 0xA0101214);
            ui.b.rect(ui.w / 2f - hw / 2, ui.s(10), ui.s(3), ui.s(20), Ui.AMBER);
            ui.textC(hf, ui.w / 2f + ui.s(2), ui.s(14), 11, Ui.AMBER);
        }
        if (interact != null) {
            ui.b.rect(ui.w / 2f - 2, ui.h / 2f - 2, 4, 4, 0xFFE2A034);
            ui.textC(interact, ui.w / 2f, ui.h / 2f + ui.s(18), 15, Ui.TXT_HI);
        }

        // ---- captions & messages
        float cy = ui.h - ui.s(150);
        for (int i = captions.size() - 1; i >= 0; i--) {
            Object[] o = captions.get(i);
            float left = (Float) o[1] - t;
            if (left <= 0) { captions.remove(i); continue; }
            String txt = (String) o[0];
            float w = ui.tw(txt, 15);
            ui.b.rect(ui.w / 2f - w / 2 - ui.s(8), cy - ui.s(3), w + ui.s(16), ui.s(22), Ui.alpha(0xB0000000, Math.min(1, left)));
            ui.textC(txt, ui.w / 2f, cy, 15, Ui.alpha((Integer) o[2], Math.min(1, left)));
            cy -= ui.s(26);
        }
        float my = ui.s(70);
        for (int i = messages.size() - 1; i >= 0; i--) {
            Object[] o = messages.get(i);
            float left = (Float) o[1] - t;
            if (left <= 0) { messages.remove(i); continue; }
            ui.text((String) o[0], ui.s(24), my, 14, Ui.alpha((Integer) o[2], Math.min(1, left)));
            my += ui.s(20);
        }
    }

    private static float fade(float a, boolean on, float dt) { return a + ((on ? 1 : 0) - a) * Math.min(1, dt / (on ? 0.12f : 0.6f)); }

    /** A core: glyph + 10 depleting pixel cells (deplete, not bars). */
    private void core(Ui ui, String glyph, float x, float y, float f, int col, float alpha, String status) {
        if (alpha < 0.01f) return;
        int g = Math.max(2, ui.s(2));
        ui.b.rect(x - ui.s(6), y - ui.s(6), ui.s(140), ui.s(38), Ui.alpha(0x900E0F0E, alpha));
        ui.glyph(glyph, x, y, g, Ui.alpha(0xFFFFFFFF, alpha));
        float cx = x + 12 * g + ui.s(8), cw = ui.s(8), gap = ui.s(2);
        for (int i = 0; i < 10; i++) {
            float fill = Math.max(0, Math.min(1, f * 10 - i));
            float px = cx + i * (cw + gap);
            ui.b.rect(px, y + ui.s(2), cw, ui.s(20), Ui.alpha(0xFF1A1C1B, alpha));
            if (fill > 0) {
                float h = ui.s(20) * fill;
                ui.b.rect(px, y + ui.s(2) + ui.s(20) - h, cw, h, Ui.alpha(col, alpha));
                ui.b.rect(px, y + ui.s(2) + ui.s(20) - h, cw, 1, Ui.alpha(0x60FFFFFF, alpha));
            }
        }
        if (status != null) ui.text(status, x, y - ui.s(20), 12, Ui.alpha(Ui.RED, alpha));
    }
}
