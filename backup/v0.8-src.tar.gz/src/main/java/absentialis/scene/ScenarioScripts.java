package absentialis.scene;

import static absentialis.scene.Scenarios.*;

import absentialis.persistence.Profile;

/**
 * The scripts {@link Scenarios} can run. Each is a short, named sequence built for one thing that has to be looked
 * at: a screen, a pose, a room. Add one here when a change needs eyes on it.
 */
final class ScenarioScripts {
    private ScenarioScripts() {}

    /** Leave the allegiance question unanswered (to photograph it). */
    static boolean keepUnaligned;

    static void build(String name) {
        switch (name == null ? "" : name) {
            case "shop" -> shop();
            case "menus" -> menus();
            case "shop_user" -> shopUser();
            case "specials" -> specials();
            case "falls" -> falls();
            case "car" -> car();
            case "interiors" -> interiors();
            case "devmap" -> devmap();
            case "glass" -> glass();
            case "poses" -> poses();
            case "devmode" -> devmode();
            case "director" -> director();
            case "gear" -> gear();
            default -> System.out.println("[Scenario] unknown scenario '" + name + "'");
        }
    }

    /** Buying a weapon and seeing it in the stash without reloading the profile (the 0.6 report). */
    private static void shop() {
        profile(p -> p.scrip = 200000);
        hideout(6, h -> h.hideout().tab = HideoutScreen.TAB_INVENTORY);
        hideout(16, h -> shot(h, "shop_00_stash_before"));
        hideout(18, h -> h.hideout().debugShow(0, false));
        hideout(28, h -> shot(h, "shop_01_weapons"));
        hideout(30, h -> { h.hideout().debugBuy("weapon.pm9"); h.console("give weapon.matilda"); });
        hideout(40, h -> shot(h, "shop_02_after_buy"));
        hideout(42, h -> h.hideout().tab = HideoutScreen.TAB_INVENTORY);
        hideout(52, h -> shot(h, "shop_03_stash_after"));
        hideout(54, h -> { Profile p = h.ctx().profile; StringBuilder b = new StringBuilder(); for (var i : p.stash.items) b.append(i.defId).append('@').append(i.x).append(',').append(i.y).append(' '); System.out.println("[Scenario] stash: " + b); });
    }

    /** The same purchase against a profile already in the scratch save directory as slot 3 (a copy of a real one). */
    private static void shopUser() {
        hideout(6, h -> { h.ctx().profile.scrip += 200000; h.hideout().tab = HideoutScreen.TAB_INVENTORY; });
        hideout(16, h -> shot(h, "user_00_stash_before"));
        hideout(18, h -> h.hideout().debugShow(0, false));
        hideout(30, h -> { h.hideout().debugBuy("weapon.pm9"); h.console("give weapon.matilda"); });
        hideout(42, h -> h.hideout().tab = HideoutScreen.TAB_INVENTORY);
        hideout(52, h -> shot(h, "user_01_stash_after"));
        hideout(54, h -> { Profile p = h.ctx().profile; StringBuilder b = new StringBuilder(); for (var i : p.stash.items) b.append(i.defId).append('@').append(i.x).append(',').append(i.y).append(i.rotated ? "r " : " "); System.out.println("[Scenario] stash " + p.stash.w + "x" + p.stash.h + ": " + b + " verify=" + p.verify()); });
    }

    private static final String[] CAST = {"walker", "sprinter", "bomber", "spewer", "tank", "gladiator", "butcher"};
    private static final absentialis.entity.Actor[] cast = new absentialis.entity.Actor[CAST.length];
    private static float cx, cy, cz;

    /** The infected, stood in a row in daylight and walked round: every special's model, front, side and back. */
    private static void specials() {
        profile(null);
        raid(20, h -> {
            Raid r = h.raid().raid;
            r.god = true; r.populate = false; r.freezeAI = true;
            r.actors.removeIf(a -> !a.isPlayer);
            cx = r.player.x; cy = r.player.y; cz = r.player.z;
            for (int i = 0; i < CAST.length; i++) {
                cast[i] = r.debugSpawn(CAST[i], cx + (i - 3) * 2.4f, cz - 7, cy);
                cast[i].yaw = (float) Math.PI;
                cast[i].homeX = cast[i].x; cast[i].homeZ = cast[i].z;
            }
            place(r, cx, cy, cz + 1.5f, 0, -0.02f);
        });
        raid(50, h -> shot(h, "spec_00_row"));
        int f = 54;
        for (int i = 2; i < CAST.length; i++) {
            final int k = i;
            raid(f, h -> place(h.raid().raid, cast[k].x, cast[k].y, cast[k].z + (k == 4 ? 4.2f : 3.0f), 0, k == 4 ? 0.12f : 0.02f));
            raid(f + 12, h -> shot(h, "spec_" + k + "0_" + CAST[k] + "_front"));
            raid(f + 14, h -> place(h.raid().raid, cast[k].x + (k == 4 ? 4.2f : 3.0f), cast[k].y, cast[k].z, (float) Math.PI / 2, k == 4 ? 0.12f : 0.02f));
            raid(f + 26, h -> shot(h, "spec_" + k + "1_" + CAST[k] + "_side"));
            raid(f + 28, h -> place(h.raid().raid, cast[k].x, cast[k].y, cast[k].z - (k == 4 ? 4.2f : 3.0f), (float) Math.PI, k == 4 ? 0.12f : 0.02f));
            raid(f + 40, h -> shot(h, "spec_" + k + "2_" + CAST[k] + "_back"));
            f += 42;
        }
        // bile: what it does to the picture
        raid(f, h -> { Raid r = h.raid().raid; place(r, cx, cy, cz + 1.5f, 0, -0.02f); r.bile(r.player, 15); });
        raid(f + 30, h -> shot(h, "spec_90_biled"));
    }

    private static absentialis.entity.Actor subject;
    private static float sx, sy, sz;

    /** A hit, by name, on the subject standing at the mark. The blow travels +x (left to right across the picture). */
    private static void strike(Raid r, String what) {
        absentialis.entity.Actor from = new absentialis.entity.Actor();
        from.x = sx - 12; from.y = sy; from.z = sz; from.faction = "raiders"; from.archetype = "rifleman";
        absentialis.entity.Actor v = subject;
        switch (what) {
            case "chest" -> r.damageActor(v, from, 9999, absentialis.gameplay.items.Content.def("ammo.556"), "torso", v.x, v.y + 1.25f, v.z);
            case "head_from_behind" -> r.damageActor(v, from, 9999, absentialis.gameplay.items.Content.def("ammo.556"), "head", v.x, v.y + 1.68f, v.z);
            case "leg" -> r.damageActor(v, from, 9999, absentialis.gameplay.items.Content.def("ammo.556"), "legs", v.x, v.y + 0.5f, v.z);
            case "buckshot" -> { r.hitKind = ""; v.hitForce = 160; r.damageActor(v, from, 9999, absentialis.gameplay.items.Content.def("ammo.shells"), "torso", v.x, v.y + 1.2f, v.z); }
            case "running" -> { v.vx = 5.2f; v.pvx = 5.2f; r.damageActor(v, from, 9999, absentialis.gameplay.items.Content.def("ammo.556"), "torso", v.x, v.y + 1.25f, v.z); }
            case "blast" -> r.explode(sx - 2.6f, sy + 0.3f, sz, 6, 400, 0, false);
            case "shove" -> r.gore.ragdolls.knockDown(v, 1, 0, 95, 2.2f);
            case "shove_back" -> r.gore.ragdolls.knockDown(v, 1, 0, 95, 2.2f);
            default -> { }
        }
    }

    /**
     * The fall study (instructions.md, Sydney Engine touching up): one body after another is hit in a named way in
     * front of a fixed camera and photographed every third frame, and each run is tiled into a contact sheet.
     * {cast, facing yaw, the hit, frames to film}. Facing pi/2 looks at the shooter (-x); -pi/2 has its back to it.
     */
    private static final Object[][] FALLS = {
            {"survivors", 1.5708f, "chest", 132}, {"survivors", -1.5708f, "head_from_behind", 132}, {"military", 1.5708f, "leg", 132}, {"raiders", 3.1416f, "buckshot", 132},
            {"survivors", -1.5708f, "running", 132}, {"military", 1.5708f, "blast", 132}, {"survivors", 1.5708f, "shove", 330}, {"mercenaries", -1.5708f, "shove_back", 330},
            {"walker", 1.5708f, "chest", 132}, {"walker", 1.5708f, "shove", 330}};

    private static void falls() {
        profile(null);
        raid(20, h -> {
            Raid r = h.raid().raid;
            r.god = true; r.populate = false; r.freezeAI = true;
            r.actors.removeIf(a -> !a.isPlayer);
            sx = r.player.x; sy = r.player.y; sz = r.player.z - 3.0f;
            place(r, sx + 0.8f, sy, sz + 3.0f, 0, -0.16f);
        });
        int f = 30;
        for (int k = 0; k < FALLS.length; k++) {
            final int n = k;
            final Object[] e = FALLS[k];
            final int frames = (Integer) e[3] > 200 ? 360 : 96, every = frames > 200 ? 15 : 4;
            raid(f, h -> {
                Raid r = h.raid().raid;
                r.actors.removeIf(a -> !a.isPlayer);
                subject = r.debugSpawn((String) e[0], sx, sz, sy);
                subject.yaw = (Float) e[1]; subject.hostileToPlayer = false; subject.homeX = sx; subject.homeZ = sz;
                place(r, sx + 0.8f, sy, sz + 3.0f, 0, -0.16f);
            });
            raid(f + 24, h -> strike(h.raid().raid, (String) e[2]));
            final String name = String.format("fall_%02d_%s_%s", n, e[0], e[2]);
            for (int i = 0; i * every < frames; i++) { final int idx = i; raid(f + 24 + i * every, h -> shot(h, String.format("%s_%03d", name, idx))); }
            raid(f + 24 + frames + 2, h -> sheet(name, 8, 300, 120, 1000, 700, 0.25f));
            f += 24 + frames + 6;
        }
    }

    /** Getting into a car and out of it again, in third person, photographed every fourth frame (the door should lead the body both ways). */
    private static void car() {
        profile(null);
        raid(20, h -> {
            Raid r = h.raid().raid;
            r.god = true; r.populate = false; r.freezeAI = true;
            r.actors.removeIf(a -> !a.isPlayer);
            h.raid().thirdPerson = true;
            h.console("vehicle car.volna");
        });
        raid(60, h -> {
            Raid r = h.raid().raid;
            if (r.vehicles.cars.isEmpty()) { System.out.println("[Scenario] no car"); return; }
            VehicleSystem.Car c = r.vehicles.cars.get(r.vehicles.cars.size() - 1);
            float[] o = new float[3];
            c.sim.origin(o);
            // stand off the driver's side, a few steps from the door
            place(r, o[0] - c.sim.body.rightX() * 2.1f - c.sim.body.fwdX() * 1.2f, r.player.y, o[2] - c.sim.body.rightZ() * 2.1f - c.sim.body.fwdZ() * 1.2f, (float) Math.atan2(c.sim.body.rightX(), c.sim.body.rightZ()), -0.1f);
        });
        raid(90, h -> { boolean ok = h.raid().raid.vehicles.enter(); System.out.println("[Scenario] enter " + ok); });
        for (int i = 0; i < 28; i++) { final int idx = i; raid(90 + i * 4, h -> { shot(h, String.format("car_enter_%03d", idx)); System.out.println(String.format("[Scenario] enter frame %d: progress %.2f door %.2f", idx, h.raid().raid.vehicles.phaseProgress(), h.raid().raid.vehicles.doorOpen())); }); }
        raid(206, h -> sheet("car_enter", 7, 250, 150, 1100, 650, 0.26f));
        // 0.8: the driver in the seat, looked at through the glass from the driver's side, from in front and from the far side
        float[] look = {2.25f, 3.1416f, -2.2f, 1.5708f};
        for (int i = 0; i < look.length; i++) {
            final int k = i;
            raid(210 + i * 16, h -> { Raid r = h.raid().raid; if (r.vehicles.driving != null) { r.player.yaw = VehicleSystem.playerYawOf(r.vehicles.driving.sim) + look[k]; r.player.pitch = -0.20f; } });
            raid(222 + i * 16, h -> { shot(h, "car_drive_" + k); Raid r = h.raid().raid; System.out.println("[Scenario] driver seated " + r.player.seated + " at the wheel " + r.player.atWheel + " seatW " + (r.player.anim == null ? -1 : r.player.anim.seatW) + " speed " + (r.player.anim == null ? -1 : r.player.anim.speed)); });
        }
        raid(280, h -> System.out.println("[Scenario] exit " + h.raid().raid.vehicles.exit()));
        for (int i = 0; i < 28; i++) { final int idx = i; raid(280 + i * 4, h -> { shot(h, String.format("car_exit_%03d", idx)); System.out.println(String.format("[Scenario] exit frame %d: progress %.2f door %.2f edge %.2f", idx, h.raid().raid.vehicles.phaseProgress(), h.raid().raid.vehicles.doorOpen(), h.raid().raid.vehicles.cars.get(0).visual.doorEdgeX())); }); }
        raid(396, h -> sheet("car_exit", 7, 250, 150, 1100, 650, 0.26f));
    }

    private static final java.util.List<Object[]> ROOMS = new java.util.ArrayList<>();

    /**
     * The interior survey (instructions.md rule 10): one room of every kind in every kind of building, photographed
     * from a corner at eye height looking across it, by day. ABS_ROOMS limits how many (default 60); ABS_ROOM_FILTER
     * keeps only rooms whose "archetype/type" contains the text. Each picture is named for what it shows.
     */
    private static void interiors() {
        profile(null);
        final int max = System.getenv("ABS_ROOMS") != null ? Integer.parseInt(System.getenv("ABS_ROOMS")) : 60;
        final String filter = System.getenv("ABS_ROOM_FILTER");
        raid(20, h -> {
            Raid r = h.raid().raid;
            r.god = true; r.populate = false; r.freezeAI = true;
            r.actors.removeIf(a -> !a.isPlayer);
            java.util.Set<String> seen = new java.util.LinkedHashSet<>();
            for (absentialis.world.MapData.Building b : r.world.map.buildings) for (absentialis.world.MapData.Room rm : b.rooms) {
                String key = (b.landmark.isEmpty() ? b.archetype : b.landmark) + "/" + rm.type;
                if (rm.circulation && !key.contains("hall") || (rm.x1 - rm.x0) < 2 || (rm.z1 - rm.z0) < 2) continue;
                if (filter != null) { boolean hit = false; for (String part : filter.split(",")) hit |= key.endsWith(part) || key.contains(part + "/"); if (!hit) continue; }
                if (!seen.add(System.getenv("ABS_ROOM_ONE") != null ? rm.type : key) || ROOMS.size() >= max) continue;
                ROOMS.add(new Object[]{key.replace('/', '_').replace(' ', '_'), rm, b});
            }
            System.out.println("[Scenario] interiors: " + ROOMS.size() + " rooms of " + seen.size() + " kinds");
        });
        for (int k = 0; k < max; k++) {
            final int n = k;
            raid(30 + k * 170, h -> {
                if (n >= ROOMS.size()) return;
                Raid r = h.raid().raid;
                absentialis.world.MapData.Room rm = (absentialis.world.MapData.Room) ROOMS.get(n)[1];
                // stand in the free corner cell furthest from the middle that has room to stand, and look at the middle
                float cx = (rm.x0 + rm.x1 + 1) / 2f, cz = (rm.z0 + rm.z1 + 1) / 2f, bx = cx, bz = cz, bd = -1;
                for (int x = rm.x0; x <= rm.x1; x++) for (int z = rm.z0; z <= rm.z1; z++) {
                    if (r.world.solid(x, rm.y + 1, z) || r.world.solid(x, rm.y + 2, z) || !r.world.solid(x, rm.y, z)) continue;
                    float d = (x + 0.5f - cx) * (x + 0.5f - cx) + (z + 0.5f - cz) * (z + 0.5f - cz);
                    if (d > bd) { bd = d; bx = x + 0.5f; bz = z + 0.5f; }
                }
                place(r, bx, rm.y + 1, bz, (float) Math.atan2(-(cx - bx), -(cz - bz)), -0.18f);
                h.raid().thirdPerson = false;
            });
            raid(30 + k * 170 + 164, h -> { if (n < ROOMS.size()) shot(h, String.format("room_%02d_%s", n, ROOMS.get(n)[0])); });
        }
    }

    /** The devmap, loaded the way a developer loads it (the console), and looked at from each of its four parts. */
    private static void devmap() {
        profile(null);
        for (int f = 8; f < 3000; f += 30) hideout(f, h -> { if (absentialis.world.gen.DevMap.mansion == null && h.worldReady()) h.console("devmap 0"); });
        raid(60, h -> { Raid r = h.raid().raid; r.god = true; place(r, absentialis.world.gen.DevMap.ROAD_X0 + 4, g(), (absentialis.world.gen.DevMap.ROAD_Z0 + absentialis.world.gen.DevMap.ROAD_Z1) / 2f + 0.5f, -1.5708f, -0.03f); });
        raid(150, h -> shot(h, "dev_00_road"));
        raid(152, h -> place(h.raid().raid, absentialis.world.gen.DevMap.mazeInX + 1, g(), absentialis.world.gen.DevMap.mazeInZ - 7, 3.1416f, -0.02f));
        raid(240, h -> shot(h, "dev_01_maze"));
        raid(242, h -> place(h.raid().raid, absentialis.world.gen.DevMap.mansion.entryX + 0.5f, g(), absentialis.world.gen.DevMap.mansion.entryZ - 9, 3.1416f, 0.12f));
        raid(330, h -> shot(h, "dev_02_mansion"));
        raid(332, h -> place(h.raid().raid, absentialis.world.gen.DevMap.YARD_X + 2, g(), absentialis.world.gen.DevMap.YARD_Z + 12, -1.35f, -0.05f));
        raid(420, h -> shot(h, "dev_03_yard"));
        raid(422, h -> place(h.raid().raid, absentialis.world.gen.DevMap.holesX + 8, g(), absentialis.world.gen.DevMap.holesZ + 7, 0f, 0.15f));
        raid(510, h -> shot(h, "dev_04_openings"));
    }

    /**
     * 0.8, Developer Mode on the devmap: the status bar and the inspector over a Gladiator and a Butcher that do not
     * know the camera is there, then the workbench open on each of its pages - and a laser, a stance icon and the
     * third-person reticle while the survivor is still a survivor.
     */
    private static void devmode() {
        profile(p -> { p.prog.addXp(absentialis.gameplay.progression.Progression.xpToReach(12)); });
        for (int f = 8; f < 3000; f += 30) hideout(f, h -> { if (absentialis.world.gen.DevMap.mansion == null && h.worldReady()) h.console("devmap 0"); });
        float rx = absentialis.world.gen.DevMap.ROAD_X0 + 6, rz = (absentialis.world.gen.DevMap.ROAD_Z0 + absentialis.world.gen.DevMap.ROAD_Z1) / 2f + 0.5f;
        raid(60, h -> { Raid r = h.raid().raid; r.god = true; place(r, rx, g(), rz, -1.5708f, -0.03f); var rifle = new absentialis.gameplay.items.ItemInstance("weapon.akr"); rifle.rounds = rifle.capacity(); rifle.ammoId = "ammo.assault"; absentialis.gameplay.inventory.InventoryService.equip(rifle, h.ctx().profile.loadout, "primary"); });
        raid(70, h -> h.raid().scenarioHold("primary"));
        // the survivor first: third person, aiming, with and without a laser
        raid(90, h -> { h.raid().thirdPerson = true; h.raid().scenarioAim = true; });
        raid(150, h -> shot(h, "devui_00_thirdperson_reticle"));
        raid(152, h -> { var gun = h.ctx().profile.loadout.slot("primary"); if (gun != null) absentialis.gameplay.weapons.Gunsmith.install(gun, "att.laser.5mw"); h.raid().raid.profile.zone.hour = 22; });
        raid(230, h -> shot(h, "devui_01_green_laser_night"));
        raid(232, h -> { h.raid().thirdPerson = false; });
        raid(290, h -> shot(h, "devui_02_laser_first_person"));
        raid(292, h -> { h.raid().scenarioAim = false; h.raid().raid.profile.zone.hour = 13; h.raid().raid.player.crouch = true; });
        raid(310, h -> shot(h, "devui_03_stance_icon"));
        raid(312, h -> { h.raid().raid.player.crouch = false; h.console("devmode"); });
        raid(330, h -> { Raid r = h.raid().raid; r.player.x = rx; r.player.z = rz; r.player.y = g() + 3.2f; r.player.yaw = -1.5708f; r.player.pitch = -0.32f; h.raid().dev.aimNow(); h.raid().dev.count = 1; h.raid().dev.frozen = false; });
        raid(334, h -> { DevMode d = h.raid().dev; d.target[0] = rx + 9; d.target[1] = g(); d.target[2] = rz - 2; d.spawnNpc("gladiator"); d.target[0] = rx + 11; d.target[2] = rz + 2.5f; d.spawnNpc("butcher"); d.target[0] = rx + 7; d.target[2] = rz + 5; d.spawnNpc("raiders"); });
        raid(520, h -> shot(h, "devui_04_ghost_inspector"));
        for (int t = 0; t < 5; t++) { final int tab = t; raid(524 + t * 40, h -> { h.raid().dev.panel = true; h.raid().dev.tab = tab; }); raid(556 + t * 40, h -> shot(h, "devui_1" + tab + "_workbench_" + DevMode.TABS[tab].toLowerCase())); }
        raid(730, h -> { h.raid().dev.panel = false; h.console("devmode"); });
        raid(760, h -> shot(h, "devui_20_back_as_survivor"));
    }

    /**
     * 0.8, Director Mode in the city, end to end: the casting screen on three kinds of actor, into the world as a
     * Gladiator, the interaction menu and its settings, an orbit camera, a four-second recording, the editor with two
     * pieces on its timeline, an export - and out again, with the survivor as they were.
     */
    private static void director() {
        profile(null);
        raid(40, h -> { h.raid().raid.god = true; h.console("directormode"); });
        raid(70, h -> shot(h, "dir_00_casting_survivor"));
        raid(72, h -> { var d = h.raid().director; d.chosen = new absentialis.director.ActorManager.Spec("mercenaries", 2, 4); d.openCastingPreview(); });
        raid(100, h -> shot(h, "dir_01_casting_mercenary"));
        raid(102, h -> { var d = h.raid().director; d.chosen = new absentialis.director.ActorManager.Spec("gladiator", 0, 0); d.persistence.shortlist.clear(); d.persistence.toggle(d.chosen); d.persistence.toggle(new absentialis.director.ActorManager.Spec("raiders", 1, 3)); d.openCastingPreview(); });
        raid(130, h -> shot(h, "dir_02_casting_gladiator"));
        raid(132, h -> { var d = h.raid().director; System.out.println("[Scenario] enter: " + d.session.enterWorld()); d.world.setTime(6); d.world.freeze(true); d.population.setNpc(3); });
        raid(260, h -> shot(h, "dir_03_world_as_gladiator"));
        raid(262, h -> h.raid().director.openMenu());
        raid(290, h -> shot(h, "dir_04_interaction_menu"));
        raid(292, h -> { var d = h.raid().director; d.gui.close(); d.camera.setMode(absentialis.director.StageManagers.CameraManager.ORBIT); System.out.println("[Scenario] record: " + d.recording.start()); });
        raid(400, h -> shot(h, "dir_05_orbit_recording"));
        raid(560, h -> { var d = h.raid().director; System.out.println("[Scenario] clip: " + d.recording.stop() + " - " + d.recording.status); d.camera.setMode(absentialis.director.StageManagers.CameraManager.GAMEPLAY); });
        raid(580, h -> { var d = h.raid().director; d.session.toEditor(); var clips = absentialis.director.RecordingManager.clips(); System.out.println("[Scenario] clips on disk: " + clips.size());
            if (!clips.isEmpty()) { var a = d.editor.add(clips.get(0)); a.out = Math.min(a.out, 2.5f); var b = d.editor.add(clips.get(0)); b.in = Math.min(1f, b.out * 0.3f); b.effect = 2; b.transition = 1; b.zoom = 1.5f; b.panX = 0.3f; b.speed = 0.5f; } });
        raid(640, h -> shot(h, "dir_06_editor"));
        raid(642, h -> h.raid().director.editor.export());
        for (int f = 660; f < 5200; f += 20) raid(f, h -> { var e = h.raid().director.editor; if (!e.exported.isEmpty() && !exportLogged) { exportLogged = true; java.io.File out = new java.io.File(e.exported); System.out.println("[Scenario] exported " + out.getName() + " " + out.length() + " bytes - " + e.status); } });
        raid(5200, h -> shot(h, "dir_07_editor_exported"));
        raid(5202, h -> { var d = h.raid().director; d.editor.closeRequested = true; });
        raid(5260, h -> { var d = h.raid().director; System.out.println("[Scenario] end: " + d.toggle()); });
        raid(5320, h -> { Raid r = h.raid().raid; shot(h, "dir_08_back_as_survivor"); System.out.println("[Scenario] restored: kind '" + r.playerKind + "' unwanted " + r.unwanted + " hp " + r.player.hp + "/" + r.player.maxHp + " saves suspended " + absentialis.persistence.SaveSystem.suspended + " look override " + (h.raid().lookOverride != null) + " cam " + (h.raid().camOverride != null)); });
    }
    private static boolean exportLogged;

    /** 0.8: the eighteen new pieces of equipment worn, three to a row - helmet, armour, pack of one rarity on each of six people. */
    private static void gear() {
        profile(null);
        for (int f = 8; f < 3000; f += 30) hideout(f, h -> { if (absentialis.world.gen.DevMap.mansion == null && h.worldReady()) h.console("devmap 0"); });
        float rx = absentialis.world.gen.DevMap.ROAD_X0 + 6, rz = (absentialis.world.gen.DevMap.ROAD_Z0 + absentialis.world.gen.DevMap.ROAD_Z1) / 2f + 0.5f;
        String[][] sets = {{"helmet.hardhat", "armor.scavenged", "bag.school"}, {"helmet.moto", "armor.rider", "bag.hiking"}, {"helmet.tactical", "armor.tactical_rig", "bag.tactical"},
                {"helmet.ballistic", "armor.full_ballistic", "bag.ballistic"}, {"helmet.sealed", "armor.advanced_suit", "bag.advanced"}, {"helmet.smart", "armor.powered", "bag.warbag"}};
        raid(60, h -> {
            Raid r = h.raid().raid;
            r.god = true; r.freezeAI = true;
            place(r, rx, g(), rz, -1.5708f, -0.05f);
            for (int i = 0; i < sets.length; i++) {
                absentialis.entity.Actor a = r.debugSpawn("survivors", rx + 5.5f, rz - 3.75f + i * 1.5f, g());
                a.hostileToPlayer = false; a.weapon = null; a.yaw = 1.5708f + (i < 3 ? 0 : 0);
                a.wornHead = sets[i][0]; a.wornArmor = sets[i][1]; a.wornPack = sets[i][2]; a.look = "gear08:" + i;
                posed[i] = a;
            }
        });
        raid(200, h -> shot(h, "gear_00_front"));
        raid(202, h -> { for (int i = 0; i < 6; i++) if (posed[i] != null) posed[i].yaw = -1.5708f; });
        raid(300, h -> shot(h, "gear_01_back"));
        raid(302, h -> { Raid r = h.raid().raid; place(r, rx + 3.2f, g(), rz - 3.2f, -1.5708f, -0.05f); for (int i = 0; i < 6; i++) if (posed[i] != null) posed[i].yaw = 1.5708f; });
        raid(400, h -> shot(h, "gear_02_close_left"));
        raid(402, h -> { Raid r = h.raid().raid; place(r, rx + 3.2f, g(), rz + 1.4f, -1.5708f, -0.05f); });
        raid(500, h -> shot(h, "gear_03_close_right"));
    }

    private static final absentialis.entity.Actor[] posed = new absentialis.entity.Actor[8];

    /**
     * 0.8, the poses nobody had looked at from outside: a row of people side-on to the camera on a bare floor - standing,
     * crouched, prone with a rifle, prone with nothing, down wounded - and then the same row from the front. A line is
     * drawn at floor level: nothing of anybody should be under it.
     */
    private static void poses() {
        profile(null);
        raid(20, h -> {
            Raid r = h.raid().raid;
            r.god = true; r.populate = false; r.freezeAI = true;
            r.actors.removeIf(a -> !a.isPlayer);
            absentialis.world.World w = r.world;
            gx = (int) r.player.x; gy = Math.round(r.player.y); gz = (int) r.player.z;
            for (int dx = -12; dx <= 12; dx++) for (int dz = -14; dz <= 4; dz++) { for (int dy = 0; dy <= 5; dy++) w.set(gx + dx, gy + dy, gz + dz, absentialis.world.Block.AIR); w.set(gx + dx, gy - 1, gz + dz, absentialis.world.Block.CONCRETE); }
            String[] who = {"military", "military", "military", "survivors", "military", "raiders"};
            for (int i = 0; i < who.length; i++) {
                absentialis.entity.Actor a = r.debugSpawn(who[i], gx - 6.25f + i * 2.5f + 0.5f, gz - 5 + 0.5f, gy);
                a.yaw = (float) -Math.PI / 2; a.hostileToPlayer = false; a.homeX = a.x; a.homeZ = a.z;      // facing +x: side-on to the camera
                posed[i] = a;
            }
            posed[1].crouch = true;
            posed[2].prone = true;
            posed[3].prone = true; posed[3].weapon = null;
            posed[4].vital = absentialis.entity.Vital.DOWNED; posed[4].bleedLeft = 9999;
            posed[5].prone = true; posed[5].yaw = (float) Math.PI;                                          // prone, feet to the camera... then head to it
            h.raid().thirdPerson = false;
            place(r, gx + 1.0f, gy, gz + 3.5f, 0, -0.10f);
        });
        raid(60, h -> { for (absentialis.entity.Actor a : posed) if (a != null) { a.vx = a.vz = 0; } });
        raid(170, h -> shot(h, "poses_00_side"));
        raid(172, h -> place(h.raid().raid, gx + 1.5f, gy, gz - 0.5f, 0, -0.22f));
        raid(260, h -> shot(h, "poses_01_prone_close"));
        raid(262, h -> place(h.raid().raid, gx + 12.5f, gy, gz - 4.5f, (float) Math.PI / 2, -0.12f));
        raid(350, h -> shot(h, "poses_02_from_the_end"));
    }

    private static int gx, gy, gz;

    /**
     * 0.8, "glass textures freak out when looking at glass through glass": three rows of different glass one behind the
     * other, straddling a chunk seam, in front of a plain wall - looked through from in front, walked past sideways (the
     * order the panes are drawn in changes as the camera crosses the seam) and looked along at a slant.
     */
    private static void glass() {
        profile(null);
        raid(20, h -> {
            Raid r = h.raid().raid;
            r.god = true; r.populate = false; r.freezeAI = true;
            r.actors.removeIf(a -> !a.isPlayer);
            absentialis.world.World w = r.world;
            gx = Math.round(r.player.x / 16f) * 16; gy = Math.round(r.player.y); gz = (int) r.player.z;
            for (int dx = -9; dx <= 9; dx++) for (int dz = -15; dz <= 3; dz++) { for (int dy = 0; dy <= 5; dy++) w.set(gx + dx, gy + dy, gz + dz, absentialis.world.Block.AIR); w.set(gx + dx, gy - 1, gz + dz, absentialis.world.Block.CONCRETE); }
            int[] kinds = {absentialis.world.Block.GLASS, absentialis.world.Block.GLASS_DIRTY, absentialis.world.Block.GLASS_CRACKED};
            for (int k = 0; k < 3; k++) for (int dx = -6; dx <= 6; dx++) for (int dy = 0; dy <= 3; dy++) w.set(gx + dx, gy + dy, gz - 4 - k * 3, kinds[k]);
            for (int dx = -9; dx <= 9; dx++) for (int dy = 0; dy <= 5; dy++) w.set(gx + dx, gy + dy, gz - 14, (dx + dy & 1) == 0 ? absentialis.world.Block.CONCRETE : absentialis.world.Block.SANDBAG);
            h.raid().thirdPerson = false;
            place(r, gx + 0.5f, gy, gz + 0.5f, 0, 0.02f);
        });
        raid(200, h -> shot(h, "glass_00_front"));
        for (int i = 0; i < 12; i++) { final int k = i; raid(204 + i * 6, h -> place(h.raid().raid, gx - 5.5f + k * 1.0f, gy, gz + 0.5f, 0.35f - k * 0.06f, 0.02f)); raid(208 + i * 6, h -> shot(h, String.format("glass_walk_%03d", k))); }
        raid(280, h -> sheet("glass_walk", 4, 300, 150, 1000, 600, 0.4f));
        raid(284, h -> place(h.raid().raid, gx - 7.5f, gy, gz - 2.5f, -1.15f, 0.0f));
        raid(380, h -> shot(h, "glass_01_slant"));
    }

    /** Every tab of the hideout, the shop departments and the deployment briefing. */
    private static void menus() {
        keepUnaligned = true;
        profile(p -> { p.scrip = 90000; p.prog.addXp(absentialis.gameplay.progression.Progression.xpToReach(9)); });
        hideout(5, h -> shot(h, "menu_00_allegiance"));
        hideout(7, h -> { absentialis.gameplay.Alliance.choose(h.ctx().profile, "survivors"); h.hideout().enter(); });
        int f = 12;
        for (int t = 0; t < HideoutScreen.TABS.length; t++) {
            final int tab = t;
            hideout(f, h -> h.hideout().tab = tab);
            hideout(f + 10, h -> shot(h, "menu_1" + tab + "_" + HideoutScreen.TABS[tab].toLowerCase()));
            f += 12;
        }
        for (int d = 0; d <= ShopPanel.RECRUITS; d++) {
            final int dept = d;
            hideout(f, h -> h.hideout().debugShow(dept, false));
            hideout(f + 10, h -> shot(h, "menu_2" + dept + "_shop"));
            f += 12;
        }
        hideout(f, h -> h.hideout().debugShow(-1, true));
        hideout(f + 10, h -> shot(h, "menu_30_briefing"));
        hideout(f + 12, h -> { h.hideout().debugShow(-1, false); h.hideout().unlocks.show(1, 9); });
        hideout(f + 70, h -> shot(h, "menu_31_unlocked"));
        hideout(f + 72, h -> h.hideout().unlocks.dismiss());
    }
}
