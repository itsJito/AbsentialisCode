package absentialis.ui;

import static org.lwjgl.glfw.GLFW.*;

import absentialis.gameplay.inventory.Container;
import absentialis.gameplay.inventory.InventoryService;
import absentialis.gameplay.inventory.Loadout;
import absentialis.gameplay.items.Content;
import absentialis.gameplay.items.ItemDef;
import absentialis.gameplay.items.ItemInstance;
import absentialis.gameplay.weapons.Gunsmith;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;

/**
 * Shared inventory interaction layer for stash, case, loot containers and gear slots (addendum
 * P1 Inventory): drag & drop with a legal-placement preview (green fits, amber combines, red
 * rejects), R rotates while dragging, shift+click quick-transfers, right-click opens actions,
 * hover shows a spinning voxel inspect with stats, holding F opens the full inspect. Every
 * mutation goes through {@link InventoryService}, so the UI can never overlap or duplicate items.
 */
public final class InventoryUi {
    public final Ui ui;
    public final ItemIcons icons;
    public ItemInstance drag, hover, inspected, menuItem;
    public boolean dragRot;
    private int grabCX, grabCY;
    private float pressX, pressY;
    private boolean pressed;
    private ItemInstance pressItem;
    public float hoverTime, spin;
    public String flash = "";
    public float flashTime;
    public int flashColor = Ui.TXT;
    public float cell = 40;
    /**
     * 0.7: something that has just arrived (bought, given, crafted). Whichever screen shows the container it is in
     * brings it into view and rings it for a few seconds, so a new item can never land where it is not seen.
     */
    public ItemInstance arrived;
    public float arrivedT;
    public void arrive(ItemInstance it) { arrived = it; arrivedT = 5f; }
    public final List<String[]> menu = new ArrayList<>(); // {label, action}
    private float menuX, menuY;
    public BiConsumer<ItemInstance, String> onAction; // context actions: use, unload, split, equip, drop, sell, read, clean
    public Container quickA, quickB;   // shift+click pairs (left grid <-> right grid)
    public Loadout owner;              // the player's loadout (case side)
    public boolean allowDrop;
    public List<String> extraActions = new ArrayList<>();

    public InventoryUi(Ui ui, ItemIcons icons) { this.ui = ui; this.icons = icons; }

    public void begin(float baseCell) {
        cell = snap(baseCell * ui.scale);
        hover = null;
        if (drag != null && ui.in.keyPressed(GLFW_KEY_R)) { dragRot = !dragRot; ui.in.consume(GLFW_KEY_R); if (ui.sound != null) ui.sound.accept("ui_rotate"); }
        spin += ui.dt * 1.4f;
        flashTime -= ui.dt;
    }

    /** Cell sizes are whole multiples of the 16px icon art (24 allowed as the smallest step). */
    public static float snap(float px) { return px >= 32 ? (float) Math.floor(px / 16) * 16 : 24; }

    /** Shrinks the cell so 'rows' grid rows fit into 'avail' pixels. */
    public void fit(float avail, int rows) { cell = Math.min(cell, snap(avail / Math.max(1, rows))); }

    public void say(String s, int col) { flash = s; flashColor = col; flashTime = 2.8f; }

    private void result(InventoryService.Result r) {
        if (!r.ok() && !r.msg().isEmpty()) say(r.msg(), Ui.RED);
        if (ui.sound != null) ui.sound.accept(r.ok() ? "ui_drop" : "ui_invalid");
    }

    // ------------------------------------------------------------------ grid
    public void grid(Container c, float x, float y, String title) {
        float cs = cell;
        float w = c.w * cs, h = c.h * cs;
        if (title != null) {
            ui.text(title.toUpperCase(), x, y - ui.s(24), 15, Ui.TXT_HI);
            ui.textR(String.format("%.1f kg", c.mass()), x + w, y - ui.s(24), 13, Ui.TXT_DIM);
        }
        ui.nine("slot", x - ui.s(4), y - ui.s(4), w + ui.s(8), h + ui.s(8), 0xFFFFFFFF);
        ui.b.rect(x, y, w, h, 0xFF101211);
        for (int gx = 0; gx <= c.w; gx++) ui.b.rect(x + gx * cs, y, 1, h, 0xFF262A27);
        for (int gy = 0; gy <= c.h; gy++) ui.b.rect(x, y + gy * cs, w, 1, 0xFF262A27);
        boolean inside = ui.hover(x, y, w, h);
        int hx = (int) Math.floor((ui.mx - x) / cs), hy = (int) Math.floor((ui.my - y) / cs);
        // placement preview
        if (drag != null && inside) {
            int iw = dragRot ? drag.baseH() : drag.baseW(), ih = dragRot ? drag.baseW() : drag.baseH();
            int px = hx - (dragRot ? grabCY : grabCX), py = hy - (dragRot ? grabCX : grabCY);
            ItemInstance under = c.at(hx, hy);
            boolean combine = under != null && under != drag && canCombine(drag, under);
            boolean fits = c.fits(px, py, iw, ih, drag);
            int col = combine ? 0x70E2A034 : fits ? 0x5060C060 : 0x60D04030;
            if (combine) ui.b.rect(x + under.x * cs, y + under.y * cs, under.w() * cs, under.h() * cs, col);
            else ui.b.rect(x + Math.max(0, px) * cs, y + Math.max(0, py) * cs, Math.min(iw, c.w - Math.max(0, px)) * cs, Math.min(ih, c.h - Math.max(0, py)) * cs, col);
            if (ui.in.mouseReleased(GLFW_MOUSE_BUTTON_LEFT)) {
                InventoryService.Result r = combine ? InventoryService.combine(drag, under) : InventoryService.move(drag, c, px, py, dragRot);
                result(r);
                drag = null;
            }
        }
        for (ItemInstance it : new ArrayList<>(c.items)) {
            float ix = x + it.x * cs, iy = y + it.y * cs, iw = it.w() * cs, ih = it.h() * cs;
            boolean hov = drag == null && ui.hover(ix, iy, iw, ih);
            itemTile(it, ix, iy, iw, ih, hov, it == drag);
            if (it == arrived && arrivedT > 0) {
                float k = 0.5f + 0.5f * (float) Math.sin(arrivedT * 7), a = Math.min(1, arrivedT);
                ui.b.outline(ix + 1, iy + 1, iw - 1, ih - 1, 2, Ui.alpha(0xFF7DBA5C, a * (0.55f + 0.45f * k)));
                ui.text("NEW", ix + ui.s(4), iy + ui.s(2), 10, Ui.alpha(0xFF7DBA5C, a));
            }
            if (hov) {
                hover = it;
                if (ui.click && !ui.consumed) {
                    ui.consumed = true;
                    if (ui.shift) quickTransfer(it, c);
                    else { pressed = true; pressItem = it; pressX = ui.mx; pressY = ui.my; grabCX = (int) ((ui.mx - ix) / cs); grabCY = (int) ((ui.my - iy) / cs); if (it.rotated) { int t = grabCX; grabCX = grabCY; grabCY = t; } }
                }
                if (ui.rclick) openMenu(it);
            }
        }
    }

    private void quickTransfer(ItemInstance it, Container from) {
        // anything of the player's goes to the other side; anything else comes to the player
        boolean mine = owner != null && (from == owner.caseGrid || from == owner.packGrid());
        Container other = quickA != null && quickA != from && (owner == null || quickA != owner.caseGrid) ? quickA : quickB != null && quickB != from && (owner == null || quickB != owner.caseGrid) ? quickB : null;
        Container to = mine ? other : owner != null ? owner.caseGrid : from == quickA ? quickB : quickA;
        if (to == null || to == from) {
            // 0.7: with nothing else open, shift-click on something that can be worn or carried in the hands puts it on
            if (mine && quickEquip(it)) return;
            say(mine ? "Nothing open to send it to" : "Nowhere to send it", Ui.TXT_DIM);
            return;
        }
        InventoryService.Result r = InventoryService.quickTransfer(it, to, owner != null && owner.caseGrid == to ? owner : null);
        if (!r.ok() && !mine) say("No room in your case for " + it.name(), Ui.RED);
        result(r);
    }

    /** Times shift-click has equipped something (gates). */
    public int quickEquips;

    /**
     * Equips an item from the case by the quickest route: its own slot if that is free, the other slot of the same
     * kind if there is one (a second long gun, another charm), and otherwise it changes places with what is there.
     * False when the thing is not something that is equipped, or there is no room to put the old one down.
     */
    public boolean quickEquip(ItemInstance it) {
        if (owner == null || it.def().slot == null || it.container == null) return false;
        String slot = it.def().slot;
        java.util.List<String> tries = new java.util.ArrayList<>();
        tries.add(slot);
        if (slot.startsWith("charm")) for (int k = 0; k < absentialis.gameplay.inventory.Loadout.CHARM_SLOTS; k++) if (!tries.contains("charm" + k)) tries.add("charm" + k);
        for (String s : tries) {
            if (owner.slot(s) != null) continue;
            InventoryService.Result r = InventoryService.equip(it, owner, s);
            if (r.ok()) { quickEquips++; say("Equipped " + it.name(), Ui.GREEN); return true; }
        }
        // every slot it could go in is taken: the one in its own slot comes off into the case, and this goes on
        ItemInstance old = owner.slot(slot);
        Container home = it.container;
        if (old == null || !InventoryService.unequip(old, home).ok()) { say("No room to take off " + (old == null ? "what is there" : old.name()), Ui.RED); return true; }
        InventoryService.Result r = InventoryService.equip(it, owner, slot);
        if (!r.ok()) { InventoryService.equip(old, owner, slot); result(r); return true; }
        quickEquips++;
        say("Equipped " + it.name() + " (took off " + old.name() + ")", Ui.GREEN);
        return true;
    }

    public static boolean canCombine(ItemInstance a, ItemInstance b) {
        ItemDef s = a.def(), d = b.def();
        if (s.stackable() && a.defId.equals(b.defId) && b.qty < d.maxStack) return true;
        if (InventoryService.herbMix(a.defId, b.defId) != null) return true;
        if (s.ammo != null && (d.magazine != null && d.magazine.caliber.equals(s.ammo.caliber) || d.weapon != null && d.weapon.internal() && s.ammo.caliber.equals(d.weapon.caliber))) return true;
        if (s.magazine != null && d.weapon != null && !d.weapon.internal() && s.magazine.magType.equals(d.weapon.magType)) return true;
        return s.attachment != null && d.weapon != null && Gunsmith.incompatibility(b, a) == null;
    }

    /** Item tile: icon, quantity / rounds badge and condition strip. */
    public void itemTile(ItemInstance it, float x, float y, float w, float h, boolean hov, boolean ghosted) {
        ItemDef d = it.def();
        int bg = switch (d.category) {
            case "weapon" -> 0xFF2A2420; case "ammo", "magazine" -> 0xFF2A281C; case "medical" -> 0xFF2C1C1C; case "food" -> 0xFF22281C;
            case "valuable", "treasure" -> 0xFF2E2A18; case "quest", "key" -> 0xFF1C2430; case "attachment" -> 0xFF242628; default -> 0xFF1E2220;
        };
        ui.b.rect(x + 1, y + 1, w - 1, h - 1, ghosted ? 0x40000000 | (bg & 0xFFFFFF) : bg);
        // loot tier: a coloured edge (white common ... yellow mythic)
        if (d.tier > 0 || "weapon".equals(d.category)) ui.b.rect(x + 1, y + 1, Math.max(2, ui.s(3)), h - 1, Ui.alpha(d.tierColor(), ghosted ? 0.3f : 0.9f));
        if (hov) ui.b.outline(x + 1, y + 1, w - 1, h - 1, 2, 0xFFE2A034);
        icons.draw(ui.b, it, x + 3, y + 3, w - 5, h - 5, ghosted ? 0x60FFFFFF : 0xFFFFFFFF);
        float fs = 12;
        if (d.stackable() && it.qty > 1) ui.textR(String.valueOf(it.qty), x + w - ui.s(4), y + h - ui.s(16), fs, Ui.TXT_HI);
        if (d.magazine != null || d.weapon != null && !d.weapon.melee()) {
            String s = d.weapon != null ? it.loadedRounds() + (it.chambered ? "+" : "") : it.rounds + "/" + it.capacity();
            ui.textR(s, x + w - ui.s(4), y + h - ui.s(16), fs, it.loadedRounds() == 0 && d.weapon != null || d.magazine != null && it.rounds == 0 ? Ui.RED : Ui.TXT_HI);
        }
        if (d.weapon != null && !d.weapon.melee()) {
            float c = it.condition() / 100f;
            ui.b.rect(x + 3, y + h - 5, (w - 6) * c, 3, c < 0.25f ? 0xFFD8483A : c < 0.5f ? 0xFFE2A034 : 0xFF7DBA5C);
            if (it.jammed) ui.text("JAM", x + ui.s(4), y + ui.s(3), 11, Ui.RED);
        }
        if (it.foundInRaid) ui.b.rect(x + w - 6, y + 3, 3, 3, 0xFFE2A034);
        if (it.fallback) ui.text("F", x + ui.s(4), y + ui.s(2), 11, Ui.TXT_DIM);
    }

    // ------------------------------------------------------------------ equipment slots
    public void slot(Loadout l, String slot, float x, float y, float w, float h, Container back) {
        ItemInstance it = slot.startsWith("charm") ? l.charms[slot.charAt(5) - '0'] : l.slots.get(slot);
        boolean hov = ui.hover(x, y, w, h);
        boolean accept = drag != null && (slot.startsWith("charm") ? drag.def().charm != null : slot.equals(drag.def().slot));
        ui.nine(hov && drag != null ? (accept ? "slot_hi" : "slot") : "slot", x, y, w, h, 0xFFFFFFFF);
        if (drag != null && hov) ui.b.rect(x + 3, y + 3, w - 6, h - 6, accept ? 0x4060C060 : 0x40D04030);
        if (it == null) ui.textC(slot.startsWith("charm") ? "CHARM" : slot.toUpperCase(), x + w / 2, y + h / 2 - ui.s(7), 11, 0xFF5A5C56);
        else {
            boolean ih = drag == null && hov;
            itemTile(it, x + 2, y + 2, w - 4, h - 4, ih, false);
            if (ih) {
                hover = it;
                if (ui.click && !ui.consumed) { ui.consumed = true; if (ui.shift && back != null) result(InventoryService.unequip(it, back)); else { pressed = true; pressItem = it; pressX = ui.mx; pressY = ui.my; grabCX = grabCY = 0; } }
                if (ui.rclick) openMenu(it);
            }
        }
        if (drag != null && hov && ui.in.mouseReleased(GLFW_MOUSE_BUTTON_LEFT)) {
            if (it != null && drag.def().magazine != null || it != null && drag.def().attachment != null || it != null && drag.def().ammo != null) result(InventoryService.combine(drag, it));
            else result(InventoryService.equip(drag, l, slot));
            drag = null;
        }
    }

    /** Space-free pouch list (treasures / keys / craft / documents). */
    public void pouch(List<ItemInstance> list, float x, float y, float w, float h, String empty) {
        ui.nine("slot", x, y, w, h, 0xFFFFFFFF);
        float tile = cell * 1.25f, pad = ui.s(6);
        int cols = Math.max(1, (int) ((w - pad) / (tile + pad)));
        if (list.isEmpty()) ui.textC(empty, x + w / 2, y + h / 2 - ui.s(8), 13, Ui.TXT_DIM);
        for (int i = 0; i < list.size(); i++) {
            ItemInstance it = list.get(i);
            float tx = x + pad + (i % cols) * (tile + pad), ty = y + pad + (i / cols) * (tile + pad);
            if (ty + tile > y + h) break;
            boolean hov = drag == null && ui.hover(tx, ty, tile, tile);
            itemTile(it, tx, ty, tile, tile, hov, false);
            if (hov) { hover = it; if (ui.rclick) openMenu(it); if (ui.click && ui.shift && quickA != null && !ui.consumed) { ui.consumed = true; result(InventoryService.add(it, quickA)); } }
        }
    }

    // ------------------------------------------------------------------ context menu
    private void openMenu(ItemInstance it) {
        ui.consumed = true;
        menu.clear();
        if (ui.sound != null) ui.sound.accept("inv_menu");
        menuItem = it;
        menuX = ui.mx; menuY = ui.my;
        ItemDef d = it.def();
        if (d.medical != null || d.food != null) menu.add(new String[]{"Use", "use"});
        if ("document".equals(d.category)) menu.add(new String[]{"Read", "read"});
        if (d.slot != null && it.slot == null) menu.add(new String[]{"Equip", "equip"});
        if (d.charm != null && it.slot == null) menu.add(new String[]{"Equip charm", "equip"});
        if (d.magazine != null && it.rounds > 0 || d.weapon != null && d.weapon.internal() && it.rounds > 0) menu.add(new String[]{"Unload rounds", "unload"});
        if (d.weapon != null && it.mag != null) menu.add(new String[]{"Remove magazine", "removemag"});
        if (d.weapon != null && !d.weapon.melee() && !it.attachments.isEmpty()) menu.add(new String[]{"Strip parts", "strip"});
        if (d.stackable() && it.qty > 1) menu.add(new String[]{"Split half", "split"});
        if (d.weapon != null && it.jammed) menu.add(new String[]{"Clear jam", "clearjam"});
        for (String a : extraActions) menu.add(new String[]{a.substring(0, 1).toUpperCase() + a.substring(1), a});
        if (allowDrop && it.slot == null && it.parent == null) menu.add(new String[]{"Drop", "drop"});
        menu.add(new String[]{"Inspect", "inspect"});
    }

    // ------------------------------------------------------------------ frame end
    /** Draws drag ghost, context menu, flash text; resolves drag start/cancel. */
    public void end() {
        // start a drag after a small movement threshold
        if (pressed && pressItem != null && (Math.abs(ui.mx - pressX) > 4 || Math.abs(ui.my - pressY) > 4)) { drag = pressItem; dragRot = pressItem.rotated; pressed = false; if (ui.sound != null) ui.sound.accept("inv_lift"); }
        if (ui.in.mouseReleased(GLFW_MOUSE_BUTTON_LEFT)) {
            if (pressed && pressItem != null && drag == null) inspected = pressItem; // click = select for inspect
            pressed = false;
            if (drag != null) { drag = null; if (ui.sound != null) ui.sound.accept("inv_move"); } // released over nothing: cancelled, item never moved
        }
        if (!menu.isEmpty()) drawMenu();
        if (drag != null) {
            int iw = dragRot ? drag.baseH() : drag.baseW(), ih = dragRot ? drag.baseW() : drag.baseH();
            float gx = ui.mx - (dragRot ? grabCY : grabCX) * cell - cell / 2, gy = ui.my - (dragRot ? grabCX : grabCY) * cell - cell / 2;
            ui.shadow(gx, gy, iw * cell, ih * cell, 0x60);
            icons.draw(ui.b, drag, gx, gy, iw * cell, ih * cell, 0xE0FFFFFF);
            ui.text("[R] rotate", gx, gy + ih * cell + ui.s(4), 12, Ui.TXT_DIM);
        }
        if (flashTime > 0) {
            float a = Math.min(1, flashTime);
            float tw = ui.tw(flash, 16);
            ui.b.rect(ui.w / 2f - tw / 2 - ui.s(12), ui.h - ui.s(96), tw + ui.s(24), ui.s(30), Ui.alpha(0xD0101010, a));
            ui.textC(flash, ui.w / 2f, ui.h - ui.s(90), 16, Ui.alpha(flashColor, a));
        }
        if (hover != null) { if (hover != inspected) hoverTime = 0; inspected = hover; hoverTime += ui.dt; }
    }

    private void drawMenu() {
        float w = ui.s(170), lh = ui.s(26), h = menu.size() * lh + ui.s(10);
        float x = Math.min(menuX, ui.w - w - 4), y = Math.min(menuY, ui.h - h - 4);
        ui.shadow(x, y, w, h, 0x80);
        ui.nine("tip", x, y, w, h, 0xFFFFFFFF);
        boolean any = false;
        for (int i = 0; i < menu.size(); i++) {
            float iy = y + ui.s(5) + i * lh;
            boolean hov = ui.hover(x, iy, w, lh);
            if (hov) { ui.b.rect(x + 3, iy, w - 6, lh, 0xFF3A3420); any = true; }
            ui.text(menu.get(i)[0], x + ui.s(12), iy + ui.s(5), 14, hov ? Ui.TXT_HI : Ui.TXT);
            if (hov && ui.click) {
                String act = menu.get(i)[1];
                ItemInstance it = menuItem;
                menu.clear();
                ui.consumed = true;
                if ("inspect".equals(act)) inspected = it;
                else if (onAction != null) onAction.accept(it, act);
                return;
            }
        }
        if ((ui.click || ui.rclick) && !any && !ui.consumed) menu.clear();
        if (ui.in.keyPressed(GLFW_KEY_ESCAPE)) menu.clear();
    }

    // ------------------------------------------------------------------ inspect
    /** Side panel: spinning voxel model + stats of the hovered / selected item. */
    public void inspectPanel(float x, float y, float w, float h) {
        ui.panelDark(x, y, w, h);
        ItemInstance it = inspected;
        if (it == null) { ui.textC("Hover an item to inspect", x + w / 2, y + h / 2, 14, Ui.TXT_DIM); return; }
        ItemDef d = it.def();
        float vs = Math.min(w - ui.s(20), ui.s(170));
        ui.b.rect(x + (w - vs) / 2, y + ui.s(10), vs, vs, 0xFF0C0D0C);
        icons.drawInspect(ui.b, it, x + (w - vs) / 2, y + ui.s(10), vs, spin, 0.45f + 0.1f * (float) Math.sin(spin * 0.7));
        float ty = y + vs + ui.s(18);
        ui.text(d.name, x + ui.s(12), ty, 16, d.tier > 0 ? d.tierColor() : Ui.TXT_HI);
        ty += ui.s(22);
        ui.text(d.tierName() + " " + d.category + "  -  " + it.baseW() + "x" + it.baseH() + "  -  " + String.format("%.2f kg", it.mass()), x + ui.s(12), ty, 12, Ui.TXT_DIM);
        ty += ui.s(20);
        for (String[] s : stats(it)) {
            if (ty > y + h - ui.s(40)) break;
            ui.text(s[0], x + ui.s(12), ty, 13, Ui.TXT);
            if (s.length > 2) {
                float f = Float.parseFloat(s[2]);
                boolean bad = s.length > 3 && "bad".equals(s[3]);
                ui.bar(x + w * 0.45f, ty + ui.s(3), w * 0.5f - ui.s(12), ui.s(10), f, bad ? 0xFFC0402E : 0xFFB0A070);
            } else ui.textR(s[1], x + w - ui.s(12), ty, 13, Ui.AMBER);
            ty += ui.s(19);
        }
        if (!d.desc.isEmpty() && ty < y + h - ui.s(50)) ui.wrap(d.desc, x + ui.s(12), ty + ui.s(6), w - ui.s(24), 12, Ui.TXT_DIM);
        ui.text("Hold [F] full inspect", x + ui.s(12), y + h - ui.s(22), 11, Ui.TXT_DIM);
    }

    /** Hold F: large centred model the mouse can rotate. */
    public void fullInspect(float yaw, float pitch) {
        if (inspected == null) return;
        ui.b.rect(0, 0, ui.w, ui.h, 0xD8080908);
        float s = Math.min(ui.w, ui.h) * 0.7f;
        icons.drawInspect(ui.b, inspected, (ui.w - s) / 2, (ui.h - s) / 2 - ui.s(20), s, yaw, pitch);
        ui.textC(inspected.def().name.toUpperCase(), ui.w / 2f, ui.h - ui.s(90), 22, Ui.TXT_HI);
        ui.textC("Move the mouse to turn  -  release [F] to close", ui.w / 2f, ui.h - ui.s(58), 13, Ui.TXT_DIM);
    }

    public static String cap(String s) { return s == null || s.isEmpty() ? "" : Character.toUpperCase(s.charAt(0)) + s.substring(1); }

    /** Stat rows: {label, text} or {label, text, fraction, bad?}. */
    public static List<String[]> stats(ItemInstance it) {
        List<String[]> l = new ArrayList<>();
        ItemDef d = it.def();
        if (d.weapon != null && !d.weapon.melee()) {
            Gunsmith.Stats s = Gunsmith.stats(it, 0);
            boolean worn = s.conditionBand > 0;
            l.add(new String[]{"Condition", Math.round(it.condition()) + "", String.valueOf(it.condition() / 100f), worn ? "bad" : ""});
            float[] pr = Gunsmith.primary(it);
            for (int k = 0; k < pr.length; k++) l.add(new String[]{Gunsmith.PRIMARY[k], "", String.valueOf(pr[k]), worn && (k == 2 || k == 3) ? "bad" : ""});
            ItemDef am = Content.ammoFor(d.weapon.caliber);
            l.add(new String[]{"Ammunition", am == null ? d.weapon.caliber : am.name});
            l.add(new String[]{"Loaded", it.loadedRounds() + " / " + s.capacity});
            l.add(new String[]{"Fire rate", Math.round(s.rpm) + " rpm"});
            l.add(new String[]{"Attachments", it.attachments.size() + " / " + absentialis.gameplay.weapons.Attachments.MAX_EQUIPPED});
            for (ItemInstance a : it.attachments.values()) l.add(new String[]{"  " + a.def().name, ""});
            if (worn) l.add(new String[]{s.conditionBand == 2 ? "CRITICAL: needs a workbench" : "Worn: clean with gun oil", ""});
        } else if (d.weapon != null) {
            l.add(new String[]{"Damage", String.valueOf((int) d.weapon.meleeDamage)});
            l.add(new String[]{"Reach", d.weapon.meleeRange + " m"});
        }
        if (d.ammo != null) { l.add(new String[]{"Damage", String.valueOf((int) d.ammo.damage)}); l.add(new String[]{"Penetration", String.valueOf((int) d.ammo.pen)}); if (d.ammo.pellets > 1) l.add(new String[]{"Pellets", String.valueOf(d.ammo.pellets)}); }
        if (d.magazine != null) { l.add(new String[]{"Rounds", it.rounds + " / " + it.capacity()}); l.add(new String[]{"Caliber", d.magazine.caliber}); }
        if (d.armor != null && d.armor.armorClass > 0) { l.add(new String[]{"Class", String.valueOf(d.armor.armorClass)}); l.add(new String[]{"Durability", Math.round(it.durability) + " / " + Math.round(it.maxDurability), String.valueOf(it.durability / Math.max(1, it.maxDurability)), ""}); }
        if ("melee.knife".equals(d.id)) l.add(new String[]{"Edge", Math.round(it.durability * 100) + "%", String.valueOf(Math.max(0, it.durability)), it.durability < 0.25f ? "bad" : ""});
        if (d.medical != null) { if (d.medical.heal > 0) l.add(new String[]{"Heals", "+" + (int) d.medical.heal}); if (d.medical.healFrac > 0) l.add(new String[]{"Heals", Math.round(d.medical.healFrac * 100) + "% of health"}); if (d.medical.uses > 1) l.add(new String[]{"Uses", it.uses + " / " + d.medical.uses}); }
        if (d.food != null) { if (d.food.energy != 0) l.add(new String[]{"Energy", String.format("%+d", (int) d.food.energy)}); if (d.food.hydration != 0) l.add(new String[]{"Hydration", String.format("%+d", (int) d.food.hydration)}); }
        if (d.attachment != null) {
            l.add(new String[]{"Slot", absentialis.gameplay.weapons.Attachments.categoryName(d.attachment.socket)});
            for (java.util.Map.Entry<String, Float> e : d.attachment.mods.entrySet()) l.add(new String[]{absentialis.gameplay.weapons.Attachments.statName(e.getKey()), String.format("%+d%%", Math.round(e.getValue()))});
        }
        if (d.armor != null && d.armor.shield > 0) l.add(new String[]{"Protection", Math.round(it.durability) + " / " + Math.round(d.armor.shield), String.valueOf(it.durability / d.armor.shield), ""});
        if (d.charm != null) l.add(new String[]{"Effect", cap(d.charm.effect) + String.format(" %+d%%", Math.round(d.charm.amount * 100))});
        l.add(new String[]{"Value", absentialis.Version.coins(it.baseValueTotal())});
        if (it.origin != null && !it.origin.isEmpty()) l.add(new String[]{"Origin", it.origin});
        return l;
    }
}
