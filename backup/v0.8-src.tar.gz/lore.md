# ABSENTIALIS — Lore & Narrative Guide

**Status:** Working narrative canon / designer-facing creative direction  
**Genre:** Single-player voxel extraction survival horror  
**Creative blend:** *Fallout*'s morally compromised communities; *Silent Hill*'s fog, guilt and uncertainty; *Resident Evil*'s tangible evidence and biological horror; *S.T.A.L.K.E.R.*'s freeform expeditions; *Grand Theft Auto*'s overlapping employers and districts.

> **Absentialis was not forgotten because everyone died. It was declared dead so nobody would have to account for the living.**

This is a **framework, not a screenplay**. Preserve the named mysteries, themes, and relationships; adapt routes, characters, pacing, dialogue, encounters, and implementation to what the playable world does best. Missions give a reason to investigate—not permission for the world to exist.

---

## 1. The city that was pronounced dead

Nine years ago, the fictional city of **Absentialis** suffered a disaster at its power complex. Authorities described a reactor accident, toxic release, and mandatory evacuation. Officials eventually reported that the remaining population was evacuated or dead. The city disappeared from schedules and public records, but its cordon stayed in place.

Those reports were false. Survivors remained. Some were deliberately excluded from evacuation counts. A classified program, **PROJECT VEIL**, operated from Industrial's science laboratory and concealed facilities linked to the power complex. Military and private procurement channels supported biological experimentation on prisoners and unregistered civilians, using experimental neurological agents and material from an anomalous underground seam. Disease, industrial contamination, and stranger phenomena became entangled in public rumor.

As disaster unfolded, officials concealed exposure readings, edited hospital records, halted departures, and diverted hazardous material toward occupied sectors to preserve restricted installations. Cleanup and containment became as much about **keeping the evidence inside** as keeping danger out.

The **VESPER** network—a damaged, semi-automated system of warning signals, gates, power routing, and records—still follows conflicting orders written by humans. It is not a sentient evil behind the accident. Its records make institutional responsibility harder to deny; its occasional inexplicable outputs leave room for horror.

**The historical allegory:** Absentialis reflects Chernobyl through the arrogance of institutions, secrecy about danger, late warnings, sacrificed workers, manipulated records, abandoned families, poisoned geography, and the burden of memory. It is **not** a factual depiction of real radiation effects or of Chernobyl's victims. The human cover-up is real within the fiction; the exact nature of every occurrence in the fog need not be resolved.

### Three layers of understanding

1. **Public lie:** An accident emptied the city. Quarantine protects everyone outside.
2. **Recoverable truth:** People remained and were erased on paper; forced transfers and medical experiments were hidden inside disaster relief.
3. **Late truth:** VEIL, the power plant, the cordon, and continuing concealment were components of the same system. Human decisions turned a catastrophe into a sustained atrocity.

Do not resolve the plot with a miracle cure, a magical shard, or a single villain who explains everything.

---

## 2. The fog and the grammar of horror

The fog is the first antagonist and the last unanswered question. Sometimes it is cold weather; sometimes it carries contamination; sometimes witnesses see or hear things nobody can verify. It shortens sightlines, makes familiar buildings unrecognizable, and distorts confidence without needing to literally create monsters. The game should not constantly tell players which interpretation is true.

**Mood:** an inhabited ruin, not a haunted theme park. Empty ration lines; a lamp lit in a supposedly abandoned home; an airport announcing a flight that never departed; fresh keys inside an officially sealed laboratory. Let long quiet stretches and limited ammunition give weight to sudden violence. Horror comes from realizing a room had a purpose and someone lied about that purpose.

Environmental storytelling should favor ordinary objects—photos, records, torn maps, family icons, dog tags, ration cards, medicine labels, service diagrams, receipts, and recordings—over lore monologues. Recurring sounds can connect places: a distant bell, a broken loudspeaker, the low pulse of machinery underneath the city. Not every uncanny sound requires a canonical explanation.

**Infected:** Zombies are former residents and responders, visually individual rather than faceless fodder. Tanks suggest extreme exposure and failed interventions. Boomers evoke accumulated biological and industrial waste. Spitters imply chemical and laboratory discharge. The **Chainsaw Man** is an apparently human roaming killer associated with cleanup and prison-transfer rumors; his exact identity remains disputed. The **Gladiator** is a blind, clawed giant connected to laboratory experimentation and guided by sound/vibration. These threats should be announced by traces—damage, smells, claw scoring, distant impacts—before the player meets them. Combat is usually optional where narrative progress is concerned.

---

## 3. The player and the first hour

The player creates a character and chooses an **initial allegiance leaning**—Mercenary, Military, Loner, or Bandit. This changes their first contacts and private interpretation of danger. It is **not** permanent membership. They can join, oppose, betray, or help any faction afterward.

They begin in a spare persistent hideout with **one handgun (10 rounds loaded, 10 spare), one first-aid spray, and one knife**. No secret message, heroic assignment, special immunity, or compulsory squadmate. Their immediate goal is unromantic: **find food, water, useful gear, and enough value to leave the city alive**. They prepare and deploy. They may ignore the story entirely until they encounter evidence in a raid.

### Intro — inner monologue

*Black screen. Wind against glass. A machine hums somewhere far away. A bell rings once, perhaps more than once. Reveal the dim hideout without an introductory firefight.*

> They say a town can die.
>
> That one morning its windows go dark, its streets empty, and the names on its doors no longer belong to anyone.
>
> Absentialis died years ago. That's what they say.
>
> But dead places aren't supposed to breathe.
>
> I can hear the wires humming in the walls. Somewhere outside, a bell keeps ringing. There shouldn't be anyone left to ring it.
>
> I don't know how long I can stay. I've got a gun, a knife, and barely enough medicine to matter. I'll need food. Water. Something worth trading. Enough to get out of this town.
>
> Before the fog finds its way inside.

**Allegiance-dependent closing thought** (use one; adjust the shared final line in voice direction so “the fog” does not repeat awkwardly):

- **Mercenary:** “The fog hides more than empty streets. Someone is still paying people to go out there. That means whatever they're collecting is worth dying for. Maybe enough to buy my way out. Maybe not.”
- **Military:** “The fog swallows the checkpoints first. Then the roads. If the men holding the cordon can't see what's coming, they won't ask questions when they shoot. I need supplies before the orders change again.”
- **Loner:** “The fog isn't what kills most people. It's what moves inside it: the infected, the ones that used to be neighbors. And the living aren't much kinder. If I want to leave, I'll have to survive both.”
- **Bandit:** “In the fog, a man can take everything you've got and swear he never saw you. Out here, that's as close to law as anyone gets. I need enough supplies to stop being easy prey.”

**Important:** Only the **Loner** inner voice explicitly names infected monsters and other humans as the danger. Other perspectives fear systems, exploitation, or the unseen. The bell may have a mundane explanation in Residential, but never conclusively certify that it was the bell from the intro.

*Camera settles. Hideout and first deployment become available. No story mission is automatically accepted.*

---

## 4. Factions: four stories about the same catastrophe

Faction identity is about **what a group thinks must be protected**. All can offer useful work and all can cause harm. Their claims should conflict without making every person in the faction identical.

| Group / base | Faces | Public claim / concealed interest | Narrative conflict |
|---|---|---|---|
| **Mercenaries — Halberd Group**, Downtown police HQ | **Elias Mercer**, **Nora Price** *(names provisional pending preferred nationality)* | Protect assets and fulfill contracts; recover VEIL property, records, and saleable discoveries for corporate clients | Loyalty versus compensation |
| **Military — 3rd Cordon Battalion**, Munincipal base | **Col. Sergei Morozov**, **Capt. Irina Belova**, **Pavel Antonov** | Contain infection and enforce permits; suppress evidence, while some officers quietly question evacuation orders | Duty versus conscience |
| **Loners — Saint Agnes Shelter / Residential Families**, Residential | **Olena Kovalenko**, **Dr. Taras Hrytsenko**, **Mykola Shevchenko** | Keep people alive, identify the missing, obtain medicine and clean water | Rescue versus safeguarding limited supplies |
| **Bandits — Kerosene Boys / Rail Yard Crew**, Barrens | **Jack “Kerosene” Walker**, **Cole Briggs**, **Mason Reed** | Reject outside authority, trade through forbidden routes; profit from protection rackets, transport secrets, and stolen resources | Independence versus predation |

**Name direction:** Bandits use American names; Loners Ukrainian; Military Russian; Mercenary naming is Georgian. The groups need not be ethnically uniform populations; these are directional naming rules for prominent faction characters.

Existing alliance structures stay intact: Mercenaries offer a **retainer agreement (1,800 tribute)**; Military an **operating permit**; Loners **mutual aid** (no tribute); Bandits a **protection pact**. Existing reputation, territory, betrayal, and squad systems express consequences. No new faction mechanic is required by this document. Leadership can fracture; a leader's death cannot destroy the shared story.

Each faction's longer investigation follows different material: **Mercenaries** trace purchasing and recovery orders; **Military** track command authorizations and falsified evacuations; **Loners** track patients and named families; **Bandits** track prison cargo, bribes, and smuggling corridors. Across the game, their interests repeatedly collide over the *same* sites and objects.

---

## 5. Districts: chapters of one wound (rename existing districts to correspond to these)

| District | Existing anchors | Story character |
|---|---|---|
| **Downtown** | Police HQ, grocery, apartments; Mercenaries | Official records contradict life on the streets: ration lines, missing names, repeating instructions. |
| **Residential** | Survivor shelters, mansion, suburban houses; Loners | Homes and improvised care expose intimate, domestic forms of experimentation and loss. |
| **Industrial** | Power plant, science lab, rail and drainage; raiders/competing recovery crews | Powered rooms in a dead plant expose physical links between research, waste, and the disaster. |
| **Munincipal** | Airport, base, administration; Military | Flights, orders, and permit windows show how a state can erase an evacuation on paper. |
| **Barrens** | Jail, farm, freight track; Bandits | Prison transfers, work details, and illicit payments expose people treated as expendable cargo. |

The primary faction presence can change; the buildings' prior functions and narrative evidence should still make sense after control shifts.

---

## 6. Campaign shape

**Opening — The Fog:** Character creation, faction leaning, monologue, sparse hideout, first deployment.

**Act I — The Names of the Dead (five discoverable narrative missions; target overall progression from starting rank toward ~20):** Disconnected local problems reveal a linked cover-up. Their dramatic order below is *suggested*, never mandatory. Each gives a substantial **one-time story XP reward**, collectively tuned by progression designers to help a new player reach rank 20. No numerical XP values are prescribed.

**Act II — Terms of Containment (roughly ranks 20–35+, adjustable):** Four overlapping faction arcs explore VEIL through contracts, field discoveries, witnesses, and district conflicts. Faction decisions alter access, aid, hostility, and whose accounts are believed. Ordinary faction **contracts** remain separate from narrative missions: they reward XP, supplies, and trade value, but are not compulsory quest gates.

**Act III — The Second Sun (late-game, roughly culminating around rank 50; not mechanically hard-locked by lore):** A renewed emergency at the power complex exposes a hidden installation and leads to **a second, internal nuclear catastrophe that destroys Absentialis**. This ending is fixed as an event, not as a fixed moral outcome. The player can affect warning, evacuation, evidence, escape routes, and who survives to tell the story. More below.

**Prestige:** Rank caps at **50** before prestige. Prestige does not inherently erase the history of the player's decisions. Backpack progression reaches its existing maximum at rank 20; the story should not give free upgrades or contradict the game's economy.

---

## 7. Five sample Act I missions — THE NAMES OF THE DEAD

These are **investigations that exist inside ordinary deployments**, not bespoke mission maps or forced boss encounters. A lead may come from a faction contact, a rumor, a found document, or observation in the field. The player may get evidence first, flee with partial findings, return much later, sell the wrong thing to the wrong people, or never participate. Each case leaves physical facts behind even if its witness disappears. Contracts can point toward them but cannot gate them.

### M01 — The Roll Call · Downtown

**Local problem:** A grocery still holds ration records for families officially evacuated years ago. The police archive contains an incompatible evacuation roll. A resident barters with an identity card belonging to a supposedly dead household.

**Gameplay premise:** Find a ration ledger, household register, or matching proof of fraud and extract. Scavenge the grocery; slip through a loading dock or service alley; risk the police archive basement; avoid infected and irregular document patrols. The cramped aisles and glass-covered floors turn stealth into a resource decision.

**Faction readings:** Halberd wants ownership records; Military wants unauthorized documents secured; Loners want names restored to ration lists; Bandits want addresses and valuable households. Any contact can offer the lead, but the papers exist regardless.

**Discovery:** The bureaucracy counted living residents as gone. A ration delivery dated after the official evacuation corroborates an erased name. Records, posted slips, or a witness provide alternate proof. The former registrar **Nadiya Bereza** may be alive or represented by retained testimony.

**Resolutions and cost:** Give the evidence to shelters to restore identities; hand it to Military to tighten control; sell it to Mercenaries or Bandits for access/value; copy and preserve it; or leave with only groceries. The neighborhood reacts through ration access, raids, searches, and rumors. If a patrol takes the original, its new location becomes a lead—not a softlock.

### M02 — The Room with the Light On · Residential

**Local problem:** A dark suburban street has one lit upstairs room. Medicine marked **P-12** continues to arrive at a house supposedly vacated years before. Nurse **Iryna** is missing; the nearby mansion holds a concealed service route.

**Gameplay premise:** Follow a medicine delivery trail through a house, garden, cellar, or estate approach. Search for dosage notes, shipping labels, and a patient card. Food, herbs, medicine, valuables, and testimony compete for limited backpack space. Quiet interiors, uncertain occupancy, and sounds through walls carry the horror; a fight is not the payoff.

**Faction readings:** Mercenaries call it an inventory discrepancy; Military suspects illegal medical stock; Loners want the nurse and treatment knowledge; Bandits expect drugs and estate valuables.

**Discovery:** The house served as an off-books **VEIL observation annex**. “Care” masked monitoring and coerced consent. Iryna may testify, flee, or die; labeled cartons, the notebook, and the mansion's patient records can corroborate the truth without her.

**Resolutions and cost:** Aid and extract Iryna, donate the evidence, sell the supply route, request a military closure, seize medicine, or keep the records private. A shelter may gain better care; the estate may be raided or sealed; the room's light eventually changes or dies. No paranormal explanation is guaranteed.

### M03 — The Empty Transfer · Barrens

**Local problem:** Jail paperwork lists detainees discharged to medical care, yet none reached a hospital. Prison bus movements align with farm fuel receipts and a freight siding leading toward Industrial. Some “prisoners” were civilians whose identities had been erased.

**Gameplay premise:** Trace a transport without necessarily capturing a fortified jail. Infiltrate a booking office, inspect a transport bus, follow a convoy, search a farm weighbill, or find scratches naming a lab gate. Patrols, armed gang traffic, narrow cells, noisy metal flooring, and open sightlines create different risks; all paths allow retreat.

**Faction readings:** Mercenaries want a missing cargo code; Military demands an official ledger; Loners search for disappeared relatives; Bandits want a vanished cache and control of the route.

**Discovery:** “Medical transfer” meant supplying subjects to VEIL. Payments to a private intermediary link the prisoner economy with corporate procurement. The primary ledger, freight reports, and dispatch radio can establish the route independently.

**Resolutions and cost:** Publish names, free reachable captives, sell the destination, surrender paperwork, or turn the route into leverage. Who controls the freight corridor and whose families get answers changes afterward. A destroyed convoy becomes evidence through wreckage and logs, not a failed script.

### M04 — Silence on the Airfield · Munincipal

**Local problem:** The airport repeater alternates between a reassuring evacuation announcement and an order to remain indoors. Unused departure boards and abandoned baggage survive behind the cordon.

**Gameplay premise:** Recover or verify conflicting broadcast records through the tower, dispatch archive, hangar records, or passenger gate lists. Enter on a permit, crawl drainage, skirt the fence, or risk the exposed runway. Restoring power is one option, not a mandatory puzzle; paper archives can replace damaged recording equipment.

**Faction readings:** Mercenaries seek private contractor communications; Military wants contradictory signals contained; Loners want the truth about a never-completed flight; Bandits seek working authorization codes for smuggling.

**Discovery:** The flight was marked evacuated **before** its departure was canceled. A private procurement channel helped order the halt. Multiple independent timestamps prove it was not merely a malfunction.

**Resolutions and cost:** Broadcast the proof, pass it through military channels, sell it, steal codes, or hold it for bargaining. Radio content, patrol doctrine, checkpoint safety, and civilian movement change. A recurring industrial pulse in an old recording points toward the plant.

### M05 — The Second Inventory · Industrial

**Local problem:** An allegedly dead plant still draws power. Cleanup crews move tagged equipment out of a hidden science annex. Two inventories exist: **A** records ordinary industrial and medical assets; **B** documents rooms, transfers, and equipment that officially never existed.

**Gameplay premise:** Reach a service road, drainage approach, rail siding, substation, or exposed maintenance roof. Gather an inventory, a copied service diagram, authenticated site evidence, or technician **Kateryna Danylchuk's** testimony, then extract. The environment is dangerous: contaminated drains, unpredictable powered access, competing scavengers, sirens, and heavily infected corridors. A Tank or Gladiator may be foreshadowed or encountered through normal world simulation; **no boss kill is required**.

**Faction readings:** Mercenaries want a missing corporate asset list; Military wants emergency equipment accounting; Loners seek discharge and patient links; Bandits want fuel, electronics, and a coded storeroom.

**Discovery:** Inventory B ties together the grocery's erased households, Residential's **P-12**, Barrens's prisoner deliveries, and Munincipal's canceled departures. The name **PROJECT VEIL** becomes independently verifiable. An additional instruction reads: **“When preservation is no longer possible, enact secondary containment. All records are to remain inside Absentialis.”** Its full meaning is withheld until the late story.

**Resolutions and cost:** Expose VEIL, sell records, surrender them to authorities, trade facility access, preserve copies, or disable a local component. Sabotage may relieve one hazard while cutting power to nearby people. Ownership of evidence and district access change. The world can move or destroy one archive, but a second proof path remains. The mission ends on discovery and successful survival—not a nuclear detonation.

### How the five connect

| Incident | Leaves the player asking… | Becomes clearer when… |
|---|---|---|
| M01: erased ration recipients | Who made people disappear on paper? | M04 exposes deliberate evacuation falsification. |
| M02: P-12 patient house | Why were residents studied at home? | M05 identifies the clinical code. |
| M03: missing prison transport | Where did the prisoners go? | M05 identifies the receiving facility. |
| M04: canceled flights | Who controlled the official story? | M05 and Act II connect military and procurement records. |
| M05: hidden inventory | What is “secondary containment”? | Act II and III uncover the plant's final secret. |

**Arc synthesis:** *Someone counted the missing, transported them, examined them, and erased the evidence. Whatever failed here, the cover-up was deliberate.* This can live in a journal entry or quiet radio exchange; it does not need a cinematic.

---

## 8. The larger faction campaigns and final catastrophe

After Act I, the four groups follow different pieces of VEIL. The Mercenaries recover or profit from research while wondering whether their employer will abandon them. The Military fractures between officers willing to warn and evacuate civilians and hardliners protecting orders. The Loners investigate limited treatment and fight to keep communities supplied. The Bandits discover how prisoner transfers, supply routes, and protection economies helped the program operate. Their assignments should intersect organically: one convoy may carry food, prisoners' records, and valuable research; each employer offers a different reason to intercept or preserve it.

**Locked finale: THE SECOND SUN.** The power complex contains a **fictional covert nuclear installation / device**, concealed within VEIL's facilities. A worsening internal emergency ultimately causes **a second nuclear detonation from inside the power-plant complex**, destroying Absentialis. This is narrative fiction; an ordinary civilian reactor is **not** depicted as exploding like a nuclear weapon. Avoid procedural technical explanations.

The climax is an extraction operation under enormous pressure, not an unbroken scripted shooting gallery. Earlier decisions determine who has an evacuation corridor, who gets warned, which troops or gangs guard exits, what proof leaves the city, and who will be blamed in the outside world. The player may escape with witnesses, sell the record, save a small group, abandon others, or fail to extract. **The city does not survive; the moral outcome is who survives and whether the lie survives with it.** Foreshadow the disaster extensively so it feels earned, not a punishment for having played.

---

## 9. Story in the loot and the survival loop

The plot is carried in things worth extracting. **Sealed packages, ledgers, notes, reports, hard drives, data drives, lab keycards, crypt keys, tissue samples, purifier cores, and military beacons** are both objects of practical value and witnesses to the city's history. A torn map can lead to a forgotten route; dog tags identify an abandoned soldier; a St. Christopher medal or tin bell can connect a death to a family; high-value chalices, jewelry, crowns, and gemstones reveal hoarding, theft, and inequality. **Anomalous shards** remain dangerous, disputed research evidence—not magic answers.

**Medical items, herbs, food, water, ammo, and limited backpack capacity stay meaningful.** A player carrying a bulky case of records may leave medicine behind. Taking a photograph or copying a page can preserve knowledge while leaving the original for another faction to seize. Secret tier-5 accessories—cat ears, chicken hat, deer antlers, wolf tail—are deliberately non-canonical unlockable absurdities, not explanations for the disaster.

---

## 10. Rules for narrative designers

1. **Write a local problem first.** Each incident must exist before a player accepts it; the requester may be mistaken or self-serving.
2. **Keep story missions secondary to extraction.** Players raid for supplies and may incidentally uncover evidence. Ordinary **contracts** remain distinct rewards-driven tasks.
3. **Use authored truth, simulated friction.** Authors own motives, reliable clues, competing interpretations, and persistent outcomes; world systems own ordinary patrols, infected movement, combat, travel, resource scarcity, and most encounter variation.
4. **No mandatory sequence.** Players can solve incidents out of order, encounter them without briefings, disengage, or extract partial findings.
5. **No fragile clues.** A major fact should have at least two independent methods of discovery. An NPC's death or an item changing hands cannot erase the overall campaign.
6. **Track fact and possession separately.** *Saw the document*, *authenticated it*, *carried the original*, *copied it*, and *gave it away* are different conditions. Do not regenerate valuable objects invisibly.
7. **Make consequences physical.** Named survivors, shelter resources, patrol behavior, radio broadcasts, open routes, and traders should visibly respond; existing faction systems can implement this.
8. **Keep journals epistemically honest.** Distinguish what was **reported**, **observed**, and **corroborated**. Do not spoil the cause before evidence exists.
9. **Protect retreat and replay.** Losing an extraction means real loss, not inexplicable story amnesia; save/load and re-entry must respect persistent discoveries.
10. **Award substantial one-time Act I story XP.** The five incidents should collectively support reaching approximately rank 20 from a new character, subject to balancing. Repeated delivery of copies does not mint extra narrative XP.
11. **Do not make the victim the spectacle.** Industrial negligence, secrecy, and accountability are the moral core of the Chernobyl metaphor; the infected are people who suffered the catastrophe.
12. **Leave silence in the story.** Not every mystery needs an answer, not every operation a boss, and not every discovery a speech.

### Deliberately open for production

The fictional state's name and precise calendar; mercenary nationality/naming style; the player character's pre-game life and arrival route; how the fog's stranger effects are represented; which individuals survive; the specific missions and pacing of Acts II–III; squad participation; and the concrete implementation of evacuation/extraction states. The **fixed narrative anchors** are the hidden human abuses of VEIL, erased residents, contradictory faction interests, the fog's ambiguity, the five opening investigations, and the city-ending internal catastrophe.

**North star:** *Let the player arrive wanting to leave with supplies—and depart, if they can, carrying proof that the city never was empty.*
