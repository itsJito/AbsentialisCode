# Attribution - third-party audio

Absentialis 0.5 uses the following recordings. Originals are kept unmodified in `tools/audio/originals/`; the files
the game plays are generated from them by `gradlew prepareAudio` (cut, layered, level-matched, resampled). Full
per-file detail: `docs/audio/weapon_asset_manifest.md`.

## The Free Firearm Sound Library
- Authors: Ben Jaszczak, Brian Nelson, Kevin Heras, Matthew Nanney
- Licence: CC0 1.0 Universal (public domain dedication) - https://creativecommons.org/publicdomain/zero/1.0/
- Source: https://opengameart.org/content/the-free-firearm-sound-library
- Used for: all gunshot layers (`assets/audio/weapons/`)

## Gun Reload Sound Effects
- Author: BMacZero (Brian MacIntosh)
- Licence: CC0 1.0 Universal
- Source: https://opengameart.org/content/gun-reload-sound-effects
- Files: clipload1.wav, clipload2.wav, singlebullet1.wav
- Used for: magazine and single-round handling (`assets/audio/handling/mag_*`, `round_*`)

## Gun Reload Sounds
- Author: as credited on the source page (to be copied here before public release; it was not recorded at download)
- Licence: CC0 1.0 Universal, as stated on the source page
- Source: https://opengameart.org/content/gun-reload-sounds
- Files: gunreload1.wav, assaultriflereload1.wav, shotguncock.wav
- Used for: reload, bolt and pump handling (`assets/audio/handling/rifle_reload_*`, `pistol_reload_*`, `pump_*`)

## Footsteps on different surfaces
- Author: congusbongus - https://opengameart.org/content/footsteps-on-different-surfaces
- Licence: Creative Commons Attribution 3.0 - https://creativecommons.org/licenses/by/3.0/
- Derived by that author from (per the `license.txt` in each folder, kept alongside the originals):
  - boots, grass, wood, tile, water: "footstep-concrete.wav", "footstep-grass.wav", "footstep-wood.wav" by swuing
    (freesound.org, CC-BY 3.0)
  - tile: also "Squeaky footstep.wav" by ceberation (freesound.org)
  - water: also "Water Footsteps" by EminYILDIRIM (freesound.org)
  - metal: "boots on aluminum ladder 01" by Eelke (freesound.org, CC-BY 3.0)
  - gravel: "Pack: Gravel Footsteps" by Ali_6868 (freesound.org, CC0)
- Changes made here: mono fold-down, level normalisation, resampling; the asphalt and dirt sets are filtered,
  re-pitched blends of the boots, grass and gravel recordings.
- Used for: footsteps (`assets/audio/footsteps/`)

No audio from commercial games, films or paid sound libraries is included.
