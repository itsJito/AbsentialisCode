# Changelog

## Version 0.5

### World
- Rewrote city generation as a twelve-stage, data-driven pipeline (`content/districts.json`, `content/buildings.json`):
  district layout by terrain suitability, protected road network, lots, landmark compounds, room-graph interiors,
  furnishing, validation with repair or rejection, and a generation report.
- Six environments: Residential, Industrial, Governmental, Downtown, Outskirts, Wilderness. Each developed district has
  exactly two landmark compounds (Mansion and large suburban house; power plant and science lab; military base and
  airport; police headquarters and grocery; jail and farming compound) and one faction headquarters.
- Every room of every building is reachable from the street; buildings that cannot be made so are repaired or removed.
- Fixed: perimeter trench (the outermost city column was never filled - an off-by-one in the outside-distance test).
- Fixed: glass-like towers outside the boundary (watchtowers were placed three blocks outside the wall).
- Fixed: floating dead-tree canopies; tree canopies blocking road cells.
- Cover points generated from world geometry, per chunk, invalidated when blocks change.
- Debug layers as PNGs (`ABS_GENDUMP`): plan, footprints, rooms, navigation, invalid cells, materials, cover.

### Combat and characters
- Tactical AI: utility-scored intents (hold, peek, suppress, advance, relocate, withdraw) over a squad blackboard;
  cover selection from the cover map; leaning and pop-up fire; chokepoint awareness; rescue of downed allies.
- Casualty state machine ACTIVE -> DOWNED -> REVIVING -> ACTIVE (or DEAD): 20 s bleed-out, 4 s revive, interruptible.
  Infected are never downed. Fatal regions and catastrophic damage always kill.
- Fixed: the player's body vanished on death (it was marked dead before the death sequence could give it a ragdoll).
- Four health conditions with configurable thresholds (`content/combat.json`) affecting speed, sprint, aim and animation.
- Cover for the player in first and third person; cover and injury animation layers.
- Physical doors: hinge swing, regional damage, latch and hinge failure, debris, navigation updates, AI door use.
- Aim-down-sights aligned from each weapon model's own sight line, with eased blending.
- Yellow Herbs raise maximum health permanently (saved with the profile, kept through prestige).

### Interface
- Status module (lower right): portrait, health arc that lengthens with maximum health, loaded and reserve ammunition.
- Squad status column and killfeed on the left; one line per confirmed death, none for incapacitation.
- Hit marker from confirmed events only: white hit, yellow incapacitation, red kill (kill > incapacitation > hit).
- Minimap contacts coloured by relation (blue squad with facing, green friendly, yellow neutral, red hostile).
- World-space speech bubbles driven by the existing dialogue.
- Resolution-independent layout helpers; fixed the Insertion Point text overflow in the hideout.

### Audio
- Layered gun audio (`engine/audio/gun`): per-weapon profiles, sample-accurate shot scheduling, transient / body /
  tail / distant / mechanical layers, voice budgets with faded stealing, occlusion, ray-traced early reflections,
  one shared late reverb, compressor and limiter. Player and NPC fire use the same path.
- Recorded assets with documented licences (`ATTRIBUTION.md`, `docs/audio/weapon_asset_manifest.md`), a reproducible
  pipeline (`gradlew prepareAudio`), originals preserved in `tools/audio/originals/`.
- Recorded footsteps for concrete, asphalt, wood, metal, dirt, grass, gravel (plus tile and water), with variation.
- Reload cues play recorded handling sounds on the reload animation's clock. Door latch, kick and break sounds.

### Project
- Version 0.5 in one place (`absentialis.Version`); save format 5 with migration from 4.
- 394 quality gates (81 new for 0.5).

## Version 0.4

### Fixed
- **No audio.** The game's audio output was fine; the Windows Volume Mixer entry for the Java runtime on the
  output device was at 0%. The game now checks its own mixer session at start-up and restores it
  (`engine/audio/WinAudioSession`), the title screen and Settings > Audio show the device and mixer level, and
  there is a test-sound button with live meters. The mixer thread also survives a device fault instead of dying.
- **Crash** (`crash.log`: `ConcurrentModificationException` in the blood system) - the gore, projectile, thrown
  and zone loops no longer mutate a list while iterating it.
- **F** only plays the interact animation when something was actually interacted with.
- **Weapon icons** are fitted to the model's occupied voxels and rendered side-on, so every gun fills the tile
  footprint it occupies (gated: >= 80% one way, >= 60% the other).
- A **container closes itself** a moment after the last item is taken.

### Removed
- The fire **voxel**. Fire is now `scene/FireSystem`: pooled flame, smoke and ember particles, flickering
  light, heat that burns whoever stands in it, rain that beats it down, and a looped crackle.

### Changed
| System | Where | Summary |
|---|---|---|
| Infection | `scene/InfectionSystem` | Bites from the infected can break the skin. The infection runs BITTEN > FEVER > SICK > CRITICAL with symptoms on the HUD and screen; **Antiviral Medicine** (common loot, in the starter kit, sold in the shop) cures it at any stage. Untreated, the player dies and rises; NPCs turn in the body, clothes and name they had, with green skin and the infected animation set. Organised factions often carry a dose and treat themselves. |
| Death | `scene/RaidScreen`, `scene/Raid` | Third-person view of the body while the picture drains to grainy black and white, then RESPAWN / MAIN MENU / QUIT. **Ironman** (chosen at profile creation) makes death permanent: the profile is deleted. |
| Squad | `scene/SquadPanel` | Every squadmate can be renamed (click the name; Enter confirms, Esc cancels, or roll a random one). |
| Lighting | `engine/render/HybridRenderer` | OpenGL 4.5 deferred PBR in HDR: cascaded sun shadows, tiled GPU light culling, shadowed local lights, irradiance probes updated by compute-shader voxel rays with visibility weighting and per-region caching, GTAO, screen-space reflections, volumetric fog and shafts, TAA, bloom, auto-exposure, ACES. Four quality presets and per-effect toggles in Settings > Graphics. Falls back to the 0.3 forward renderer if GL 4.5 is unavailable (`ABS_LEGACY_GL=1` forces it). |
| Damage | `anatomy/*`, `scene/Gore` | Each body is layered voxels (skin, fat, muscle, bone, joint, organ, armour). Hits are traced against the posed body and remove what they pass through; wounds are meshed from what is left and persist; a limb comes away when the structure joining it fails; ragdoll reactions, blood and what the AI can still do all follow from the same state. |
| Enemy AI | `ai/Tactics`, `ai/SquadMind`, `ai/CloseCombat` | Five awareness levels driven by sight and sound only; memory of a last known position that goes stale; squads share information by voice or radio with delay and range; roles (aggressor, flanker, suppressor, searcher, defender); scored cover and flank positions; suppression from near misses; coordinated search of cleared and uncleared ground; close combat with turn-taking, shoves and grabs. |
| Vehicles | `vehicle/*`, `scene/VehicleSystem` | Force-driven four-wheel rigid-body simulation at a fixed 50 Hz: suspension rays, adhesion-limited tyres, automatic gearbox, per-surface grip, zone deformation, burst tyres, entry and exit animations, chase and seat cameras. Eight vehicles in seven families, all data in `content/vehicles.json`. Bought in the SHOP under VEHICLES; one can be brought per operation and is lost if you die. At most four vehicles exist in an operation. |
| Deployment | `scene/HideoutScreen` | The deploy dialog is now a one-page Operation Briefing: insertion cards with who holds the district and how infected it is, time on the ground, vehicle, element, a readiness checklist and a one-line summary beside DEPLOY. |

### Added
- **Version numbers**: this build is Version 0.4 (title screen, hideout, HUD footer, saves).
