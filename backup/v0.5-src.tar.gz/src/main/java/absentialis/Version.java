package absentialis;

/**
 * Build identity and the currency format: the one place the version is written. The title screen, the hideout,
 * the HUD footer, the window title, crash reports and save files all read it from here. This iteration is Version 0.5.
 */
public final class Version {
    private Version() {}

    public static final String NUMBER = "0.5";
    public static final String LABEL = "Version " + NUMBER;
    public static final String TITLE = "ABSENTIALIS " + NUMBER;
    /** Save-format generation written into profiles so a later build can tell what produced a file. */
    public static final int SAVE_FORMAT = 5;
    /** Short build stamp for the HUD corner, crash reports and the window title: "v0.5". */
    public static final String SHORT = "v" + NUMBER;

    /** The colon sign: the Zone trades in coins. */
    public static final char COIN = '₡';

    /** "₡12,500" */
    public static String coins(long amount) { return COIN + String.format("%,d", amount); }
}
