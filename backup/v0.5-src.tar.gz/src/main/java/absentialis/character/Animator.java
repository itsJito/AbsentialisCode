package absentialis.character;

import static absentialis.character.Rig.*;

import absentialis.engine.math.Mat4;
import absentialis.entity.Actor;

/**
 * Per-character animation state and pose evaluation (iteration P2).
 *
 * Lower body: the gait phase advances by distance actually travelled divided by the blended stride,
 * so a stance foot stays planted whatever the speed, and the hips turn toward the movement
 * direction while the torso keeps facing the aim (upper and lower body are independent layers).
 * Upper body: weapon holds and action clips drive a weapon channel; both hands are solved onto the
 * weapon by IK. Everything blends over 120 ms. Feet are finally re-solved against the ground.
 *
 * The state is advanced by the simulation ({@link #update}); poses are evaluated on demand by the
 * renderer, the first-person camera and - once, at death - the ragdoll.
 */
public final class Animator {
    public static final float BLEND = 0.12f;

    /** Walkable surface lookup for foot placement: world y of the floor near y at (x, z), or NaN. */
    public interface Ground { float top(float x, float z, float y); }

    // ----- locomotion state
    public float phase, speed, moveAngle, hipYaw, visY, crouchT, armedT, aimT, sprintT, climbT, airT, reachT, turnW, climbPhase;
    private float footYaw, lastX, lastY, lastZ;
    private boolean started, started2, reverse, turning;
    /** Gait family: human, walker, sprinter, fat, giant. */
    public String family = "human";
    public float scale = 1;
    // ----- actions
    public String action = "";
    public float actionTime, actionDur, fireT, hitT, hitYaw;
    /** Kneeling over a casualty (set by scene.Casualty); blended in and out like every other layer. */
    public boolean reviving;
    /** Layer weights eased by update: injury (0 fine .. 1 critical), down on the ground, working on a casualty, in cover, lean. */
    public float injuryT, downT, reviveT2, coverT, coverLowT, leanT, clock;
    /** Which leg carries the limp (fixed per character so it reads as an injury, not a wobble). */
    public int limpSide = 1;
    /** Support-hand grip distance ahead of the firing grip (voxels); 0 = one-handed. */
    public float gripSep = 6.5f;
    public boolean twoHanded = true;

    private final Pose a = new Pose(), b = new Pose(), act = new Pose();
    private final float[] v = new float[3], ik = new float[3];
    private static final float PI = (float) Math.PI;

    public static String familyOf(String archetype, boolean infected) {
        if (!infected) return "human";
        return switch (archetype) { case "sprinter", "screecher" -> "sprinter"; case "boomer" -> "fat"; case "tank" -> "giant"; default -> "walker"; };
    }

    /** Starts a one-shot action clip; dur <= 0 uses the clip's own length. */
    public void play(String clip, float dur) {
        if (!Anims.has(clip)) return;
        action = clip;
        actionTime = 0;
        actionDur = dur > 0 ? dur : Anims.get(clip).duration;
    }

    public boolean playing(String clip) { return action.equals(clip); }
    public void fire() { fireT = 1; }
    public void hit(float worldYaw) { hitT = 1; hitYaw = worldYaw; }

    private float actionWeight() {
        if (action.isEmpty()) return 0;
        return Math.max(0, Math.min(1, Math.min(actionTime / BLEND, (actionDur - actionTime) / BLEND)));
    }

    private static float wrap(float x) { while (x > PI) x -= 2 * PI; while (x < -PI) x += 2 * PI; return x; }
    /** Linear cross-fade weight: reaches its target in exactly BLEND seconds. */
    private static float toward(float cur, float target, float dt) { float step = dt / BLEND; return cur < target ? Math.min(target, cur + step) : Math.max(target, cur - step); }

    // ------------------------------------------------------------------ simulation-side update
    public void update(Actor ac, float dt, boolean armed, boolean aiming, boolean engaged) {
        if (!started) { lastX = ac.x; lastY = ac.y; lastZ = ac.z; footYaw = ac.yaw; started = true; }
        float dx = ac.x - lastX, dy = ac.y - lastY, dz = ac.z - lastZ;
        lastX = ac.x; lastY = ac.y; lastZ = ac.z;
        float dist = (float) Math.sqrt(dx * dx + dz * dz);
        if (dist > 3 || Math.abs(dy) > 3) { dist = 0; dy = 0; }  // teleport
        float vel = dt > 1e-5f ? dist / dt : 0;
        // health condition (brief 7): the injury layer eases in, and a hurt body changes pace more slowly
        absentialis.gameplay.CombatConfig cfg = absentialis.gameplay.CombatConfig.get();
        boolean person = family.equals("human");
        int cond = person && !ac.dead ? cfg.condition(ac.hp, ac.maxHp).ordinal() : 0;
        injuryT += (cfg.animation[cond] - injuryT) * Math.min(1, dt * 2.2f);
        clock += dt;
        if (!started2) { limpSide = (ac.id & 1) == 0 ? 1 : -1; started2 = true; }
        speed += (vel - speed) * Math.min(1, dt * 12 * cfg.blendRate[cond]);
        downT = toward(downT, person && ac.downed() ? 1 : 0, dt * 0.4f);
        reviveT2 = toward(reviveT2, reviving ? 1 : 0, dt * 0.5f);
        boolean covered = person && ac.coverAmt > 0.5f && ac.cover != null;
        coverT = toward(coverT, covered ? 1 : 0, dt * 0.55f);
        coverLowT = toward(coverLowT, covered && ac.cover.height == absentialis.world.CoverMap.LOW ? 1 : 0, dt * 0.55f);
        // an agent's lean is kept relative to its cover; the pose needs it relative to the body
        float lean = ac.lean;
        if (!ac.isPlayer && ac.cover != null) { float side = ac.cover.leftX() * (float) Math.cos(ac.yaw) - ac.cover.leftZ() * (float) Math.sin(ac.yaw); lean = -lean * (side >= 0 ? 1 : -1); }
        leanT += (lean - leanT) * Math.min(1, dt * 9);
        // root motion smoothing over one-block steps; a quick knee-up sells the climb
        if (ac.onGround && !ac.climbing && Math.abs(dy) > 0.45f && Math.abs(dy) < 1.3f) {
            visY -= dy;
            if (dy > 0 && action.isEmpty() && !armed) play("vault", 0.32f);
        }
        visY *= (float) Math.exp(-dt * 11);
        if (Math.abs(visY) < 0.002f) visY = 0;
        if (ac.climbing) climbPhase += dy / 1.1f;
        // movement direction relative to the facing; walking backwards runs the cycle in reverse
        float sy = (float) Math.sin(ac.yaw), cy = (float) Math.cos(ac.yaw);
        if (dist > 1e-4f && speed > 0.25f) {
            float f = dx * -sy + dz * -cy, r = dx * cy + dz * -sy;
            float ang = (float) Math.atan2(r, f);
            reverse = Math.abs(ang) > (reverse ? 1.45f : 1.9f);
            if (reverse) ang = ang > 0 ? ang - PI : ang + PI;
            moveAngle += wrap(ang - moveAngle) * Math.min(1, dt * 10);
        } else moveAngle *= 1 - Math.min(1, dt * 6);
        phase += (reverse ? -1 : 1) * dist / stride(ac.crouch);
        phase -= (float) Math.floor(phase);
        if (speed > 0.3f) {
            float target = -Math.max(-0.8f, Math.min(0.8f, moveAngle));
            hipYaw += (target - hipYaw) * Math.min(1, dt * 10);
            footYaw = ac.yaw + hipYaw;
            turning = false;
        } else {
            // feet stay planted while the torso turns; past ~55 degrees the feet shuffle round
            float off = wrap(footYaw - ac.yaw);
            if (Math.abs(off) > 0.95f) turning = true;
            if (turning) {
                off -= Math.signum(off) * Math.min(Math.abs(off), dt * 5.5f);
                phase += dt * 1.7f;
                if (Math.abs(off) < 0.08f) turning = false;
            }
            footYaw = ac.yaw + off;
            hipYaw = off;
        }
        turnW = toward(turnW, turning ? 1 : 0, dt);
        crouchT = toward(crouchT, ac.crouch ? 1 : 0, dt);
        armedT = toward(armedT, armed ? 1 : 0, dt);
        aimT = toward(aimT, aiming ? 1 : 0, dt);
        sprintT = toward(sprintT, ac.sprinting || !ac.isPlayer && armed && !engaged && speed > 3.4f ? 1 : 0, dt);
        climbT = toward(climbT, ac.climbing ? 1 : 0, dt);
        airT = toward(airT, !ac.onGround && !ac.climbing && Math.abs(ac.vy) > 2.5f ? 1 : 0, dt);
        reachT = toward(reachT, engaged ? 1 : 0, dt * 0.5f);
        if (!action.isEmpty()) { actionTime += dt; if (actionTime >= actionDur) action = ""; }
        fireT = Math.max(0, fireT - dt / 0.14f);
        hitT = Math.max(0, hitT - dt / 0.35f);
    }

    // ------------------------------------------------------------------ gait selection
    private String[] gaitNames() {
        return switch (family) {
            case "walker" -> new String[]{"inf_idle", "inf_shamble", "inf_run"};
            case "sprinter" -> new String[]{"inf_idle", "inf_shamble", "inf_run"};
            case "fat" -> new String[]{"inf_idle", "fat_waddle", "fat_waddle"};
            case "giant" -> new String[]{"inf_idle", "giant_stomp", "giant_stomp"};
            default -> new String[]{"idle", "walk", "jog", "sprint"};
        };
    }

    private float[] gaitSpeeds() {
        return switch (family) {
            case "walker" -> new float[]{0, 0.8f, 4.5f};
            case "sprinter" -> new float[]{0, 1.0f, 4.5f};
            case "fat" -> new float[]{0, 0.8f, 3f};
            case "giant" -> new float[]{0, 1.4f, 6f};
            default -> new float[]{0, 1.3f, 3.4f, 6.0f};
        };
    }

    /** Index of the lower gait and the blend toward the next one for the current speed. */
    private float gaitBlend(int[] idx) {
        float[] s = gaitSpeeds();
        float sp = speed / scale;
        int i = 0;
        while (i < s.length - 2 && sp > s[i + 1]) i++;
        idx[0] = i;
        return Math.max(0, Math.min(1, (sp - s[i]) / (s[i + 1] - s[i])));
    }

    /** Metres travelled per gait cycle: stance travel / duty factor, so stance feet match ground speed. */
    public float stride(boolean crouched) {
        int[] idx = new int[1];
        float t = gaitBlend(idx);
        String[] n = gaitNames();
        AnimClip c0 = Anims.get(n[idx[0]]), c1 = Anims.get(n[idx[0] + 1]);
        float travel = c0.travel + (c1.travel - c0.travel) * t, duty = c0.duty + (c1.duty - c0.duty) * t;
        if (family.equals("human") && crouchT > 0.01f) {
            AnimClip cw = Anims.get("crouch_walk");
            float ct = Math.min(1, speed / 1.2f);
            travel += (cw.travel * ct - travel) * crouchT;
            duty += (cw.duty - duty) * crouchT;
        }
        return Math.max(0.35f, travel / duty * VOX * scale);
    }

    // ------------------------------------------------------------------ pose evaluation
    /**
     * Evaluates the current pose. aimPitch is the look pitch (radians, up positive); ground may be
     * null (no foot placement). firstPerson keeps the spine upright so the body never swings into
     * the camera.
     */
    public void pose(Actor ac, Pose out, float aimPitch, Ground ground, boolean firstPerson) {
        int[] idx = new int[1];
        float t = gaitBlend(idx);
        String[] names = gaitNames();
        Anims.get(names[idx[0]]).sample(phase, out);
        Anims.get(names[idx[0] + 1]).sample(phase, a);
        out.blend(a, t, ALL_MASK, true, false);
        boolean human = family.equals("human");
        float moveW = Math.min(1, speed / (0.8f * scale));
        if (human && crouchT > 0.01f) {
            Anims.get("crouch_idle").sample(phase, a);
            Anims.get("crouch_walk").sample(phase, b);
            a.blend(b, Math.min(1, speed / 1.2f), ALL_MASK, true, false);
            out.blend(a, crouchT, ALL_MASK, true, false);
        }
        if (turnW > 0.01f) { Anims.get(names[1]).sample(phase, a); out.blend(a, turnW * 0.55f, LOWER_MASK, false, false); }
        if (airT > 0.01f) {
            a.set(out);
            a.r(L_THIGH, 0.55f, 0, 0).r(L_SHIN, -0.95f, 0, 0).r(R_THIGH, 0.15f, 0, 0).r(R_SHIN, -0.55f, 0, 0).r(L_UPPER_ARM, 0.5f, 0, -0.45f).r(R_UPPER_ARM, 0.3f, 0, 0.45f);
            a.rootY = 0;
            out.blend(a, airT, ALL_MASK, true, false);
        }
        if (climbT > 0.01f) { Anims.get("climb").sample(climbPhase, a); out.blend(a, climbT, ALL_MASK, true, false); }

        // lower body turns into the movement direction; the torso counter-rotates to keep facing the aim
        out.rootYaw = hipYaw;
        float resid = (-moveAngle - hipYaw) * moveW * (1 - climbT);
        out.rot[L_THIGH * 3 + 1] = resid;
        out.rot[R_THIGH * 3 + 1] = resid;
        out.rot[TORSO * 3 + 1] -= hipYaw;

        if (human && injuryT > 0.01f) injury(out, moveW);
        float aw = actionWeight();
        AnimClip ac2 = action.isEmpty() ? null : Anims.get(action);
        if (ac2 != null) ac2.sample(actionTime / actionDur, act);
        float pitch = Math.max(-1.2f, Math.min(1.2f, aimPitch));
        if (human) {
            float armed = armedT * (1 - climbT);
            // weapon channel: low ready <-> shouldered <-> port arms while sprinting
            Anims.get("wpn_ready").sample(0, a);
            Anims.get("wpn_aim").sample(0, b);
            a.blend(b, aimT, 0, false, true);
            Anims.get("wpn_sprint").sample(0, b);
            a.blend(b, sprintT * (1 - aimT), 0, false, true);
            System.arraycopy(a.wpn, 0, out.wpn, 0, 9);
            // weapon handling follows the body: a hurt arm carries the weapon lower and holds it less still
            if (injuryT > 0.01f) { out.wpn[1] -= 0.9f * injuryT * (1 - aimT); out.wpn[3] += (float) Math.sin(clock * 3.1f) * 0.035f * injuryT; out.wpn[4] += (float) Math.sin(clock * 2.3f + 1) * 0.03f * injuryT; }
            out.lhOnWeapon = twoHanded ? 1 : 0;
            if (!twoHanded) { out.wpn[6] = -4.2f; out.wpn[7] = -7.5f + 1.5f * (float) Math.sin(phase * 2 * PI) * moveW; out.wpn[8] = -1.5f; }
            if (ac2 != null && aw > 0 && !ac2.additive) {
                if (ac2.drivesWeapon && !twoHanded && act.lhOnWeapon > 0.5f) { act.lhOnWeapon = 0; act.wpn[6] = -4.2f; act.wpn[7] = -7.5f; act.wpn[8] = -1.5f; }
                applyAction(out, ac2, aw);
            }
            // bladed stance and reduced counter-swing with a weapon up
            out.rot[TORSO * 3 + 1] += -0.32f * armed * (twoHanded ? 1 : 0.4f);
            out.rot[HEAD * 3 + 1] += 0.30f * armed * (twoHanded ? 1 : 0.4f);
            out.rot[TORSO * 3] += (firstPerson ? 0 : pitch * 0.30f);
            out.rot[HEAD * 3] += pitch * 0.45f;
            if (firstPerson) out.rot[TORSO * 3] = Math.max(out.rot[TORSO * 3], -0.10f);
            boolean throwing = ac2 != null && !ac2.drivesWeapon && (ac2.mask & ARMS_MASK) != 0;
            if (armed > 0.01f && !throwing) solveArms(out, pitch, armed);
        } else {
            Anims.get("inf_droop").sample(phase * 0.5f + ac.id * 0.37f, a);
            Anims.get("inf_reach").sample(phase + ac.id * 0.21f, b);
            a.blend(b, reachT, UPPER_MASK, false, false);
            float keep = family.equals("fat") ? 0.6f : 1f;
            // gait lean stays, arms and head come from the infected layer
            out.blend(a, keep, ARMS_MASK | bit(HEAD), false, false);
            out.rot[TORSO * 3] += a.rx(TORSO) * keep * 0.6f;
            out.rot[TORSO * 3 + 2] += a.rz(TORSO) * keep;
            if (ac2 != null && aw > 0 && !ac2.additive) applyAction(out, ac2, aw);
            out.rot[HEAD * 3] += pitch * 0.3f;
        }
        // additive layers: recoil and flinch
        if (fireT > 0 && human) { Anims.get("fire").sample(1 - fireT, a); out.addScaled(a, 1, bit(TORSO) | bit(HEAD)); }
        if (hitT > 0) {
            Anims.get("hit").sample(1 - hitT, a);
            float rel = wrap(hitYaw - ac.yaw);
            out.addScaled(a, (float) Math.cos(rel) > 0 ? -1f : 1f, UPPER_MASK);
            out.rot[TORSO * 3 + 2] += (float) Math.sin(rel) * 0.25f * hitT;
        }
        if (human) {
            if (coverT > 0.01f || Math.abs(leanT) > 0.01f) cover(out);
            if (reviveT2 > 0.01f) kneel(out);
            if (downT > 0.01f) downed(out);
        }
        if (ground != null && climbT < 0.5f && airT < 0.5f && downT < 0.5f) plantFeet(ac, out, ground);
    }

    // ------------------------------------------------------------------ 0.5 layers: injury, cover, rescue, the ground
    /**
     * The limp. On the half of the cycle the bad leg carries the weight, the hips drop onto it and the trunk leans
     * over it; that leg takes a short, stiff step; the whole posture closes up round the hurt. At the critical end
     * the trunk sways and the knees are close to giving. Driven by the same gait phase as the legs, so the dip
     * lands on the footfall.
     */
    private void injury(Pose out, float moveW) {
        float k = injuryT, s = (float) Math.sin(phase * 2 * PI) * limpSide, load = Math.max(0, s);
        int th = limpSide > 0 ? R_THIGH : L_THIGH, sh = th + 1;
        out.rot[th * 3] *= 1 - 0.45f * k;
        out.rot[sh * 3] *= 1 - 0.40f * k;
        out.rootY -= (0.35f + 1.0f * load * moveW) * k;
        out.rot[TORSO * 3 + 2] += -limpSide * 0.17f * k * load * moveW;
        out.rot[TORSO * 3] -= 0.17f * k;
        out.rot[HEAD * 3] -= 0.10f * k;
        // the arm on the hurt side is held in against the body instead of swinging
        int arm = limpSide > 0 ? R_UPPER_ARM : L_UPPER_ARM;
        out.rot[arm * 3] *= 1 - 0.6f * k * (1 - armedT);
        out.rot[arm * 3 + 2] += -limpSide * 0.12f * k * (1 - armedT);
        if (k > 0.7f) {
            float c = (k - 0.7f) / 0.3f, sway = (float) Math.sin(clock * 2.1f);
            out.rot[TORSO * 3 + 2] += sway * 0.07f * c;
            out.rootX += sway * 0.55f * c;
            out.rootY -= 0.5f * c + Math.max(0, (float) Math.sin(clock * 0.9f)) * 0.35f * c;
        }
    }

    /** In cover: tucked against the obstacle, a quarter turned with the shoulder to it; leaning out takes the trunk with the weapon. */
    private void cover(Pose out) {
        float c = coverT, hide = 1 - aimT;
        out.rootZ -= 1.1f * c;
        out.rot[TORSO * 3 + 1] += 0.34f * c * hide;
        out.rot[HEAD * 3 + 1] -= 0.30f * c * hide;
        out.rootY -= 0.9f * coverLowT * hide;
        out.rot[TORSO * 3] -= 0.10f * coverLowT * hide;
        out.rootX += leanT * 3.0f;
        out.rot[TORSO * 3 + 2] -= leanT * 0.30f;
        out.rot[HEAD * 3 + 2] += leanT * 0.20f;
    }

    /** Working on a casualty: down on the knees (the crouch supplies the legs), bent over, both hands pressing in rhythm. */
    private void kneel(Pose out) {
        float w = reviveT2, pump = (float) Math.sin(clock * 7.5f) * 0.12f;
        out.rot[TORSO * 3] += (-0.50f - out.rot[TORSO * 3]) * w;
        out.rot[HEAD * 3] += (-0.30f - out.rot[HEAD * 3]) * w;
        for (int arm : new int[]{L_UPPER_ARM, R_UPPER_ARM}) {
            out.rot[arm * 3] += (0.95f + pump - out.rot[arm * 3]) * w;
            out.rot[arm * 3 + 1] *= 1 - w;
            out.rot[arm * 3 + 2] += ((arm == L_UPPER_ARM ? 0.22f : -0.22f) - out.rot[arm * 3 + 2]) * w;
            out.rot[(arm + 1) * 3] += (0.35f - pump - out.rot[(arm + 1) * 3]) * w;
        }
        out.rootY -= 0.6f * w;
    }

    /**
     * The wounded ground pose: on the back with the hips on the floor, propped on one elbow, one leg out and one
     * knee drawn up, the head lifted to look along the body. A weapon hand keeps whatever the arm solver gave it
     * (the sidearm stays on its target); the other arm is the prop. Crawling rocks the body with the gait phase.
     */
    private void downed(Pose out) {
        a.set(out);
        float crawl = Math.min(1, speed / 0.5f), rock = (float) Math.sin(phase * 2 * PI) * crawl;
        a.rootX = 0; a.rootZ = 0; a.rootRoll = 0.10f * limpSide + rock * 0.05f;
        a.rootY = -(HIP_Y - 2.2f);
        a.rootPitch = 1.12f + rock * 0.05f;
        a.r(TORSO, -0.48f, 0, 0).r(HEAD, -0.30f, 0, 0);
        a.r(L_THIGH, 0.45f + rock * 0.12f, 0, 0).r(L_SHIN, -0.05f, 0, 0);
        a.r(R_THIGH, 0.95f - rock * 0.12f, 0, 0).r(R_SHIN, -1.15f, 0, 0);
        a.r(L_UPPER_ARM, -0.95f + rock * 0.18f, 0, -0.30f).r(L_FOREARM, 0.25f, 0, 0);
        if (armedT < 0.5f) a.r(R_UPPER_ARM, 0.35f, 0, 0.55f).r(R_FOREARM, 1.25f, 0, 0);     // a hand over the wound
        a.lhOnWeapon = 0;
        out.blend(a, downT, ALL_MASK, true, false);
        out.lhOnWeapon *= 1 - downT;
    }

    /** Layers the sampled action clip: limbs and head blend in, the torso is added on top of the gait. */
    private void applyAction(Pose out, AnimClip clip, float w) {
        out.blend(act, w, clip.mask & ~bit(TORSO), clip.drivesRoot, clip.drivesWeapon);
        if (!clip.drivesRoot) out.rootY += act.rootY * w;
        if ((clip.mask & bit(TORSO)) != 0) for (int k = 0; k < 3; k++) out.rot[TORSO * 3 + k] += act.rot[TORSO * 3 + k] * w;
    }

    /** Shoulder-centre origin of the aim frame in hips space. */
    private void shoulderOrigin(Pose p, float[] o) {
        o[0] = 0; o[1] = SHOULDER_Y; o[2] = 0;
        rotX(o, p.rx(TORSO)); rotZ(o, p.rz(TORSO)); rotY(o, p.ry(TORSO));
        o[1] += HIP_Y;
    }

    /** Aim frame (weapon space parent): hips * shoulder origin * facing * look pitch. */
    public void aimFrame(Pose p, float aimPitch, Mat4 hips, Mat4 out) {
        shoulderOrigin(p, v);
        out.set(hips).translate(v[0], v[1], v[2]).rotateY(-p.rootYaw).rotateX(Math.max(-1.2f, Math.min(1.2f, aimPitch)));
    }

    /** Weapon matrix: aim frame * weapon channel. Origin = firing grip, -z = muzzle direction. */
    public static void weaponFrame(Pose p, Mat4 aim, Mat4 out) {
        out.set(aim).translate(p.wpn[0], p.wpn[1], p.wpn[2]).rotateY(p.wpn[4]).rotateX(p.wpn[3]).rotateZ(p.wpn[5]);
    }

    private final float[] o = new float[3], h = new float[3];

    /** Converts an aim-frame point to torso space. */
    private void aimToTorso(Pose p, float pitch, float[] pt) {
        rotX(pt, pitch); rotY(pt, -p.rootYaw);
        pt[0] += o[0]; pt[1] += o[1] - HIP_Y; pt[2] += o[2];
        rotY(pt, -p.ry(TORSO)); rotZ(pt, -p.rz(TORSO)); rotX(pt, -p.rx(TORSO));
    }

    private void solveArms(Pose p, float pitch, float weight) {
        shoulderOrigin(p, o);
        // firing hand on the grip
        h[0] = p.wpn[0]; h[1] = p.wpn[1]; h[2] = p.wpn[2];
        aimToTorso(p, pitch, h);
        armIk(h[0] - SHOULDER_X, h[1] - SHOULDER_Y, h[2], ik);
        blendArm(p, R_UPPER_ARM, weight);
        // support hand: on the weapon (grip + clip offset) or free
        float on = p.lhOnWeapon;
        h[0] = on >= 0.5f ? p.wpn[6] : 0; h[1] = (on >= 0.5f ? p.wpn[7] : 0) + 0.5f; h[2] = (on >= 0.5f ? p.wpn[8] : 0) - gripSep;
        rotZ(h, p.wpn[5]); rotX(h, p.wpn[3]); rotY(h, p.wpn[4]);
        h[0] += p.wpn[0]; h[1] += p.wpn[1]; h[2] += p.wpn[2];
        float fx = on < 0.5f ? p.wpn[6] : -4.0f, fy = on < 0.5f ? p.wpn[7] : -7.0f, fz = on < 0.5f ? p.wpn[8] : -2.0f;
        h[0] = fx + (h[0] - fx) * on; h[1] = fy + (h[1] - fy) * on; h[2] = fz + (h[2] - fz) * on;
        aimToTorso(p, pitch, h);
        armIk(h[0] + SHOULDER_X, h[1] - SHOULDER_Y, h[2], ik);
        blendArm(p, L_UPPER_ARM, weight);
    }

    private void blendArm(Pose p, int upper, float w) {
        int fore = upper + 1, hand = upper + 2;
        p.rot[upper * 3] += (ik[1] - p.rot[upper * 3]) * w;
        p.rot[upper * 3 + 1] += (ik[0] - p.rot[upper * 3 + 1]) * w;
        p.rot[upper * 3 + 2] *= 1 - w;
        p.rot[fore * 3] += (ik[2] - p.rot[fore * 3]) * w;
        p.rot[fore * 3 + 1] *= 1 - w; p.rot[fore * 3 + 2] *= 1 - w;
        p.rot[hand * 3] *= 1 - w;
    }

    /** Foot IK: stance feet follow the real floor (kerbs, stairs), swing feet never dip into it. */
    private void plantFeet(Actor ac, Pose p, Ground ground) {
        float sy = (float) Math.sin(ac.yaw), cy = (float) Math.cos(ac.yaw), unit = VOX * scale;
        for (int side = 0; side < 2; side++) {
            int th = side == 0 ? L_THIGH : R_THIGH, sh = th + 1;
            float t = p.rx(th), s = p.rx(sh);
            float fwd = THIGH * (float) Math.sin(t) + SHIN * (float) Math.sin(t + s), down = THIGH * (float) Math.cos(t) + SHIN * (float) Math.cos(t + s);
            v[0] = 0; v[1] = 0; v[2] = -fwd;
            rotY(v, p.ry(th));
            v[0] += side == 0 ? -HIP_X : HIP_X;
            rotY(v, p.rootYaw);
            v[0] += p.rootX; v[2] += p.rootZ;
            float wx = ac.x + (cy * v[0] + sy * v[2]) * unit, wz = ac.z + (-sy * v[0] + cy * v[2]) * unit;
            float footH = p.rootY + HIP_Y - down;                       // voxels above the actor's floor
            float g = ground.top(wx, wz, ac.y);
            if (Float.isNaN(g)) continue;
            float floor = (g - ac.y - visY) / unit;                      // real floor relative to the actor's floor
            float want;
            if (footH < 0.7f) want = Math.max(-9f, Math.min(9f, floor)) + Math.max(0, footH);
            else want = Math.max(footH, floor + 0.3f);
            float delta = want - footH;
            if (Math.abs(delta) < 0.08f) continue;
            legIk(fwd, down - delta, ik);
            p.rot[th * 3] = ik[0];
            p.rot[sh * 3] = ik[1];
        }
    }
}
