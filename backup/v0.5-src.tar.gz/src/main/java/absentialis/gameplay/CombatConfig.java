package absentialis.gameplay;

import absentialis.engine.util.Json;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Combat and casualty tuning from {@code content/combat.json} (0.5): health-condition thresholds and their
 * effects, incapacitation eligibility, bleed-out and revival, hit-marker and killfeed timing, speech bubbles and
 * contextual cover. One instance, read once; systems ask it instead of carrying numbers of their own.
 */
public final class CombatConfig {
    /** The four health presentation conditions, in order of severity. */
    public enum Condition {
        FINE("Fine"), CAUTION("Caution"), INJURED("Injured"), CRITICAL("Critical");
        public final String label;
        Condition(String l) { label = l; }
    }

    // ---- health conditions
    public float caution = 0.70f, injured = 0.45f, critical = 0.22f;
    public final float[] speed = {1f, 0.92f, 0.76f, 0.52f}, sprintSpeed = {1f, 0.95f, 0.8f, 0f}, aimError = {1f, 1.08f, 1.25f, 1.55f}, blendRate = {1f, 0.85f, 0.65f, 0.48f}, animation = {0f, 0.34f, 0.68f, 1f};
    public final boolean[] sprint = {true, true, true, false};
    public final int[] colors = {0xFF7DBA5C, 0xFFE0C040, 0xFFE08A30, 0xFFD8483A};
    // ---- maximum health progression
    public int baseHealth = 100, perHerb = 10, healthCap = 200;
    // ---- incapacitation
    public float downChance = 0.2f, downChancePlayer = 0.45f, downChanceMate = 0.6f, overkill = 0.55f, bleedOut = 20f, downedHealth = 34, crawlSpeed = 0.55f, sidearmError = 2.2f, sidearmCooldown = 1.6f, helpCallEvery = 6f;
    public final Map<String, Float> downTypes = new HashMap<>();
    public final java.util.Set<String> fatalRegions = new java.util.HashSet<>();
    // ---- revival
    public float reviveTime = 4f, reviveRange = 1.9f, reviveHealth = 0.18f;
    public float aiUrgency = 1.6f, aiDistance = 0.045f, aiPressure = 1.8f, aiExposure = 1.2f, aiCover = 0.6f, aiOwnHealth = 1.4f, aiRoleCost = 0.5f, aiThreshold = 0.15f, aiMaxDistance = 34f, aiAbortSuppression = 0.75f;
    // ---- feedback
    public float markerLife = 0.28f, markerLifeKill = 0.5f, markerSize = 9, markerGap = 5;
    public final int[] markerColors = {0xFFFFFFFF, 0xFFF2D43A, 0xFFE23B2E};
    public float feedLife = 6.5f, feedFade = 0.6f, feedSlide = 0.18f;
    public int feedMax = 6;
    public float talkBase = 2.2f, talkPerChar = 0.045f, talkMaxDistance = 30, talkFadeFrom = 20, talkWrap = 190;
    public int talkMaxVisible = 6;
    public float coverReach = 0.62f, coverMaxSpeed = 1.4f, coverLean = 0.42f, coverAiLean = 0.46f;

    private static CombatConfig instance;

    public static synchronized CombatConfig get() {
        if (instance == null) instance = load();
        return instance;
    }

    /** The condition for a health value against a maximum. */
    public Condition condition(float hp, float maxHp) {
        float f = maxHp <= 0 ? 0 : hp / maxHp;
        return f > caution ? Condition.FINE : f > injured ? Condition.CAUTION : f > critical ? Condition.INJURED : Condition.CRITICAL;
    }

    public int color(Condition c) { return colors[c.ordinal()]; }

    /** Maximum health for a number of Yellow Herbs taken (capped). */
    public int maxHealth(int herbs) { return Math.min(healthCap, baseHealth + Math.max(0, herbs) * perHerb); }
    public int herbCap() { return Math.max(0, (healthCap - baseHealth) / Math.max(1, perHerb)); }

    public float downType(String kind) { return downTypes.getOrDefault(kind, 0.5f); }

    private static void floats(Map<String, Object> m, String key, float[] out) {
        List<Object> l = Json.list(m, key);
        for (int i = 0; i < out.length && i < l.size(); i++) out[i] = ((Number) l.get(i)).floatValue();
    }

    private static void colours(Map<String, Object> m, String key, int[] out) {
        List<Object> l = Json.list(m, key);
        for (int i = 0; i < out.length && i < l.size(); i++) out[i] = 0xFF000000 | Integer.parseInt(l.get(i).toString(), 16);
    }

    private static CombatConfig load() {
        CombatConfig c = new CombatConfig();
        c.downTypes.put("bullet", 1f); c.downTypes.put("melee", 0.8f); c.downTypes.put("blunt", 0.7f); c.downTypes.put("blast", 0.35f);
        c.downTypes.put("vehicle", 0.3f); c.downTypes.put("burn", 0f); c.downTypes.put("bleed", 0f);
        c.fatalRegions.add("head");
        try (InputStream in = CombatConfig.class.getResourceAsStream("/content/combat.json")) {
            if (in == null) { System.err.println("[Combat] content/combat.json missing - using built-in defaults"); return c; }
            Map<String, Object> root = Json.parseObject(new String(in.readAllBytes(), StandardCharsets.UTF_8));
            Map<String, Object> h = Json.obj(root, "health");
            c.caution = (float) Json.num(h, "caution", c.caution); c.injured = (float) Json.num(h, "injured", c.injured); c.critical = (float) Json.num(h, "critical", c.critical);
            floats(h, "speed", c.speed); floats(h, "sprintSpeed", c.sprintSpeed); floats(h, "aimError", c.aimError); floats(h, "blendRate", c.blendRate); floats(h, "animation", c.animation);
            colours(h, "colors", c.colors);
            List<Object> sp = Json.list(h, "sprint");
            for (int i = 0; i < 4 && i < sp.size(); i++) c.sprint[i] = Boolean.TRUE.equals(sp.get(i));
            Map<String, Object> mh = Json.obj(root, "maxHealth");
            c.baseHealth = Json.integer(mh, "base", c.baseHealth); c.perHerb = Json.integer(mh, "perHerb", c.perHerb); c.healthCap = Json.integer(mh, "cap", c.healthCap);
            Map<String, Object> d = Json.obj(root, "downed");
            c.downChance = (float) Json.num(d, "chance", c.downChance); c.downChancePlayer = (float) Json.num(d, "chancePlayer", c.downChancePlayer); c.downChanceMate = (float) Json.num(d, "chanceMate", c.downChanceMate);
            c.overkill = (float) Json.num(d, "overkill", c.overkill); c.bleedOut = (float) Json.num(d, "bleedOut", c.bleedOut); c.downedHealth = (float) Json.num(d, "health", c.downedHealth);
            c.crawlSpeed = (float) Json.num(d, "crawlSpeed", c.crawlSpeed); c.sidearmError = (float) Json.num(d, "sidearmError", c.sidearmError); c.sidearmCooldown = (float) Json.num(d, "sidearmCooldown", c.sidearmCooldown);
            c.helpCallEvery = (float) Json.num(d, "helpCallEvery", c.helpCallEvery);
            for (Map.Entry<String, Object> e : Json.obj(d, "types").entrySet()) if (e.getValue() instanceof Number n) c.downTypes.put(e.getKey(), n.floatValue());
            List<String> fr = Json.strList(d, "fatalRegions");
            if (!fr.isEmpty()) { c.fatalRegions.clear(); c.fatalRegions.addAll(fr); }
            Map<String, Object> r = Json.obj(root, "revive");
            c.reviveTime = (float) Json.num(r, "time", c.reviveTime); c.reviveRange = (float) Json.num(r, "range", c.reviveRange); c.reviveHealth = (float) Json.num(r, "health", c.reviveHealth);
            Map<String, Object> ai = Json.obj(r, "ai");
            c.aiUrgency = (float) Json.num(ai, "urgency", c.aiUrgency); c.aiDistance = (float) Json.num(ai, "distance", c.aiDistance); c.aiPressure = (float) Json.num(ai, "pressure", c.aiPressure);
            c.aiExposure = (float) Json.num(ai, "exposure", c.aiExposure); c.aiCover = (float) Json.num(ai, "cover", c.aiCover); c.aiOwnHealth = (float) Json.num(ai, "ownHealth", c.aiOwnHealth);
            c.aiRoleCost = (float) Json.num(ai, "roleCost", c.aiRoleCost); c.aiThreshold = (float) Json.num(ai, "threshold", c.aiThreshold); c.aiMaxDistance = (float) Json.num(ai, "maxDistance", c.aiMaxDistance);
            c.aiAbortSuppression = (float) Json.num(ai, "abortSuppression", c.aiAbortSuppression);
            Map<String, Object> hm = Json.obj(root, "hitmarker");
            c.markerLife = (float) Json.num(hm, "life", c.markerLife); c.markerLifeKill = (float) Json.num(hm, "lifeKill", c.markerLifeKill); c.markerSize = (float) Json.num(hm, "size", c.markerSize); c.markerGap = (float) Json.num(hm, "gap", c.markerGap);
            colours(hm, "colors", c.markerColors);
            Map<String, Object> kf = Json.obj(root, "killfeed");
            c.feedLife = (float) Json.num(kf, "life", c.feedLife); c.feedFade = (float) Json.num(kf, "fade", c.feedFade); c.feedSlide = (float) Json.num(kf, "slide", c.feedSlide); c.feedMax = Json.integer(kf, "max", c.feedMax);
            Map<String, Object> dl = Json.obj(root, "dialogue");
            c.talkBase = (float) Json.num(dl, "base", c.talkBase); c.talkPerChar = (float) Json.num(dl, "perChar", c.talkPerChar); c.talkMaxDistance = (float) Json.num(dl, "maxDistance", c.talkMaxDistance);
            c.talkFadeFrom = (float) Json.num(dl, "fadeFrom", c.talkFadeFrom); c.talkWrap = (float) Json.num(dl, "wrap", c.talkWrap); c.talkMaxVisible = Json.integer(dl, "maxVisible", c.talkMaxVisible);
            Map<String, Object> cv = Json.obj(root, "cover");
            c.coverReach = (float) Json.num(cv, "reach", c.coverReach); c.coverMaxSpeed = (float) Json.num(cv, "maxSpeed", c.coverMaxSpeed); c.coverLean = (float) Json.num(cv, "lean", c.coverLean); c.coverAiLean = (float) Json.num(cv, "aiLean", c.coverAiLean);
        } catch (Exception e) {
            System.err.println("[Combat] content/combat.json could not be read: " + e + " - using built-in defaults");
        }
        return c;
    }
}
