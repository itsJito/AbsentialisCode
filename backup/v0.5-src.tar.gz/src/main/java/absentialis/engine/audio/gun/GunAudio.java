package absentialis.engine.audio.gun;

import absentialis.engine.audio.gun.AcousticEnvironment.Acoustics;
import absentialis.engine.audio.gun.AcousticEnvironment.Geometry;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/**
 * The game's one door into gun audio (0.5, brief 17): firing code reports a round - who, with what, where, at what
 * rate of fire - and this turns it into a {@link ShotEvent} on the mixer's clock. It owns the profile library, the
 * scheduler and the gun bus, and the small amount of state that keeps consecutive shots from sounding the same.
 *
 * All of this runs on the game thread; the only thing that crosses to the audio thread is the finished event.
 */
public final class GunAudio {
    public final AudioMixer mixer = new AudioMixer();
    public final ShotEventScheduler scheduler = new ShotEventScheduler(AudioMixer.RATE);
    public WeaponAudioProfile.Library library = new WeaponAudioProfile.Library();
    /** Rays cast for the listener's own weapon, for a nearby shooter and for a far one. */
    public int raysLocal = 14, raysNear = 10, raysFar = 6;

    /** Per shooter: the last two takes used, so a take is never repeated back to back (nor A-B-A when there are three). */
    private static final class Bag { int last = -1, prev = -1, lastFar = -1, lastBody = -1; }
    private final Map<Integer, Bag> bags = new HashMap<>();
    private long serial;
    /** Shots posted, and the last event built (diagnostics and tests). */
    public int posted;
    public ShotEvent last;

    public void load(Path assets) {
        library = WeaponAudioProfile.load(assets);
        mixer.layers.handling = library.handling;
        for (String p : library.problems) System.err.println("[Audio] guns: " + p);
        System.out.println("[Audio] guns: " + library.profiles.size() + " weapon profiles, " + library.sets.size() + " recorded sets, " + library.handling.size() + " handling samples, " + (library.bytes >> 20) + " MB decoded");
    }

    /** True when this weapon is rendered by the layered system (it has a profile and its recordings are loaded). */
    public boolean handles(String weaponId) { return library.has(weaponId); }

    private static int pick(long seed, int n, int avoidA, int avoidB) {
        if (n <= 1) return 0;
        int k = (int) Math.floorMod(seed >>> 17, (long) n);
        for (int i = 0; i < n; i++) {
            int c = (k + i) % n;
            if (c == avoidA) continue;
            if (n > 2 && c == avoidB) continue;
            return c;
        }
        return k;
    }

    /**
     * One round fired. Returns the event posted, or null when the weapon has no usable profile (the caller then
     * keeps whatever it did before). The listener position is the engine's.
     */
    public ShotEvent shot(Geometry g, String weaponId, int shooterId, float rpm, float x, float y, float z, float dirX, float dirZ, boolean suppressed, boolean local,
                          float lx, float ly, float lz, float lyaw) {
        WeaponAudioProfile p = library.profiles.get(weaponId);
        if (p == null || p.set == null || !p.set.usable()) return null;
        float dx = x - lx, dy = y - ly, dz = z - lz, d2 = dx * dx + dy * dy + dz * dz;
        if (d2 > p.maxDistance * p.maxDistance) return null;                       // out of earshot: nothing to render
        Acoustics a = mixer.environment.analyse(g, x, y, z, dirX, dirZ, lx, ly, lz, lyaw, p.refDistance, local ? raysLocal : d2 < 60 * 60 ? raysNear : raysFar, AudioMixer.RATE);
        if (local) { a.pan = 0; a.travel = 0; a.distance = 0; a.directGain = 1; a.directLowpass = 0; }
        long[] at = scheduler.schedule(shooterId, weaponId, rpm, mixer.clock());
        long seed = (++serial) * 0x9E3779B97F4A7C15L ^ ((long) shooterId << 32) ^ weaponId.hashCode();
        float[] v = ShotEvent.vary(seed, p.varRate, p.varDb);
        Bag b = bags.computeIfAbsent(shooterId, k -> new Bag());
        int take = pick(seed, p.set.takes(), b.last, b.prev);
        int far = pick(seed >>> 7, Math.max(1, p.set.distant.size()), b.lastFar, -1);
        // the low band of one take under the high band of another is still this weapon, and doubles the shots it can make
        int body = pick(seed >>> 23, p.set.takes(), b.lastBody, -1);
        b.prev = b.last; b.last = take; b.lastFar = far; b.lastBody = body;
        ShotEvent e = new ShotEvent(weaponId, p, shooterId, (int) at[1], at[0], x, y, z, dirX, dirZ, suppressed, local, seed, take, body, far, v[0], v[1], a);
        if (!mixer.post(e)) return null;
        posted++;
        last = e;
        return e;
    }

    /** The handling sample a reload cue maps to for a weapon family (rifle, pistol, shotgun), or null. */
    public String cue(String family, String cue) {
        Map<String, String> m = library.cues.get(family);
        String s = m == null ? null : m.get(cue);
        return s != null && library.handling.containsKey(s) ? s : null;
    }

    public void forget() { bags.clear(); scheduler.clear(); }
}
