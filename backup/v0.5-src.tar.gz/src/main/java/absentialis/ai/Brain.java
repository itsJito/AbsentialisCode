package absentialis.ai;

import absentialis.entity.Actor;
import absentialis.entity.Physics;
import absentialis.scene.Raid;
import absentialis.world.MapData;

/**
 * Agent behaviour (iteration P6 / P8).
 *
 * Shared by everyone: a vision cone limited by distance, light, weather, stance and movement; hearing
 * through attenuated, occluded sound events; and a memory that stores a last-known position with a
 * timestamp, a confidence and an uncertainty radius that grows while the target is unseen - agents
 * act on where they think something is, never on the player's real coordinates.
 *
 * Human factions run four distinct doctrines on top of that:
 *   MERC     disciplined fire teams - suppress, flank, radio for reinforcements, hold their asset,
 *            fall back in order when outmatched, strip weapons from the dead.
 *   BANDIT   predatory and loud - lurk on routes, size the target up, extort the weak, rush, and
 *            break quickly when it goes wrong; rifle through corpses in seconds.
 *   MILITARY cordon troops - fixed patrol routes and posts, cover and peek, warn before enforcing
 *            a restricted area, call in support, never chase beyond the perimeter.
 *   LONER    cautious scavengers - neutral by default, back away from trouble, search containers,
 *            ask for help, fight only when cornered or when one of their own is hit.
 *
 * Infected archetypes (regular, fast, fat, giant) share one ecology and telegraph every special.
 */
public final class Brain {
    private Brain() {}

    /** Archetype tuning: speed, hp, melee damage, sight range, hearing multiplier, fov (cos). */
    public record Arch(String id, float speed, float runSpeed, float hp, float melee, float sight, float hearing, float fovCos, boolean infected) {}

    public static final Arch[] ARCHS = {
            new Arch("rifleman", 1.6f, 4.6f, 100, 0, 70, 1.0f, 0.45f, false),
            new Arch("marksman", 1.4f, 4.2f, 90, 0, 110, 0.9f, 0.6f, false),
            new Arch("shotgunner", 1.7f, 4.8f, 110, 0, 45, 1.0f, 0.4f, false),
            new Arch("walker", 0.9f, 1.6f, 90, 14, 16, 1.3f, 0.3f, true),       // Regular
            new Arch("sprinter", 1.4f, 6.4f, 55, 10, 26, 1.4f, 0.2f, true),     // Fast
            new Arch("boomer", 0.8f, 1.3f, 260, 0, 16, 1.0f, 0.3f, true),       // Fat
            new Arch("tank", 1.2f, 3.0f, 1400, 48, 30, 0.9f, 0.3f, true),       // Giant
            new Arch("shambler", 0.7f, 1.1f, 230, 22, 14, 1.2f, 0.3f, true),    // legacy variants (console spawn only)
            new Arch("screecher", 1.0f, 2.0f, 70, 8, 30, 1.6f, 0.0f, true),
    };
    /** The four infected archetypes that populate the Zone. */
    public static final String[] INFECTED = {"walker", "sprinter", "boomer", "tank"};

    public static Arch arch(String id) { for (Arch a : ARCHS) if (a.id.equals(id)) return a; return ARCHS[0]; }

    public static String displayName(String archetype) {
        return switch (archetype) { case "walker" -> "Regular"; case "sprinter" -> "Fast"; case "boomer" -> "Fat"; case "tank" -> "Giant"; default -> archetype; };
    }

    // ------------------------------------------------------------------ doctrines
    public enum Doctrine { MERC, BANDIT, MILITARY, LONER }

    /** leash = how far from home they will fight; fightDist = preferred engagement range. */
    public record Doc(Doctrine d, float leash, float morale, float risk, float fightDist, float breakAt, boolean cover) {}

    private static final Doc MERC = new Doc(Doctrine.MERC, 46, 0.95f, 0.55f, 18, 0.25f, true);
    private static final Doc BANDIT = new Doc(Doctrine.BANDIT, 70, 0.60f, 0.75f, 10, 0.45f, false);
    private static final Doc MILITARY = new Doc(Doctrine.MILITARY, 34, 0.90f, 0.40f, 22, 0.20f, true);
    private static final Doc LONER = new Doc(Doctrine.LONER, 40, 0.55f, 0.15f, 16, 0.50f, true);

    public static Doc doc(String faction) {
        return switch (faction) { case "mercenaries" -> MERC; case "raiders" -> BANDIT; case "military" -> MILITARY; default -> LONER; };
    }

    /** Sets the doctrine's starting morale and risk tolerance on a freshly spawned human. */
    public static void initHuman(Actor a) { Doc d = doc(a.faction); a.morale = d.morale(); a.risk = d.risk(); }

    // ------------------------------------------------------------------ hostility
    /** Hostility from the diplomatic matrix + player standing + observed evidence. */
    public static boolean hostile(Raid r, Actor a, Actor b) {
        if (a.faction.equals(b.faction)) return false;
        if (a.infected() || b.infected()) return true;
        // the player's squadmates stand exactly where the player stands with everyone
        if ("player".equals(b.faction)) return a.hostileToPlayer;
        if ("player".equals(a.faction)) return b.hostileToPlayer;
        String x = a.faction, y = b.faction;
        // The cordon suppresses bandits; bandits prey on loners and probe the contractors' sites.
        // Military and mercenaries keep an uneasy truce; loners have no standing feud with either.
        return pair(x, y, "military", "raiders") || pair(x, y, "survivors", "raiders") || pair(x, y, "raiders", "mercenaries");
    }

    private static boolean pair(String a, String b, String p, String q) { return a.equals(p) && b.equals(q) || a.equals(q) && b.equals(p); }

    /** Initial disposition toward the player for this raid, from standing. */
    public static boolean initialHostility(String faction, float rep) {
        switch (faction) {
            case "military": return rep < -10;
            case "survivors": return rep < -25;
            case "raiders": return rep < 30;
            case "mercenaries": return rep < 20;
            default: return true;
        }
    }

    // ------------------------------------------------------------------ perception
    /** A heard sound: memory update + reaction. Called by Raid.emitSound for agents in range. */
    public static void hear(Raid r, Actor a, float sx, float sy, float sz, float loudness, String category, int sourceId) {
        if (a.dead || a.id == sourceId) return;
        if (a.mate()) { if (!"engage".equals(a.state)) { float dd = a.distXZ(sx, sz); remember(r, a, sx, sy, sz, Math.min(1, loudness) * 0.5f, Math.max(2, dd * 0.15f)); a.alertness = Math.min(1, a.alertness + loudness * 0.5f); } return; }
        // sleepers miss quiet sounds; a loud one wakes them and they stay up for a while
        if (absentialis.sim.Agents.asleep(a.routine) && r.time > a.wakeUntil) { if (loudness < 0.45f) return; a.wakeUntil = r.time + 90; }
        float conf = Math.min(1f, loudness);
        // positional uncertainty grows with distance and shrinks with loudness
        float d = a.distXZ(sx, sz), err = d * 0.12f * (1.2f - conf);
        float ex = sx + (r.rng.nextFloat() - 0.5f) * err * 2, ez = sz + (r.rng.nextFloat() - 0.5f) * err * 2;
        if (conf >= a.memConfidence * 0.7f || r.time - a.memTime > 6) remember(r, a, ex, sy, ez, conf * 0.6f, Math.max(1.5f, err));
        a.alertness = Math.min(1f, a.alertness + conf * 0.6f);
        if (a.infected()) {
            if ("screech".equals(category) || "shriek".equals(category)) a.alertness = 1;
            if (!"engage".equals(a.state)) setState(a, "investigate");
            return;
        }
        a.memConfirmed = false;
        if ("engage".equals(a.state) || "flee".equals(a.state) || "retreat".equals(a.state) || "extort".equals(a.state) || "warn".equals(a.state)) return;
        Doc dc = doc(a.faction);
        boolean combatNoise = category.startsWith("shot") || category.equals("explosion") || category.equals("shout") || category.equals("screech") || category.equals("roar");
        // an ally's voice is not a disturbance: what it says arrives through the squad
        Actor src = r.actor(sourceId);
        if (src != null && !src.isPlayer && src.faction.equals(a.faction) && (category.equals("speech") || category.equals("shout") || category.equals("radio_chatter") || category.equals("reload") || category.equals("step"))) return;
        if ("search".equals(a.state) || "alert".equals(a.state)) {
            // already hunting: a new sound redirects the hunt instead of restarting it
            Raid.Squad hs = r.squad(a);
            if (hs != null && conf > 0.25f) hs.mind.report(r, a, ex, sy, ez, 0, 0, hs.mind.targetId, false, conf * 0.6f);
            a.hasSearch = false; a.searchX = ex; a.searchZ = ez; a.hasSearch = true; a.searchAt = r.time;
            if ("alert".equals(a.state)) setState(a, "search");
            return;
        }
        // gunfire and explosions mean a hostile is about (threat aware); anything else is only something unexplained (suspicious)
        a.awareLevel = combatNoise ? Tactics.THREAT_AWARE : Math.max(a.awareLevel, Tactics.SUSPICIOUS);
        // loners move away from gunfire that is not on top of them; everyone else goes to look
        if (dc.d() == Doctrine.LONER && combatNoise && d > 14) { setState(a, "avoid"); return; }
        setState(a, "investigate");
    }

    static void remember(Raid r, Actor a, float x, float y, float z, float conf, float err) {
        a.memX = x; a.memY = y; a.memZ = z; a.memTime = r.time; a.memConfidence = conf; a.memErr = err;
    }

    static void setState(Actor a, String s) { if (!a.state.equals(s)) { a.state = s; a.stateTime = 0; a.hasGoal = false; a.hasCover = false; } }

    /** Sight range of a against o right now: light, weather, stance and movement all matter. */
    public static float sightRange(Raid r, Actor a, Arch ar, Actor o) {
        float light = r.world.brightness(o.x, o.y + 1, o.z, r.daylight());
        if (o.isPlayer && (r.playerFlashlight || r.playerLaser)) light = 1;   // a torch or a visible laser gives you away in the dark
        if (o.light || r.time < o.flashUntil || o.isPlayer && r.time - r.lastPlayerShot < 0.35f) light = 1;   // so does anyone's torch, and every muzzle flash
        if (a.light && a.dist(o) < 20) light = Math.max(light, 0.75f);                                      // the observer's own torch lights what is close
        if (absentialis.sim.Agents.asleep(a.routine) && r.time > a.wakeUntil) return 2.2f;                  // asleep: only what trips over them
        float stance = o.crouch ? 0.6f : 1f;
        float moving = (Math.abs(o.vx) + Math.abs(o.vz)) > 0.5f ? 1.25f : 0.85f;
        float weather = 1 - 0.3f * r.rain() - 0.25f * r.fogAt(o.x, o.z);
        return ar.sight * (0.35f + 0.65f * light) * stance * moving * weather * r.difficultySight();
    }

    /** Sight: awareness accumulates while a hostile is visible; returns the confirmed target or null. */
    private static Actor look(Raid r, Actor a, Arch ar, float dt) {
        Actor best = null;
        float bestScore = 0;
        if (r.time < a.blindUntil) { a.awareness = Math.max(0, a.awareness - dt); return null; }   // flashed: nothing to see
        float fx = (float) -Math.sin(a.yaw), fz = (float) -Math.cos(a.yaw);
        for (Actor o : r.nearby(a.x, a.z, ar.sight * 1.2f)) {
            if (o == a || o.dead || !hostile(r, a, o) && !(o.isPlayer && !a.infected() && !a.hostileToPlayer && a.sawPlayerAggress)) continue;
            float dx = o.x - a.x, dz = o.z - a.z, d = (float) Math.sqrt(dx * dx + dz * dz);
            if (d < 0.01f) continue;
            float cos = (dx * fx + dz * fz) / d;
            boolean close = d < 3.2f;
            if (!close && cos < ar.fovCos) continue;
            float range = sightRange(r, a, ar, o);
            if (d > range && !close) continue;
            if (!Physics.los(r.world, a.x, a.eyeY(), a.z, o.x, o.eyeY() - 0.2f, o.z)) continue;
            float score = (1 - d / Math.max(1, range)) + (o.isPlayer ? 0.2f : 0);
            if (o.vital != absentialis.entity.Vital.ACTIVE) score *= 0.35f;          // someone on the ground is not the threat
            if (score > bestScore) { bestScore = score; best = o; }
        }
        if (best == null) { a.awareness = Math.max(0, a.awareness - dt * 0.35f); return null; }
        float d = a.dist(best);
        float rate = (a.alertness > 0.5f ? 2.2f : 0.9f) * (d < 8 ? 3 : d < 20 ? 1.4f : 0.7f);
        a.awareness = Math.min(1.2f, a.awareness + dt * rate);
        remember(r, a, best.x, best.y, best.z, Math.min(1, a.awareness), 0.3f);
        a.lastSeenTime = r.time;
        if (a.awareness >= 1f) { a.targetId = best.id; return best; }
        // partial: turn toward the suspicious shape, and once it has been there long enough, go and see what it is
        a.yaw = turn(a.yaw, (float) Math.atan2(-(best.x - a.x), -(best.z - a.z)), dt * 1.5f);
        if (a.awareness > 0.5f && "idle".equals(a.state) && !a.infected() && !a.mate()) {
            a.awareLevel = Tactics.SUSPICIOUS;
            a.memConfirmed = false;
            setState(a, "investigate");
            if (r.time - a.lastSay > 10) r.say(a, r.rng.chance(0.5) ? "Something moved over there." : "Did you see that?", "bark_search");
        }
        return null;
    }

    // ------------------------------------------------------------------ update
    public static void update(Raid r, Actor a, float dt) {
        if (a.dead) return;
        Arch ar = arch(a.archetype);
        a.stateTime += dt;
        a.fireCooldown -= dt;
        a.specialTimer -= dt;
        a.alertness = Math.max(0, a.alertness - dt * 0.03f);
        if (a.memConfidence > 0) a.memConfidence = Math.max(0, a.memConfidence - dt * 0.02f);
        // unseen targets move: the remembered position gets vaguer every second
        if (r.time - a.lastSeenTime > 0.5f) a.memErr = Math.min(14, a.memErr + dt * 0.7f);
        if (a.tier == 1) { regional(r, a, ar, dt); return; }
        Actor tgt = look(r, a, ar, dt);
        if (a.vital != absentialis.entity.Vital.ACTIVE) { r.casualty.downedBrain(a, tgt, dt); return; }
        if (ar.infected) infected(r, a, ar, tgt, dt);
        else {
            // a squad with someone down weighs a rescue before anything else gets this agent's tick
            Raid.Squad rsq = r.squad(a);
            if (rsq != null && rsq.mind.wounded > 0 || a.mate() && r.player.downed()) {
                if (rsq != null) { r.casualty.assign(rsq, r.squadMembers(a), a.mate()); if (r.casualty.rescue(a, rsq, dt)) return; }
            }
            if ("medic".equals(a.tacRole)) a.tacRole = "";
            if (a.mate()) squadmate(r, a, ar, tgt, dt);
            else human(r, a, ar, tgt, dt);
        }
        a.crouch &= !ar.infected;
    }

    /** Regional tier (loaded district, outside the engagement): coarse travel toward goals, no perception or combat. */
    private static void regional(Raid r, Actor a, Arch ar, float dt) {
        if (a.hasOrder && r.time < a.orderUntil) {
            if (a.distXZ(a.orderX, a.orderZ) > 6) { goTo(r, a, a.orderX, a.orderZ, ar.runSpeed * 0.8f, dt); return; }
            a.hasOrder = false;
            remember(r, a, a.orderX, a.y, a.orderZ, 0.5f, 6);
            setState(a, "investigate");
        }
        if ("investigate".equals(a.state) && r.time - a.memTime < 40) {
            if (a.distXZ(a.memX, a.memZ) > 4) goTo(r, a, a.memX, a.memZ, ar.speed * 1.2f, dt); else stop(a);
            return;
        }
        if (!"idle".equals(a.state) && a.stateTime > 20) setState(a, "idle");
        idleMove(r, a, ar, dt);
    }

    // ================================================================== infected
    private static void infected(Raid r, Actor a, Arch ar, Actor tgt, float dt) {
        if (tgt != null) setState(a, "engage");
        boolean fast = "sprinter".equals(a.archetype) || "screecher".equals(a.archetype), fat = "boomer".equals(a.archetype), giant = "tank".equals(a.archetype);
        // the giant is never a surprise: its footfalls carry and shake the ground
        if (giant && (Math.abs(a.vx) + Math.abs(a.vz)) > 0.4f) { a.talkTimer -= dt; if (a.talkTimer <= 0) { a.talkTimer = 0.95f; r.emitSound(a.x, a.y, a.z, 46, "stomp", a.id, false); r.quake(a.x, a.z, 26, 0.22f); } }
        switch (a.state) {
            case "engage" -> {
                Actor t = r.actor(a.targetId);
                if (t == null || t.dead) { setState(a, "search"); break; }
                boolean seen = tgt == t;
                if (!seen && r.time - a.memTime > 2.5f) { setState(a, "search"); break; }
                float d = a.dist(t);
                a.yaw = turn(a.yaw, (float) Math.atan2(-(a.memX - a.x), -(a.memZ - a.z)), dt * 6);
                float speed = ar.runSpeed;
                float gx = a.memX, gz = a.memZ;
                if (fast) {
                    // loud vocal cue first, then the rush; they tire quickly and come in on a flank
                    if (a.stateTime < 0.05f && a.specialTimer <= 0) { a.specialTimer = 12; r.telegraph(a, "shriek", 0.7f); a.fireCooldown = 0.7f; }
                    if (r.telegraphing(a, "shriek")) { stop(a); break; }
                    if (a.stateTime > 7) speed = ar.speed * 1.5f;
                    if (d > 7) { float side = (a.id & 1) == 0 ? 1 : -1, ang = (float) Math.atan2(a.x - t.x, a.z - t.z) + side * 0.9f; gx = t.x + (float) Math.sin(ang) * 5.5f; gz = t.z + (float) Math.cos(ang) * 5.5f; }
                }
                if (fat) {
                    // telegraphed bile: a one-second retch, then a pool where the target WAS standing
                    if (seen && d > 3.2f && d < 10 && a.specialTimer <= 0 && !r.telegraphing(a, "retch")) { a.specialTimer = 7.5f; a.goalX = t.x; a.goalZ = t.z; a.memY = t.y; r.telegraph(a, "retch", 1.0f); a.burstLeft = 1; }
                    if (r.telegraphing(a, "retch")) { stop(a); break; }
                    if (a.burstLeft > 0) { a.burstLeft = 0; r.spit(a, a.goalX, a.memY, a.goalZ); }
                    if (d < 2.4f && !r.telegraphing(a, "swell")) { if (a.suppressUntil <= 0) { a.suppressUntil = r.time + 0.9f; r.telegraph(a, "swell", 0.9f); } }
                    if (a.suppressUntil > 0 && r.time >= a.suppressUntil) { r.explodeBoomer(a, null); return; }
                    if (a.suppressUntil > 0) { stop(a); break; }
                }
                if (giant) {
                    if (seen && d > 10 && d < 30 && a.specialTimer <= 0 && !r.telegraphing(a, "throw")) { a.specialTimer = 9; a.goalX = t.x; a.goalZ = t.z; a.memY = t.y; r.telegraph(a, "throw", 1.3f); a.burstLeft = 1; }
                    if (r.telegraphing(a, "throw")) { stop(a); break; }
                    if (a.burstLeft > 0) { a.burstLeft = 0; r.hurl(a, a.goalX, a.memY, a.goalZ); }
                    if (d > 5 && d <= 10 && a.specialTimer <= 0) { a.specialTimer = 8; a.suppressUntil = r.time + 2.6f; r.telegraph(a, "charge", 1.1f); }
                    if (r.telegraphing(a, "charge")) { stop(a); break; }
                    if (r.time < a.suppressUntil) speed = 8.5f;                                   // the charge itself
                    if (a.stuckTime > 0.15f) r.smash(a);                                          // light cover does not stop it
                }
                if (d < 1.6f + ar.melee * 0.01f + (giant ? 0.6f : 0) && a.fireCooldown <= 0 && ar.melee > 0) {
                    a.fireCooldown = giant ? 1.8f : 1.1f;
                    if (a.anim != null) a.anim.play(giant ? "giant_smash" : "inf_attack", 0);
                    r.melee(a, t, ar.melee * r.difficultyDamage());
                }
                if (d > (fat ? 2.0f : 1.1f)) goTo(r, a, gx, gz, speed, dt); else stop(a);
            }
            case "investigate" -> {
                if (r.time - a.memTime > 30) { setState(a, a.awareLevel >= Tactics.THREAT_AWARE ? "alert" : "idle"); break; }
                float d = a.distXZ(a.memX, a.memZ);
                if (d > 2.2f) goTo(r, a, a.memX, a.memZ, ar.speed * 1.3f, dt);
                else { stop(a); a.yaw += dt * 1.2f; if (a.stateTime > 10) setState(a, "idle"); }
            }
            case "search" -> {
                float d = a.distXZ(a.memX, a.memZ);
                if (d > 2) goTo(r, a, a.memX, a.memZ, ar.speed * 1.2f, dt); else { stop(a); a.yaw += dt * 1.6f; }
                if (a.stateTime > 14) setState(a, "idle");
            }
            default -> {
                // ecology: the regular dead drift to unattended corpses and gather there (group pressure builds on bodies)
                if ("walker".equals(a.archetype)) {
                    a.lootTimer -= dt;
                    if (a.lootTimer <= 0) {
                        a.lootTimer = 4 + r.rng.nextFloat() * 4;
                        Actor c = r.nearestCorpse(a.x, a.z, 26);
                        if (c != null && a.distXZ(c.x, c.z) > 3) { a.goalX = c.x + r.rng.range(-1.5f, 1.5f); a.goalZ = c.z + r.rng.range(-1.5f, 1.5f); a.hasGoal = true; a.stateTime = 0; a.thinkTimer = 0; }
                    }
                }
                idleMove(r, a, ar, dt);
            }
        }
    }

    // ================================================================== humans
    private static void human(Raid r, Actor a, Arch ar, Actor tgt, float dt) {
        Doc dc = doc(a.faction);
        Raid.Squad sq = r.squad(a);
        a.morale = Math.min(dc.morale(), a.morale + dt * 0.012f);
        if (tgt != null) contact(r, a, dc, sq, tgt);
        else if (sq != null && ("idle".equals(a.state) || "investigate".equals(a.state) || "alert".equals(a.state)) && r.time - sq.mind.tTime < 6
                && !(sq.extortDone && !sq.bloodied) && !a.paidOff && a.distXZ(sq.mind.tx, sq.mind.tz) < 70 && Tactics.receive(r, a, sq)) {
            // a squadmate's report has reached this member: a position with error, held as hearsay until seen
            if (dc.d() != Doctrine.LONER) setState(a, sq.mind.tConfirmed ? "engage" : "search");
        }
        if ("idle".equals(a.state) && a.alertness < 0.2f) a.awareLevel = Tactics.UNAWARE;
        // self-preservation and morale
        if (!"flee".equals(a.state) && !"retreat".equals(a.state)) {
            boolean hurt = a.hp < a.maxHp * 0.3f, broken = a.morale < dc.breakAt();
            boolean outmatched = sq != null && sq.initial >= 2 && sq.alive <= Math.max(1, Math.round(sq.initial * 0.35f)) && "engage".equals(a.state);
            if (dc.d() == Doctrine.MERC && (outmatched || hurt)) { setState(a, "retreat"); r.say(a, "Falling back!", "shout"); }
            else if (dc.d() == Doctrine.MILITARY && hurt && r.rng.chance(dt * 0.6)) setState(a, "retreat");
            else if ((dc.d() == Doctrine.BANDIT || dc.d() == Doctrine.LONER) && (broken || hurt) && r.rng.chance(dt * 2)) { setState(a, "flee"); if (dc.d() == Doctrine.BANDIT) r.say(a, "Screw this - run!", "shout"); }
        }
        switch (a.state) {
            case "engage" -> Tactics.engage(r, a, ar, dc, sq, tgt, dt);
            case "alert" -> Tactics.alert(r, a, ar, dc, sq, dt);
            case "extort" -> extort(r, a, ar, sq, dt);
            case "warn" -> warn(r, a, ar, sq, dt);
            case "investigate" -> {
                if (r.time - a.memTime > 30) { setState(a, "idle"); break; }
                float d = a.distXZ(a.memX, a.memZ);
                float sp = dc.d() == Doctrine.MILITARY || dc.d() == Doctrine.MERC ? ar.runSpeed * 0.75f : ar.speed * 1.2f;
                if (r.night() && !a.light) sp *= 0.8f;
                a.light = r.night() && dc.d() != Doctrine.BANDIT;
                if (d > Math.max(2.2f, a.memErr * 0.6f)) goTo(r, a, a.memX, a.memZ, sp, dt);
                else {
                    stop(a); a.yaw += dt * 1.2f;
                    if (evidence(r, a, dc, dt)) break;
                    // nothing here: someone who came because of gunfire stays wary; someone who came for a noise goes back to work
                    if (a.stateTime > 10) { if (a.awareLevel >= Tactics.THREAT_AWARE) { if (sq != null) sq.mind.alertUntil = Math.max(sq.mind.alertUntil, r.time + 90); setState(a, "alert"); } else { a.awareLevel = Tactics.UNAWARE; setState(a, "idle"); } }
                }
                a.crouch = dc.d() == Doctrine.BANDIT && d < 12;
            }
            case "search" -> Tactics.search(r, a, ar, dc, sq, dt);
            case "loot" -> loot(r, a, ar, dc, dt);
            case "avoid" -> {
                // loners put distance and a wall between themselves and trouble
                float ax = a.x - a.memX, az = a.z - a.memZ, l = (float) Math.sqrt(ax * ax + az * az);
                if (!a.hasGoal) { float k = l < 0.1f ? 0 : 22 / l; a.goalX = a.x + ax * k * 0.6f + (a.homeX - a.x) * 0.4f; a.goalZ = a.z + az * k * 0.6f + (a.homeZ - a.z) * 0.4f; a.hasGoal = true; }
                goTo(r, a, a.goalX, a.goalZ, ar.runSpeed * 0.8f, dt);
                a.crouch = a.stateTime > 4;
                if (a.stateTime > 9 || a.distXZ(a.goalX, a.goalZ) < 2) { a.crouch = false; setState(a, "idle"); }
            }
            case "retreat" -> {
                // ordered withdrawal toward the post: move, turn, cover the squad, never rout
                float d = a.distXZ(a.homeX, a.homeZ);
                boolean coverTurn = ((int) (a.stateTime / 1.6f) & 1) == 1 && tgt != null;
                if (coverTurn) { stop(a); a.yaw = turn(a.yaw, (float) Math.atan2(-(tgt.x - a.x), -(tgt.z - a.z)), dt * 7); if (a.weapon != null && a.fireCooldown <= 0) r.npcFire(a, tgt, dt); }
                else if (d > 5) goTo(r, a, a.homeX, a.homeZ, ar.runSpeed, dt); else stop(a);
                if (a.stateTime > 14 || d <= 5 && tgt == null && a.stateTime > 5) { a.hp = Math.min(a.maxHp, a.hp + 12); a.morale = Math.max(a.morale, 0.6f); setState(a, "idle"); }
            }
            case "flee" -> {
                if (!a.hasGoal) { a.goalX = a.homeX + (r.rng.nextFloat() - 0.5f) * 50; a.goalZ = a.homeZ + (r.rng.nextFloat() - 0.5f) * 50; a.hasGoal = true; }
                goTo(r, a, a.goalX, a.goalZ, ar.runSpeed, dt);
                if (a.stateTime > 12) { setState(a, "idle"); a.hp = Math.min(a.maxHp, a.hp + 10); a.morale = Math.max(a.morale, dc.breakAt() + 0.15f); }
            }
            default -> idleHuman(r, a, ar, dc, sq, dt);
        }
    }

    private static boolean canLoot(Doc dc) { return dc.d() == Doctrine.MERC || dc.d() == Doctrine.BANDIT; }

    /** First confirmed sight of a hostile: doctrine decides between attack, hold-up, warning and withdrawal. */
    private static void contact(Raid r, Actor a, Doc dc, Raid.Squad sq, Actor tgt) {
        if ("flee".equals(a.state) || "retreat".equals(a.state)) return;
        if (a.paidOff && tgt.isPlayer && !a.hostileToPlayer) return;
        if (sq != null) { sq.tx = tgt.x; sq.tz = tgt.z; sq.targetId = tgt.id; sq.contactTime = r.time; }
        if ("engage".equals(a.state) || "extort".equals(a.state)) return;
        float d = a.dist(tgt);
        switch (dc.d()) {
            case BANDIT -> {
                // predators size the prey up: rob a lone, quiet target; back off from a strong one
                int mine = sq == null ? 1 : sq.alive;
                float theirs = r.strengthNear(tgt, a.faction);
                if (tgt.isPlayer && sq != null && !sq.extortDone && mine >= 2 && d > 5 && !r.playerAiming && r.time - r.lastPlayerShot > 6) {
                    sq.extortDone = true;
                    sq.extortUntil = r.time + 8;
                    r.say(a, "Hands where we can see them! " + Raid.EXTORT_PRICE + " coins and you walk.", "shout");
                    for (Actor m : r.squadMembers(a)) { setState(m, "extort"); m.targetId = tgt.id; }
                    return;
                }
                if (mine < theirs * 0.8f && d > 9) { a.morale -= 0.15f; setState(a, "flee"); r.say(a, "Too many of them!", "shout"); return; }
                if (r.rng.chance(0.4)) r.say(a, r.rng.chance(0.5) ? "Fresh meat!" : "Get 'em!", "bark_taunt");
            }
            case LONER -> {
                // avoid the fight unless it is on top of us or they hurt one of ours
                if (d > 10 && a.hp >= a.maxHp * 0.95f && (sq == null || !sq.bloodied)) { setState(a, "avoid"); return; }
            }
            case MERC -> {
                if (sq != null && !sq.backupCalled) { sq.backupCalled = true; r.say(a, "Contact! Requesting support on my position.", "radio_chatter"); r.dispatch(a.faction, tgt.x, tgt.z, a.squad, "reinforce"); }
            }
            case MILITARY -> { }
        }
        setState(a, "engage");
        Tactics.sighted(r, a, sq, tgt);
    }

    /** Cover and peek (the player's squadmates): find a spot with a block between us and the threat, duck, pop up to shoot. */
    private static void cover(Raid r, Actor a, Arch ar, float dt, boolean seen, float want, boolean leashed) {
        float d = a.distXZ(a.memX, a.memZ);
        if (!a.hasCover || r.time > a.coverUntil) {
            a.hasCover = findCover(r, a, a.memX, a.memY, a.memZ);
            a.coverUntil = r.time + (a.hasCover ? 7 : 2.5f);
        }
        if (a.hasCover) {
            if (a.distXZ(a.coverX, a.coverZ) > 0.9f) { goTo(r, a, a.coverX, a.coverZ, ar.runSpeed * 0.8f, dt); return; }
            stop(a);
            float cycle = (r.time + a.id * 0.37f) % 3.4f;
            a.crouch = cycle > 1.7f || !seen && cycle > 0.9f;
            return;
        }
        if (leashed) { if (a.distXZ(a.homeX, a.homeZ) > 4) goTo(r, a, a.homeX, a.homeZ, ar.speed * 1.3f, dt); else stop(a); return; }
        if (d > want * 1.3f || !seen) goTo(r, a, a.memX, a.memZ, ar.speed * 1.4f, dt);
        else if (d < want * 0.5f) { a.vx = (float) Math.sin(a.yaw) * ar.speed; a.vz = (float) Math.cos(a.yaw) * ar.speed; }
        else strafe(a, ar.speed * 0.6f, r);
        a.crouch = seen && d > 12 && (r.time + a.id) % 6 < 3;
    }

    /** Looks for a standable cell near a where a solid block shields a crouched body from the threat. */
    public static boolean findCover(Raid r, Actor a, float tx, float ty, float tz) {
        float best = Float.MAX_VALUE;
        boolean found = false;
        for (int k = 0; k < 20; k++) {
            float ang = k * 0.9f + a.id, rad = 1.5f + (k % 5) * 1.3f;
            float px = (float) Math.floor(a.x + Math.sin(ang) * rad) + 0.5f, pz = (float) Math.floor(a.z + Math.cos(ang) * rad) + 0.5f;
            int gy = r.groundY((int) px, (int) pz);
            if (gy < 0 || Math.abs(gy - a.y) > 1.2f || !Physics.boxFree(r.world, px, gy, pz, a.radius, a.stand)) continue;
            if (Physics.los(r.world, px, gy + 0.75f, pz, tx, ty + 1.3f, tz)) continue;   // crouched body exposed: not cover
            float cost = a.distXZ(px, pz) + (Physics.los(r.world, px, gy + 1.65f, pz, tx, ty + 1.3f, tz) ? 0 : 3);   // prefer cover you can shoot over
            if (cost < best) { best = cost; a.coverX = px; a.coverZ = pz; found = true; }
        }
        return found;
    }

    /** Bandit hold-up: weapons trained, no shots, until the player pays, resists or the clock runs out. */
    private static void extort(Raid r, Actor a, Arch ar, Raid.Squad sq, float dt) {
        Actor p = r.player;
        if (sq == null) { setState(a, "engage"); return; }
        float d = a.dist(p);
        a.yaw = turn(a.yaw, (float) Math.atan2(-(p.x - a.x), -(p.z - a.z)), dt * 6);
        if (d > 9) goTo(r, a, p.x, p.z, ar.speed * 1.2f, dt); else stop(a);
        if (sq.paid) { for (Actor m : r.squadMembers(a)) { m.hostileToPlayer = false; m.paidOff = true; m.awareness = 0; m.targetId = 0; setState(m, "idle"); } r.say(a, "Smart. Now get lost.", "shout"); return; }
        boolean resisted = r.playerAiming || r.time - r.lastPlayerShot < 1 || d < 3.2f || d > 34;
        if (resisted || r.time > sq.extortUntil) {
            if (!sq.bloodied) r.say(a, resisted ? "Wrong move!" : "Time's up!", "shout");
            sq.bloodied = true;
            for (Actor m : r.squadMembers(a)) { m.hostileToPlayer = true; m.targetId = p.id; setState(m, "engage"); }
        }
    }

    /** Military restricted-area enforcement: a spoken warning and a grace period before force. */
    private static void warn(Raid r, Actor a, Arch ar, Raid.Squad sq, float dt) {
        Actor p = r.player;
        a.yaw = turn(a.yaw, (float) Math.atan2(-(p.x - a.x), -(p.z - a.z)), dt * 6);
        stop(a);
        a.warnTimer -= dt;
        if (!r.restrictedFor(p.x, p.z)) { a.warned = false; r.say(a, "Keep moving.", "shout"); setState(a, "idle"); return; }
        if (a.warnTimer <= 0 || r.playerAiming && a.dist(p) < 25) {
            r.say(a, "Final warning ignored - engaging!", "shout");
            r.trespass();
            for (Actor m : r.nearby(a.x, a.z, 40)) if (m.faction.equals(a.faction)) { m.hostileToPlayer = true; m.targetId = p.id; remember(r, m, p.x, p.y, p.z, 1, 0.5f); setState(m, "engage"); }
        }
    }

    /** Walk to the nearest lootable corpse and strip it: mercenaries take the hardware, bandits take everything fast. */
    private static void loot(Raid r, Actor a, Arch ar, Doc dc, float dt) {
        Actor c = r.nearestCorpse(a.x, a.z, 22);
        if (c == null || c.corpse == null || c.corpse.items.isEmpty() || a.stateTime > 25) { a.looted = true; setState(a, "idle"); return; }
        if (a.distXZ(c.x, c.z) > 1.6f) { goTo(r, a, c.x, c.z, dc.d() == Doctrine.BANDIT ? ar.runSpeed * 0.8f : ar.speed * 1.3f, dt); a.lootTimer = 0; return; }
        stop(a);
        a.crouch = true;
        a.lootTimer += dt;
        if (a.lootTimer > (dc.d() == Doctrine.BANDIT ? 1.6f : 3.2f)) { r.npcLoot(a, c, dc.d() == Doctrine.MERC); a.looted = true; a.crouch = false; setState(a, "idle"); }
    }

    // ------------------------------------------------------------------ idle behaviour per doctrine
    /**
     * Evidence: a body of one's own, or blood on the ground, seen at close range. Blood is examined pool by
     * pool, freshest first - which walks an agent along a trail to whoever left it. Returns true if it reacted.
     */
    private static boolean evidence(Raid r, Actor a, Doc dc, float dt) {
        a.evidenceTimer -= dt;
        if (a.evidenceTimer > 0) return false;
        a.evidenceTimer = 1.1f + (a.id % 5) * 0.12f;
        if (a.evidenceSeen == null) a.evidenceSeen = new java.util.HashSet<>();
        float fx = (float) -Math.sin(a.yaw), fz = (float) -Math.cos(a.yaw);
        for (Actor c : r.actors) {
            if (!c.dead || c.isPlayer || c.infected() || !c.faction.equals(a.faction) || Math.abs(c.x - a.x) > 16 || Math.abs(c.z - a.z) > 16 || a.evidenceSeen.contains(-c.id)) continue;
            float dx = c.x - a.x, dz = c.z - a.z, d = (float) Math.sqrt(dx * dx + dz * dz);
            if (d > 4 && (dx * fx + dz * fz) / d < 0.2f) continue;
            if (!Physics.los(r.world, a.x, a.eyeY(), a.z, c.x, c.y + 0.4f, c.z)) continue;
            a.evidenceSeen.add(-c.id);
            a.alertness = 1; a.morale -= 0.08f; a.wakeUntil = r.time + 150;
            r.say(a, r.rng.chance(0.5) ? "Body here! Eyes up!" : "Man down - spread out!", "shout");
            for (Actor m : r.squadMembers(a)) { m.alertness = 1; m.wakeUntil = r.time + 150; if (m.evidenceSeen == null) m.evidenceSeen = new java.util.HashSet<>(); m.evidenceSeen.add(-c.id); }
            if (dc.d() == Doctrine.LONER) { remember(r, a, c.x, c.y, c.z, 0.5f, 4); setState(a, "avoid"); return true; }
            remember(r, a, c.x, c.y, c.z, 0.5f, 9);
            setState(a, "search");
            return true;
        }
        absentialis.scene.Gore.Pool p = r.gore.evidence(a, 13);
        if (p == null) return false;
        float dx = p.x - a.x, dz = p.z - a.z, d = (float) Math.sqrt(dx * dx + dz * dz);
        if (d > 3 && (dx * fx + dz * fz) / d < 0.1f || !Physics.los(r.world, a.x, a.eyeY(), a.z, p.x, p.y + 0.3f, p.z)) return false;
        a.evidenceSeen.add(p.id);
        if (r.time - p.born > 300) return false;        // old, dry blood: noted, not worth a detour
        a.alertness = Math.max(a.alertness, 0.7f); a.wakeUntil = r.time + 90;
        if (r.time - a.lastSay > 8) r.say(a, r.rng.chance(0.5) ? "Blood. Fresh." : "Somebody's bleeding - this way.", "shout");
        remember(r, a, p.x, p.y, p.z, 0.45f, 3);
        if (dc.d() == Doctrine.LONER && r.rng.chance(0.5)) setState(a, "avoid"); else { a.state = "investigate"; a.stateTime = 0; a.hasGoal = false; }
        return true;
    }

    private static final Doc SQUAD = new Doc(Doctrine.MERC, 60, 1f, 0.5f, 16, 0.1f, true);

    /**
     * The player's squadmates. They perceive, remember, path, take cover and shoot through exactly the same
     * code as every hostile human - what differs is their objective: the Element Leader's standing order
     * (follow in formation, hold a position, move to one, sweep it) and the fight in front of them.
     */
    private static void squadmate(Raid r, Actor a, Arch ar, Actor tgt, float dt) {
        Actor p = r.player;
        a.hostileToPlayer = false;
        a.light = false;
        float ax = a.sqX, az = a.sqZ;
        if ("follow".equals(a.sqOrder)) {
            // formation: Red on the leader's left, Blue on the right, in pairs stepping back
            int i = 0;
            for (Actor m : r.mates) { if (m == a) break; if (!m.dead && m.team.equals(a.team) && "follow".equals(m.sqOrder)) i++; }
            float side = "red".equals(a.team) ? -1 : 1, behind = 2.0f + i * 1.5f, lateral = side * (1.5f + (i % 2) * 1.1f);
            float fx = (float) -Math.sin(p.yaw), fz = (float) -Math.cos(p.yaw), rx = (float) Math.cos(p.yaw), rz = (float) -Math.sin(p.yaw);
            ax = p.x - fx * behind + rx * lateral; az = p.z - fz * behind + rz * lateral;
        }
        a.homeX = ax; a.homeZ = az;
        if (tgt != null) {
            boolean fresh = !"engage".equals(a.state);
            a.targetId = tgt.id;
            setState(a, "engage");
            if (fresh) {
                r.say(a, tgt.infected() ? "Infected - " + Raid.describe(tgt).replace("a ", "") + "!" : "Contact!", "shout");
                // called out on the net: the caller's own team reacts at once, the other team as the word reaches it
                for (Actor m : r.mates) if (m != a && !m.dead && !"engage".equals(m.state) && m.dist(a) < 70) {
                    remember(r, m, tgt.x + (r.rng.nextFloat() - 0.5f) * 4, tgt.y, tgt.z + (r.rng.nextFloat() - 0.5f) * 4, 0.6f, 4);
                    if (m.team.equals(a.team)) m.alertness = 1;
                }
            }
        }
        if ("engage".equals(a.state)) {
            Actor t = r.actor(a.targetId);
            if (t == null || t.dead) { if (t != null && r.rng.chance(0.4)) r.say(a, "Target down.", "radio_chatter"); setState(a, "idle"); }
            else if (tgt != t && r.time - a.memTime > 5) setState(a, "idle");
            else {
                boolean hurt = a.hp < a.maxHp * 0.3f;
                float leash = "hold".equals(a.sqOrder) ? 6 : "follow".equals(a.sqOrder) ? 26 : 40;
                a.yaw = turn(a.yaw, (float) Math.atan2(-(a.memX - a.x), -(a.memZ - a.z)), dt * 6);
                a.crouch = false;
                cover(r, a, ar, dt, tgt == t, "shotgunner".equals(a.archetype) ? 8 : "marksman".equals(a.archetype) ? 30 : 16, a.distXZ(ax, az) > leash || hurt);
                if (a.weapon != null && a.fireCooldown <= 0) {
                    if (tgt == t) r.npcFire(a, t, dt);
                    else if (r.time - a.memTime < 3 && "rifleman".equals(a.archetype) && (a.id & 1) == 0 && a.distXZ(a.memX, a.memZ) < 50) r.npcSuppress(a, a.memX, a.memY + 1.1f, a.memZ);
                }
                return;
            }
        }
        a.crouch = false;
        float d = a.distXZ(ax, az);
        switch (a.sqOrder) {
            case "hold" -> { if (d > 1.5f) goTo(r, a, ax, az, ar.speed * 1.3f, dt); else { stop(a); a.crouch = true; a.yaw += (float) Math.sin(r.time * 0.3f + a.id) * dt * 0.5f; } }
            case "move", "sweep" -> {
                boolean sweep = "sweep".equals(a.sqOrder);
                if (d > 1.8f) { goTo(r, a, ax, az, sweep ? ar.speed * 1.2f : ar.runSpeed * 0.85f, dt); a.crouch = sweep && d < 10; }
                else { a.sqOrder = "hold"; r.say(a, sweep ? "Clear." : "In position.", "radio_chatter"); }
            }
            default -> {
                if (d > 2.4f) goTo(r, a, ax, az, d > 9 || p.sprinting ? ar.runSpeed * (d > 20 ? 1.15f : 0.95f) : ar.speed * 1.4f, dt);
                else { stop(a); a.yaw = turn(a.yaw, p.yaw, dt * 2); a.crouch = p.crouch; }
            }
        }
        if (r.time - a.lastSeenTime > 20) a.hp = Math.min(a.maxHp, a.hp + dt * 1.2f);   // patched up between fights
    }

    /**
     * Daily routine: what the schedule says this agent should be doing at this hour. Returns true when the
     * routine handled the tick (walking to the bunk, resting, sleeping). Combat, alarms, wounds and loud
     * noise interrupt it - a woken agent stays up and alert for a while before going back.
     */
    private static boolean routine(Raid r, Actor a, Arch ar, Doc dc, float dt) {
        if (a.agentId == 0) return false;
        String now = absentialis.sim.Agents.activity(a.faction, a.duty, a.nightShift, r.hour(), a.agentId);
        if (!now.equals(a.routine)) {
            boolean wasOff = absentialis.sim.Agents.offDuty(a.routine), isOff = absentialis.sim.Agents.offDuty(now);
            a.routine = now;
            a.hasGoal = false;
            if (wasOff != isOff && r.time - a.lastSay > 20 && a.dist(r.player) < 30) r.say(a, isOff ? "That's my shift. Going down." : "Relief's here. Go and sleep.", "shout");
        }
        boolean awake = r.time < a.wakeUntil || a.hp < a.maxHp * 0.5f;
        boolean off = absentialis.sim.Agents.offDuty(now) && !awake;
        // on duty in the dark: sentries and patrols carry a torch (it helps them see and it shows where they are)
        a.light = r.night() && !off && dc.d() != Doctrine.BANDIT && dc.d() != Doctrine.LONER;
        if (!off) { a.role = "guard".equals(a.duty) || r.night() && dc.d() == Doctrine.MILITARY && (a.id & 1) == 0 ? "hold" : a.role.equals("hold") && !"guard".equals(a.duty) ? "" : a.role; return false; }
        float d = a.distXZ(a.homeX, a.homeZ);
        if (d > ("sleep".equals(now) ? 2.5f : 5f)) { goTo(r, a, a.homeX, a.homeZ, ar.speed, dt); return true; }
        stop(a);
        a.crouch = true;                                   // sitting by the fire, or down on the bedroll
        if ("rest".equals(now)) a.yaw += (float) Math.sin(r.time * 0.2f + a.id) * dt * 0.3f;
        a.hp = Math.min(a.maxHp, a.hp + dt * 0.4f);
        return true;
    }

    private static void idleHuman(Raid r, Actor a, Arch ar, Doc dc, Raid.Squad sq, float dt) {
        a.crouch = false;
        if (!absentialis.sim.Agents.asleep(a.routine) || r.time < a.wakeUntil) { if (evidence(r, a, dc, dt)) return; }
        if (!a.hasOrder && routine(r, a, ar, dc, dt)) return;
        if (a.hasOrder) {
            if (r.time > a.orderUntil) a.hasOrder = false;
            else if (a.distXZ(a.orderX, a.orderZ) > 5) { goTo(r, a, a.orderX, a.orderZ, ar.runSpeed * 0.8f, dt); return; }
            else { a.hasOrder = false; remember(r, a, a.orderX, a.y, a.orderZ, 0.5f, 6); setState(a, "investigate"); return; }
        }
        Actor p = r.player;
        switch (dc.d()) {
            case MILITARY -> {
                // cordon enforcement: the unauthorised get one warning inside a restricted area
                if (!a.hostileToPlayer && !p.dead && r.restrictedFor(p.x, p.z) && a.dist(p) < 30 && Physics.los(r.world, a.x, a.eyeY(), a.z, p.x, p.eyeY(), p.z)) {
                    if (!a.warned) { a.warned = true; a.warnTimer = 7; r.say(a, "Restricted area! Turn back - you have seconds.", "shout"); }
                    setState(a, "warn");
                    return;
                }
                if ("hold".equals(a.role)) { hold(r, a, dt); return; }
                patrol(r, a, ar, sq, dt);
            }
            case MERC -> {
                // guard the asset: half the team is static, the rest walks a tight loop round it
                if (a.dist(p) < 18 && !a.hostileToPlayer && !p.dead && a.talkTimer <= 0 && Physics.los(r.world, a.x, a.eyeY(), a.z, p.x, p.eyeY(), p.z)) { a.talkTimer = 20; r.say(a, "Private site. Keep your distance.", "shout"); }
                a.talkTimer -= dt;
                if ((a.id & 1) == 0) { hold(r, a, dt); return; }
                if (!a.hasGoal || a.distXZ(a.goalX, a.goalZ) < 1.6f) {
                    a.routeIndex = (a.routeIndex + 1) & 3;
                    float ang = a.routeIndex * 1.5708f + (a.squad & 3);
                    a.goalX = a.homeX + (float) Math.sin(ang) * 11; a.goalZ = a.homeZ + (float) Math.cos(ang) * 11; a.hasGoal = true; a.thinkTimer = r.rng.range(1.5f, 4f);
                }
                if (a.thinkTimer > 0) { a.thinkTimer -= dt; stop(a); return; }
                goTo(r, a, a.goalX, a.goalZ, ar.speed, dt);
                if (a.stuckTime > 2.5f) a.hasGoal = false;
            }
            case BANDIT -> {
                // lurk on the route: crouch in wait most of the time, relocate now and then, never quiet for long
                a.talkTimer -= dt;
                if (a.talkTimer <= 0) { a.talkTimer = r.rng.range(14f, 34f); if (r.rng.chance(0.5)) r.emitSound(a.x, a.y + 1.5f, a.z, 22, "whistle", a.id, false); }
                if (a.thinkTimer > 0) { a.thinkTimer -= dt; stop(a); a.crouch = true; a.yaw += (float) Math.sin(r.time * 0.4 + a.id) * dt * 0.5f; return; }
                if (!a.hasGoal) {
                    MapData.Node n = r.world.map.nearestNode(a.homeX + (r.rng.nextFloat() - 0.5f) * 44, a.homeZ + (r.rng.nextFloat() - 0.5f) * 44);
                    a.goalX = n != null ? n.x + r.rng.range(-5f, 5f) : a.homeX; a.goalZ = n != null ? n.z + r.rng.range(-5f, 5f) : a.homeZ; a.hasGoal = true; a.stateTime = 0;
                }
                goTo(r, a, a.goalX, a.goalZ, ar.speed * 0.9f, dt);
                if (a.distXZ(a.goalX, a.goalZ) < 2 || a.stateTime > 22) { a.hasGoal = false; a.thinkTimer = r.rng.range(8f, 22f); }
            }
            case LONER -> scavenge(r, a, ar, dt);
        }
    }

    private static void hold(Raid r, Actor a, float dt) {
        if (a.distXZ(a.homeX, a.homeZ) > 2.5f) { goTo(r, a, a.homeX, a.homeZ, arch(a.archetype).speed, dt); return; }
        stop(a);
        a.yaw += (float) Math.sin(r.time * 0.25f + a.id * 1.7f) * dt * 0.45f;   // slow scan of the arc
    }

    /** Fixed patrol loop on the street graph: same nodes, same order, single file behind the lead. */
    private static void patrol(Raid r, Actor a, Arch ar, Raid.Squad sq, float dt) {
        if (sq == null || sq.route.isEmpty()) { idleMove(r, a, ar, dt); return; }
        if (a.routeIndex < 0) a.routeIndex = 0;
        float[] wp = sq.route.get(a.routeIndex % sq.route.size());
        int rank = r.squadRank(a);
        float gx = wp[0] + (rank % 2 == 0 ? -1.2f : 1.2f), gz = wp[1] + (rank % 2 == 0 ? -1.2f : 1.2f);
        if (a.thinkTimer > 0) { a.thinkTimer -= dt; stop(a); a.yaw += dt * 0.5f * ((a.id & 1) == 0 ? 1 : -1); return; }
        if (a.distXZ(gx, gz) < 2.4f) { a.routeIndex = (a.routeIndex + 1) % sq.route.size(); a.thinkTimer = 2.5f + rank * 0.6f; return; }
        goTo(r, a, gx, gz, ar.speed, dt);
        if (a.stuckTime > 3.5f) { a.routeIndex = (a.routeIndex + 1) % sq.route.size(); a.stuckTime = 0; }
    }

    /** Loners work the nearby containers, one at a time, and take a knee when hurt. */
    private static void scavenge(Raid r, Actor a, Arch ar, float dt) {
        if (a.needsHelp && !a.helped) { stop(a); a.crouch = true; a.talkTimer -= dt; if (a.talkTimer <= 0 && a.dist(r.player) < 14) { a.talkTimer = 12; r.say(a, "Hey - you got a bandage? Please.", "shout"); } return; }
        if (a.thinkTimer > 0) { a.thinkTimer -= dt; stop(a); a.crouch = a.lootTimer > 0; if (a.thinkTimer <= 0 && a.lootTimer > 0) { a.lootTimer = 0; r.emitSound(a.x, a.y + 0.5f, a.z, 6, "search", a.id, false); } return; }
        if (!a.hasGoal) {
            MapData.LootSpot s = r.lootSpotNear(a.homeX, a.homeZ, 26, a.id + (int) (r.time / 20));
            if (s != null) { a.goalX = s.x + 0.5f; a.goalZ = s.z + 0.5f; a.lootTimer = 1; }
            else { a.goalX = a.homeX + (r.rng.nextFloat() - 0.5f) * 20; a.goalZ = a.homeZ + (r.rng.nextFloat() - 0.5f) * 20; a.lootTimer = 0; }
            a.hasGoal = true; a.stateTime = 0;
        }
        goTo(r, a, a.goalX, a.goalZ, ar.speed * 0.85f, dt);
        if (a.distXZ(a.goalX, a.goalZ) < 2.2f || a.stateTime > 20 || a.stuckTime > 2.5f) { a.hasGoal = false; a.thinkTimer = a.lootTimer > 0 && a.distXZ(a.goalX, a.goalZ) < 3 ? 4f : r.rng.range(1f, 4f); if (a.distXZ(a.goalX, a.goalZ) >= 3) a.lootTimer = 0; }
    }

    private static void idleMove(Raid r, Actor a, Arch ar, float dt) {
        // wander around the home post along the street graph
        if (!a.hasGoal || a.distXZ(a.goalX, a.goalZ) < 1.8f || a.stateTime > 25) {
            float rad = ar.infected ? 10 : 18;
            MapData.Node n = r.world.map.nearestNode(a.homeX + (r.rng.nextFloat() - 0.5f) * rad * 2, a.homeZ + (r.rng.nextFloat() - 0.5f) * rad * 2);
            if (n != null && Math.abs(n.x - a.homeX) < 40 && Math.abs(n.z - a.homeZ) < 40 && r.rng.chance(0.6)) { a.goalX = n.x + 0.5f; a.goalZ = n.z + 0.5f; }
            else { a.goalX = a.homeX + (r.rng.nextFloat() - 0.5f) * rad; a.goalZ = a.homeZ + (r.rng.nextFloat() - 0.5f) * rad; }
            a.hasGoal = true;
            a.stateTime = 0;
            a.thinkTimer = r.rng.range(1f, 5f);
        }
        if (a.thinkTimer > 0) { a.thinkTimer -= dt; stop(a); a.yaw += (float) Math.sin(r.time * 0.3 + a.id) * dt * 0.4f; return; }
        goTo(r, a, a.goalX, a.goalZ, ar.speed * (ar.infected ? 0.7f : 0.8f), dt);
    }

    /** A squadmate went down: morale drops by doctrine; bandits take it worst. */
    /** An ally in sight has been badly hurt: it shakes the squad, names the casualty and points at who did it. */
    public static void onAllyHurt(Raid r, Actor ally, Actor hurt, float severity, Actor attacker) {
        if (ally.dead || ally.infected()) return;
        Doc dc = doc(ally.faction);
        ally.morale -= severity * switch (dc.d()) { case BANDIT -> 0.22f; case LONER -> 0.18f; case MILITARY -> 0.07f; case MERC -> 0.05f; };
        ally.alertness = 1;
        if (attacker != null && !attacker.dead && hostile(r, ally, attacker) && !"engage".equals(ally.state)) {
            // they did not see the shot, only the result: the direction it came from, not the shooter's position
            float dx = attacker.x - hurt.x, dz = attacker.z - hurt.z, dl = (float) Math.sqrt(dx * dx + dz * dz);
            float reach = Math.min(dl, 18);
            if (dl > 0.5f) remember(r, ally, hurt.x + dx / dl * reach, attacker.y, hurt.z + dz / dl * reach, 0.45f, Math.max(4, dl * 0.35f));
        }
        if (r.time - ally.lastSay > 4 && r.rng.chance(0.6)) r.say(ally, (hurt.name.isEmpty() ? "Man" : callsign(hurt)) + (severity > 0.6f ? " is down bad - cover him!" : " is hit!"), "bark_down");
    }

    /**
     * This agent has just been hit. If it can see who did it, it has a target. If it cannot, it knows only that
     * the shot came from over there - the further away, the vaguer - and it starts hunting for the shooter.
     */
    public static void onShot(Raid r, Actor v, Actor attacker) {
        if (v.dead || attacker == null || attacker == v) return;
        v.wakeUntil = r.time + 120;
        v.alertness = 1;
        if ("engage".equals(v.state) && v.targetId == attacker.id) return;
        float d = v.dist(attacker);
        Arch ar = arch(v.archetype);
        float dx = attacker.x - v.x, dz = attacker.z - v.z, dl = Math.max(0.1f, (float) Math.sqrt(dx * dx + dz * dz));
        float cos = (dx * (float) -Math.sin(v.yaw) + dz * (float) -Math.cos(v.yaw)) / dl;
        boolean sees = v.infected() || v.mate() || d < 9 || cos > 0.1f && d < sightRange(r, v, ar, attacker) * 1.3f && Physics.los(r.world, v.x, v.eyeY(), v.z, attacker.x, attacker.eyeY() - 0.2f, attacker.z);
        if (sees) {
            remember(r, v, attacker.x, attacker.y, attacker.z, 1, 0.5f);
            v.memConfirmed = true; v.awareness = 1; v.targetId = attacker.id; v.lastSeenTime = r.time;
            if (!"flee".equals(v.state) && !"retreat".equals(v.state)) setState(v, "engage");
            return;
        }
        // direction only: a point some way along the line the shot came down, with error that grows with range
        float reach = Math.min(dl, 22), err = Math.max(5, dl * 0.35f);
        remember(r, v, v.x + dx / dl * reach + (r.rng.nextFloat() - 0.5f) * err, attacker.y, v.z + dz / dl * reach + (r.rng.nextFloat() - 0.5f) * err, 0.5f, err);
        v.memConfirmed = false; v.targetId = attacker.id; v.awareLevel = Tactics.THREAT_AWARE;
        Raid.Squad sq = r.squad(v);
        if (sq != null) { sq.mind.report(r, v, v.memX, v.memY, v.memZ, 0, 0, attacker.id, false, 0.5f); sq.mind.alertUntil = Math.max(sq.mind.alertUntil, r.time + 150); }
        if (!"engage".equals(v.state) && !"flee".equals(v.state) && !"retreat".equals(v.state)) {
            v.hasSearch = false;
            setState(v, "search");
            Tactics.say(r, v, sq, r.rng.chance(0.5) ? "I'm hit! Where's it coming from?!" : "Shooter - " + Tactics.bearing(v.x, v.z, v.memX, v.memZ) + " somewhere!", "bark_pain", 0.5f);
        }
    }

    /** How one agent names another out loud. */
    public static String callsign(Actor a) { return a.name.isEmpty() ? "you" : absentialis.gameplay.squad.Roster.shortName(a.name); }

    public static void onAllyDown(Raid r, Actor ally, Actor dead) {
        if (ally.dead || ally.infected()) return;
        Doc dc = doc(ally.faction);
        Raid.Squad asq = r.squad(ally);
        if (asq != null) {
            SquadMind am = asq.mind;
            if (r.time - am.lastCasualty > 0.2f || am.casualties == 0) am.casualties++;
            am.lastCasualty = r.time;
            am.rolesAt = -99;                       // the plan has a hole in it: deal the roles again
            am.alertUntil = Math.max(am.alertUntil, r.time + 180);
            String who = dead.name.isEmpty() ? "Man" : callsign(dead);
            Tactics.say(r, ally, asq, am.casualties >= 2 ? who + "'s down too! Get to cover!" : r.rng.chance(0.5) ? who + "'s down!" : "They got " + who + "!", "bark_down", 0.8f);
            if (!"engage".equals(ally.state) && !"flee".equals(ally.state) && !"retreat".equals(ally.state)) { ally.awareLevel = Tactics.THREAT_AWARE; if ("idle".equals(ally.state)) setState(ally, "alert"); }
        }
        ally.morale -= switch (dc.d()) { case BANDIT -> 0.38f; case LONER -> 0.30f; case MILITARY -> 0.12f; case MERC -> 0.08f; };
        if (dc.d() == Doctrine.LONER && !"engage".equals(ally.state) && dead.lastAttacker != 0) {
            // defend their own: the attacker becomes a target even for the cautious
            Actor k = r.actor(dead.lastAttacker);
            if (k != null && !k.dead && ally.dist(k) < 40) { ally.targetId = k.id; remember(r, ally, k.x, k.y, k.z, 0.8f, 2); ally.state = "engage"; ally.stateTime = 0; }
        }
    }

    static void strafe(Actor a, float sp, Raid r) {
        float side = ((int) (r.time * 0.5f + a.id) % 2 == 0) ? 1 : -1;
        a.vx = (float) Math.cos(a.yaw) * sp * side;
        a.vz = (float) -Math.sin(a.yaw) * sp * side;
    }

    static void stop(Actor a) { a.vx *= 0.5f; a.vz *= 0.5f; }

    /** Steering with simple obstacle avoidance; long detours handled by walking the street graph. */
    public static void goTo(Raid r, Actor a, float tx, float tz, float speed, float dt) {
        if (a.distXZ(tx, tz) < 0.3f) { stop(a); return; }
        // route: straight when the way is open, otherwise the next cell of a grid path (long trips ride the waypoint graph)
        float[] wp = waypoint(r, a, tx, tz);
        float dx = wp[0] - a.x, dz = wp[1] - a.z, d = (float) Math.sqrt(dx * dx + dz * dz);
        if (d < 0.05f) { stop(a); return; }
        float want = (float) Math.atan2(-dx, -dz);
        if (a.stuckTime > 0.6f) {
            // probe left/right for an open heading
            for (float off : new float[]{0.8f, -0.8f, 1.6f, -1.6f, 2.4f}) {
                float h = want + off;
                float px = a.x - (float) Math.sin(h) * 1.2f, pz = a.z - (float) Math.cos(h) * 1.2f;
                if (Physics.boxFree(r.world, px, a.y + 1.01f, pz, a.radius, 1.7f) || Physics.boxFree(r.world, px, a.y, pz, a.radius, 1.7f)) { want = h; break; }
            }
            if (a.stuckTime > 3) { a.hasGoal = false; a.stuckTime = 0; }
        }
        a.yaw = turn(a.yaw, want, dt * 5);
        a.vx = (float) -Math.sin(a.yaw) * speed;
        a.vz = (float) -Math.cos(a.yaw) * speed;
    }

    private static final float[] WP = new float[2];

    /** Where to head right now to reach (tx, tz): the target itself, or the next point of the agent's path. */
    private static float[] waypoint(Raid r, Actor a, float tx, float tz) {
        absentialis.world.Nav nav = r.world.nav;
        boolean doors = !a.infected();
        WP[0] = tx; WP[1] = tz;
        float d = a.distXZ(tx, tz);
        if (!a.onGround && a.path == null) return WP;
        if (d < 16 && nav.clear(a.x, a.y, a.z, tx, tz, false)) { a.path = null; a.hasVia = false; return WP; }
        float gx = tx, gz = tz;
        if (d > 44) {
            if (!a.hasVia || r.time - a.routeAt > 5 || a.distXZ(a.viaX, a.viaZ) < 5) {
                float[] v = nav.via(a.x, a.z, tx, tz, 30);
                a.routeAt = r.time;
                a.hasVia = v != null;
                if (v != null) { a.viaX = v[0]; a.viaZ = v[1]; }
            }
            if (a.hasVia) { gx = a.viaX; gz = a.viaZ; }
        } else a.hasVia = false;
        boolean moved = Math.abs(gx - a.pathTX) + Math.abs(gz - a.pathTZ) > 3;
        boolean stale = a.path == null ? r.time - a.pathAt > 0.6f : moved || r.time - a.pathAt > 4 || a.stuckTime > 1.2f && r.time - a.pathAt > 1;
        // the world changed along the way (a wall down, a door forced or blown): the old route is no longer trusted
        if (!stale && a.path != null && r.world.navTouched(a.pathNav, a.path, a.pathI)) stale = true;
        if (stale && nav.budget > 0) {
            nav.budget--;
            a.path = nav.path(a.x, a.y, a.z, gx, gz, a.tier == 1 ? 900 : 2600, doors);
            a.pathI = 0; a.pathAt = r.time; a.pathTX = gx; a.pathTZ = gz; a.pathNav = r.world.navVersion;
            // the route stops short of where it was going, at a locked door: force it if this is that kind of moment
            if (doors && a.path != null && !a.mate()) forceEntry(r, a, gx, gz);
        }
        int[] p = a.path;
        if (p == null) { WP[0] = gx; WP[1] = gz; return WP; }
        int n = p.length / 3;
        while (a.pathI < n - 1 && a.distXZ(p[a.pathI * 3] + 0.5f, p[a.pathI * 3 + 2] + 0.5f) < 0.75f) a.pathI++;
        // look a few cells ahead and cut the corner when the line to them is open
        int pick = a.pathI;
        for (int k = Math.min(n - 1, a.pathI + 4); k > a.pathI; k--) if (nav.clear(a.x, a.y, a.z, p[k * 3] + 0.5f, p[k * 3 + 2] + 0.5f, false)) { pick = k; break; }
        int cx = p[pick * 3], cy = p[pick * 3 + 1], cz = p[pick * 3 + 2];
        // a closed door on the way: people open it, the dead do not
        if (doors) for (int k = a.pathI; k <= Math.min(n - 1, a.pathI + 1); k++) {
            int qx = p[k * 3], qy = p[k * 3 + 1], qz = p[k * 3 + 2];
            if (a.distXZ(qx + 0.5f, qz + 0.5f) < 1.9f && r.world.solid(qx, qy, qz)) { absentialis.scene.Doors.Door dr = r.doors.at(qx, qy, qz); if (dr != null) r.doors.open(dr, a); }
        }
        a.wantClimb = cy > a.y + 1.2f;
        WP[0] = cx + 0.5f; WP[1] = cz + 0.5f;
        if (pick == n - 1 && a.distXZ(WP[0], WP[1]) < 0.6f && !a.hasVia && Math.abs(gx - tx) + Math.abs(gz - tz) < 0.01f) { WP[0] = tx; WP[1] = tz; a.path = null; a.pathAt = r.time; }
        return WP;
    }

    /**
     * Forced entry. A locked door is an obstacle navigation routes round; an agent only puts a boot through one
     * when it has a reason - it is in a fight or hunting someone it believes is on the other side - and when its
     * doctrine allows the noise: soldiers and contractors breach, bandits kick anything in, loners never do.
     */
    private static void forceEntry(Raid r, Actor a, float gx, float gz) {
        if (r.time < a.kickAt) return;
        int n = a.path.length / 3;
        float ex = a.path[(n - 1) * 3] + 0.5f, ez = a.path[(n - 1) * 3 + 2] + 0.5f;
        if (Math.abs(ex - gx) + Math.abs(ez - gz) < 2.5f) return;                       // the path gets there
        absentialis.scene.Doors.Door d = r.doors.near(a.x, a.y, a.z, 1.8f);
        if (d == null || r.doors.state(d) != absentialis.scene.Doors.State.LOCKED) return;
        // the door has to be between here and where it is going
        float tx = gx - a.x, tz = gz - a.z, dx = d.cx() - a.x, dz = d.cz() - a.z;
        if (tx * dx + tz * dz <= 0) return;
        Doctrine dc = doc(a.faction).d();
        boolean hunting = "engage".equals(a.state) || "search".equals(a.state) && a.awareLevel >= Tactics.THREAT_AWARE;
        boolean may = dc == Doctrine.BANDIT && (hunting || "loot".equals(a.state)) || (dc == Doctrine.MILITARY || dc == Doctrine.MERC) && hunting;
        if (!may) return;
        a.kickAt = r.time + 0.9f;
        a.yaw = (float) Math.atan2(-dx, -dz);
        if (a.anim != null) a.anim.play("melee", 0.45f);
        if (r.doors.kick(d, a) && r.time - a.lastSay > 6) r.say(a, "Door's open - go!", "shout");
    }

    public static float turn(float cur, float target, float maxStep) {
        float d = target - cur;
        while (d > Math.PI) d -= Math.PI * 2;
        while (d < -Math.PI) d += Math.PI * 2;
        return cur + Math.max(-maxStep, Math.min(maxStep, d));
    }
}
