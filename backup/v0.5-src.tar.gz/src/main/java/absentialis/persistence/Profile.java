package absentialis.persistence;

import absentialis.engine.util.Json;
import absentialis.gameplay.inventory.Container;
import absentialis.gameplay.inventory.InventoryService;
import absentialis.gameplay.inventory.Loadout;
import absentialis.gameplay.items.ItemInstance;
import absentialis.gameplay.missions.Contracts;
import absentialis.gameplay.progression.Progression;
import absentialis.sim.ZoneState;
import absentialis.world.World;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * One of four isolated survivor profiles (GDD 4.1): appearance, currency, stash, loadout,
 * progression, reputation, hideout, contracts, world-state branch, map discovery and statistics.
 */
public final class Profile {
    public static final int STASH_W = 10, STASH_BASE_H = 24, MAP_CELL = 8, MAP_CELLS = World.W / MAP_CELL;

    public int slot;
    public String name = "Survivor";
    /** One life: when this survivor dies the profile is deleted (chosen at creation, never changed afterwards). */
    public boolean ironman;
    /** Vehicles owned (handling ids), and the one chosen to bring on the next operation ("" = on foot). */
    public final java.util.List<String> garage = new java.util.ArrayList<>();
    public String deployVehicle = "";
    public int armVariant = 4, skin = 1, outfit = 0, tagColor = 0;
    /** Customization: definition-table ids only (iteration P3). */
    public absentialis.character.Appearance appearance = absentialis.character.Appearance.legacy(1, 0);
    public boolean facePaint = true;
    public long scrip = 1500;
    public long seed = 1337L;
    public final Container stash = new Container("stash", STASH_W, STASH_BASE_H);
    public Loadout loadout = new Loadout();
    public Progression prog = new Progression();
    public final Map<String, Float> rep = new LinkedHashMap<>();
    public final Map<String, Integer> hideout = new LinkedHashMap<>();
    public Contracts contracts = new Contracts();
    public ZoneState zone = ZoneState.fresh();
    public final BitSet discovered = new BitSet(MAP_CELLS * MAP_CELLS);
    public final Map<String, Integer> stats = new LinkedHashMap<>();
    public final Map<String, Integer> recentSales = new LinkedHashMap<>();
    public final List<Map<String, Object>> presets = new ArrayList<>();
    public float health = 100, energy = 80, hydration = 80;
    /**
     * Yellow Herbs taken: each raises maximum health for good (gameplay.CombatConfig sets how much, and the cap).
     * Kept through rank resets and prestige - it is a property of the survivor, not of the climb.
     */
    public int herbs;
    public long lastFallbackDay = -10;
    public String lastDebrief = "";

    public Profile() {
        for (String f : ZoneState.FACTIONS) rep.put(f, "raiders".equals(f) ? -20f : "mercenaries".equals(f) ? -10f : 0f);
        hideout.put("workbench", 1);
        hideout.put("medical", 1);
        hideout.put("kitchen", 1);
        hideout.put("radio", 0);
        hideout.put("case", 0);
        hideout.put("stash", 0);
    }

    public int level(String facility) { return hideout.getOrDefault(facility, 0); }

    /** A-Life: every human and infected in the Zone as a persistent individual (seeded on first deployment). */
    public absentialis.sim.Agents agents = new absentialis.sim.Agents();
    /** Save format this profile was loaded from when it was older than the current one (0 = current); not saved. */
    public int migratedFrom;

    /** Saved workbench builds: weapon definition id -> up to five attachment lists (null = empty slot). */
    public final Map<String, List<List<String>>> builds = new LinkedHashMap<>();
    /** The AI squad: roster, teams and their own progression (see gameplay.squad.Roster). */
    public absentialis.gameplay.squad.Roster squad = new absentialis.gameplay.squad.Roster();

    public List<List<String>> builds(String weaponId) {
        List<List<String>> l = builds.computeIfAbsent(weaponId, k -> new ArrayList<>());
        while (l.size() < absentialis.gameplay.weapons.Attachments.MAX_BUILDS) l.add(null);
        return l;
    }

    public float rep(String faction) { return rep.getOrDefault(faction, 0f); }
    public void addRep(String faction, float d) { if (rep.containsKey(faction)) rep.put(faction, Math.max(-100, Math.min(100, rep(faction) + d))); }
    public void stat(String k, int d) { stats.merge(k, d, Integer::sum); }
    public int stat(String k) { return stats.getOrDefault(k, 0); }

    /** Applies stash height from rank/prestige/hideout and case size from the case workshop. */
    public void applyCapacity() {
        int rows = STASH_BASE_H + prog.stashRows() + level("stash") * 4;
        stash.h = Math.max(stash.h, rows);
        // the case grows with Rank (6x10 -> 9x13) and never shrinks again, Prestige included
        int[] d = prog.caseDims();
        loadout.resizeCase(d[0], d[1]);
        absentialis.gameplay.weapons.Gunsmith.prestigeLevel = prog::weaponPrestige;
        squad.ensure(prog.squadSlots(), seed ^ name.hashCode());
    }

    public boolean discovered(int cx, int cz) { return cx >= 0 && cz >= 0 && cx < MAP_CELLS && cz < MAP_CELLS && discovered.get(cx * MAP_CELLS + cz); }

    /** Marks map cells around a world position as reconnoitred; returns newly revealed count. */
    public int discover(float x, float z, int radiusCells) {
        int cx = (int) x / MAP_CELL, cz = (int) z / MAP_CELL, n = 0;
        for (int dx = -radiusCells; dx <= radiusCells; dx++) for (int dz = -radiusCells; dz <= radiusCells; dz++) {
            if (dx * dx + dz * dz > radiusCells * radiusCells) continue;
            int a = cx + dx, b = cz + dz;
            if (a < 0 || b < 0 || a >= MAP_CELLS || b >= MAP_CELLS) continue;
            int i = a * MAP_CELLS + b;
            if (!discovered.get(i)) { discovered.set(i); n++; }
        }
        return n;
    }

    /** Every instance the profile owns (stash + loadout), for audits and uid uniqueness checks. */
    public List<ItemInstance> allItems() {
        List<ItemInstance> out = new ArrayList<>();
        for (ItemInstance i : stash.items) i.collect(out);
        out.addAll(loadout.all());
        return out;
    }

    public String verify() {
        String s = stash.verify();
        if (s != null) return s;
        s = loadout.caseGrid.verify();
        if (s != null) return s;
        java.util.Set<Long> seen = new java.util.HashSet<>();
        for (ItemInstance i : allItems()) if (!seen.add(i.uid)) return "duplicate instance uid " + i.uid + " (" + i.name() + ")";
        if (scrip < 0) return "negative currency";
        return null;
    }

    /**
     * v0.3 migration: the old 12x16 attaché case becomes the Rank-sized grid. Everything that was in it is
     * repacked; what no longer fits moves to the stash (which grows if it has to) - nothing is lost.
     */
    void migrateCase() {
        List<ItemInstance> held = new ArrayList<>(loadout.caseGrid.items);
        for (ItemInstance i : held) InventoryService.release(i);
        int[] d = prog.caseDims();
        loadout.caseGrid.w = d[0]; loadout.caseGrid.h = d[1];
        for (ItemInstance i : held) {
            if (InventoryService.store(i, loadout).ok()) continue;
            while (!InventoryService.add(i, stash).ok()) stash.h += 4;
        }
    }

    /** Starting kit for a brand-new profile. */
    public void starterKit() {
        String[][] kit = {{"weapon.mosin", "1"}, {"ammo.rifle", "20"}, {"weapon.pm9", "1"}, {"ammo.handgun", "50"}, {"ammo.handgun", "20"},
                {"melee.knife", "1"}, {"herb.green", "1"}, {"herb.green", "1"}, {"med.bandage", "1"}, {"med.antiviral", "2"}, {"med.painkillers", "2"}, {"food.beans", "1"},
                {"drink.water", "1"}, {"armor.vest_soft", "1"}, {"helmet.cap", "1"}, {"mat.gun_oil", "2"}, {"tool.noisemaker", "1"}, {"grenade.frag", "1"}};
        for (String[] k : kit) {
            ItemInstance i = new ItemInstance(k[0]);
            i.qty = Integer.parseInt(k[1]);
            i.origin = "starter";
            if (i.def().weapon != null && !i.def().weapon.melee()) { i.rounds = i.capacity(); i.ammoId = absentialis.gameplay.items.Content.ammoFor(i.def().weapon.caliber).id; }
            InventoryService.add(i, stash);
        }
        ItemInstance charm = new ItemInstance("charm.rabbit");
        charm.origin = "starter";
        InventoryService.add(charm, stash);
    }

    // ------------------------------------------------------------------ persistence
    public Map<String, Object> toJson() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("version", absentialis.Version.SAVE_FORMAT);
        m.put("game", absentialis.Version.NUMBER);
        m.put("slot", slot);
        m.put("name", name);
        m.put("armVariant", armVariant);
        m.put("skin", skin);
        m.put("outfit", outfit);
        m.put("tagColor", tagColor);
        m.put("appearance", appearance.toJson());
        m.put("ironman", ironman);
        m.put("garage", new java.util.ArrayList<Object>(garage));
        m.put("deployVehicle", deployVehicle);
        m.put("build", absentialis.Version.NUMBER);
        m.put("facePaint", facePaint);
        m.put("scrip", String.valueOf(scrip));
        m.put("seed", String.valueOf(seed));
        m.put("nextUid", String.valueOf(ItemInstance.peekUid()));
        m.put("stashH", stash.h);
        List<Object> st = new ArrayList<>();
        for (ItemInstance i : stash.items) st.add(i.toJson());
        m.put("stash", st);
        m.put("loadout", loadout.toJson());
        m.put("progression", prog.toJson());
        Map<String, Object> r = new LinkedHashMap<>();
        for (Map.Entry<String, Float> e : rep.entrySet()) r.put(e.getKey(), (double) e.getValue());
        m.put("rep", r);
        m.put("hideout", new LinkedHashMap<String, Object>(hideout));
        m.put("contracts", contracts.toJson());
        m.put("zone", zone.toJson());
        m.put("discovered", java.util.Base64.getEncoder().encodeToString(discovered.toByteArray()));
        m.put("stats", new LinkedHashMap<String, Object>(stats));
        m.put("recentSales", new LinkedHashMap<String, Object>(recentSales));
        m.put("presets", new ArrayList<Object>(presets));
        m.put("health", (double) health);
        m.put("herbs", (double) herbs);
        m.put("energy", (double) energy);
        m.put("hydration", (double) hydration);
        m.put("lastFallbackDay", String.valueOf(lastFallbackDay));
        m.put("lastDebrief", lastDebrief);
        Map<String, Object> bs = new LinkedHashMap<>();
        for (Map.Entry<String, List<List<String>>> e : builds.entrySet()) {
            List<Object> slots = new ArrayList<>();
            for (List<String> b : e.getValue()) slots.add(b == null ? null : new ArrayList<Object>(b));
            bs.put(e.getKey(), slots);
        }
        m.put("builds", bs);
        m.put("squad", squad.toJson());
        m.put("agents", agents.toJson());
        return m;
    }

    @SuppressWarnings("unchecked")
    public static Profile fromJson(Map<String, Object> m) {
        Profile p = new Profile();
        p.slot = Json.integer(m, "slot", 0);
        p.name = Json.str(m, "name", "Survivor");
        p.ironman = Json.bool(m, "ironman", false);
        p.garage.addAll(Json.strList(m, "garage"));
        p.deployVehicle = Json.str(m, "deployVehicle", "");
        if (!p.garage.contains(p.deployVehicle)) p.deployVehicle = "";
        p.armVariant = Json.integer(m, "armVariant", 4);
        p.skin = Json.integer(m, "skin", 1);
        p.outfit = Json.integer(m, "outfit", 0);
        p.tagColor = Json.integer(m, "tagColor", 0);
        p.appearance = m.containsKey("appearance") ? absentialis.character.Appearance.fromJson(Json.obj(m, "appearance")) : absentialis.character.Appearance.legacy(p.skin, p.outfit);
        p.facePaint = Json.bool(m, "facePaint", true);
        ItemInstance.legacyOrientation = Json.integer(m, "version", 2) < 3;
        try { load(p, m); } finally { ItemInstance.legacyOrientation = false; }
        return p;
    }

    @SuppressWarnings("unchecked")
    private static void load(Profile p, Map<String, Object> m) {
        p.scrip = Json.lng(m, "scrip", 0);
        p.seed = Json.lng(m, "seed", 1337L);
        ItemInstance.ensureUidAbove(Json.lng(m, "nextUid", 1) - 1);
        p.stash.h = Json.integer(m, "stashH", STASH_BASE_H);
        for (Object o : Json.list(m, "stash")) { ItemInstance i = ItemInstance.fromJson((Map<String, Object>) o); if (i != null) p.stash.restore(i); }
        p.loadout = Loadout.fromJson(Json.obj(m, "loadout"));
        p.prog = Progression.fromJson(Json.obj(m, "progression"));
        for (Map.Entry<String, Object> e : Json.obj(m, "rep").entrySet()) p.rep.put(e.getKey(), ((Number) e.getValue()).floatValue());
        for (Map.Entry<String, Object> e : Json.obj(m, "hideout").entrySet()) p.hideout.put(e.getKey(), ((Number) e.getValue()).intValue());
        p.contracts = Contracts.fromJson(Json.obj(m, "contracts"));
        p.zone = ZoneState.fromJson(Json.obj(m, "zone"));
        String disc = Json.str(m, "discovered", "");
        if (!disc.isEmpty()) p.discovered.or(BitSet.valueOf(java.util.Base64.getDecoder().decode(disc)));
        for (Map.Entry<String, Object> e : Json.obj(m, "stats").entrySet()) p.stats.put(e.getKey(), ((Number) e.getValue()).intValue());
        for (Map.Entry<String, Object> e : Json.obj(m, "recentSales").entrySet()) p.recentSales.put(e.getKey(), ((Number) e.getValue()).intValue());
        for (Object o : Json.list(m, "presets")) if (o instanceof Map) p.presets.add((Map<String, Object>) o);
        p.health = (float) Json.num(m, "health", 100);
        p.herbs = Math.max(0, Math.min(absentialis.gameplay.CombatConfig.get().herbCap(), Json.integer(m, "herbs", 0)));
        p.energy = (float) Json.num(m, "energy", 80);
        p.hydration = (float) Json.num(m, "hydration", 80);
        p.lastFallbackDay = Json.lng(m, "lastFallbackDay", -10);
        p.lastDebrief = Json.str(m, "lastDebrief", "");
        for (Map.Entry<String, Object> e : Json.obj(m, "builds").entrySet()) {
            List<List<String>> slots = new ArrayList<>();
            if (e.getValue() instanceof List) for (Object o : (List<Object>) e.getValue()) {
                if (!(o instanceof List)) { slots.add(null); continue; }
                List<String> b = new ArrayList<>();
                for (Object s : (List<Object>) o) b.add(String.valueOf(s));
                slots.add(b);
            }
            p.builds.put(e.getKey(), slots);
        }
        if (m.containsKey("agents")) p.agents = absentialis.sim.Agents.fromJson(Json.obj(m, "agents"));
        if (m.containsKey("squad")) p.squad = absentialis.gameplay.squad.Roster.fromJson(Json.obj(m, "squad"));
        if (Json.integer(m, "version", 2) < 4) p.migrateCase();
        if (Json.integer(m, "version", 2) < 5) {
            // 0.5 rebuilt the city. Everything the survivor owns and has earned carries over; what described the old
            // streets - who lived where, which ground had been walked, where fights had left their marks - describes
            // nothing now and is started afresh.
            p.agents = new absentialis.sim.Agents();
            p.discovered.clear();
            p.zone.log.clear();
            p.migratedFrom = Json.integer(m, "version", 2);
        }
        p.applyCapacity();
    }
}
