package absentialis.scene;

import absentialis.ai.Brain;
import absentialis.character.Animator;
import absentialis.character.Pose;
import absentialis.character.Ragdoll;
import absentialis.character.Rig;
import absentialis.engine.math.Mat4;
import absentialis.engine.events.EventBus;
import absentialis.engine.events.Events;
import absentialis.engine.util.Rng;
import absentialis.entity.Actor;
import absentialis.entity.Physics;
import absentialis.entity.Survivor;
import absentialis.gameplay.inventory.Container;
import absentialis.gameplay.inventory.InventoryService;
import absentialis.gameplay.items.Content;
import absentialis.gameplay.items.ItemDef;
import absentialis.gameplay.items.ItemInstance;
import absentialis.gameplay.weapons.Gunsmith;
import absentialis.gameplay.weapons.WeaponService;
import absentialis.persistence.Profile;
import absentialis.persistence.Settings;
import absentialis.sim.ZoneState;
import absentialis.world.Block;
import absentialis.world.District;
import absentialis.world.MapData;
import absentialis.world.Material;
import absentialis.world.World;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * One deployment (GDD 2): the operational slice of the persistent Zone. Owns the raid clock and
 * closing phase, extraction rules, ballistics, sound propagation, the tiered agent population
 * and loot. It never writes to the profile directly - outcomes are collected into a
 * {@link Debrief} that {@link RaidResolver} applies exactly once.
 */
public final class Raid {
    public final World world;
    public final Profile profile;
    public final Settings settings;
    public final EventBus bus;
    public final Rng rng;
    public final Actor player = new Actor();
    public final Survivor body = new Survivor();
    public final List<Actor> actors = new ArrayList<>();
    public final List<Projectile> projectiles = new ArrayList<>();
    public final List<Thrown> thrown = new ArrayList<>();
    public final List<WorldItem> items = new ArrayList<>();
    public final List<Sound> sounds = new ArrayList<>();
    public final List<Effect> effects = new ArrayList<>();
    public final List<Telegraph> telegraphs = new ArrayList<>();
    public final List<Zone> zones = new ArrayList<>();
    public final Map<Integer, Squad> squads = new HashMap<>();
    /** Anatomical damage, severed parts and blood. */
    public final Gore gore = new Gore(this);
    /** Simulated fire: burn barrels, incendiary pools, anything that is alight. */
    public final FireSystem fire = new FireSystem(this);
    /** Bites, the course of the infection, treatment and turning. */
    public final InfectionSystem infection = new InfectionSystem(this);
    /** Drivable vehicles: never more than four in an operation. */
    public final VehicleSystem vehicles = new VehicleSystem(this);
    /** Every door as a hinged, damageable entity. */
    public final Doors doors = new Doors(this);
    /** Incapacitation, bleed-out and rescue: the life-state machine of every human. */
    public final Casualty casualty = new Casualty(this);
    public final absentialis.gameplay.CombatConfig combat = absentialis.gameplay.CombatConfig.get();
    /** The weapon behind the damage being applied right now (the round's, not whatever the shooter holds by then). */
    private String hitWeaponId;
    /** The player's deployed AI squadmates (Gold Team = all of them). */
    public final List<Actor> mates = new ArrayList<>();
    /** Everyone who deployed with the player, living or dead, in deployment order (the squad status column). */
    public final List<Actor> element = new ArrayList<>();
    /** How the damage being applied right now was delivered ("blast" while an explosion resolves). */
    public String hitKind = "";
    private String lastKind = "bullet";
    /** Seconds the camera stays on the player's body before the debrief (0 = resolve at once: headless runs). */
    public float deathCam;
    public float dying = -1, slipT;
    private String dyingReason = "";
    /** With a death camera: the raid stays on the body until {@link #resolveDeath()} (the player picks respawn, menu or quit). */
    public boolean deathHold;
    public String deathReason() { return dyingReason; }

    /** Ends a held death: the raid resolves as KILLED on this call. */
    public void resolveDeath() { if (player.dead && debrief.outcome == Debrief.Outcome.NONE) finishDeath(dyingReason.isEmpty() ? "Killed in action" : dyingReason); }
    private float alifeTimer;
    /** Smoke columns left by off-screen fighting (A-Life evidence): {x, y, z}. */
    public final List<float[]> smoke = new ArrayList<>();
    public static final int EXTORT_PRICE = 200;
    /** Quality gates set this so every run of the suite sees the same dice (null in play: each raid is its own). */
    public static Long fixedSeed;
    private static long raidSerial;
    public float lastPlayerShot = -99;
    /** The player is reloading, treating a wound or off balance until this raid time: the moment opponents wait for. */
    public float playerVulnerableUntil = -99;
    /** Someone has hold of the player until this raid time (movement all but stops until they are hit or it runs out). */
    public float grabUntil = -99;
    public int grabbedBy;
    private float lastMeleeOn = -99, lastMeleeBy;
    /** Noise-propagation service counters: events that crossed the response threshold, infected moved, squads sent. */
    public int noiseEvents, migrations, dispatches, trespasses, scripPaid;
    public final Map<Integer, Container> containers = new HashMap<>();
    public final List<ExitState> exits = new ArrayList<>();
    public final Debrief debrief = new Debrief();
    public final String raidId;
    public final MapData.Point insertion;
    public float time, duration, extractProgress;
    public ExitState extracting;
    public boolean playerFlashlight, god, noclip, playerAiming;
    /** A visible laser or weapon light is on: the player stands out in the dark. */
    public boolean playerLaser;
    /** Screen white-out from a flash grenade (1 = blind), decays over a few seconds. */
    public float flashBlind;
    public boolean aiDebug, noiseDebug;
    public float muzzleFlash, damageShake;
    public final List<float[]> hitMarkers = new ArrayList<>(); // {dirAngle, time}
    public interface Listener {
        void message(String text, int color);
        void caption(String text, float x, float z, float loud);
        default void footstep(Actor a, String material, float speed) {}
        /** A spoken callout: the named voice sample, at the speaker. */
        default void voice(Actor a, String sample) {}
    }
    public Listener listener;
    private final Map<Integer, int[]> cells = new HashMap<>(); // cell -> {infected, military, raiders, survivors, mercenaries}
    private final float[] heat = new float[CELLS * CELLS];   // accumulated loud noise per strategic cell
    private float squadTimer, zoneTimer;
    private final java.util.Set<Integer> activeCells = new java.util.HashSet<>();
    private float cellTimer, discoverTimer, envTimer, radioTimer;
    private boolean warned10, warned3, closedAnnounced;
    /** False disables strategic-cell population (isolated perception tests). */
    public boolean populate = true;
    /** Non-player deaths this raid (population audit: living + dead is conserved). */
    public int deaths;
    public static final int CELL = 64, CELLS = World.W / CELL;

    // ------------------------------------------------------------------ records
    public static final class Projectile {
        public float x, y, z, vx, vy, vz, px, py, pz, damage, power, age;
        /** Effective range and muzzle position: damage falls away past the weapon's range. */
        public float range = 9999, ox, oy, oz;
        public int owner;
        public String ownerFaction, weaponId;
        public ItemDef ammo;
        public boolean tracer, dead;
        /** The last actor this round passed close to without hitting (each is startled once per round). */
        public int nearId;
    }
    public static final class Thrown { public float x, y, z, vx, vy, vz, fuse; public ItemDef def; public int owner; public boolean armed, dead, debris, impact; }
    /** Area denial left on the ground: fat-infected bile ("acid") or the contamination of a rupture ("contam"). */
    public static final class Zone { public float x, y, z, radius, until, dps, tick; public String kind; public int owner; }
    /**
     * A group that moves and decides together. Holds the shared tactical picture (last known target
     * position, not the truth), casualties for morale, and the doctrine bookkeeping.
     */
    public static final class Squad {
        public int id, targetId, initial, alive;
        public String faction;
        public float tx, tz, contactTime = -99, extortUntil;
        public boolean extortDone, paid, bloodied, backupCalled;
        /** Members who went down with nobody watching: {x, y, z, time}. The squad notices when they stop answering. */
        public final List<float[]> missing = new ArrayList<>();
        public long uid;
        public final List<float[]> route = new ArrayList<>();
        /** What the squad knows together, who is doing what, and where it has already looked (ai.SquadMind). */
        public final absentialis.ai.SquadMind mind = new absentialis.ai.SquadMind();
    }
    public static final class WorldItem { public float x, y, z, vy; public ItemInstance it; public float age; }
    public record Sound(float x, float y, float z, float radius, String category, int source, float time) {}
    public static final class Effect { public float x, y, z, vx, vy, vz, life, max, size; public int color; public boolean glow; }
    public record Telegraph(int actorId, String kind, float until) {}

    public static final class ExitState {
        public final MapData.Exit exit;
        public boolean eligible, signaled, open = true;
        public String requirement = "", status = "";
        public float signalTimer;
        ExitState(MapData.Exit e) { exit = e; }
    }

    public static final class Debrief {
        public enum Outcome { NONE, EXTRACTED, KILLED, MIA }
        public Outcome outcome = Outcome.NONE;
        public String reason = "", exitName = "";
        public final Map<String, Integer> kills = new LinkedHashMap<>();
        public final List<String[]> xp = new ArrayList<>(); // {label, amount}
        public final List<String> consequences = new ArrayList<>();
        public final List<String> killedFactions = new ArrayList<>();
        public final Map<String, Float> repDelta = new LinkedHashMap<>();
        public float noise, distance;
        public int cellsRevealed, containersSearched, documents, shotsFired, hits, emergencyCost, aided, lootValue, challenges;
        public boolean powerRestored;
        public District deployedIn;
        public boolean resolved;
        public void xp(String label, int amount) { if (amount > 0) xp.add(new String[]{label, String.valueOf(amount)}); }
        public int totalXp() { int t = 0; for (String[] s : xp) t += Integer.parseInt(s[1]); return t; }
    }

    // ------------------------------------------------------------------ setup
    public Raid(World world, Profile profile, Settings settings, EventBus bus, int insertionIndex, float minutes) {
        this.world = world;
        this.profile = profile;
        this.settings = settings;
        this.bus = bus;
        this.raidId = "raid-" + profile.zone.day + "-" + (int) (profile.zone.hour * 60) + "-" + System.nanoTime() % 100000;
        this.rng = new Rng(fixedSeed != null ? profile.seed ^ fixedSeed ^ (raidSerial++ * 0x9E3779B97F4A7C15L) : profile.seed ^ System.nanoTime());
        this.duration = minutes * 60f;
        List<MapData.Point> ins = world.map.insertions;
        insertion = ins.get(Math.floorMod(insertionIndex, ins.size()));
        player.isPlayer = true;
        player.faction = "player";
        player.archetype = "player";
        float[] spot = outdoorSpot(insertion.x, insertion.z);
        player.x = spot[0]; player.y = spot[1]; player.z = spot[2];
        player.yaw = (float) Math.atan2(-(352 - player.x), -(352 - player.z));
        player.maxHp = combat.maxHealth(profile.herbs);
        player.hp = Math.min(player.maxHp, Math.max(35, profile.health));
        player.name = profile.name == null ? "" : profile.name;
        body.energy = profile.energy;
        body.hydration = profile.hydration;
        body.staminaDrainMul = 1 + profile.loadout.charm("stamina");
        debrief.deployedIn = world.district(player.x, player.z);
        applyArmor();
        actors.add(player);
        deploySquad();
        for (MapData.Exit e : world.map.exits) exits.add(new ExitState(e));
        evaluateExits();
        seedCells();
        if (System.getenv("ABS_TEST_NOPOP") != null) populate = false;
        seedEvidence();
        profile.discover(player.x, player.z, 3);
        if (world.map.fires == null) world.scanFires();
        for (int[] b : world.map.fires) fire.bind(b[0], b[1], b[2], 0.42f);
        if (populate && System.getenv("ABS_TEST_NOVEHICLES") == null) vehicles.populate(profile.deployVehicle);
        doors.scan();
    }

    private float burnMsg = -99;

    /** Heat from a fire: damage with no bullet behind it. The player is told once in a while; agents flinch and can die of it. */
    public void burnActor(Actor a, float dmg, int owner) {
        if (a.dead || a.isPlayer && god) return;
        a.hp -= dmg * (a.isPlayer ? difficultyDamage() : 1);
        a.hurtFlash = 0.15f;
        if (a.tier == 0) gore.burn(a, dmg);
        if (a.isPlayer) {
            damageShake = Math.min(1, damageShake + 0.2f);
            body.healthChanged = time;
            if (time - burnMsg > 3) { burnMsg = time; msg("You are burning - move!", 0xFFE2A034); }
            return;
        }
        a.staggerUntil = Math.max(a.staggerUntil, time + 0.4f);
        a.wakeUntil = time + 60;
        if (a.hp <= 0) { a.hitRegion = "torso"; a.hitForce = 6; finish(a, actor(owner), "burn"); }
    }

    /** Nearest standable column under open sky (insertions must not drop you inside a building). */
    private float[] outdoorSpot(int x0, int z0) {
        for (int pass = 0; pass < 2; pass++) for (int r = 0; r < 48; r++) for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) {
            if (Math.max(Math.abs(dx), Math.abs(dz)) != r) continue;
            int x = x0 + dx, z = z0 + dz;
            int y = groundY(x, z);
            if (y < 0 || world.sky(x, y + 1, z) < 15 || world.heightAt(x, z) >= y + 1) continue;
            if (pass == 0 && y > World.GROUND + 1) continue; // street level first, rooftops only as a fallback
            if (!Physics.boxFree(world, x + 0.5f, y, z + 0.5f, 0.35f, 1.8f)) continue;
            return new float[]{x + 0.5f, y, z + 0.5f};
        }
        return new float[]{x0 + 0.5f, Math.max(World.GROUND, groundY(x0, z0)), z0 + 0.5f};
    }

    public void applyArmor() {
        ItemInstance arm = profile.loadout.slot("armor"), hel = profile.loadout.slot("head");
        boolean plate = arm != null && arm.def().armor != null && arm.def().armor.shield > 0;
        player.armorClass = arm != null && arm.def().armor != null && !plate ? arm.def().armor.armorClass : 0;
        player.armorDur = arm != null && !plate ? arm.durability : 0;
        player.armorMax = arm != null && !plate ? arm.maxDurability : 0;
        // Body Armor: a pool on top of health that takes the damage first; what is left is stored on the item
        player.shield = plate ? arm.durability : 0;
        player.shieldMax = plate ? arm.def().armor.shield : 0;
        player.helmet = hel != null && hel.def().armor != null && hel.def().armor.armorClass > 0;
    }

    /** The clock runs through the raid: two real minutes to the game hour, so a long operation crosses dusk or dawn. */
    public double hour() { return profile.zone.hour + time / 120.0; }
    public float daylight() { return ZoneState.daylightAt(hour()); }
    public boolean night() { return daylight() < 0.35f; }
    public float remaining() { return duration - time; }
    public boolean closed() { return remaining() <= 0; }
    public float difficultySight() { return settings.difficulty == 0 ? 0.75f : settings.difficulty == 2 ? 1.15f : 1f; }
    public float difficultyDamage() { return settings.difficulty == 0 ? 0.7f : settings.difficulty == 2 ? 1.25f : 1f; }

    public Actor actor(int id) { for (Actor a : actors) if (a.id == id) return a; return null; }

    public List<Actor> nearby(float x, float z, float r) {
        List<Actor> l = new ArrayList<>();
        for (Actor a : actors) if (!a.dead && Math.abs(a.x - x) < r && Math.abs(a.z - z) < r) l.add(a);
        return l;
    }

    private void msg(String s, int col) { if (listener != null) listener.message(s, col); }

    // ------------------------------------------------------------------ extraction rules (GDD 16)
    public void evaluateExits() {
        double hour = profile.zone.hour;
        for (ExitState s : exits) {
            MapData.Exit e = s.exit;
            boolean ok = true;
            StringBuilder req = new StringBuilder();
            switch (e.type) {
                case PERMANENT -> req.append("Always open");
                case EMERGENCY -> { ok = closed(); req.append("Opens when the window closes. Cost: \u20A11,500 or your secured treasures"); }
                case TIME_WINDOW -> {
                    String[] w = e.condition.substring(7).split("-");
                    int a = Integer.parseInt(w[0]), b = Integer.parseInt(w[1]);
                    double h = hour + time / 60.0 * 0.5; // zone clock runs at 30x during raids
                    ok = b > 24 ? (h % 24 >= a || h % 24 < b - 24) : (h % 24 >= a && h % 24 < b);
                    req.append(String.format("Runs %02d:00-%02d:00", a, b % 24));
                }
                case SIGNALED -> { ok = s.signaled; req.append("Throw a signal flare in the zone, then hold for 60s"); }
                case CONDITIONAL -> {
                    ok = false;
                    for (String c : e.condition.split("\\|")) {
                        if (req.length() > 0) req.append(" OR ");
                        if (c.startsWith("item:")) { String id = c.substring(5); ok |= profile.loadout.count(id) > 0; req.append("Carry ").append(Content.def(id) != null ? Content.def(id).name : id); }
                        else if (c.startsWith("rep:")) { String[] p = c.split(":"); ok |= profile.rep(p[1]) >= Float.parseFloat(p[2]); req.append(ZoneState.cap(p[1])).append(" standing >= ").append(p[2]); }
                        else if (c.startsWith("pay:")) { int cost = Integer.parseInt(c.substring(4)); ok |= profile.scrip >= cost; req.append("Pay a ").append(absentialis.Version.coins(cost)).append(" toll"); }
                        else if (c.equals("power")) { ok |= profile.zone.power[District.INDUSTRIAL.ordinal()] || profile.zone.power[e.district.ordinal()]; req.append("District power restored"); }
                    }
                }
            }
            if (e.type != MapData.ExitType.EMERGENCY && closed()) ok = false;
            // a controlling hostile faction restricts its checkpoint
            if (!e.faction.isEmpty() && e.type != MapData.ExitType.EMERGENCY && profile.rep(e.faction) < -40) { ok = false; req.append(" - ").append(ZoneState.cap(e.faction)).append(" have barred you"); }
            s.eligible = ok;
            s.requirement = req.toString();
        }
    }

    // ------------------------------------------------------------------ strategic cells -> active population
    private void seedCells() {
        if (profile.agents.agents.isEmpty()) profile.agents = absentialis.sim.Agents.seed(world, profile.zone, profile.seed);
        for (absentialis.sim.Agents.Agent g : profile.agents.agents) g.actorId = 0;
        rebuildCells();
    }

    /** The abstract counts are a view of the offline agents: rebuilt whenever agents change hands. */
    private void rebuildCells() { cells.clear(); cells.putAll(profile.agents.allCounts()); }

    private int cellOf(float x, float z) { return V(x) * CELLS + V(z); }
    private static int V(float v) { return Math.max(0, Math.min(CELLS - 1, (int) v / CELL)); }

    /** Activates cells near the player (spawning their population) and folds distant ones back. */
    private void manageCells() {
        int pcx = V(player.x), pcz = V(player.z);
        java.util.Set<Integer> want = new java.util.HashSet<>();
        for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) {
            int a = pcx + dx, b = pcz + dz;
            if (a >= 0 && b >= 0 && a < CELLS && b < CELLS) want.add(a * CELLS + b);
        }
        for (Integer c : want) if (!activeCells.contains(c)) { activeCells.add(c); spawnCell(c); }
        for (Integer c : new ArrayList<>(activeCells)) {
            int a = c / CELLS, b = c % CELLS;
            if (Math.abs(a - pcx) > 2 || Math.abs(b - pcz) > 2) { activeCells.remove(c); foldCell(c); }
        }
    }

    private static final String[] POP_FACTION = {"infected", "military", "raiders", "survivors", "mercenaries"};

    /** Brings every offline agent of a cell online, each as the same individual it was before. */
    private void spawnCell(int c) {
        for (absentialis.sim.Agents.Agent ag : new ArrayList<>(profile.agents.agents)) if (ag.alive && ag.actorId == 0 && ag.cell() == c) materialize(ag, c, 40);
        rebuildCells();
    }

    /**
     * Offline -> online. The agent keeps its identity (look, weapon and kit are seeded by its id), health, home,
     * shift and squad. Refused - the agent simply stays offline a little longer - when the spot is close to the
     * player or anywhere the player could watch it appear.
     */
    private boolean materialize(absentialis.sim.Agents.Agent ag, int c, float minDist) {
        float[] p = standNear(ag.x, ag.z);
        if (p == null) return false;
        float d = player.distXZ(p[0], p[2]);
        if (d < minDist) return false;
        if (d < 75 && Physics.los(world, player.x, player.eyeY(), player.z, p[0], p[1] + 1.2f, p[2])) return false;
        Actor a = makeActor(ag.faction, p[0], p[1], p[2], new Rng(ag.id * 7919L + 17));
        if ("tank".equals(a.archetype) && d < 70) a = remake(a, "walker");
        actors.add(a);
        a.cell = c;
        a.agentId = ag.id; ag.actorId = a.id;
        a.name = ag.name;
        a.nightShift = ag.night;
        a.duty = ag.role;
        a.homeX = ag.homeX; a.homeZ = ag.homeZ;
        a.hp = Math.max(8, a.maxHp * ag.hp);
        if (!a.infected()) {
            a.morale = Math.min(a.morale, 0.35f + 0.65f * ag.morale);
            a.squad = ag.squad == 0 ? 500000 + (int) (ag.id % 400000) : 1 + (int) (ag.squad % 400000);
            a.role = "guard".equals(ag.role) ? "hold" : "";
            if (ag.hp < 0.6f && "survivors".equals(a.faction) && rng.chance(0.5)) a.needsHelp = true;
            Squad sq = squadOf(a.squad, a.faction);
            int members = 0;
            for (Actor m : actors) if (!m.dead && m.squad == a.squad && m.faction.equals(a.faction)) members++;
            sq.alive = members; sq.initial = Math.max(sq.initial, members);
            if ("military".equals(a.faction) && sq.route.isEmpty()) buildRoute(sq, a.homeX, a.homeZ);
        }
        a.routine = absentialis.sim.Agents.activity(ag.faction, ag.role, ag.night, hour(), ag.id);
        return true;
    }

    /** A standable street-level spot at or right beside a position, or null. */
    private float[] standNear(float x, float z) {
        int ix = (int) Math.floor(x), iz = (int) Math.floor(z);
        for (int r = 0; r <= 4; r++) for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) {
            if (Math.max(Math.abs(dx), Math.abs(dz)) != r) continue;
            int y = world.nav.stepY(ix + dx, iz + dz, World.GROUND, false);
            if (y < 0) y = world.nav.stepY(ix + dx, iz + dz, World.GROUND - 2, false);
            if (y >= 0 && Physics.boxFree(world, ix + dx + 0.5f, y, iz + dz + 0.5f, 0.3f, 1.8f)) return new float[]{ix + dx + 0.5f, y, iz + dz + 0.5f};
        }
        int gy = groundY(ix, iz);
        return gy < 0 ? null : new float[]{ix + 0.5f, gy, iz + 0.5f};
    }

    /** Online -> offline: the agent's position and condition are written back; the dead stay as bodies for a while. */
    private void foldCell(int c) {
        for (Actor a : new ArrayList<>(actors)) {
            if (a.isPlayer || a.mate() || a.cell != c) continue;
            if (!a.dead) release(a);
            if (!a.dead || a.deadTime > 120) actors.remove(a);
        }
        rebuildCells();
    }

    private void release(Actor a) {
        absentialis.sim.Agents.Agent ag = a.agentId == 0 ? null : profile.agents.byId(a.agentId);
        if (ag == null) return;
        ag.x = a.x; ag.z = a.z;
        ag.hp = Math.max(0.05f, a.hp / a.maxHp);
        ag.morale = a.infected() ? ag.morale : Math.max(0.05f, Math.min(1, a.morale));
        ag.actorId = 0;
    }

    /** Raid end: everyone still online goes back to the offline population where they stand. */
    public void releaseAll() { for (Actor a : actors) if (!a.dead && !a.isPlayer && !a.mate()) release(a); }

    /** Total living population across folded cells + live actors (tier transition audit). */
    public int populationTotal() {
        int n = 0;
        for (int[] p : cells.values()) for (int v : p) n += v;
        for (Actor a : actors) if (!a.isPlayer && !a.dead && !a.mate()) n++;
        return n;
    }

    private String lastSpawnKind = "";

    private float[] spawnPoint(int cx, int cz, Rng r, boolean infected, String faction) {
        List<MapData.Point> cand = new ArrayList<>();
        for (MapData.Point p : infected ? world.map.nests : world.map.posts) if (p.x / CELL == cx && p.z / CELL == cz && (infected || p.faction.equals(faction))) cand.add(p);
        if (!cand.isEmpty() && r.chance(0.75)) { MapData.Point p = r.pick(cand); lastSpawnKind = p.kind; return new float[]{p.x + r.range(-2f, 2f), p.y, p.z + r.range(-2f, 2f)}; }
        for (int tries = 0; tries < 12; tries++) {
            float x = cx * CELL + r.range(2f, CELL - 2), z = cz * CELL + r.range(2f, CELL - 2);
            MapData.Node n = world.map.nearestNode(x, z);
            if (n != null && Math.abs(n.x - x) < CELL && Math.abs(n.z - z) < CELL) return new float[]{n.x + r.range(-3f, 3f), n.y, n.z + r.range(-3f, 3f)};
        }
        return null;
    }

    /**
     * The standable cell closest to a wanted height: agents spawn on the street or the floor their
     * post is on, never on top of a lamp arm or an awning that happens to be the highest block.
     */
    public int standY(int x, int z, int near) {
        for (int d = 0; d <= 4; d++) for (int s = -1; s <= 1; s += 2) {
            int y = near + d * s;
            if (y > 1 && y < World.H - 3 && world.solid(x, y - 1, z) && !world.solid(x, y, z) && !world.solid(x, y + 1, z)) return y;
            if (d == 0) break;
        }
        return groundY(x, z);
    }

    /** When set, agents keep their bodies and animation but stop deciding (staging, screenshots). */
    public boolean freezeAI;

    /** Console / automation: spawns one agent of a faction or infected archetype at a position. */
    public Actor debugSpawn(String what, float x, float z, float nearY) {
        boolean human = java.util.List.of(ZoneState.FACTIONS).contains(what);
        int y = standY((int) Math.floor(x), (int) Math.floor(z), Math.round(nearY));
        Actor a = makeActor(human ? what : "infected", x, y, z, rng);
        if (!human) remake(a, what);
        a.look = a.faction + ":" + a.archetype;
        a.squad = human ? 900000 + what.hashCode() % 1000 : 0;
        actors.add(a);
        return a;
    }

    public int groundY(int x, int z) {
        for (int y = Math.min(World.H - 3, world.heightAt(x, z) + 1); y > 1; y--) {
            if (!world.solid(x, y, z) && !world.solid(x, y + 1, z) && world.solid(x, y - 1, z)) return y;
        }
        return -1;
    }

    private Actor makeActor(String faction, float x, float y, float z, Rng r) {
        Actor a = new Actor();
        a.faction = faction;
        a.x = x; a.y = y; a.z = z; a.homeX = x; a.homeZ = z;
        a.yaw = r.range(0f, 6.28f);
        if ("infected".equals(faction)) {
            // four archetypes: mostly regulars for group pressure, a few specials that change the fight
            float roll = r.nextFloat();
            boolean closing = remaining() < 600;
            a.archetype = roll < 0.62f ? "walker" : roll < 0.84f ? "sprinter" : roll < (closing ? 0.93f : 0.965f) ? "boomer" : "tank";
            if ("tank".equals(a.archetype) && !r.chance(0.5)) a.archetype = "walker";
        } else {
            Map<String, List<String>> kit = Content.KITS.get(faction);
            List<String> prim = kit == null ? List.of("weapon.akr") : kit.get("primary");
            String w = r.pick(prim);
            a.weapon = armed(w, r);
            ItemDef wd = Content.def(w);
            a.archetype = wd.weapon.family.equals("shotgun") ? "shotgunner" : w.equals("weapon.mosin") || w.equals("weapon.sr16") ? "marksman" : "rifleman";
            List<String> arm = kit == null ? List.of("") : kit.get("armor");
            String av = r.pick(arm);
            if (!av.isEmpty()) { a.armorClass = Content.def(av).armor.armorClass; a.armorDur = Content.def(av).armor.durability; a.armorMax = a.armorDur; a.look += "vest:" + av + ";"; }
            List<String> hd = kit == null ? List.of("") : kit.get("head");
            String hv = r.pick(hd);
            if (!hv.isEmpty()) { a.helmet = Content.def(hv).armor.armorClass > 0; a.look += "head:" + hv + ";"; }
            a.hostileToPlayer = Brain.initialHostility(faction, profile.rep(faction));
            a.aggressor = a.hostileToPlayer;
            Brain.initHuman(a);
        }
        shape(a);
        a.look = faction + ":" + a.archetype + ":" + a.look + (a.weapon != null ? a.weapon.defId : "");
        return a;
    }

    /** Body dimensions, health and animation family for an archetype. */
    public static void shape(Actor a) {
        Brain.Arch ar = Brain.arch(a.archetype);
        a.hp = a.maxHp = ar.hp();
        a.stand = 1.8f; a.radius = 0.3f;
        if ("tank".equals(a.archetype)) { a.stand = 2.6f; a.radius = 0.55f; }
        if ("shambler".equals(a.archetype) || "boomer".equals(a.archetype)) { a.radius = 0.42f; a.stand = 1.9f; }
        shapeAnim(a);
    }

    private static void shapeAnim(Actor a) {
        a.anim = new Animator();
        a.anim.family = Animator.familyOf(a.archetype, a.infected());
        a.anim.scale = "tank".equals(a.archetype) ? 1.45f : "boomer".equals(a.archetype) ? 1.08f : 1f;
    }

    private Actor remake(Actor a, String archetype) { a.archetype = archetype; shape(a); a.visual = null; return a; }

    private ItemInstance armed(String id, Rng r) {
        ItemInstance w = new ItemInstance(id);
        w.origin = raidId;
        w.setCondition(r.range(30f, 85f));
        ItemDef d = w.def();
        w.rounds = Math.max(1, d.weapon.capacity - r.nextInt(Math.max(1, d.weapon.capacity / 3)));
        w.ammoId = Content.ammoFor(d.weapon.caliber).id;
        return w;
    }

    // ------------------------------------------------------------------ update
    public void update(float dt) {
        if (debrief.outcome != Debrief.Outcome.NONE) return;
        time += dt;
        world.nav.budget = 8;
        cellTimer -= dt;
        if (cellTimer <= 0 && populate) { cellTimer = 1f; manageCells(); }
        muzzleFlash = Math.max(0, muzzleFlash - dt * 12);
        damageShake = Math.max(0, damageShake - dt * 3);
        flashBlind = Math.max(0, flashBlind - dt * 0.28f);
        hitMarkers.removeIf(h -> time - h[1] > 1.6f);
        telegraphs.removeIf(t -> time > t.until());
        timerPhases();
        squadTimer -= dt;
        if (squadTimer <= 0) { squadTimer = 1f; countSquads(); missingPatrols(); for (int i = 0; i < heat.length; i++) heat[i] = Math.max(0, heat[i] - 0.04f); }
        updateZones(dt);
        gore.update(dt);
        fire.update(dt);
        infection.update(dt);
        vehicles.update(dt);
        doors.update(dt);
        casualty.update(dt);
        if (body.herbsTaken > 0) {
            // permanent: written to the profile the moment it is eaten, whatever happens to the rest of the raid
            int before = profile.herbs;
            profile.herbs = Math.min(combat.herbCap(), profile.herbs + body.herbsTaken);
            body.herbsTaken = 0;
            float gain = combat.maxHealth(profile.herbs) - player.maxHp;
            if (gain > 0) { player.maxHp += gain; player.hp = Math.min(player.maxHp, player.hp + gain); msg("Maximum health +" + Math.round(gain) + "  (" + Math.round(player.maxHp) + ")", 0xFFE0C040); }
            else if (profile.herbs == before) msg("Your body can take no more from the herb - maximum health is at its limit", 0xFFE2A034);
            body.healthChanged = time;
        }
        slipT = Math.max(0, slipT - dt);
        // offline agents keep living their day: a quarter of a game hour every thirty seconds
        alifeTimer += dt;
        if (alifeTimer >= 30 && populate) {
            alifeTimer = 0;
            profile.agents.step(world, profile.zone, hour(), 0.25f, rng, activeCells::contains);
            rebuildCells();
        }
        if (player.anim == null) player.anim = new Animator();
        player.anim.update(player, dt, player.weapon != null, playerAiming, false);
        // agents: active tier full rate, regional tier at reduced rate (no spikes on transition)
        for (Actor a : new ArrayList<>(actors)) {
            if (a.isPlayer) { if (a.dead && a.ragdoll != null && !a.ragdoll.settled) a.ragdoll.update(world, dt); continue; }
            if (a.dead) {
                a.deadTime += dt;
                if (a.ragdoll != null && !a.ragdoll.settled) {
                    a.ragdoll.update(world, dt);
                    a.x = a.ragdoll.x[Ragdoll.PELVIS]; a.z = a.ragdoll.z[Ragdoll.PELVIS]; a.y = Math.max(0, a.ragdoll.lowestY());
                }
                continue;
            }
            if (a.ragdoll != null) continue;   // knocked down: physics has the body until it gets up (RagdollController)
            if (a.injurySeverity > 0) a.injurySeverity = Math.max(0, a.injurySeverity - dt * 0.03f);
            float d = a.distXZ(player.x, player.z);
            a.tier = a.mate() || d < 80 ? 0 : 1;
            if (a.tier == 1) {
                a.regionalAccum += dt;
                if (a.regionalAccum < 0.5f) continue;
                float rdt = a.regionalAccum;
                a.regionalAccum = 0;
                Brain.update(this, a, rdt);
                a.vx *= 0.5f; a.vz *= 0.5f;
                Physics.move(world, a, rdt * 0.5f);
                continue;
            }
            if (!freezeAI) Brain.update(this, a, dt); else { a.vx *= 0.6f; a.vz *= 0.6f; }
            if (a.dead) continue;
            // movement has weight: velocity eases toward what the mind asked for instead of snapping to it
            float acc = Math.min(1, dt * (a.infected() ? 9f : 12f));
            a.vx = a.pvx + (a.vx - a.pvx) * acc; a.vz = a.pvz + (a.vz - a.pvz) * acc;
            a.pvx = a.vx; a.pvz = a.vz;
            a.wantClimb = false;
            if (time < a.staggerUntil) { a.vx *= 0.35f; a.vz *= 0.35f; }
            if (a.speedMul < 1) { a.vx *= a.speedMul; a.vz *= a.speedMul; }   // crippled or crawling
            if (!a.infected() && a.vital == absentialis.entity.Vital.ACTIVE) { float k = combat.speed[combat.condition(a.hp, a.maxHp).ordinal()]; a.vx *= k; a.vz *= k; }
            if (Physics.move(world, a, dt)) a.stuckTime += dt; else a.stuckTime = Math.max(0, a.stuckTime - dt);
            float sp = (float) Math.sqrt(a.vx * a.vx + a.vz * a.vz);
            a.walkPhase += sp * dt * 2.2f;
            if (a.anim == null) shapeAnim(a);
            boolean eng = "engage".equals(a.state) || "extort".equals(a.state) || "warn".equals(a.state) || "search".equals(a.state) || "alert".equals(a.state);
            float before = a.anim.phase;
            a.anim.update(a, dt, a.weapon != null, eng && !a.infected(), eng);
            // footfalls: one per half cycle, on the material actually underfoot
            if (a.onGround && sp > 0.4f && d < 45 && (before < 0.5f) != (a.anim.phase < 0.5f)) footstep(a, sp);
            if (a.y < -10) a.dead = true;
            // infected footsteps & groans are audible cues
            if (a.infected() && rng.chance(dt * 0.08)) emitSound(a.x, a.y + 1, a.z, 10, "groan", a.id, false);
        }
        updateProjectiles(dt);
        updateThrown(dt);
        for (WorldItem w : items) {
            w.age += dt;
            w.vy -= Physics.GRAVITY * dt;
            float ny = w.y + w.vy * dt;
            if (world.solid((int) Math.floor(w.x), (int) Math.floor(ny), (int) Math.floor(w.z))) { w.vy = 0; w.y = (float) Math.floor(ny) + 1; }
            else w.y = ny;
        }
        for (Effect e : effects) { e.life -= dt; e.vy -= 9 * dt; e.x += e.vx * dt; e.y += e.vy * dt; e.z += e.vz * dt; }
        effects.removeIf(e -> e.life <= 0);
        if (effects.size() > 900) effects.subList(0, effects.size() - 900).clear();
        sounds.removeIf(s -> time - s.time() > 4);
        environment(dt);
        extraction(dt);
        if (player.hp <= 0 && !god && !player.dead) {
            // a blow that would kill may put the player down instead; anything slower (blood, hunger, fever, fire) simply kills
            Actor by = actor(player.lastAttacker);
            boolean blow = time - player.lastHitTime < 0.35f;
            if (!(blow && casualty.lethal(player, by, -player.hp, player.hitRegion, player.lastHitKind, Gore.lost(player, absentialis.character.Rig.HEAD))))
                die(player.vital != absentialis.entity.Vital.ACTIVE ? "Bled out" + (by != null && by != player ? " - put down by " + describe(by) : "") : "Killed in action" + (by != null && by != player ? " by " + describe(by) : ""));
        }
        if (dying > 0 && !deathHold) { dying -= dt; if (dying <= 0) finishDeath(dyingReason); }
    }

    public static String describe(Actor a) { return a.infected() ? "a " + a.archetype : "a " + a.faction.substring(0, a.faction.length() - 1) + " " + a.archetype; }

    private void timerPhases() {
        float rem = remaining();
        if (rem <= 600 && !warned10) { warned10 = true; radio("All units, extraction window closing in ten minutes. Sweep teams moving in."); escalate(1); }
        if (rem <= 180 && !warned3) { warned3 = true; radio("Three minutes. Cordon closes at zero - get out or get left."); escalate(2); }
        if (rem <= 0 && !closedAnnounced) {
            closedAnnounced = true;
            radio("Window closed. Emergency cordon gate open for three minutes - it will cost you.");
            evaluateExits();
        }
        if (rem <= -180 && debrief.outcome == Debrief.Outcome.NONE) {
            debrief.outcome = Debrief.Outcome.MIA;
            debrief.reason = "Missed extraction - lost in the Zone when the cordon closed";
            bus.emit(new Events.RaidFailed(debrief.reason));
        }
        radioTimer -= 1 / 60f;
    }

    private void radio(String text) {
        emitSound(player.x, player.y + 1.5f, player.z, 0, "radio", player.id, true);
        msg("RADIO: " + text, 0xFFE2A034);
    }

    /** Closing-phase escalation: infected migrate toward the player's area (redistribution, not magic spawns). */
    private void escalate(int stage) {
        int pc = cellOf(player.x, player.z);
        for (Map.Entry<Integer, int[]> e : new ArrayList<>(cells.entrySet())) if (e.getKey() != pc && e.getValue()[0] > 1) for (int k = 0; k < stage; k++) profile.agents.shift(e.getKey(), pc, "infected", rng);
        rebuildCells();
    }

    private void environment(float dt) {
        envTimer -= dt;
        discoverTimer -= dt;
        if (discoverTimer <= 0) {
            discoverTimer = 0.5f;
            int n = profile.discover(player.x, player.z, 3);
            if (n > 0) { debrief.cellsRevealed += n; profile.contracts.onExplore(world.district(player.x, player.z), n); }
            evaluateExits();
        }
        // wilderness radiation: the further out, the worse
        float out = World.outsideDistance(player.x, player.z);
        float radiation = out > 0 ? 0.5f + out * 0.12f : 0;
        boolean mask = profile.loadout.slot("face") != null && profile.loadout.slot("face").def().armor != null && profile.loadout.slot("face").def().armor.gasMask;
        if (radiation > 0 && envTimer <= 0) { envTimer = 1.2f; emitSound(player.x, player.y, player.z, 0, "geiger", player.id, true); }
        if (out > 10) player.hp -= dt * out * 0.02f; // the Zone pushes back
        Block feet = world.block((int) Math.floor(player.x), (int) Math.floor(player.y - 0.2f), (int) Math.floor(player.z));
        Block in = world.block((int) Math.floor(player.x), (int) Math.floor(player.y + 0.2f), (int) Math.floor(player.z));
        if ((feet != null && feet.is(Block.HAZARD)) || (in != null && in.is(Block.HAZARD))) { player.hp -= dt * 4; radiation += 1.5f; }
        player.radius = 0.3f;
        float weaponMass = player.weapon == null ? 0 : player.weapon.mass();
        body.update(player, dt, time, Math.abs(player.vx) + Math.abs(player.vz) > 0.3f, player.sprinting, playerAiming, weaponMass, radiation, mask, settings.difficulty == 2 ? 1.4f : settings.difficulty == 0 ? 0.7f : 1f);
        // passive weapon decay in rain / sewer water
        boolean sewer = player.y < World.GROUND - 2;
        float env = WeaponService.environmentWear(profile.zone.weatherRain > 0.5f && world.sky((int) player.x, (int) player.eyeY(), (int) player.z) > 12, sewer, out > 0);
        for (String s : new String[]{"primary", "sidearm"}) { ItemInstance w = profile.loadout.slot(s); if (w != null) WeaponService.wearCarried(w, dt, env); }
    }

    public float environmentWear() {
        boolean sewer = player.y < World.GROUND - 2;
        return WeaponService.environmentWear(profile.zone.weatherRain > 0.5f, sewer, World.outsideDistance(player.x, player.z) > 0);
    }

    // ------------------------------------------------------------------ extraction
    public ExitState exitAt(float x, float y, float z) {
        for (ExitState s : exits) {
            MapData.Exit e = s.exit;
            float dx = x - (e.x + 0.5f), dz = z - (e.z + 0.5f);
            if (dx * dx + dz * dz < e.radius * e.radius && Math.abs(y - e.y) < 4) return s;
        }
        return null;
    }

    private void extraction(float dt) {
        for (ExitState s : exits) if (s.signalTimer > 0) {
            s.signalTimer -= dt;
            if (s.signalTimer <= 0) { s.signaled = true; msg("Helicopter on station at " + s.exit.name + " - extraction available.", 0xFF7DBA5C); evaluateExits(); }
        }
        ExitState here = player.dead ? null : exitAt(player.x, player.y, player.z);
        if (here == null || !here.eligible) {
            if (extracting != null) msg("Extraction cancelled - left the zone", 0xFFD8483A);
            extracting = null; extractProgress = 0;
            return;
        }
        if (extracting != here) { extracting = here; extractProgress = 0; bus.emit(new Events.ExtractionStarted(here.exit.id, 8)); }
        // hostile interference delays departure
        boolean threatened = false;
        for (Actor a : nearby(player.x, player.z, 12)) if (!a.isPlayer && Brain.hostile(this, a, player) && "engage".equals(a.state)) threatened = true;
        extractProgress += dt * (threatened ? 0.25f : 1f);
        if (extractProgress >= 8f) extract(here);
    }

    private void extract(ExitState s) {
        MapData.Exit e = s.exit;
        if (e.type == MapData.ExitType.EMERGENCY) {
            if (profile.scrip >= 1500) { debrief.emergencyCost = 1500; debrief.consequences.add("Paid " + absentialis.Version.coins(1500) + " to the cordon guards"); }
            else { debrief.emergencyCost = -1; debrief.consequences.add("Could not pay the cordon - guards confiscated your treasures"); }
        }
        if (e.condition.contains("pay:") && profile.rep("military") < 0) debrief.emergencyCost = Integer.parseInt(e.condition.replaceAll(".*pay:(\\d+).*", "$1"));
        debrief.outcome = Debrief.Outcome.EXTRACTED;
        debrief.exitName = e.name;
        debrief.reason = "Extracted via " + e.name;
        bus.emit(new Events.ExtractionCompleted(e.id));
    }

    /** The player dies once. With a death camera the body ragdolls in the world first; the raid resolves when it ends. */
    public void die(String reason) {
        if (debrief.outcome != Debrief.Outcome.NONE || dying > 0 || player.dead) return;
        Actor killer = actor(player.lastAttacker);
        confirmKill(player, time - player.lastHitTime < 20 ? killer : null);
        casualty.died(player);
        player.dead = true;
        player.vx = player.vz = 0;
        dyingReason = reason;
        if (player.anim == null) shapeAnim(player);
        // the body stays in the world whatever happens next: animation hands it to the ragdoll in the pose it died in
        gore.deathBlow(player, lastKindFor(player));
        startRagdoll(player);
        gore.onDeath(player, Math.max(30, player.hitForce), lastKindFor(player));
        if (deathCam > 0) { dying = deathCam; return; }
        finishDeath(reason);
    }

    private void finishDeath(String reason) {
        if (debrief.outcome != Debrief.Outcome.NONE) return; // death applies once
        debrief.outcome = Debrief.Outcome.KILLED;
        debrief.reason = reason;
        bus.emit(new Events.RaidFailed(reason));
    }

    /** A wounded agent ran out of blood. */
    public void bleedOut(Actor a) {
        if (a.dead) return;
        a.hitRegion = "torso"; a.hitForce = 8;
        a.hp = 0;
        finish(a, actor(a.lastAttacker), "bleed");
    }

    /** Ends a character by a named cause (blood loss, the end of a bleed-out): no incapacitation roll, one death. */
    void finish(Actor a, Actor by, String kind) {
        if (a.dead) return;
        lastKind = kind;
        a.lastHitKind = kind;
        if (a.isPlayer) { a.hp = 0; die(kind.equals("bleed") ? "Bled out" + (by != null && by != a ? " - put down by " + describe(by) : "") : "Killed in action"); return; }
        kill(a, by);
    }

    /** What a character is called on screen: its own name, or what it is. */
    public static String displayName(Actor a) {
        if (a == null) return "";
        if (a.name != null && !a.name.isEmpty()) return a.name.contains("\"") ? a.name.substring(a.name.indexOf('"') + 1, a.name.lastIndexOf('"')) : a.name;
        if (a.isPlayer) return "You";
        if (a.infected()) return a.turned ? "Turned " + speaker(a).toLowerCase() : Brain.displayName(a.archetype) + " infected";
        return speaker(a);
    }

    /** One death, one event: who, by whom, with what. Every route to death comes through here exactly once. */
    private void confirmKill(Actor v, Actor attacker) {
        String cause = lastKindFor(v);
        String weapon = "";
        if (attacker != null && (cause.equals("bullet") || cause.equals("melee"))) weapon = hitWeaponId != null ? hitWeaponId : attacker.weapon != null ? attacker.weapon.defId : "";
        boolean friendly = attacker != null && attacker != v && (attacker.faction.equals(v.faction) || casualty.friendly(attacker, v));
        boolean ours = attacker != null && "player".equals(attacker.faction);
        bus.emit(new Events.KillConfirmed(attacker == null ? 0 : attacker.id, attacker == null ? "" : displayName(attacker), attacker == null ? "" : attacker.faction, v.id, displayName(v), v.faction,
                weapon, cause, friendly, "head".equals(v.hitRegion) && cause.equals("bullet"), ours, time));
    }

    private String lastKindFor(Actor v) { return v.lastHitKind == null || v.lastHitKind.isEmpty() ? lastKind : v.lastHitKind; }

    /** The player lost their footing in fresh blood. */
    public void playerSlip() {
        slipT = 0.9f;
        damageShake = Math.min(1, damageShake + 0.45f);
        msg("You slip in the blood", 0xFFE2A034);
        emitSound(player.x, player.y, player.z, 12, "slip", player.id, false);
    }

    /**
     * Missing patrol members: a squad does not know the instant one of its own dies out of sight. After a
     * while someone notices the silence, says so, and the squad goes to look where that member was last headed.
     */
    private void missingPatrols() {
        for (Squad sq : squads.values()) {
            if (sq.missing.isEmpty()) continue;
            float[] m = sq.missing.get(0);
            if (time - m[3] < 18) continue;
            sq.missing.remove(0);
            boolean said = false;
            for (Actor a : actors) {
                if (a.dead || a.isPlayer || a.squad != sq.id || !a.faction.equals(sq.faction)) continue;
                if (!said) { say(a, rng.chance(0.5) ? "He's not answering. Something's wrong." : "We're one short - go and look.", "radio_chatter"); said = true; }
                a.morale -= 0.06f;
                a.alertness = Math.max(a.alertness, 0.7f);
                if ("idle".equals(a.state) || "investigate".equals(a.state)) { a.memX = m[0] + rng.range(-5f, 5f); a.memY = m[1]; a.memZ = m[2] + rng.range(-5f, 5f); a.memTime = time; a.memConfidence = 0.4f; a.memErr = 8; a.state = "investigate"; a.stateTime = 0; a.hasGoal = false; a.wakeUntil = time + 90; }
            }
        }
    }

    // ------------------------------------------------------------------ sound & perception
    /** Emits a signature; agents within its attenuated radius hear it (GDD 17.2). */
    public void emitSound(float x, float y, float z, float radius, String category, int source, boolean playerOnly) {
        sounds.add(new Sound(x, y, z, radius, category, source, time));
        if (source == player.id) debrief.noise += radius;
        if (listener != null && source != player.id) listener.caption(category, x, z, Math.max(0.1f, 1 - player.distXZ(x, z) / Math.max(1, radius * 1.5f)));
        if (playerOnly || radius <= 0) return;
        for (Actor a : actors) {
            if (a.isPlayer || a.dead || a.id == source) continue;
            float dx = a.x - x, dy = a.y - y, dz = a.z - z;
            float d = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
            // busy districts mask sound; rain dulls it further
            // at arm's length a sound is a sound; further out, busy districts and rain mask it
            float mask = d < 6 ? 1 : (1 - 0.22f * world.district(a.x, a.z).def.noise) * (1 - 0.2f * rain());
            float hearing = Brain.arch(a.archetype).hearing() * mask;
            float eff = radius * hearing;
            if (d > eff) continue;
            float occl = d < 6 ? 1 : 0.45f + 0.55f * Physics.openness(world, x, y, z, a.x, a.eyeY(), a.z);
            if (d > eff * occl) continue;
            Brain.hear(this, a, x, y, z, 1 - d / Math.max(1, eff * occl), category, source);
        }
        if (source == player.id) profile.zone.reportNoise(world.district(x, z), radius * 0.05f);
        noiseEvent(x, y, z, radius, category, source);
    }

    public void telegraph(Actor a, String kind, float dur) {
        telegraphs.add(new Telegraph(a.id, kind, time + dur));
        // every special has an audible cue AND a wind-up animation (never audio-only, never instant)
        String clip = null;
        switch (kind) {
            case "screech" -> { emitSound(a.x, a.y + 1.5f, a.z, 70, "screech", a.id, false); clip = "inf_shriek"; }
            case "shriek" -> { emitSound(a.x, a.y + 1.5f, a.z, 45, "shriek", a.id, false); clip = "inf_shriek"; }
            case "swell" -> { emitSound(a.x, a.y + 1, a.z, 18, "gurgle", a.id, false); clip = "fat_swell"; }
            case "retch" -> { emitSound(a.x, a.y + 1, a.z, 22, "retch", a.id, false); clip = "fat_retch"; }
            case "charge" -> { emitSound(a.x, a.y + 1, a.z, 50, "roar", a.id, false); clip = "giant_windup"; }
            case "throw" -> { emitSound(a.x, a.y + 1, a.z, 55, "roar", a.id, false); clip = "giant_throw"; }
            default -> {}
        }
        if (clip != null) { if (a.anim == null) shapeAnim(a); a.anim.play(clip, dur); }
    }

    public boolean telegraphing(Actor a, String kind) { for (Telegraph t : telegraphs) if (t.actorId() == a.id && t.kind().equals(kind)) return true; return false; }

    // ------------------------------------------------------------------ combat
    /** Spawns projectiles for one trigger pull. dir must be normalised. Returns pellets spawned. */
    public int fireProjectiles(Actor shooter, ItemInstance weapon, ItemDef ammo, float ox, float oy, float oz, float dx, float dy, float dz, float spreadDeg) {
        ItemDef.Ammo am = ammo.ammo;
        Gunsmith.Stats st = Gunsmith.stats(weapon, 0);
        float speed = Gunsmith.velocity(ammo) * st.velocityMul;
        int pellets = Math.max(1, am.pellets);
        for (int p = 0; p < pellets; p++) {
            float sp = (float) Math.toRadians(spreadDeg + am.spread * (pellets > 1 ? 1 : 0));
            float ax = dx + (float) rng.nextGaussian() * sp * 0.5f, ay = dy + (float) rng.nextGaussian() * sp * 0.5f, az = dz + (float) rng.nextGaussian() * sp * 0.5f;
            float l = (float) Math.sqrt(ax * ax + ay * ay + az * az);
            Projectile pr = new Projectile();
            pr.x = pr.px = ox; pr.y = pr.py = oy; pr.z = pr.pz = oz;
            pr.vx = ax / l * speed; pr.vy = ay / l * speed; pr.vz = az / l * speed;
            pr.damage = am.damage * weapon.def().weapon.damageMul * st.damageMul;
            pr.power = am.pen * st.penMul / 10f;
            pr.range = st.range; pr.ox = ox; pr.oy = oy; pr.oz = oz;
            pr.owner = shooter.id;
            pr.ownerFaction = shooter.faction;
            pr.weaponId = weapon.defId;
            pr.ammo = ammo;
            pr.tracer = am.tracer || shooter != player && rng.chance(0.3);
            projectiles.add(pr);
        }
        return pellets;
    }

    public void shotSignature(Actor shooter, ItemInstance weapon, Gunsmith.Stats st, float x, float y, float z) {
        float radius = st.noise * (st.suppressed ? 0.9f : 1.6f);
        boolean silent = "special".equals(weapon.def().weapon.family);   // a crossbow string is not a gunshot
        // the event first: whoever renders the shot from it has done so before the generic sound report arrives
        bus.emit(new Events.ShotFired(shooter.id, shooter.faction, x, y, z, radius, weapon.defId, st.suppressed, st.rpm, (float) -Math.sin(shooter.yaw), (float) -Math.cos(shooter.yaw)));
        emitSound(x, y, z, silent ? st.noise : radius, silent ? "bolt_release" : st.suppressed ? "shot_suppressed" : "shot", shooter.id, false);
        if (shooter == player) {
            debrief.shotsFired++;
            lastPlayerShot = time;
            // firing on a neutral faction member in view is observed aggression
            for (Actor a : nearby(x, z, 50)) if (!a.isPlayer && !a.mate() && !a.infected() && !a.hostileToPlayer && Physics.los(world, a.x, a.eyeY(), a.z, x, y, z)) a.sawPlayerAggress = true;
        }
    }

    private void updateProjectiles(float dt) {
        for (int pi = 0; pi < projectiles.size(); pi++) {   // by index: a hit can chain into anything (ruptures, blasts, debris)
            Projectile p = projectiles.get(pi);
            p.age += dt;
            if (p.dead) continue;
            p.px = p.x; p.py = p.y; p.pz = p.z;
            float rem = dt;
            while (rem > 0 && !p.dead) {
                float step = Math.min(rem, 0.6f / Math.max(1, Math.abs(p.vx) + Math.abs(p.vy) + Math.abs(p.vz)) * 30);
                rem -= step;
                p.vy -= 9.81f * step;
                float nx = p.x + p.vx * step, ny = p.y + p.vy * step, nz = p.z + p.vz * step;
                segment(p, nx, ny, nz);
                if (!p.dead) { p.x = nx; p.y = ny; p.z = nz; }
            }
            if (p.age > 2.5f || p.y < 0) p.dead = true;
        }
        projectiles.removeIf(p -> p.dead || p.age > 3);
    }

    /** Moves along one sub-segment: actor hits first, then voxel penetration/stop. */
    private void segment(Projectile p, float nx, float ny, float nz) {
        float dx = nx - p.x, dy = ny - p.y, dz = nz - p.z, len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-5f) return;
        dx /= len; dy /= len; dz /= len;
        // voxel walk along the segment
        float blockT = Float.MAX_VALUE;
        int bx = 0, by = 0, bz = 0;
        int steps = (int) (len * 4) + 1;
        for (int i = 1; i <= steps; i++) {
            float t = len * i / steps;
            int x = (int) Math.floor(p.x + dx * t), y = (int) Math.floor(p.y + dy * t), z = (int) Math.floor(p.z + dz * t);
            int id = world.get(x, y, z);
            if (id != 0 && Block.ALL[id].solid()) { blockT = t; bx = x; by = y; bz = z; break; }
        }
        // bodywork and tyres: a car is cover, and a tyre is a target
        float carT = vehicles.cars.isEmpty() ? -1 : vehicles.rayHit(p.x, p.y, p.z, dx, dy, dz, Math.min(len, blockT), carHit);
        Actor hit = null;
        float hitT = Float.MAX_VALUE;
        for (Actor a : actors) {
            if (a.dead || a.id == p.owner) continue;
            // squads do not cut down their own flankers: agents' rounds pass their own side (the player's never do)
            if (a.faction.equals(p.ownerFaction) && (p.owner != player.id || a.mate())) continue;
            if (Math.abs(a.x - p.x) > len + 2 || Math.abs(a.z - p.z) > len + 2) continue;
            float t = a.intersect(p.x, p.y, p.z, dx, dy, dz, len);
            if (t >= 0 && t < hitT) { hitT = t; hit = a; }
            else if (t < 0 && p.nearId != a.id) {
                // a round that passes close is felt: closest approach of this step to the head and chest
                float hx0 = a.x - p.x, hy0 = a.y + a.height() * 0.8f - p.y, hz0 = a.z - p.z;
                float along = Math.max(0, Math.min(Math.min(len, blockT), hx0 * dx + hy0 * dy + hz0 * dz));
                float cx0 = hx0 - dx * along, cy0 = hy0 - dy * along, cz0 = hz0 - dz * along;
                if (cx0 * cx0 + cy0 * cy0 + cz0 * cz0 < 1.7f * 1.7f) {
                    p.nearId = a.id;
                    if (a.isPlayer) emitSound(player.x, player.y + 1.5f, player.z, 0, "bullet_snap", p.owner, true);
                    else absentialis.ai.Tactics.nearMiss(this, a, p.x + dx * along, p.y + dy * along, p.z + dz * along, p.owner);
                }
            }
        }
        if (carT >= 0 && carT < hitT && !(vehicles.driving != null && p.owner == player.id && carT < 2.5f)) {
            float hx = p.x + dx * carT, hy = p.y + dy * carT, hz = p.z + dz * carT;
            float through = vehicles.bullet(carHit[0], carHit[1], hx, hy, hz, p.damage, p.power);
            impact(hx, hy, hz, Material.THIN_METAL, 5);
            emitSound(hx, hy, hz, 10, "impact", p.owner, false);
            if (through <= 0) { p.dead = true; p.x = hx; p.y = hy; p.z = hz; return; }
            p.damage *= through; p.power *= through;
        }
        // a leaf standing open in the line of fire
        if (!doors.doors.isEmpty()) {
            float doorT = doors.ray(p.x, p.y, p.z, dx, dy, dz, Math.min(len, blockT), doorHit);
            if (doorT >= 0 && doorT < hitT) {
                float hx = p.x + dx * doorT, hy = p.y + dy * doorT, hz = p.z + dz * doorT;
                float through = doors.strikeOpen(doorHit[0], hx, hy, hz, p.damage, dx, dz, p.owner);
                impact(hx, hy, hz, doorHit[0].kind == Doors.METAL ? Material.METAL : doorHit[0].kind == Doors.GLASS ? Material.GLASS : Material.WOOD, 4);
                if (through <= 0) { p.dead = true; p.x = hx; p.y = hy; p.z = hz; return; }
                p.damage *= through; p.power *= through;
            }
        }
        Gore.Entry en = null;
        if (hit != null && hitT < blockT && hit.tier == 0) {
            // the capsule is only the broad phase: trace the round against the body's voxels in its current pose
            en = gore.trace(hit, p.x, p.y, p.z, dx, dy, dz, len + 0.8f);
            if (en == null || en.t > blockT) hit = null;      // between the arm and the ribs, or past the shoulder: a miss
            else hitT = en.t;
        }
        if (hit != null && hitT < blockT) {
            float hy = p.y + dy * hitT, hx = p.x + dx * hitT, hz = p.z + dz * hitT;
            rayEntry = en; rayDX = dx; rayDY = dy; rayDZ = dz; rayPower = p.power;
            float trav = (float) Math.sqrt((hx - p.ox) * (hx - p.ox) + (hy - p.oy) * (hy - p.oy) + (hz - p.oz) * (hz - p.oz));
            float falloff = trav <= p.range ? 1 : Math.max(0.4f, 1 - (trav - p.range) / Math.max(1, p.range) * 0.8f);
            hitWeaponId = p.weaponId;
            damageActor(hit, actor(p.owner), p.damage * falloff, p.ammo, hit.regionAt(hy), hx, hy, hz);
            hitWeaponId = null;
            rayEntry = null;
            p.dead = true;
            p.x += dx * hitT; p.y += dy * hitT; p.z += dz * hitT;
            return;
        }
        if (blockT < Float.MAX_VALUE) {
            Block b = Block.ALL[world.get(bx, by, bz)];
            Material m = b.mat;
            float hx = p.x + dx * blockT, hy = p.y + dy * blockT, hz = p.z + dz * blockT;
            Doors.Door struck = b.is(Block.DOOR) ? doors.at(bx, by, bz) : null;
            if (struck != null) doors.hit(struck, hx, hy, hz, p.damage, dx, dz, p.owner, "bullet");      // located on the leaf: panel, hinge or latch
            else damageBlock(bx, by, bz, p.damage, p.owner);
            if (p.power > m.resist) {
                // penetrate: lose energy proportional to material resistance
                p.power -= m.resist;
                p.damage *= Math.max(0.25f, 1 - m.resist / (p.power + m.resist + 0.01f));
                impact(hx, hy, hz, m, 3);
                return; // keeps flying through
            }
            impact(hx, hy, hz, m, 7);
            emitSound(hx, hy, hz, 8, "impact", p.owner, false);
            // rounds striking the wall beside someone pin them as surely as rounds going past
            for (Actor a : nearby(hx, hz, 2.4f)) if (!a.isPlayer && a.id != p.owner && !a.faction.equals(p.ownerFaction) && Math.abs(a.y + 1 - hy) < 2.2f) absentialis.ai.Tactics.nearMiss(this, a, hx, hy, hz, p.owner);
            p.dead = true;
            p.x = hx; p.y = hy; p.z = hz;
        }
    }

    private final int[] carHit = new int[2];
    private final Doors.Door[] doorHit = new Doors.Door[1];
    /** The round being resolved right now: where it entered the victim's anatomy, its direction and penetrating power. */
    private Gore.Entry rayEntry;
    private float rayDX, rayDY, rayDZ, rayPower, blastX, blastY, blastZ;
    /** Set by a caller to mark the close attack being resolved as a bite or a cut (default: a blunt blow). */
    public String meleeKind = "";

    private void impact(float x, float y, float z, Material m, int n) {
        for (int i = 0; i < n; i++) {
            Effect e = new Effect();
            e.x = x; e.y = y; e.z = z;
            e.vx = (rng.nextFloat() - 0.5f) * 4; e.vy = rng.nextFloat() * 3; e.vz = (rng.nextFloat() - 0.5f) * 4;
            e.life = e.max = 0.4f + rng.nextFloat() * 0.5f;
            e.size = 0.05f + rng.nextFloat() * 0.06f;
            e.color = 0xFF000000 | (m.r << 16) | (m.g << 8) | m.b;
            effects.add(e);
        }
    }

    public void damageBlock(int x, int y, int z, float dmg, int by) {
        int id = world.get(x, y, z);
        Block b = Block.ALL[id];
        if (b.is(Block.DOOR)) {
            // a door is not a block that vanishes: the hit goes to the entity (blast from its centre, anything else square on)
            Doors.Door d = doors.at(x, y, z);
            if (d != null) {
                if ("blast".equals(hitKind)) doors.blast(d, dmg * 0.25f, d.cx() - blastX, d.cz() - blastZ, by);
                else doors.hit(d, x + 0.5f, y + 0.5f, z + 0.5f, dmg, 0, 0, by, "blunt");
            }
            return;
        }
        if (b.hp <= 0) return;
        int idx = World.idx(x, y, z);
        float total = world.blockDamage.getOrDefault(idx, 0) + dmg;
        if (b.is(Block.FRAGILE) || total >= b.hp) {
            if (b.is(Block.CONTAINER) && !isLocked(x, y, z)) {
                Container box = containers.containsKey(idx) ? containers.get(idx) : openContainer(x, y, z);
                for (ItemInstance it : new ArrayList<>(box.items)) { InventoryService.release(it); dropItem(it, x + 0.5f + rng.range(-0.3f, 0.3f), y + 0.6f, z + 0.5f + rng.range(-0.3f, 0.3f)); }
            }
            world.set(x, y, z, b.breaksInto);
            bus.emit(new Events.BlockDestroyed(x, y, z, id, by));
            emitSound(x + 0.5f, y + 0.5f, z + 0.5f, b.mat == Material.GLASS ? 30 : 22, b.mat == Material.GLASS ? "glass_break" : "debris", by, false);
            impact(x + 0.5f, y + 0.5f, z + 0.5f, b.mat, 10);
        } else world.blockDamage.put(idx, Math.round(total));
    }

    /** Applies a hit: armour check, region multiplier, injuries, death and evidence. */
    public void damageActor(Actor v, Actor attacker, float dmg, ItemDef ammo, String region, float hx, float hy, float hz) {
        if (v.dead) return;
        if (v.isPlayer && god) return;
        if (v.isPlayer) {
            if (profile.loadout.charm("damage_one") > 0) dmg = Math.min(dmg, 1);
            if (v.shield > 0) {
                float soak = Math.min(v.shield, dmg);
                v.shield -= soak; dmg -= soak;
                ItemInstance plate = profile.loadout.slot("armor");
                if (plate != null && plate.def().armor != null && plate.def().armor.shield > 0) plate.durability = v.shield;
                body.healthChanged = time;
                if (v.shield <= 0) msg("Body armor destroyed", 0xFFD8483A);
                if (dmg <= 0.01f) { damageShake = Math.min(1, damageShake + soak / 60f); if (attacker != null) hitMarkers.add(new float[]{(float) Math.atan2(-(attacker.x - v.x), -(attacker.z - v.z)), time}); v.lastAttacker = attacker == null ? 0 : attacker.id; return; }
            }
        }
        // ---- where did it really land? Trace the blow against the body's voxels (near bodies; far ones use the coarse region)
        String kind = "blast".equals(hitKind) ? "blast" : "vehicle".equals(hitKind) ? "blunt" : ammo != null ? "bullet" : attacker != null ? "melee" : "blunt";
        Gore.Entry en = rayEntry;
        float idx = rayDX, idy = rayDY, idz = rayDZ;
        boolean anatomy = v.tier == 0 && !kind.equals("blast");
        boolean traced = en != null;
        if (anatomy && en == null) {
            // no projectile path: the caller named the region. Find where on that region the blow lands, coming
            // from the attacker's side (or, with nobody to blame, from wherever the body is facing).
            float ax = attacker != null ? v.x - attacker.x : (float) Math.sin(v.yaw), az = attacker != null ? v.z - attacker.z : (float) Math.cos(v.yaw);
            float al = (float) Math.sqrt(ax * ax + az * az);
            if (al < 0.05f) { ax = (float) Math.sin(v.yaw); az = (float) Math.cos(v.yaw); al = 1; }
            idx = ax / al; idy = 0; idz = az / al;
            float h = region.equals("legs") ? 0.22f : region.equals("head") ? 0.9f : region.equals("arms") ? 0.56f : 0.62f;
            // an arm is off the body's centre line: aim at the side the blow was reported on
            float side = region.equals("arms") ? 0.3f * ((v.id & 1) == 0 ? 1 : -1) : region.equals("legs") ? 0.11f * ((v.id & 1) == 0 ? 1 : -1) : 0;
            float sx0 = -idz * side, sz0 = idx * side;
            en = gore.trace(v, v.x - idx * 2 + sx0, v.y + v.height() * h, v.z - idz * 2 + sz0, idx, 0, idz, 4);
            if (en == null) en = gore.trace(v, v.x - idx * 2, v.y + v.height() * h, v.z - idz * 2, idx, 0, idz, 4);
        }
        rayEntry = null;
        // only a real projectile path overrides the region the caller reported
        if (en != null && traced) region = absentialis.anatomy.DamageProcessor.regionName(en.group);
        float pen = ammo != null && ammo.ammo != null ? ammo.ammo.pen : 20;
        boolean penetrated = true;
        if ((region.equals("torso") && v.armorClass > 0 && v.armorDur > 0) || (region.equals("head") && v.helmet)) {
            float chance = Math.max(0.05f, Math.min(0.95f, (pen - v.armorClass * 10) / 20f + 0.5f));
            penetrated = rng.chance(chance);
            if (region.equals("torso")) v.armorDur = Math.max(0, v.armorDur - dmg * (ammo != null && ammo.ammo != null ? ammo.ammo.armorDamage : 0.5f) * 0.4f);
            if (!penetrated) dmg *= 0.22f;
        }
        // fast infected are fragile where it counts: a clean head shot drops them
        // ---- the physical event: voxels destroyed, structure tested, blood, reaction (see Gore)
        float raw = dmg;
        boolean bite = "bite".equals(meleeKind), blade = "blade".equals(meleeKind);
        Gore.Impact im = null;
        if (attacker != null) {
            float ddx = v.x - attacker.x, ddz = v.z - attacker.z, dl = (float) Math.sqrt(ddx * ddx + ddz * ddz);
            if (dl > 0.01f) { v.hitDirX = ddx / dl; v.hitDirZ = ddz / dl; }
        } else { v.hitDirX = 0; v.hitDirZ = 0; }
        if (en != null && anatomy) {
            int type = kind.equals("bullet") ? (penetrated ? absentialis.anatomy.DamageProcessor.BULLET : absentialis.anatomy.DamageProcessor.BLUNT)
                    : bite ? absentialis.anatomy.DamageProcessor.BITE : blade ? absentialis.anatomy.DamageProcessor.BLADE : absentialis.anatomy.DamageProcessor.BLUNT;
            float power = kind.equals("bullet") ? (rayPower > 0 ? rayPower : pen / 10f) : 1f;
            im = gore.impact(v, attacker, en, type, kind.equals("bullet") && !penetrated ? raw * 2.2f : raw, power, idx, idy, idz);
            dmg *= im.vital;
        } else if (kind.equals("blast") && v.tier == 0) gore.blast(v, blastX, blastY, blastZ, raw);
        rayPower = 0;
        float mul = switch (region) { case "head" -> "sprinter".equals(v.archetype) ? 4.5f : v.infected() ? 2.5f : 3.2f; case "torso" -> 1f; case "arms" -> 0.6f; default -> 0.7f; };
        dmg *= mul;
        v.hp -= dmg;
        v.hurtFlash = 0.15f;
        v.hitRegion = region;
        v.lastHitTime = time;
        v.lastHitKind = kind.equals("melee") && "vehicle".equals(hitKind) ? "vehicle" : kind;
        if (attacker != null && attacker != v && dmg > 0) bus.emit(new Events.HitConfirmed(attacker.id, v.id, region, dmg, time));
        if (attacker != null) v.lastAttacker = attacker.id;
        v.hitForce = dmg;
        // far bodies have no anatomy to react with: they keep the simple flinch
        if (im == null && v.anim != null) v.anim.hit((float) Math.atan2(v.hitDirX, v.hitDirZ));
        if (v.isPlayer && v.anim != null) v.anim.hit((float) Math.atan2(v.hitDirX, v.hitDirZ));
        if (!v.isPlayer && !v.infected()) { v.morale -= dmg / 260f; Squad sq = squad(v); if (sq != null) sq.bloodied = true; }
        v.bleed += raw * (region.equals("legs") ? 0.018f : region.equals("torso") ? 0.012f : 0.014f) * (im != null && im.destroyed == 0 ? 0.3f : 1f);
        bus.emit(new Events.ActorInjured(v.id, attacker == null ? 0 : attacker.id, region, dmg, penetrated));
        lastKind = kind;
        if (v.isPlayer) {
            if (region.equals("arms") || kind.equals("blast")) body.armInjury = Math.min(1, body.armInjury + dmg / 55f);
            if (region.equals("legs") || kind.equals("blast")) body.legInjury = Math.min(1, body.legInjury + dmg / 60f);
            damageShake = Math.min(1, damageShake + dmg / 40f);
            if (attacker != null) hitMarkers.add(new float[]{(float) Math.atan2(-(attacker.x - v.x), -(attacker.z - v.z)), time});
            if (penetrated && dmg > 12 && rng.chance(0.35)) body.bleedLight = true;
            if (penetrated && dmg > 30 && rng.chance(0.3)) body.bleedHeavy = true;
            if (region.equals("legs") && dmg > 15 && rng.chance(0.25)) { body.fracture = true; msg("Leg fractured - splint it", 0xFFD8483A); }
            body.healthChanged = time;
        } else {
            if (attacker == player) debrief.hits++;
            // being shot is unambiguous evidence
            if (attacker != null && (attacker.isPlayer || attacker.mate()) && !v.infected() && !v.mate()) { v.hostileToPlayer = true; for (Actor a : nearby(v.x, v.z, 30)) if (a.faction.equals(v.faction) && a.squad == v.squad) a.hostileToPlayer = true; }
            // being hit tells them they are under attack and roughly from where - a target only if they can see it
            Brain.onShot(this, v, attacker);
            if (v.id == grabbedBy) grabUntil = -99;        // whoever had hold of the player lets go when hit
            v.wakeUntil = time + 120;
        }
        if (v.hp <= 0 && !v.isPlayer) {
            // otherwise-lethal damage: down or dead is decided in one place (the player's turn comes in update())
            boolean catastrophic = Gore.lost(v, absentialis.character.Rig.HEAD) || raw > v.maxHp * 1.6f;
            if (!casualty.lethal(v, attacker, -v.hp, region, v.lastHitKind, catastrophic)) kill(v, attacker);
        }
    }

    /** Kills credited to each squadmate this raid (experience at the debrief). */
    public final Map<Long, Integer> mateKills = new HashMap<>();

    private void kill(Actor v, Actor attacker) {
        if (v.dead) return;
        // the player's death is a presentation of its own (ragdoll, camera, choice): it must go through die(), which
        // is what 0.4 skipped here - the body was marked dead before die() ran, so it was never given a ragdoll or drawn
        if (v.isPlayer) { v.vx = v.vz = 0; if (attacker != null) v.lastAttacker = attacker.id; die("Killed in action" + (attacker != null && attacker != v ? " by " + describe(attacker) : "")); return; }
        confirmKill(v, attacker);
        casualty.died(v);
        v.dead = true;
        if (v.stowed != null && v.weapon != v.stowed) { if (v.weapon != null) v.carried.add(v.weapon); v.weapon = v.stowed; v.stowed = null; }
        deaths++;
        if (v.tier == 0 && !v.infected()) gore.deathBlow(v, lastKindFor(v));
        if (v.ragdoll == null) startRagdoll(v);      // already down under physics: the same ragdoll simply never gets up
        gore.onDeath(v, v.hitForce, lastKind);
        v.vx = v.vz = 0;
        if (v.agentId != 0) profile.agents.kill(v.agentId);
        if (v.mate()) { absentialis.gameplay.squad.Roster.Mate dm = profile.squad.byId(v.mateId); if (dm != null) dm.downs++; mates.remove(v); msg(v.name + " is down!", 0xFFD8483A); }
        if (attacker != null && attacker.mate()) { absentialis.gameplay.squad.Roster.Mate km = profile.squad.byId(attacker.mateId); if (km != null) km.kills++; mateKills.merge(attacker.mateId, 1, Integer::sum); }
        // a squad learns of a death by seeing or hearing it - otherwise the member is simply missing for a while
        boolean noticed = false;
        for (Actor m : actors) if (m != v && !m.dead && !m.isPlayer && m.faction.equals(v.faction) && m.squad == v.squad && m.squad != 0) {
            float md = m.dist(v);
            if (md < 14 || md < 48 && Physics.los(world, m.x, m.eyeY(), m.z, v.x, v.y + 1, v.z)) { Brain.onAllyDown(this, m, v); noticed = true; }
        }
        if (!noticed && v.squad != 0 && !v.infected() && !v.mate()) { Squad sq = squads.get(v.squad); if (sq != null && sq.faction.equals(v.faction)) sq.missing.add(new float[]{v.x, v.y, v.z, time}); }
        if (v.infected()) profile.zone.reportCorpse(world.district(v.x, v.z));
        // witnesses: same-faction members with line of sight
        boolean witnessed = false;
        for (Actor a : nearby(v.x, v.z, 45)) if (a != v && !a.isPlayer && a.faction.equals(v.faction) && Physics.los(world, a.x, a.eyeY(), a.z, v.x, v.y + 1, v.z)) { witnessed = true; if (attacker == player || attacker != null && attacker.mate()) a.hostileToPlayer = true; }
        District d = world.district(v.x, v.z);
        bus.emit(new Events.ActorKilled(v.id, attacker == null ? 0 : attacker.id, v.faction, attacker == null ? "" : attacker.faction, v.x, v.y, v.z, witnessed, v.archetype));
        if (attacker == player || attacker != null && attacker.mate() && !v.mate()) {
            debrief.kills.merge(v.infected() ? v.archetype : v.faction, 1, Integer::sum);
            profile.contracts.onKill(v.faction, d);
            if (v.infected()) { profile.zone.reportInfectedKill(d); }
            else {
                profile.zone.reportKill(d, v.faction, witnessed);
                debrief.killedFactions.add(v.faction);
                // standing reacts to evidence: witnessed murders cost the most, self-defence against an aggressor the least
                float rd = v.aggressor ? -0.5f : witnessed ? -6f : -1.5f;
                debrief.repDelta.merge(v.faction, rd, Float::sum);
                // rivals appreciate it
                for (String f : ZoneState.FACTIONS) if (!f.equals(v.faction) && Brain.hostile(this, fake(f), fake(v.faction))) debrief.repDelta.merge(f, 0.6f, Float::sum);
            }
            if (attacker == player && weaponMastery != null && player.weapon != null) weaponMastery.accept(player.weapon.defId, v.infected() ? 120L : 300L);
        }
        // corpse inventory: what they carried, nothing more
        Container c = new Container("corpse:" + v.id, 8, 8);
        c.label = v.infected() ? ZoneState.cap(v.archetype) + " remains" : ZoneState.cap(v.faction) + " " + v.archetype;
        // a fallen squadmate's kit is recovered with them, not left as free loot
        if (v.weapon != null && !v.mate()) { v.weapon.ownerFaction = v.faction; InventoryService.add(v.weapon, c); }
        v.weapon = null;
        for (ItemInstance taken : v.carried) InventoryService.add(taken, c);
        v.carried.clear();
        if (!v.infected() && !v.mate()) {
            Map<String, List<String>> kit = Content.KITS.get(v.faction);
            String table = kit != null && kit.get("loot") != null ? kit.get("loot").get(0) : "body";
            for (Object[] e : Content.roll(table, rng, profile.zone.availability(d), 0)) addRolled(c, (String) e[0], (Integer) e[1], v.faction);
        } else if (rng.chance(0.25)) for (Object[] e : Content.roll("body", rng, null, 0.3f)) addRolled(c, (String) e[0], (Integer) e[1], null);
        v.corpse = c;
        // fat infected rupture however they die: acid, a contamination zone and a noise event
        if ("boomer".equals(v.archetype) && !v.burst) burst(v, attacker);
    }

    public java.util.function.BiConsumer<String, Long> weaponMastery;

    private static Actor fake(String f) { Actor a = new Actor(); a.faction = f; return a; }

    private void addRolled(Container c, String id, int qty, String owner) {
        ItemInstance i = new ItemInstance(id);
        ItemDef d = i.def();
        i.qty = d.stackable() ? Math.min(d.maxStack, qty) : 1;
        i.origin = raidId;
        i.foundInRaid = true;
        i.ownerFaction = owner;
        if (d.magazine != null) { i.rounds = rng.range(0, i.capacity()); if (i.rounds > 0) i.ammoId = Content.ammoFor(d.magazine.caliber).id; }
        if (d.weapon != null && !d.weapon.melee()) { i.setCondition(rng.range(25f, 90f)); i.rounds = rng.range(0, Math.max(1, d.weapon.capacity / 2)); if (i.rounds > 0) i.ammoId = Content.ammoFor(d.weapon.caliber).id; }
        InventoryService.add(i, c);
    }

    /** NPC shooting: aim error grows with distance and target movement; real projectiles. */
    public void npcFire(Actor a, Actor t, float dt) { npcFireAt(a, t, 0, 0, 0); }

    /** Suppressive fire on a remembered position: no target needed, wide error, keeps heads down. */
    public void npcSuppress(Actor a, float x, float y, float z) { npcFireAt(a, null, x, y, z); }

    private void npcFireAt(Actor a, Actor t, float aimX, float aimY, float aimZ) {
        ItemInstance w = a.weapon;
        ItemDef.Weapon wd = w.def().weapon;
        if (!WeaponService.canFire(w)) {
            if (w.jammed) { WeaponService.clearJam(w); a.fireCooldown = 1.5f; return; }
            // reload from abstract reserve
            w.rounds = w.capacity(); w.ammoId = Content.ammoFor(wd.caliber).id;
            boolean single = "single".equals(wd.reloadStyle);
            a.fireCooldown = single ? Math.min(4.5f, wd.reloadTime * 1.2f * wd.capacity) : wd.reloadTime * 1.3f;
            if (a.anim != null) a.anim.play(single ? "reload_shell" : "reload_empty", Math.min(a.fireCooldown, 2.6f));
            emitSound(a.x, a.y + 1, a.z, 12, "reload", a.id, false);
            return;
        }
        if ("pump".equals(w.fireModeName()) || "bolt".equals(w.fireModeName())) { if (!wd.internal()) WeaponService.chamberFromMag(w); }
        Gunsmith.Stats st = Gunsmith.stats(w, 0);
        ItemDef ammo = WeaponService.fire(w, st, 1, rng);
        if (ammo == null) return;
        if (!wd.internal() && !w.chambered) WeaponService.chamberFromMag(w);
        float ox = a.x, oy = a.eyeY() - 0.1f, oz = a.z;
        float tx = t != null ? t.x : aimX, ty = t != null ? t.y + t.height() * 0.62f : aimY, tz = t != null ? t.z : aimZ;
        float dx = tx - ox, dy = ty - oy, dz = tz - oz, d = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        a.flashUntil = time + 0.3f;
        absentialis.gameplay.squad.Roster.Mate fm = a.mate() ? profile.squad.byId(a.mateId) : null;
        float skill = a.aimPenalty * (fm != null ? 1 - 0.45f * fm.skill() : 1) * (night() && !a.light ? 1.25f : 1) * ("marksman".equals(a.archetype) ? 0.5f : "military".equals(a.faction) || "mercenaries".equals(a.faction) ? 0.85f : 1f);
        float moving = t != null && (Math.abs(t.vx) + Math.abs(t.vz)) > 1 ? 1.8f : 1f;
        skill *= combat.aimError[combat.condition(a.hp, a.maxHp).ordinal()];
        float err = (1.2f + d * 0.035f) * skill * (1 + a.suppression * 0.8f) * moving * (t != null && t.crouch ? 1.3f : 1f) * (t == null ? 2.4f : 1f) * (settings.difficulty == 0 ? 1.5f : settings.difficulty == 2 ? 0.8f : 1f);
        fireProjectiles(a, w, ammo, ox, oy, oz, dx / d, dy / d + d * 0.0006f, dz / d, err + st.dispersion);
        if (a.anim != null) a.anim.fire();
        shotSignature(a, w, st, ox, oy, oz);
        float rpmGap = 60f / st.rpm;
        if (a.burstLeft <= 0) a.burstLeft = wd.modes.contains("auto") ? rng.range(2, 5) : 1;
        a.burstLeft--;
        a.fireCooldown = a.burstLeft > 0 ? rpmGap : rng.range(0.5f, 1.4f) + ("marksman".equals(a.archetype) ? 1.2f : 0);
    }

    /**
     * Shove: makes room. The target is thrown back and off balance; against a wall the wall does the damage.
     */
    public void shove(Actor a, Actor t) {
        float dx = t.x - a.x, dz = t.z - a.z, dl = Math.max(0.1f, (float) Math.sqrt(dx * dx + dz * dz));
        dx /= dl; dz /= dl;
        // is there something solid right behind them?
        boolean wall = world.solid((int) Math.floor(t.x + dx * 1.0f), (int) Math.floor(t.y + 1.0f), (int) Math.floor(t.z + dz * 1.0f));
        t.vx += dx * 6.5f; t.vz += dz * 6.5f;
        emitSound(a.x, a.y + 1, a.z, 9, "melee", a.id, false);
        if (t.isPlayer) {
            damageShake = Math.min(1, damageShake + 0.45f);
            playerVulnerableUntil = Math.max(playerVulnerableUntil, time + 0.5f);
            if (wall) { hitKind = "vehicle"; damageActor(t, a, 11 * difficultyDamage(), null, "torso", t.x, t.y + 1.1f, t.z); hitKind = ""; slipT = Math.max(slipT, 0.45f); msg("Slammed into the wall", 0xFFD8483A); }
        } else {
            t.staggerUntil = Math.max(t.staggerUntil, time + (wall ? 1.2f : 0.7f));
            if (wall) { hitKind = "vehicle"; damageActor(t, a, 12, null, "torso", t.x, t.y + 1.1f, t.z); hitKind = ""; }
        }
    }

    /** Grab: the target is held for a moment - long enough for someone else to shoot. A blow or a round on the holder breaks it. */
    public void grab(Actor a, Actor t) {
        emitSound(a.x, a.y + 1, a.z, 9, "grab", a.id, false);
        if (t.isPlayer) { grabbedBy = a.id; grabUntil = time + 1.35f; damageShake = Math.min(1, damageShake + 0.3f); msg("Grabbed! Strike or shoot them to break free", 0xFFD8483A); }
        else t.staggerUntil = Math.max(t.staggerUntil, time + 1.1f);
    }

    /** Lobs a grenade from an agent toward a point: a ballistic throw that lands near it, and a fuse that gives a listener time to move. */
    public void npcThrow(Actor a, float tx, float ty, float tz, String itemId) {
        ItemDef def = Content.def(itemId);
        if (def == null || def.throwable == null) return;
        Thrown t = new Thrown();
        t.x = a.x; t.y = a.eyeY(); t.z = a.z;
        float dx = tx - t.x, dy = ty + 0.3f - t.y, dz = tz - t.z, dist = (float) Math.sqrt(dx * dx + dz * dz);
        float T = Math.max(0.9f, dist / 11f);
        t.vx = dx / T; t.vz = dz / T; t.vy = (dy + 0.5f * Physics.GRAVITY * T * T) / T;
        t.def = def; t.owner = a.id; t.fuse = T + 1.1f;
        thrown.add(t);
        if (a.anim != null) a.anim.play("throw", 0.6f);
        emitSound(a.x, a.y + 1.5f, a.z, 6, "pin", a.id, false);
    }

    public void melee(Actor a, Actor t, float dmg) {
        if (a.dist(t) > 2.2f + a.radius) return;
        // blows on one target are taken in turn: two arriving in the same instant would be one attack too many
        if (time - lastMeleeOn < 0.32f && lastMeleeBy != a.id && t.isPlayer) { a.fireCooldown = Math.max(a.fireCooldown, 0.3f); return; }
        if (t.isPlayer) { lastMeleeOn = time; lastMeleeBy = a.id; }
        // the infected go for the neck and the arms that fend them off; a bite that breaks the skin carries the virus
        boolean bite = rng.chance(infection.biteChance(a, t));
        meleeKind = bite ? "bite" : a.weapon != null && "melee.knife".equals(a.weapon.defId) ? "blade" : "";
        String region = bite ? (rng.chance(0.55) ? "arms" : "torso") : t.isPlayer ? (rng.chance(0.3) ? "arms" : "torso") : "torso";
        float hx = t.x + (a.x - t.x) * 0.3f, hz = t.z + (a.z - t.z) * 0.3f;
        if (bite && a.anim != null) a.anim.play("melee", 0.45f);
        damageActor(t, a, bite ? dmg * 0.8f : dmg, null, region, hx, t.y + t.height() * (bite ? 0.78f : 0.62f), hz);
        meleeKind = "";
        emitSound(a.x, a.y + 1, a.z, 10, "melee", a.id, false);
        if (bite) infection.bitten(t, a);
    }

    /** A status line for the player (not speech: nobody else hears it). */
    public void notice(String text, int color) { msg(text, color); }

    /** An agent is gone from its faction without dying as itself (it turned): squad, roster and A-Life bookkeeping. */
    void agentLost(Actor a) {
        if (a.mate()) {
            absentialis.gameplay.squad.Roster.Mate dm = profile.squad.byId(a.mateId);
            if (dm != null) dm.downs++;
            mates.remove(a);
            a.mateId = 0; a.team = "";
        }
        if (a.agentId != 0) { profile.agents.kill(a.agentId); a.agentId = 0; }
        Squad sq = a.squad == 0 ? null : squads.get(a.squad);
        if (sq != null && sq.faction.equals(a.faction)) { sq.alive = Math.max(0, sq.alive - 1); sq.bloodied = true; }
    }

    public void explode(float x, float y, float z, float radius, float dmg, int owner, boolean breakWalls) {
        emitSound(x, y, z, 160, "explosion", owner, false);
        hitKind = "blast";
        blastX = x; blastY = y; blastZ = z;
        for (Actor a : nearby(x, z, radius + 2)) {
            float d = a.dist(fakeAt(x, y, z));
            if (d > radius || !Physics.los(world, x, y + 0.5f, z, a.x, a.y + 1, a.z)) continue;
            damageActor(a, actor(owner), dmg * (1 - d / radius), null, "torso", a.x, a.y + 1, a.z);
        }
        hitKind = "";
        int r = (int) Math.ceil(radius / (breakWalls ? 2 : 3));
        for (int dx = -r; dx <= r; dx++) for (int dy = -r; dy <= r; dy++) for (int dz = -r; dz <= r; dz++) {
            if (dx * dx + dy * dy + dz * dz > r * r) continue;
            int bx = (int) Math.floor(x) + dx, by = (int) Math.floor(y) + dy, bz = (int) Math.floor(z) + dz;
            Block b = world.block(bx, by, bz);
            if (b != null && b.hp > 0 && (b.hp < 400 || breakWalls && b.hp < 1000)) damageBlock(bx, by, bz, dmg * 4, owner);
        }
        for (int i = 0; i < 40; i++) { Effect e = new Effect(); e.x = x; e.y = y + 0.5f; e.z = z; e.vx = (rng.nextFloat() - 0.5f) * 14; e.vy = rng.nextFloat() * 9; e.vz = (rng.nextFloat() - 0.5f) * 14; e.life = e.max = 0.6f + rng.nextFloat(); e.size = 0.12f + rng.nextFloat() * 0.2f; e.color = i % 3 == 0 ? 0xFFFFB040 : 0xFF3A3632; e.glow = i % 3 == 0; effects.add(e); }
        if (player.dist(fakeAt(x, y, z)) < 25) damageShake = 1;
    }

    private static Actor fakeAt(float x, float y, float z) { Actor a = new Actor(); a.x = x; a.y = y; a.z = z; return a; }

    public void explodeBoomer(Actor a, Actor attacker) {
        a.hp = 0;
        kill(a, attacker);
    }

    /** Rupture of a fat infected: blast, a lingering contamination zone and a district-level noise event. */
    private void burst(Actor a, Actor attacker) {
        a.burst = true;
        float bx = a.x, by = a.y, bz = a.z;
        explode(bx, by + 0.8f, bz, 4.5f, 55, a.id, false);
        Zone z = new Zone();
        z.x = bx; z.y = by; z.z = bz; z.radius = 4.6f; z.until = time + 22; z.dps = 6; z.kind = "contam"; z.owner = a.id;
        zones.add(z);
        District d = world.district(bx, bz);
        profile.zone.reportNoise(d, 20);
        profile.zone.reportContamination(d, 1);
        if (listener != null && player.distXZ(bx, bz) < 30) listener.message("Contamination released - stay out of the cloud.", 0xFFB8D048);
    }

    // ------------------------------------------------------------------ throwables
    public void throwItem(ItemInstance it, float dx, float dy, float dz) { throwItem(it, dx, dy, dz, 1, false); }

    /** Throws (or, with an underbarrel launcher, fires) a grenade: power scales the velocity, impact bursts it on first contact. */
    public void throwItem(ItemInstance it, float dx, float dy, float dz, float power, boolean impact) {
        Thrown t = new Thrown();
        t.impact = impact;
        t.x = player.x + dx * 0.5f; t.y = player.eyeY(); t.z = player.z + dz * 0.5f;
        t.vx = dx * 14 * power; t.vy = dy * 14 * power + 3; t.vz = dz * 14 * power;
        t.def = it.def(); t.owner = player.id; t.fuse = t.def.throwable.fuse;
        thrown.add(t);
        emitSound(player.x, player.y + 1, player.z, 4, "pin", player.id, true);
    }

    private void updateThrown(float dt) {
        for (int ti = 0; ti < thrown.size(); ti++) {
            Thrown t = thrown.get(ti);
            t.fuse -= dt;
            t.vy -= Physics.GRAVITY * dt;
            float nx = t.x + t.vx * dt, ny = t.y + t.vy * dt, nz = t.z + t.vz * dt;
            if (world.solid((int) Math.floor(nx), (int) Math.floor(t.y), (int) Math.floor(t.z))) { t.vx *= -0.4f; nx = t.x; }
            if (world.solid((int) Math.floor(t.x), (int) Math.floor(t.y), (int) Math.floor(nz))) { t.vz *= -0.4f; nz = t.z; }
            if (t.debris) {
                // hurled masonry: bursts on the first thing it touches
                boolean hit = world.solid((int) Math.floor(nx), (int) Math.floor(ny), (int) Math.floor(nz)) || nx == t.x && t.vx != 0 || nz == t.z && t.vz != 0;
                for (Actor a : nearby(nx, nz, 1.6f)) if (a.id != t.owner && Math.abs(a.y + 1 - ny) < 1.6f) hit = true;
                if (hit || t.fuse < -6) { t.dead = true; debrisImpact(t.x, t.y, t.z, t.owner); continue; }
                t.x = nx; t.y = ny; t.z = nz;
                continue;
            }
            if (world.solid((int) Math.floor(nx), (int) Math.floor(ny), (int) Math.floor(nz))) { if (Math.abs(t.vy) > 2) emitSound(t.x, t.y, t.z, 6, "bounce", t.owner, false); t.vy *= -0.35f; t.vx *= 0.6f; t.vz *= 0.6f; ny = t.y; if (t.impact) t.fuse = 0; }
            if (t.impact && (nx == t.x && t.vx != 0 || nz == t.z && t.vz != 0)) t.fuse = 0;
            t.x = nx; t.y = ny; t.z = nz;
            if (t.fuse <= 0 && !t.dead) {
                t.dead = true;
                ItemDef.Throwable th = t.def.throwable;
                switch (th.kind) {
                    case "flare" -> {
                        emitSound(t.x, t.y, t.z, th.noise, "flare", t.owner, false);
                        for (ExitState s : exits) if (s.exit.type == MapData.ExitType.SIGNALED && Math.abs(s.exit.x - t.x) < 14 && Math.abs(s.exit.z - t.z) < 14 && !s.signaled && s.signalTimer <= 0) { s.signalTimer = 60; msg("Flare seen - helicopter inbound to " + s.exit.name + " in 60s. Hold the area.", 0xFFE2A034); }
                        for (int i = 0; i < 30; i++) { Effect e = new Effect(); e.x = t.x; e.y = t.y; e.z = t.z; e.vx = (rng.nextFloat() - 0.5f); e.vy = 3 + rng.nextFloat() * 4; e.vz = (rng.nextFloat() - 0.5f); e.life = e.max = 2 + rng.nextFloat() * 2; e.size = 0.15f; e.color = 0xFFFF4030; e.glow = true; effects.add(e); }
                    }
                    case "noise" -> emitSound(t.x, t.y, t.z, th.noise, "alarm_clock", t.owner, false);
                    case "fire" -> incendiary(t.x, t.y, t.z, th, t.owner);
                    case "flash" -> flashbang(t.x, t.y, t.z, th, t.owner);
                    default -> explode(t.x, t.y, t.z, th.radius, th.damage, t.owner, "pipe".equals(th.kind));
                }
            }
        }
        thrown.removeIf(t -> t.dead);
    }

    /** Incendiary grenade: a burning pool that damages anything standing in it, living or dead. */
    private void incendiary(float x, float y, float z, ItemDef.Throwable th, int owner) {
        int gy = groundY((int) Math.floor(x), (int) Math.floor(z));
        Zone zn = new Zone();
        zn.x = x; zn.y = gy < 0 || Math.abs(gy - y) > 3 ? y : gy; zn.z = z; zn.radius = th.radius; zn.until = time + 9; zn.dps = th.damage; zn.kind = "fire"; zn.owner = owner;
        zones.add(zn);
        emitSound(x, y, z, th.noise, "fire_burst", owner, false);
        // the flames themselves: a pool of real fire over the area the zone burns (the zone carries the damage)
        fire.pool(x, zn.y, z, th.radius, 9, owner);
    }

    /** Flash grenade: everyone with a sight line loses their eyes for a few seconds - the infected for longer. */
    private void flashbang(float x, float y, float z, ItemDef.Throwable th, int owner) {
        emitSound(x, y, z, th.noise, "flashbang", owner, false);
        for (int i = 0; i < 30; i++) { Effect e = new Effect(); e.x = x; e.y = y + 0.3f; e.z = z; e.vx = (rng.nextFloat() - 0.5f) * 12; e.vy = rng.nextFloat() * 8; e.vz = (rng.nextFloat() - 0.5f) * 12; e.life = e.max = 0.25f + rng.nextFloat() * 0.3f; e.size = 0.2f; e.color = 0xFFFFFFFF; e.glow = true; effects.add(e); }
        for (Actor a : nearby(x, z, th.radius)) {
            float d = (float) Math.sqrt((a.x - x) * (a.x - x) + (a.eyeY() - y) * (a.eyeY() - y) + (a.z - z) * (a.z - z));
            if (d > th.radius || !Physics.los(world, x, y + 0.4f, z, a.x, a.eyeY(), a.z)) continue;
            float k = 1 - d / th.radius * 0.6f;
            if (a.isPlayer) {
                // looking away saves most of your sight
                float fx = (float) (-Math.sin(a.yaw) * Math.cos(a.pitch)), fy = (float) Math.sin(a.pitch), fz = (float) (-Math.cos(a.yaw) * Math.cos(a.pitch));
                float facing = d < 0.5f ? 1 : ((x - a.x) * fx + (y - a.eyeY()) * fy + (z - a.z) * fz) / d;
                flashBlind = Math.max(flashBlind, k * (facing > 0.2f ? 1f : 0.35f));
                continue;
            }
            a.blindUntil = time + (a.infected() ? 8 : 5) * k;
            a.awareness = 0;
            a.staggerUntil = Math.max(a.staggerUntil, time + 2.2f * k);
            if (!a.infected()) a.morale -= 0.15f;
            if (a.anim != null) a.anim.play("stumble", 0.8f);
            if (!"flee".equals(a.state) && !"retreat".equals(a.state)) { a.state = "search"; a.stateTime = 0; a.hasGoal = false; }
        }
    }

    // ------------------------------------------------------------------ locked drawers (Small Key)
    /** One desk or cabinet in six is locked until a Small Key opens it; the roll is fixed by position. */
    public boolean isLocked(int x, int y, int z) {
        int id = world.get(x, y, z);
        if (id != Block.DESK && id != Block.CABINET && id != Block.FILING) return false;
        if (containers.containsKey(World.idx(x, y, z))) return false;
        return Rng.hash(x, y, z, (int) (profile.seed & 0xFFFF) + 77) < 0.17f;
    }

    /** Spends a Small Key on a locked drawer. Returns false when the player has none. */
    public boolean unlock(int x, int y, int z) {
        for (ItemInstance k : new ArrayList<>(profile.loadout.keys)) if ("key.small".equals(k.defId)) { InventoryService.consume(k, 1); unlocked.add(World.idx(x, y, z)); return true; }
        return false;
    }

    private final java.util.Set<Integer> unlocked = new java.util.HashSet<>();

    // ------------------------------------------------------------------ the player's element (Red / Blue / Gold)
    public static final int MATE_SQUAD = 777777;

    /** Deploys the active roster around the insertion point: same individuals, same kit, their own level of skill. */
    private void deploySquad() {
        List<absentialis.gameplay.squad.Roster.Mate> act = profile.squad.active();
        for (int i = 0; i < act.size(); i++) {
            absentialis.gameplay.squad.Roster.Mate m = act.get(i);
            double ang = i * 2.399;
            float[] p = standNear(player.x + (float) Math.sin(ang) * (2.2f + i * 0.5f), player.z + (float) Math.cos(ang) * (2.2f + i * 0.5f));
            if (p == null) p = new float[]{player.x, player.y, player.z};
            Actor a = new Actor();
            a.faction = "player";
            a.mateId = m.id; a.team = m.team; a.name = m.name.contains("\"") ? m.name.substring(m.name.indexOf('"') + 1, m.name.lastIndexOf('"')) : m.name;
            a.appearance = m.look;
            a.x = p[0]; a.y = p[1]; a.z = p[2]; a.yaw = player.yaw;
            a.homeX = a.x; a.homeZ = a.z;
            a.weapon = armed(m.weapon, rng);
            a.weapon.setCondition(95);
            for (String id : m.build) Gunsmith.install(a.weapon, id);
            ItemDef wd = a.weapon.def();
            a.archetype = wd.weapon.family.equals("shotgun") ? "shotgunner" : m.weapon.equals("weapon.mosin") || m.weapon.equals("weapon.sr16") ? "marksman" : "rifleman";
            shape(a);
            a.hp = a.maxHp = m.maxHp();
            a.armorClass = 2; a.armorDur = a.armorMax = 45;
            a.squad = MATE_SQUAD;
            a.morale = 1; a.risk = 0.5f;
            a.look = "mate:" + m.id;
            m.raids++;
            actors.add(a);
            mates.add(a);
            element.add(a);
        }
    }

    /** Living squadmates addressed by a team name: "red", "blue", or "gold" for the whole deployed element. */
    public List<Actor> team(String team) {
        List<Actor> l = new ArrayList<>();
        for (Actor a : mates) if (a.active() && ("gold".equals(team) || a.team.equals(team))) l.add(a);
        return l;
    }

    /**
     * Gives a team an order (follow, hold, move, sweep). A queued order is held by that team until Gold
     * issues Initiate, so Red and Blue can be set up for different objectives and released together.
     * Returns how many squadmates took it.
     */
    public int squadOrder(String team, String order, float x, float z, boolean queued) {
        List<Actor> t = team(team);
        for (int i = 0; i < t.size(); i++) {
            Actor a = t.get(i);
            float ox = x + (float) Math.sin(i * 2.4) * (1.2f + i * 0.5f), oz = z + (float) Math.cos(i * 2.4) * (1.2f + i * 0.5f);
            if (Float.isNaN(x)) { ox = a.x; oz = a.z; }   // "hold": each where they stand
            if (queued) { a.qOrder = order; a.qX = ox; a.qZ = oz; }
            else { a.sqOrder = order; a.sqX = ox; a.sqZ = oz; a.qOrder = null; a.hasGoal = false; a.path = null; }
        }
        if (!t.isEmpty() && !queued) say(t.get(0), switch (order) { case "hold" -> "Holding."; case "move" -> "Moving."; case "sweep" -> "Sweeping it."; default -> "On you."; }, "radio_chatter");
        return t.size();
    }

    /** Gold's Initiate: every team executes whatever it has queued, at the same moment. */
    public int initiate() {
        int n = 0;
        for (Actor a : mates) if (!a.dead && a.qOrder != null) { a.sqOrder = a.qOrder; a.sqX = a.qX; a.sqZ = a.qZ; a.qOrder = null; a.hasGoal = false; a.path = null; n++; }
        if (n > 0 && !mates.isEmpty()) msg("GOLD: Initiate - " + n + " executing", 0xFFE2B030);
        return n;
    }

    /** Moves a deployed squadmate between Red and Blue during the operation (four per team at most). */
    public String reassign(Actor a) {
        String to = "red".equals(a.team) ? "blue" : "red";
        if (team(to).size() >= absentialis.gameplay.squad.Roster.TEAM_CAP) return (to.equals("red") ? "Red" : "Blue") + " Team is full";
        a.team = to;
        absentialis.gameplay.squad.Roster.Mate m = profile.squad.byId(a.mateId);
        if (m != null) m.team = to;
        return a.name + " -> " + (to.equals("red") ? "Red" : "Blue") + " Team";
    }

    // ------------------------------------------------------------------ squads (shared tactical picture)
    public Squad squad(Actor a) { return a.squad == 0 || a.infected() || a.isPlayer ? null : squadOf(a.squad, a.faction); }

    private Squad squadOf(int id, String faction) {
        Squad s = squads.get(id);
        if (s == null) {
            s = new Squad();
            s.id = id; s.faction = faction;
            int n = 0;
            for (Actor m : actors) if (m.squad == id && m.faction.equals(faction) && !m.dead) n++;
            s.initial = s.alive = Math.max(1, n);
            squads.put(id, s);
        }
        return s;
    }

    /** Living members of an agent's squad, in a stable order. */
    public List<Actor> squadMembers(Actor a) {
        List<Actor> l = new ArrayList<>();
        for (Actor m : actors) if (!m.dead && !m.isPlayer && m.squad == a.squad && m.faction.equals(a.faction)) l.add(m);
        l.sort(java.util.Comparator.comparingInt(m -> m.id));
        return l;
    }

    public int squadRank(Actor a) { int k = 0; for (Actor m : actors) if (!m.dead && m.squad == a.squad && m.faction.equals(a.faction) && m.id < a.id) k++; return k; }

    private void countSquads() {
        for (Squad s : squads.values()) s.alive = 0;
        for (Actor a : actors) if (!a.dead && !a.isPlayer && a.squad != 0) { Squad s = squads.get(a.squad); if (s != null && s.faction.equals(a.faction)) s.alive++; }
        for (Squad s : squads.values()) s.initial = Math.max(s.initial, s.alive);
    }

    /** A fixed loop on the street graph from the squad's post: same nodes, same order, every time. */
    private void buildRoute(Squad sq, float x, float z) {
        MapData.Node n = world.map.nearestNode(x, z);
        java.util.Set<Integer> seen = new java.util.HashSet<>();
        for (int k = 0; k < 5 && n != null; k++) {
            seen.add(n.id);
            sq.route.add(new float[]{n.x + 0.5f, n.z + 0.5f});
            MapData.Node next = null;
            for (int l : n.links) { MapData.Node c = world.map.nodes.get(l); if (!seen.contains(c.id) && Math.abs(c.x - x) < 70 && Math.abs(c.z - z) < 70 && (next == null || c.id < next.id)) next = c; }
            n = next;
        }
    }

    private static String speaker(Actor a) {
        if (!a.name.isEmpty()) return a.name;
        return switch (a.faction) { case "military" -> "Soldier"; case "raiders" -> "Bandit"; case "mercenaries" -> "Contractor"; case "survivors" -> "Loner"; default -> ZoneState.cap(a.faction); };
    }

    /** A spoken line: a real sound others can hear, shown to the player when in earshot. */
    public void say(Actor a, String text, String category) {
        if (a == null) { msg(text, 0xFFB8D048); return; }   // no speaker: a status line for the player alone
        if (time - a.lastSay < 2.5f) return;
        a.lastSay = time;
        a.sayText = text; a.sayAt = time; a.sayUntil = time + combat.talkBase + text.length() * combat.talkPerChar;
        said++;
        // "bark_*" names the voice sample for this kind of callout; to other agents every spoken line is a voice
        boolean bark = category.startsWith("bark_");
        emitSound(a.x, a.y + 1.6f, a.z, category.equals("radio_chatter") ? 14 : 30, bark ? "speech" : category, a.id, false);
        if (listener == null) return;
        if (bark) listener.voice(a, category);
        if (a.mate() && a.dist(player) > 12) listener.message(speaker(a) + ": " + text, 0xFF7DBA5C);
    }

    /** Lines spoken this raid (tests: communication must actually happen). */
    public int said;

    /** How strong a target looks to someone sizing it up: armed friends nearby count. */
    public float strengthNear(Actor t, String observerFaction) {
        float s = t.isPlayer ? (t.weapon != null && t.weapon.def().weapon != null && !t.weapon.def().weapon.melee() ? 1.6f : 0.8f) : 1f;
        for (Actor o : nearby(t.x, t.z, 16)) if (o != t && !o.infected() && !o.isPlayer && o.faction.equals(t.faction) && o.weapon != null) s += 1;
        return s;
    }

    public float rain() { return profile.zone.weatherRain > 0.5f ? (profile.zone.weatherRain - 0.5f) * 2 : 0; }
    /** Extra haze of a district beyond a clear day (0..1). */
    public float fogAt(float x, float z) { return Math.max(0, Math.min(1, (world.district(x, z).fogDensity - 0.8f) / 0.6f)); }

    /** Ground shock felt by the player (giant footfalls, charges, debris). */
    public void quake(float x, float z, float range, float amount) {
        float d = player.distXZ(x, z);
        if (d < range) damageShake = Math.max(damageShake, amount * (1 - d / range));
    }

    // ------------------------------------------------------------------ restricted areas, extortion, loners
    private List<MapData.Point> restricted;

    /** True when the player stands in a military restricted area without the standing that passes for a permit. */
    public boolean restrictedFor(float x, float z) {
        if (profile.rep("military") >= 25) return false;
        if (restricted == null) {
            restricted = new ArrayList<>();
            for (MapData.Point p : world.map.posts) if ("military".equals(p.faction) && (p.kind.equals("camp") || p.kind.equals("leader") || p.kind.equals("restricted"))) restricted.add(p);
        }
        for (MapData.Point p : restricted) { float dx = x - p.x, dz = z - p.z; if (dx * dx + dz * dz < 16 * 16) return true; }
        return false;
    }

    /** Ignoring the warning is a recorded offence: standing drops and the garrison turns on you. */
    public void trespass() {
        trespasses++;
        debrief.repDelta.merge("military", -4f, Float::sum);
        msg("You are now a trespasser in a restricted area.", 0xFFD8483A);
    }

    /** The squad currently holding the player up, if any. */
    public Squad extortion() {
        for (Squad s : squads.values()) if (s.extortDone && !s.paid && !s.bloodied && time < s.extortUntil) return s;
        return null;
    }

    /** Pays a bandit hold-up. The money leaves the profile when the raid resolves. */
    public String payExtortion() {
        Squad s = extortion();
        if (s == null) return null;
        if (profile.scrip - scripPaid < EXTORT_PRICE) return "You do not have " + absentialis.Version.coins(EXTORT_PRICE);
        scripPaid += EXTORT_PRICE;
        s.paid = true;
        return "Paid " + absentialis.Version.coins(EXTORT_PRICE) + ". They lower their weapons.";
    }

    /** A wounded loner who can be helped right now (within reach), or null. */
    public Actor lonerInNeed(float r) {
        for (Actor a : nearby(player.x, player.z, r)) if (!a.isPlayer && a.needsHelp && !a.helped && !a.hostileToPlayer && a.dist(player) < r) return a;
        return null;
    }

    /** Gives a bandage to a wounded loner: standing, experience and a marked stash in return. */
    public String helpLoner(Actor a) {
        ItemInstance bandage = null;
        for (ItemInstance i : profile.loadout.all()) if ("med.bandage".equals(i.defId) && i.parent == null) { bandage = i; break; }
        if (bandage == null) return "You have no bandage to give";
        InventoryService.consume(bandage, 1);
        a.helped = true; a.needsHelp = false;
        a.hp = Math.min(a.maxHp, a.hp + 35);
        debrief.repDelta.merge("survivors", 3f, Float::sum);
        debrief.aided++;
        int n = profile.discover(a.homeX, a.homeZ, 7);
        debrief.cellsRevealed += n;
        emitSound(a.x, a.y + 1, a.z, 5, "search", player.id, true);
        return "The loner patches up and marks what they know on your map" + (n > 0 ? " (" + n + " cells)" : "");
    }

    /** A faction looter strips a corpse. Contractors take the hardware; bandits take anything worth carrying. */
    public void npcLoot(Actor a, Actor corpse, boolean hardwareOnly) {
        if (corpse.corpse == null) return;
        for (ItemInstance it : new ArrayList<>(corpse.corpse.items)) {
            ItemDef d = it.def();
            boolean hw = d.weapon != null || d.ammo != null || d.magazine != null || d.armor != null;
            if (hw || !hardwareOnly && d.value >= 20) { InventoryService.release(it); a.carried.add(it); }
        }
        emitSound(corpse.x, corpse.y + 0.5f, corpse.z, 7, "search", a.id, false);
    }

    private Map<Integer, List<MapData.LootSpot>> lootIndex;

    /** A street-level searchable container near a point (loners scavenge what is actually there). */
    public MapData.LootSpot lootSpotNear(float x, float z, float r, int salt) {
        if (lootIndex == null) {
            lootIndex = new HashMap<>();
            for (MapData.LootSpot s : world.map.loot) if (Math.abs(s.y - World.GROUND) <= 1) lootIndex.computeIfAbsent((s.x >> 5) * 64 + (s.z >> 5), k -> new ArrayList<>()).add(s);
        }
        List<MapData.LootSpot> cand = new ArrayList<>();
        int cx = (int) x >> 5, cz = (int) z >> 5;
        for (int a = cx - 1; a <= cx + 1; a++) for (int b = cz - 1; b <= cz + 1; b++) {
            List<MapData.LootSpot> l = lootIndex.get(a * 64 + b);
            if (l != null) for (MapData.LootSpot s : l) if (Math.abs(s.x - x) < r && Math.abs(s.z - z) < r) cand.add(s);
        }
        return cand.isEmpty() ? null : cand.get(Math.floorMod(salt * 31, cand.size()));
    }

    // ------------------------------------------------------------------ infected specials
    /** Fat infected bile: lands where the target stood when the retch began - move and it misses. */
    public void spit(Actor a, float x, float y, float z) {
        int gy = groundY((int) Math.floor(x), (int) Math.floor(z));
        Zone zn = new Zone();
        zn.x = x; zn.y = gy < 0 ? y : gy; zn.z = z; zn.radius = 2.6f; zn.until = time + 9; zn.dps = 9; zn.kind = "acid"; zn.owner = a.id;
        zones.add(zn);
        emitSound(x, zn.y + 0.5f, z, 20, "splash", a.id, false);
        for (int i = 0; i < 26; i++) {
            float t = i / 26f;
            Effect e = new Effect();
            e.x = a.x + (x - a.x) * t; e.z = a.z + (z - a.z) * t; e.y = a.y + 1.6f + (zn.y - a.y - 1.6f) * t + (float) Math.sin(t * Math.PI) * 1.4f;
            e.vx = (rng.nextFloat() - 0.5f); e.vy = rng.nextFloat(); e.vz = (rng.nextFloat() - 0.5f);
            e.life = e.max = 0.5f + rng.nextFloat() * 0.4f; e.size = 0.1f; e.color = 0xFFB4D040; e.glow = true;
            effects.add(e);
        }
    }

    /** Giant debris throw: a ballistic chunk of masonry aimed at where the target stood. */
    public void hurl(Actor a, float x, float y, float z) {
        Thrown t = new Thrown();
        t.debris = true; t.owner = a.id;
        t.x = a.x; t.y = a.y + a.stand + 0.4f; t.z = a.z;
        float dx = x - t.x, dz = z - t.z, dy = y + 0.8f - t.y, dist = (float) Math.sqrt(dx * dx + dz * dz);
        float T = Math.max(0.7f, Math.min(1.9f, dist / 15f));
        t.vx = dx / T; t.vz = dz / T; t.vy = (dy + 0.5f * Physics.GRAVITY * T * T) / T;
        thrown.add(t);
        emitSound(a.x, a.y + 2, a.z, 30, "debris", a.id, false);
    }

    private void debrisImpact(float x, float y, float z, int owner) {
        emitSound(x, y, z, 60, "debris", owner, false);
        quake(x, z, 22, 0.8f);
        for (Actor a : nearby(x, z, 4)) {
            if (a.id == owner) continue;
            float d = (float) Math.sqrt((a.x - x) * (a.x - x) + (a.y + 1 - y) * (a.y + 1 - y) + (a.z - z) * (a.z - z));
            if (d < 2.8f) damageActor(a, actor(owner), 42 * (1 - d / 3.4f) * difficultyDamage(), null, "torso", a.x, a.y + 1, a.z);
        }
        for (int dx = -1; dx <= 1; dx++) for (int dy = -1; dy <= 1; dy++) for (int dz = -1; dz <= 1; dz++) {
            int bx = (int) Math.floor(x) + dx, by = (int) Math.floor(y) + dy, bz = (int) Math.floor(z) + dz;
            Block b = world.block(bx, by, bz);
            if (b != null && b.hp > 0 && b.hp < 400) damageBlock(bx, by, bz, 9999, owner);
        }
        impact(x, y, z, Material.CONCRETE, 26);
    }

    /** The giant walks through light cover: fences, furniture, sandbags, wooden walls in its path give way. */
    public void smash(Actor a) {
        float fx = (float) -Math.sin(a.yaw), fz = (float) -Math.cos(a.yaw);
        boolean broke = false;
        for (float s = 0.8f; s <= 1.6f; s += 0.8f) for (int side = -1; side <= 1; side++) for (int dy = 0; dy <= 2; dy++) {
            int bx = (int) Math.floor(a.x + fx * s - fz * side * 0.6f), by = (int) Math.floor(a.y) + dy, bz = (int) Math.floor(a.z + fz * s + fx * side * 0.6f);
            Block b = world.block(bx, by, bz);
            if (b != null && b.solid() && b.hp > 0 && b.hp < 400) { damageBlock(bx, by, bz, 9999, a.id); broke = true; }
        }
        if (broke) { a.stuckTime = 0; quake(a.x, a.z, 20, 0.5f); if (a.anim != null && !a.anim.playing("giant_smash")) a.anim.play("giant_smash", 0); }
    }

    private void updateZones(float dt) {
        zoneTimer -= dt;
        boolean tick = zoneTimer <= 0;
        if (tick) zoneTimer = 0.5f;
        for (int zi = 0; zi < zones.size(); zi++) {   // by index: a boomer dying in a zone adds its own contamination zone
            Zone z = zones.get(zi);
            if (!z.kind.equals("fire") && rng.chance(dt * 14)) {
                float ang = rng.range(0f, 6.28f), rad = rng.nextFloat() * z.radius;
                Effect e = new Effect();
                e.x = z.x + (float) Math.sin(ang) * rad; e.z = z.z + (float) Math.cos(ang) * rad; e.y = z.y + 0.1f;
                e.vx = 0; e.vz = 0; e.vy = 3.4f + rng.nextFloat() * (z.kind.equals("contam") ? 2.5f : 0.8f);
                e.life = e.max = 0.5f + rng.nextFloat() * 0.5f; e.size = z.kind.equals("contam") ? 0.16f : z.kind.equals("fire") ? 0.18f : 0.1f; e.color = z.kind.equals("contam") ? 0xC08CA83A : z.kind.equals("fire") ? (rng.chance(0.5) ? 0xFFFF9A28 : 0xFFE0481C) : 0xFFB4D040; e.glow = true;
                effects.add(e);
            }
            if (!tick) continue;
            for (Actor a : nearby(z.x, z.z, z.radius + 1)) {
                if (a.infected() && !z.kind.equals("fire") || a.distXZ(z.x, z.z) > z.radius || Math.abs(a.y - z.y) > 2.2f) continue;
                if (a.isPlayer && god) continue;
                a.hp -= z.dps * 0.5f * (a.isPlayer ? difficultyDamage() : 1);
                a.hurtFlash = 0.15f;
                a.staggerUntil = time + 0.6f;
                if (a.isPlayer) {
                    damageShake = Math.min(1, damageShake + 0.25f);
                    body.healthChanged = time;
                    if (z.kind.equals("contam")) body.infection = Math.min(100, body.infection + 1.5f);
                    if (time - z.tick > 3) { z.tick = time; msg(z.kind.equals("contam") ? "Contaminated ground - get clear!" : z.kind.equals("fire") ? "You are on fire - move!" : "Acid! Move!", 0xFFB8D048); }
                } else if (a.hp <= 0) finish(a, actor(z.owner), z.kind.equals("fire") ? "burn" : "acid");
            }
        }
        zones.removeIf(z -> time > z.until);
    }

    /** True if the point lies in a hazard zone (HUD warning / AI avoidance). */
    public Zone zoneAt(float x, float y, float z) {
        for (Zone zn : zones) if (Math.abs(y - zn.y) < 2.2f && (x - zn.x) * (x - zn.x) + (z - zn.z) * (z - zn.z) < zn.radius * zn.radius) return zn;
        return null;
    }

    // ------------------------------------------------------------------ ragdolls
    private final Pose deathPose = new Pose();
    private final Mat4 rdBase = new Mat4(), rdHips = new Mat4();
    private final Mat4[] rdBones = new Mat4[Rig.GROUPS];

    /**
     * Death hands the body from animation to a constrained ragdoll: it starts in the exact pose the
     * actor died in, takes an impulse along the hit direction and settles within eight seconds.
     * Bodies far from the player skip the visible simulation and are placed already at rest.
     */
    /** The transforms of a character's twelve skeletal regions right now (animation pose, or the ragdoll if it has the body). Shared scratch. */
    public Mat4[] bones(Actor v) {
        if (rdBones[0] == null) for (int g = 0; g < Rig.GROUPS; g++) rdBones[g] = new Mat4();
        if (v.ragdoll != null) { v.ragdoll.bones(rdBones); return rdBones; }
        if (v.anim == null) shapeAnim(v);
        float s = Rig.VOX * v.anim.scale;
        v.anim.pose(v, deathPose, 0, null, false);
        rdBase.identity().translate(v.x, v.y + v.anim.visY, v.z).rotateY(v.yaw).scale(s, s, s);
        Rig.fk(deathPose, rdBase, rdHips, rdBones);
        return rdBones;
    }

    void startRagdoll(Actor v) {
        if (v.anim == null) shapeAnim(v);
        if (rdBones[0] == null) for (int g = 0; g < Rig.GROUPS; g++) rdBones[g] = new Mat4();
        float scale = v.anim.scale, s = Rig.VOX * scale;
        v.anim.pose(v, deathPose, 0, null, false);
        rdBase.identity().translate(v.x, v.y + v.anim.visY, v.z).rotateY(v.yaw).scale(s, s, s);
        Rig.fk(deathPose, rdBase, rdHips, rdBones);
        Ragdoll r = new Ragdoll(scale);
        r.fromPose(rdBones, v.vx, v.vy, v.vz);
        float push = Math.max(1.4f, Math.min(7.5f, 1.2f + v.hitForce / 22f));
        r.impulse(v.hitRegion, v.hitDirX * push, 0.6f + push * 0.22f, v.hitDirZ * push);
        v.ragdoll = r;
        if (v.tier == 1 || v.distXZ(player.x, player.z) > 55) {
            r.fastForward(world);
            v.x = r.x[Ragdoll.PELVIS]; v.z = r.z[Ragdoll.PELVIS]; v.y = Math.max(0, r.lowestY());
        }
    }

    private void footstep(Actor a, float speed) {
        if (listener == null) return;
        Block feet = world.block((int) Math.floor(a.x), (int) Math.floor(a.y + 0.2f), (int) Math.floor(a.z));
        Block under = world.block((int) Math.floor(a.x), (int) Math.floor(a.y - 0.1f), (int) Math.floor(a.z));
        String mat = feet != null && feet.mat == Material.WATER ? "water" : WorldAcoustics.stepSurface(under);
        if (!"none".equals(mat)) listener.footstep(a, mat, speed);
    }

    // ------------------------------------------------------------------ noise propagation service (A-Life milestone)
    private static final java.util.Set<String> LOUD = java.util.Set.of("shot", "explosion", "alarm_clock", "screech");

    /**
     * One loud action, several systems: (1) agents in earshot perceive it and investigate (done in
     * emitSound), (2) infected beyond earshot migrate toward it - live ones get a vague heading,
     * abstract cell populations shift a cell closer, (3) the faction holding the district sends its
     * nearest uncommitted squad, (4) district-level infected pressure redistributes and the event is
     * logged. Sustained noise is required: heat builds per cell and decays.
     */
    private void noiseEvent(float x, float y, float z, float radius, String category, int source) {
        if (radius < 40 || !LOUD.contains(category)) return;
        int c = cellOf(x, z);
        heat[c] += radius / 120f;
        if (heat[c] < 3) return;
        heat[c] = -3;   // the same cell needs a fresh burst before it draws another response
        noiseEvents++;
        District d = world.district(x, z);
        migrate(c, x, y, z, radius);
        String ctrl = profile.zone.controller(d);
        Actor src = actor(source);
        boolean sent = ctrl != null && dispatch(ctrl, x, z, src == null ? 0 : src.squad, "noise");
        profile.zone.reportNoise(d, radius);
        profile.zone.log("noise", d, (int) x, (int) z, src == null ? "" : src.faction, sent ? ctrl : "", "Sustained gunfire in the " + d.display + (sent ? " - " + ZoneState.cap(ctrl) + " responded" : ""));
    }

    private void migrate(int c, float x, float y, float z, float radius) {
        // live infected just beyond earshot: a vague pull toward the noise, not a position fix
        int drawn = 0;
        for (Actor a : actors) {
            if (drawn >= 8) break;
            if (a.dead || !a.infected() || "engage".equals(a.state)) continue;
            float d = a.distXZ(x, z);
            if (d < radius * 0.9f || d > radius * 2.4f) continue;
            a.memX = x + (rng.nextFloat() - 0.5f) * 24; a.memZ = z + (rng.nextFloat() - 0.5f) * 24; a.memY = y; a.memTime = time; a.memConfidence = 0.3f; a.memErr = 12;
            if (!"investigate".equals(a.state)) { a.state = "investigate"; a.stateTime = 0; a.hasGoal = false; }
            drawn++; migrations++;
        }
        // abstract populations: every nearby folded cell sends one of its infected a cell closer
        int cx = c / CELLS, cz = c % CELLS;
        for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) {
            int ax = cx + dx, az = cz + dz;
            if ((dx == 0 && dz == 0) || ax < 0 || az < 0 || ax >= CELLS || az >= CELLS) continue;
            int[] from = cells.get(ax * CELLS + az);
            if (from == null || from[0] <= 0) continue;
            int tx = ax - Integer.signum(dx), tz = az - Integer.signum(dz), to = tx * CELLS + tz;
            if (!profile.agents.shift(ax * CELLS + az, to, "infected", rng)) continue;
            from[0]--;
            cells.computeIfAbsent(to, k -> new int[5])[0]++;
            migrations++;
            if (activeCells.contains(to) && populate) spawnOne(to, 0);
        }
    }

    /** Materialises one unit of a cell's abstract population at its far edge (never on top of the player). */
    private boolean spawnOne(int c, int k) {
        for (absentialis.sim.Agents.Agent ag : profile.agents.agents) {
            if (!ag.alive || ag.actorId != 0 || ag.cell() != c || !ag.faction.equals(POP_FACTION[k])) continue;
            if (materialize(ag, c, 45)) { int[] pop = cells.get(c); if (pop != null && pop[k] > 0) pop[k]--; return true; }
        }
        return false;
    }

    /**
     * Sends the nearest uncommitted squad of a faction to a position (patrol response, reinforcement).
     * Live squads get a move order; if none is loaded, abstract population shifts a cell toward it.
     */
    public boolean dispatch(String faction, float x, float z, int exceptSquad, String reason) {
        Actor best = null;
        float bd = 260;
        for (Actor a : actors) {
            if (a.dead || a.isPlayer || !a.faction.equals(faction) || a.squad == exceptSquad || a.hasOrder) continue;
            if (!"idle".equals(a.state)) continue;
            float d = a.distXZ(x, z);
            if (d > 12 && d < bd) { bd = d; best = a; }
        }
        if (best != null) {
            for (Actor m : squadMembers(best)) {
                if (!"idle".equals(m.state)) continue;
                m.hasOrder = true; m.orderX = x + rng.range(-4f, 4f); m.orderZ = z + rng.range(-4f, 4f); m.orderUntil = time + 120;
            }
            dispatches++;
            return true;
        }
        int k = 0;
        for (int i = 1; i < POP_FACTION.length; i++) if (POP_FACTION[i].equals(faction)) k = i;
        if (k == 0) return false;
        int tc = cellOf(x, z), tx = tc / CELLS, tz = tc % CELLS, bestCell = -1, bestD = 99;
        for (Map.Entry<Integer, int[]> e : cells.entrySet()) {
            if (e.getValue()[k] <= 0 || e.getKey() == tc) continue;
            int d = Math.max(Math.abs(e.getKey() / CELLS - tx), Math.abs(e.getKey() % CELLS - tz));
            if (d < bestD && d <= 4) { bestD = d; bestCell = e.getKey(); }
        }
        if (bestCell < 0) return false;
        int bx = bestCell / CELLS, bz = bestCell % CELLS, to = (bx + Integer.signum(tx - bx)) * CELLS + bz + Integer.signum(tz - bz);
        int n = Math.min(2, cells.get(bestCell)[k]);
        for (int i = 0; i < n; i++) profile.agents.shift(bestCell, to, faction, rng);
        cells.get(bestCell)[k] -= n;
        cells.computeIfAbsent(to, kk -> new int[5])[k] += n;
        if (activeCells.contains(to) && populate) for (int i = 0; i < n; i++) spawnOne(to, k);
        dispatches++;
        return true;
    }

    /** Abstract population of a strategic cell (tests / debug): {infected, military, bandits, loners, mercenaries}. */
    public int[] cellPopulation(int cx, int cz) { int[] p = cells.get(cx * CELLS + cz); return p == null ? new int[5] : p.clone(); }

    // ------------------------------------------------------------------ strategic -> active evidence
    /**
     * Whatever the strategic tier resolved while this district was unloaded leaves marks that match
     * the log: bodies and smoke where a fight was lost, sandbags where a roadblock went up.
     */
    private void seedEvidence() {
        ZoneState z = profile.zone;
        Rng r = new Rng(profile.seed ^ z.day * 7919L);
        int placed = 0;
        for (absentialis.sim.ALife.Event e : z.log) {
            if (placed >= 8 || e.age(z.day, z.hour) > 36) continue;
            int y = groundY(e.x(), e.z());
            if (y < 0) continue;
            switch (e.type()) {
                case "battle", "overrun" -> {
                    String loser = e.type().equals("battle") ? e.b() : e.a();
                    int bodies = 2 + r.nextInt(2);
                    for (int i = 0; i < bodies; i++) corpseAt(loser, e.x() + r.range(-4f, 4f), e.z() + r.range(-4f, 4f), r);
                    if (e.type().equals("overrun")) corpseAt("infected", e.x() + r.range(-3f, 3f), e.z() + r.range(-3f, 3f), r);
                    smoke.add(new float[]{e.x() + 0.5f, y, e.z() + 0.5f});
                    evidence.add(e);
                    placed++;
                }
                case "roadblock" -> {
                    for (int k = -3; k <= 3; k++) {
                        int bx = e.x() + k, by = groundY(bx, e.z());
                        if (by < 0 || Math.abs(by - y) > 1 || world.get(bx, by, e.z()) != 0) continue;
                        if (k == 0) continue;   // a gap to walk through
                        world.set(bx, by, e.z(), Math.abs(k) == 1 ? Block.BARRIER : Block.SANDBAG);
                        if (Math.abs(k) >= 2 && world.get(bx, by + 1, e.z()) == 0) world.set(bx, by + 1, e.z(), Block.SANDBAG);
                    }
                    evidence.add(e);
                    placed++;
                }
                default -> {}
            }
        }
    }

    /** Strategic log entries that were turned into physical evidence this raid. */
    public final List<absentialis.sim.ALife.Event> evidence = new ArrayList<>();

    private void corpseAt(String faction, float x, float z, Rng r) {
        int y = groundY((int) Math.floor(x), (int) Math.floor(z));
        if (y < 0) return;
        Actor a = makeActor(faction, x, y, z, r);
        a.cell = cellOf(x, z);
        a.tier = 1;
        a.hitDirX = r.range(-1f, 1f); a.hitDirZ = r.range(-1f, 1f); a.hitForce = 30;
        actors.add(a);
        a.hp = 0;
        deaths--;                 // evidence bodies were never part of this raid's living population
        kill(a, null);
        a.deadTime = 30;
    }

    // ------------------------------------------------------------------ loot & interaction
    /** Lazily rolls a searchable block's contents (stockpile-aware) the first time it is opened. */
    public Container openContainer(int x, int y, int z) {
        int key = World.idx(x, y, z);
        Container c = containers.get(key);
        if (c != null) return c;
        Block b = world.block(x, y, z);
        MapData.LootSpot spot = world.map.lootAt(x, y, z);
        String table = unlocked.contains(key) ? "locked" : spot != null ? spot.table : b.containerType != null ? b.containerType : "crate";
        District d = world.district(x, z);
        c = new Container("box:" + key, 8, 6);
        c.label = ZoneState.cap(b.name.replace('_', ' '));
        float depletion = 1f - Math.min(1f, avgSupply(d));
        for (Object[] e : Content.roll(table, new Rng(profile.seed ^ key ^ profile.zone.day * 31L), profile.zone.availability(d), depletion)) {
            addRolled(c, (String) e[0], (Integer) e[1], null);
            profile.zone.reportLoot(d, Content.supplyCategory(Content.def((String) e[0])), 1);
        }
        containers.put(key, c);
        debrief.containersSearched++;
        bus.emit(new Events.ContainerSearched(key, table, x, y, z));
        emitSound(x + 0.5f, y + 0.5f, z + 0.5f, 6, "search", player.id, false);
        return c;
    }

    private float avgSupply(District d) { float s = 0; for (float v : profile.zone.supply[d.ordinal()]) s += v; return s / ZoneState.SUPPLY.length; }

    public void dropItem(ItemInstance it, float x, float y, float z) {
        WorldItem w = new WorldItem();
        w.it = it; w.x = x; w.y = y; w.z = z;
        items.add(w);
    }

    public WorldItem nearestItem(float x, float y, float z, float r) {
        WorldItem best = null; float bd = r * r;
        for (WorldItem w : items) { float d = (w.x - x) * (w.x - x) + (w.y - y) * (w.y - y) + (w.z - z) * (w.z - z); if (d < bd) { bd = d; best = w; } }
        return best;
    }

    public Actor nearestCorpse(float x, float z, float r) {
        Actor best = null; float bd = r;
        for (Actor a : actors) if (a.dead && a.corpse != null && !a.isPlayer) { float d = a.distXZ(x, z); if (d < bd) { bd = d; best = a; } }
        return best;
    }

    /** Toggles a two-block door (and its partner above/below). */
    public void toggleDoor(int x, int y, int z) { toggleDoor(x, y, z, player); }

    /** Opens or closes a door leaf; whoever worked the handle is the source of the sound. */
    public void toggleDoor(int x, int y, int z, Actor by) {
        Doors.Door d = doors.at(x, y, z);
        if (d != null) doors.use(d, by);
    }

    /** Infrastructure repair (substation): 2 electrical parts restore district power. */
    public String repairSite(int x, int y, int z) {
        District d = world.district(x, z);
        if (profile.zone.power[d.ordinal()]) return "Power is already flowing here";
        List<ItemInstance> parts = new ArrayList<>();
        for (ItemInstance i : profile.loadout.all()) if ("mat.electrical".equals(i.defId) && i.parent == null) parts.add(i);
        if (parts.size() < 2) return "Needs 2x Electrical Parts to restore power";
        InventoryService.consume(parts.get(0), 1);
        InventoryService.consume(parts.get(1), 1);
        profile.zone.power[d.ordinal()] = true;
        debrief.powerRestored = true;
        for (MapData.Point p : world.map.lampsOnPower) if (world.district(p.x, p.z) == d && world.get(p.x, p.y, p.z) == Block.LAMP_OFF) world.set(p.x, p.y, p.z, Block.LAMP);
        emitSound(x, y, z, 60, "machines", player.id, false);
        profile.zone.news("Power restored in the " + d.display + " by an unknown survivor");
        bus.emit(new Events.InfrastructureChanged(d.name(), "power"));
        evaluateExits();
        return "Power restored - lamps, the pumping station tunnel and local trade come back online";
    }
}
