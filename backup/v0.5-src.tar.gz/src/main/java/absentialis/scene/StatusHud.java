package absentialis.scene;

import absentialis.engine.math.Mat4;
import absentialis.entity.Actor;
import absentialis.entity.Physics;
import absentialis.entity.Vital;
import absentialis.gameplay.CombatConfig;
import absentialis.gameplay.CombatConfig.Condition;
import absentialis.gameplay.items.Content;
import absentialis.gameplay.items.ItemDef;
import absentialis.gameplay.items.ItemInstance;
import absentialis.ui.Layout;
import absentialis.ui.Layout.Box;
import absentialis.ui.Portrait;
import absentialis.ui.Ui;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The 0.5 survival-action interface (brief sections 9.2, 10, 11, 12, 13): one visual language for the lower-right
 * character status module (portrait, curved health gauge, ammunition), the squad column and killfeed on the left
 * edge, the centre-screen hit marker, speech bubbles over heads, minimap contacts and the inventory's status
 * panel. Everything is read from authoritative state each frame - entity health, the loadout, the raid's
 * confirmed events - and laid out in anchored, scaled units, so nothing here can drift from the game or from the
 * screen it is drawn on.
 */
public final class StatusHud {
    private final Ctx c;
    private final Raid raid;
    private final CombatConfig cfg = CombatConfig.get();
    public final CombatFeed feed;
    private final Portrait portraits = new Portrait();
    private final Map<String, ItemInstance> iconItems = new HashMap<>();
    private float shownHp = -1, ammoDim = 1;
    /** Layout results of the last frame (gates check the module stays on screen and the feed clear of the squad column). */
    public Box moduleBox = new Box(0, 0, 0, 0), squadBox = new Box(0, 0, 0, 0), feedBox = new Box(0, 0, 0, 0);
    public int bubblesDrawn, bubblesSkipped;

    StatusHud(Ctx c, Raid raid) {
        this.c = c; this.raid = raid;
        feed = new CombatFeed(raid);
        feed.attach(raid.bus);
    }

    // ------------------------------------------------------------------ shared pieces
    /** Arc length of the health gauge for a maximum health: a half circle at the base maximum, wrapping further as it grows. */
    public static float gaugeSpan(float maxHp, CombatConfig cfg) {
        float k = Math.max(0, Math.min(1, (maxHp - cfg.baseHealth) / Math.max(1f, cfg.healthCap - cfg.baseHealth)));
        return (float) Math.PI * (1f + 0.78f * k);
    }

    /** Reserve rounds for a weapon: every loose round of its calibre carried, not counting what is loaded. */
    public static int reserve(Raid raid, ItemInstance weapon) {
        if (weapon == null || weapon.def().weapon == null || weapon.def().weapon.caliber == null) return 0;
        String cal = weapon.def().weapon.caliber;
        int n = 0;
        for (ItemInstance it : raid.profile.loadout.all()) { ItemDef d = it.def(); if (d.ammo != null && cal.equals(d.ammo.caliber)) n += it.qty; }
        return n;
    }

    private int portrait(Actor a, ActorRenderer.Look look) {
        Condition cond = cfg.condition(a.hp, a.maxHp);
        return portraits.texture(look.key, () -> c.ar.flatten(look), a.dead ? Condition.CRITICAL : cond, a.dead || a.vital != Vital.ACTIVE);
    }

    private ItemInstance iconFor(String defId) {
        if (defId == null || defId.isEmpty() || Content.def(defId) == null) return null;
        return iconItems.computeIfAbsent(defId, id -> new ItemInstance(-9, id));
    }

    /** An item's icon fitted inside a box, keeping its proportions. */
    private void icon(Ui ui, ItemInstance it, float x, float y, float w, float h, int argb) {
        float ar = it.baseW() / (float) Math.max(1, it.baseH());
        float iw = Math.min(w, h * ar), ih = iw / ar;
        c.icons.draw(ui.b, it, Math.round(x + (w - iw) / 2), Math.round(y + (h - ih) / 2), iw, ih, argb);
    }

    /**
     * The portrait inside its gauge. Returns nothing; draws at (cx, cy) with outer radius r. Shared by the gameplay
     * module and the inventory panel so the two read as one object.
     */
    private void gauge(Ui ui, Actor p, ActorRenderer.Look look, float cx, float cy, float r, float t) {
        float r0 = r - ui.s(8), r1 = r;
        Condition cond = cfg.condition(p.hp, p.maxHp);
        int col = cfg.color(cond);
        float a0 = (float) Math.PI, span = gaugeSpan(p.maxHp, cfg);
        // portrait on a dark disc
        Layout.arc(ui, cx, cy, 0, r0 - ui.s(3), 0, (float) Math.PI * 2, 0xE0101311);
        float ps = Math.round((r0 - ui.s(5)) * 1.42f);
        ui.b.image(portrait(p, look), Math.round(cx - ps / 2), Math.round(cy - ps / 2), ps, ps, p.downed() ? 0xFFB0A8A8 : 0xFFFFFFFF);
        // track, then the fill: current health as a share of the arc the maximum allows
        Layout.arc(ui, cx, cy, r0 - 1, r1 + 1, a0 - 0.012f, a0 + span + 0.012f, 0xFF0B0C0B);
        Layout.arc(ui, cx, cy, r0, r1, a0, a0 + span, 0xFF24282A);
        if (shownHp < 0) shownHp = p.hp;
        shownHp += (p.hp - shownHp) * Math.min(1, ui.dt * 9);
        float f = Math.max(0, Math.min(1, shownHp / Math.max(1f, p.maxHp)));
        if (p.downed()) {
            // on the ground the gauge is the blood that is left
            float bl = raid.casualty.bleedFraction(p), pulse = 0.7f + 0.3f * (float) Math.sin(t * 6);
            Layout.arc(ui, cx, cy, r0, r1, a0, a0 + span * bl, Ui.alpha(cfg.color(Condition.CRITICAL), pulse));
            if (p.vital == Vital.REVIVING) Layout.arc(ui, cx, cy, r1 + ui.s(2), r1 + ui.s(5), a0, a0 + span * raid.casualty.reviveFraction(p), 0xFF7DBA5C);
        } else {
            // a recent loss shows for a moment as a paler tail behind the fill
            if (shownHp > p.hp + 0.5f) Layout.arc(ui, cx, cy, r0, r1, a0 + span * Math.max(0, p.hp / p.maxHp), a0 + span * f, 0xFFE8E0D0);
            float pulse = cond == Condition.CRITICAL ? 0.72f + 0.28f * (float) Math.sin(t * 5.2f) : 1;       // restrained: brightness, not size
            Layout.arc(ui, cx, cy, r0, r1, a0, a0 + span * Math.max(0, Math.min(1, p.hp / p.maxHp)), Ui.alpha(col, pulse));
            Layout.arc(ui, cx, cy, r1 - ui.s(2), r1, a0, a0 + span * Math.max(0, Math.min(1, p.hp / p.maxHp)), Ui.alpha(Ui.mix(col, 0xFFFFFFFF, 0.35f), pulse));
        }
        // a notch every fifty points, so a longer gauge reads as more health and not as a bigger picture
        for (float hp = 50; hp < p.maxHp - 1; hp += 50) { float a = a0 + span * hp / p.maxHp; Layout.arc(ui, cx, cy, r0, r1, a - 0.014f, a + 0.014f, 0xFF0B0C0B); }
        // body armour: a thin outer band over the same sweep
        if (p.shieldMax > 0) {
            Layout.arc(ui, cx, cy, r1 + ui.s(3), r1 + ui.s(6), a0, a0 + span, 0xFF1A2026);
            Layout.arc(ui, cx, cy, r1 + ui.s(3), r1 + ui.s(6), a0, a0 + span * Math.max(0, p.shield / p.shieldMax), 0xFF6AA4D6);
        }
    }

    // ------------------------------------------------------------------ the lower-right module
    public void module(Ui ui, ItemInstance held, float reloadT, float reloadMax, ActorRenderer.Look look, float ammoShown) {
        Actor p = raid.player;
        float t = raid.time;
        Box box = Layout.anchor(ui, 1, 1, 330, 176, 14, 12);
        moduleBox = box;
        float r = ui.s(50), cx = box.r() - ui.s(70), cy = box.y + ui.s(64);
        // a soft plate behind the whole module so it holds together over any scene
        ui.b.rect(box.x + ui.s(28), box.y + ui.s(30), box.w - ui.s(96), ui.s(86), 0x66090A09);
        gauge(ui, p, look, cx, cy, r, t);
        // identity and condition under the portrait
        Condition cond = cfg.condition(p.hp, p.maxHp);
        String name = raid.profile.name == null || raid.profile.name.isEmpty() ? "Survivor" : raid.profile.name;
        float ny = cy + r + ui.s(10), nw = ui.s(132);
        float ns = Layout.fitSize(ui, name, nw, 13, 9);
        ui.textC(Layout.elide(ui, name, nw, ns), cx, ny, ns, Ui.TXT_HI);
        String state = p.downed() ? (p.vital == Vital.REVIVING ? "BEING REVIVED" : "DOWNED  " + Math.max(0, (int) Math.ceil(p.bleedLeft)) + "s") : cond.label.toUpperCase();
        ui.textC(state + "   " + Math.max(0, Math.round(p.hp)) + " / " + Math.round(p.maxHp), cx, ny + ui.s(17), 10, p.downed() ? cfg.color(Condition.CRITICAL) : cfg.color(cond));
        // stamina and focus: two slim bars in the module's width
        float bw = ui.s(60), bx = cx - bw - ui.s(3), by = ny + ui.s(34);
        ui.b.rect(bx, by, bw, ui.s(3), 0xFF1A1C1B); ui.b.rect(bx, by, bw * raid.body.stamina / 100f, ui.s(3), raid.body.exhausted > 0 ? Ui.RED : 0xFFE0B830);
        ui.b.rect(cx + ui.s(3), by, bw, ui.s(3), 0xFF1A1C1B); ui.b.rect(cx + ui.s(3), by, bw * raid.body.focus / 100f, ui.s(3), 0xFF6AA4D6);

        // ---- ammunition: loaded rounds large, reserve small, the weapon's own silhouette - inside the gauge's curve
        float ax = cx - r - ui.s(14);                                     // right edge of the ammunition block
        boolean gun = held != null && held.def().weapon != null && !held.def().weapon.melee();
        ammoDim += ((t - ammoShown < 3.5f || reloadT > 0 ? 1f : 0.62f) - ammoDim) * Math.min(1, ui.dt * 6);
        if (gun) {
            int loaded = held.loadedRounds(), res = reserve(raid, held);
            String big = String.valueOf(loaded), small = String.valueOf(res);
            float bwid = ui.tw(big, 38);
            ui.textR(big, ax, cy - ui.s(30), 38, Ui.alpha(loaded == 0 ? Ui.RED : Ui.TXT_HI, ammoDim));
            ui.textR(small, ax, cy + ui.s(12), 16, Ui.alpha(res == 0 ? Ui.AMBER : Ui.TXT, ammoDim));
            ui.b.rect(ax - Math.max(bwid, ui.tw(small, 16)), cy + ui.s(9), Math.max(bwid, ui.tw(small, 16)), 1, Ui.alpha(0xFF8E897A, ammoDim * 0.7f));
            float ix = ax - Math.max(bwid, ui.s(34)) - ui.s(14) - ui.s(104);
            icon(ui, held, ix, cy - ui.s(26), ui.s(104), ui.s(40), Ui.alpha(0xFFFFFFFF, ammoDim));
            String mode = held.fireModeName().toUpperCase();
            Layout.fit(ui, held.def().name, ix, cy + ui.s(18), ui.s(104), 11, 8, Ui.alpha(Ui.TXT, ammoDim));
            ui.text(mode, ix, cy + ui.s(32), 9, Ui.alpha(Ui.TXT_DIM, ammoDim));
            float cond2 = held.condition() / 100f;
            ui.b.rect(ix + ui.tw(mode, 9) + ui.s(8), cy + ui.s(37), ui.s(50) * cond2, ui.s(2), Ui.alpha(cond2 < 0.25f ? Ui.RED : cond2 < 0.5f ? Ui.AMBER : Ui.GREEN, ammoDim));
            if (reloadT > 0) {
                float f = 1 - reloadT / Math.max(0.01f, reloadMax);
                ui.b.rect(ix, cy - ui.s(34), ui.s(104), ui.s(3), 0x80000000);
                ui.b.rect(ix, cy - ui.s(34), ui.s(104) * f, ui.s(3), 0xFFE2A034);
            }
            if (held.jammed) ui.textR("JAMMED - [R] CLEAR", ax, cy - ui.s(52), 12, Ui.RED);
        } else if (held != null) {
            float ix = ax - ui.s(104);
            icon(ui, held, ix, cy - ui.s(22), ui.s(104), ui.s(40), 0xD0FFFFFF);
            Layout.fit(ui, held.def().name, ix, cy + ui.s(22), ui.s(104), 11, 8, Ui.TXT);
        } else ui.textR(p.downed() ? "NO SIDEARM" : "UNARMED", ax, cy - ui.s(6), 12, Ui.TXT_DIM);
    }

    // ------------------------------------------------------------------ squad column (left edge)
    /** Draws the squad status column and returns the y just below it. */
    public float squad(Ui ui, String squadSel, int[] teamColors) {
        List<Actor> el = raid.element;
        float x = ui.s(18), y = Math.round(ui.h * 0.30f), w = ui.s(206), rh = ui.s(24);
        if (el.isEmpty()) { squadBox = new Box(x, y, 0, 0); return y; }
        String[] teams = {"gold", "red", "blue"};
        for (int i = 0; i < 3; i++) {
            boolean sel = teams[i].equals(squadSel);
            ui.b.rect(x + i * ui.s(69), y, ui.s(66), ui.s(16), sel ? Ui.alpha(teamColors[i], 0.9f) : 0x90101010);
            ui.textC(teams[i].toUpperCase() + " " + raid.team(teams[i]).size(), x + i * ui.s(69) + ui.s(33), y + ui.s(2), 10, sel ? 0xFF101010 : teamColors[i]);
        }
        float top = y;
        y += ui.s(20);
        for (Actor m : el) {
            boolean dead = m.dead, down = m.downed();
            Condition cond = cfg.condition(m.hp, m.maxHp);
            int col = dead ? 0xFF6A665C : down ? cfg.color(Condition.CRITICAL) : cfg.color(cond);
            // the row itself tells active from incapacitated at a glance: tint, bar, word
            ui.b.rect(x, y, w, rh - ui.s(2), dead ? 0x70080808 : down ? 0x905A1410 : 0x80101010);
            ui.b.rect(x, y, ui.s(4), rh - ui.s(2), dead ? 0xFF4A463E : teamColors["red".equals(m.team) ? 1 : 2]);
            float nx = x + ui.s(10);
            Layout.fit(ui, Raid.displayName(m), nx, y + ui.s(1), ui.s(92), 11, 8, dead ? 0xFF7A766C : Ui.TXT_HI);
            String word = dead ? "DEAD" : m.vital == Vital.REVIVING ? "REVIVING" : down ? "DOWN " + Math.max(0, (int) Math.ceil(m.bleedLeft)) + "s" : cond.label.toUpperCase();
            ui.textR(word, x + w - ui.s(6), y + ui.s(1), 10, col);
            float bx = nx, bw = w - ui.s(18), by = y + ui.s(15);
            ui.b.rect(bx, by, bw, ui.s(4), 0xFF1A1C1B);
            if (dead) { ui.b.rect(bx, by + ui.s(1), bw, 1, 0xFF4A463E); }
            else if (down) {
                float pulse = 0.65f + 0.35f * (float) Math.sin(raid.time * 6);
                ui.b.rect(bx, by, bw * raid.casualty.bleedFraction(m), ui.s(4), Ui.alpha(col, pulse));
                if (m.vital == Vital.REVIVING) ui.b.rect(bx, by + ui.s(4), bw * raid.casualty.reviveFraction(m), ui.s(2), Ui.GREEN);
            } else ui.b.rect(bx, by, bw * Math.max(0, Math.min(1, m.hp / m.maxHp)), ui.s(4), col);
            if (!dead && !down) { String ord = ("engage".equals(m.state) ? "FIGHTING" : m.sqOrder.toUpperCase()) + (m.qOrder != null ? " > " + m.qOrder.toUpperCase() : ""); ui.text(ord, nx + ui.s(96), y + ui.s(2), 8, m.qOrder != null ? Ui.AMBER : Ui.TXT_DIM); }
            y += rh;
        }
        ui.text("[T] team  [F1] follow  [F2] hold  [F3] move  [F4] sweep", x, y + ui.s(2), 9, Ui.TXT_DIM);
        ui.text("[Ctrl]+order queue  [F5] initiate  [F6] swap team", x, y + ui.s(14), 9, Ui.TXT_DIM);
        y += ui.s(30);
        squadBox = new Box(x, top, w, y - top);
        return y;
    }

    // ------------------------------------------------------------------ killfeed (left side, under the squad column)
    public void killfeed(Ui ui, float y) {
        float t = raid.time;
        feed.prune(t);
        float x = ui.s(18), rh = ui.s(22), top = y + ui.s(6);
        y = top;
        float maxW = 0;
        for (int i = feed.entries.size() - 1; i >= 0; i--) {
            CombatFeed.Entry e = feed.entries.get(i);
            float age = t - e.time, left = cfg.feedLife - age;
            float in = Math.min(1, age / Math.max(0.01f, cfg.feedSlide)), alpha = Math.min(1, left / Math.max(0.01f, cfg.feedFade)) * in;
            float ox = (1 - in) * (1 - in) * -ui.s(60);                    // slides in from the edge, eases to rest
            String killer = e.killerId == 0 ? "" : Layout.elide(ui, e.killer, ui.s(120), 12), victim = Layout.elide(ui, e.victim, ui.s(120), 12);
            ItemInstance wi = iconFor(e.weapon);
            String tag = wi != null ? null : switch (e.cause) { case "blast" -> "EXPLOSION"; case "burn" -> "FIRE"; case "bleed" -> "BLED OUT"; case "acid" -> "ACID"; case "melee" -> "MELEE"; case "vehicle" -> "RUN DOWN"; case "blunt" -> "IMPACT"; default -> "KILLED"; };
            float kw = killer.isEmpty() ? 0 : ui.tw(killer, 12) + ui.s(8), iw = wi != null ? ui.s(46) : ui.tw(tag, 9) + ui.s(10), vw = ui.tw(victim, 12);
            float extra = (e.headshot ? ui.s(22) : 0) + (e.friendlyFire ? ui.s(22) : 0);
            float w = ui.s(8) + kw + iw + ui.s(8) + vw + extra + ui.s(8);
            ui.b.rect(x + ox, y, w, rh - ui.s(3), Ui.alpha(0xA0101010, alpha));
            ui.b.rect(x + ox, y, ui.s(3), rh - ui.s(3), Ui.alpha(CombatFeed.color(e.killerId == 0 ? e.victimRel : e.killerRel), alpha));
            float cx = x + ox + ui.s(8);
            if (!killer.isEmpty()) { ui.text(killer, cx, y + ui.s(2), 12, Ui.alpha(CombatFeed.color(e.killerRel), alpha)); cx += kw; }
            if (wi != null) icon(ui, wi, cx, y + ui.s(1), ui.s(42), rh - ui.s(6), Ui.alpha(0xFFFFFFFF, alpha));
            else { ui.b.rect(cx, y + ui.s(3), iw - ui.s(4), rh - ui.s(9), Ui.alpha(0xFF2A2C2A, alpha)); ui.text(tag, cx + ui.s(3), y + ui.s(5), 9, Ui.alpha(Ui.TXT, alpha)); }
            cx += iw + ui.s(4);
            if (e.headshot) { ui.text("HS", cx, y + ui.s(4), 9, Ui.alpha(Ui.AMBER, alpha)); cx += ui.s(22); }
            ui.text(victim, cx, y + ui.s(2), 12, Ui.alpha(CombatFeed.color(e.victimRel), alpha));
            cx += vw + ui.s(6);
            if (e.friendlyFire) ui.text("FF", cx, y + ui.s(4), 9, Ui.alpha(Ui.RED, alpha));
            maxW = Math.max(maxW, w);
            y += rh;
        }
        feedBox = new Box(x, top, maxW, y - top);
    }

    // ------------------------------------------------------------------ hit marker (centre screen)
    public void hitmarker(Ui ui) {
        float k = feed.marker(raid.time);
        if (k <= 0) return;
        int col = cfg.markerColors[feed.markerLevel];
        float cx = ui.w / 2f, cy = ui.h / 2f;
        // a quick pop on arrival, then it only fades: no growth, no travel
        float pop = 1 + 0.35f * Math.max(0, (k - 0.75f) / 0.25f);
        float gap = ui.s(cfg.markerGap) * pop, len = ui.s(cfg.markerSize) * (feed.markerLevel == CombatFeed.KILL ? 1.25f : 1f), th = Math.max(2, ui.s(2));
        float a = Math.min(1, k * 2.2f);
        for (int sx = -1; sx <= 1; sx += 2) for (int sy = -1; sy <= 1; sy += 2) {
            ui.b.line(cx + sx * gap + sx, cy + sy * gap + sy, cx + sx * (gap + len) + sx, cy + sy * (gap + len) + sy, th + 2, Ui.alpha(0xB0000000, a));
            ui.b.line(cx + sx * gap, cy + sy * gap, cx + sx * (gap + len), cy + sy * (gap + len), th, Ui.alpha(col, a));
        }
    }

    // ------------------------------------------------------------------ speech bubbles (world space)
    private final float[] ndc = new float[3];
    private final List<Box> placed = new ArrayList<>();
    private final List<Actor> speakers = new ArrayList<>();

    /** Bubbles over the heads of whoever is speaking: anchored to the head, facing the camera, smaller and fainter with distance. */
    public void bubbles(Ui ui, Mat4 pv, float camX, float camY, float camZ) {
        bubblesDrawn = bubblesSkipped = 0;
        float t = raid.time;
        speakers.clear();
        for (Actor a : raid.actors) if (!a.isPlayer && t < a.sayUntil && !a.sayText.isEmpty() && !a.dead) speakers.add(a);
        if (speakers.isEmpty()) return;
        speakers.sort((p, q) -> Float.compare(dist2(p, camX, camY, camZ), dist2(q, camX, camY, camZ)));
        placed.clear();
        for (Actor a : speakers) {
            float d = (float) Math.sqrt(dist2(a, camX, camY, camZ));
            if (d > cfg.talkMaxDistance || bubblesDrawn >= cfg.talkMaxVisible) { bubblesSkipped++; continue; }
            float hx = a.x, hy = a.y + a.height() + 0.42f + (a.anim != null ? a.anim.visY : 0), hz = a.z;
            float w = pv.project(hx, hy, hz, ndc);
            if (w <= 0.05f || Math.abs(ndc[0]) > 1.05f || Math.abs(ndc[1]) > 1.05f) { bubblesSkipped++; continue; }
            // a voice carries through a wall, a bubble does not: out of sight it shows only close by, and fainter
            boolean visible = Physics.los(raid.world, camX, camY, camZ, hx, hy - 0.3f, hz);
            if (!visible && d > 9) { bubblesSkipped++; continue; }
            float age = t - a.sayAt, left = a.sayUntil - t;
            float alpha = Math.min(1, age / 0.15f) * Math.min(1, left / 0.4f) * (d > cfg.talkFadeFrom ? 1 - (d - cfg.talkFadeFrom) / Math.max(1f, cfg.talkMaxDistance - cfg.talkFadeFrom) : 1) * (visible ? 1 : 0.5f);
            if (alpha <= 0.02f) continue;
            float size = d < 8 ? 13 : d < 18 ? 12 : 11;
            float wrapW = ui.s(cfg.talkWrap) * (d < 18 ? 1 : 0.85f);
            List<String> lines = Layout.wrap(ui, a.sayText, wrapW, size);
            if (lines.size() > 4) { lines = new ArrayList<>(lines.subList(0, 4)); lines.set(3, Layout.elide(ui, lines.get(3) + " ...", wrapW, size)); }
            float lh = Layout.lineHeight(ui, size), tw = 0;
            for (String l : lines) tw = Math.max(tw, ui.tw(l, size));
            String who = Raid.displayName(a);
            tw = Math.max(tw, ui.tw(who, 9));
            float bw = tw + ui.s(16), bh = lines.size() * lh + ui.s(18);
            float sx = (ndc[0] * 0.5f + 0.5f) * ui.w, sy = (1 - (ndc[1] * 0.5f + 0.5f)) * ui.h;
            Box b = new Box(Math.round(sx - bw / 2), Math.round(sy - bh - ui.s(8)), bw, bh);
            b.x = Math.max(ui.s(6), Math.min(ui.w - bw - ui.s(6), b.x));
            // step up out of the way of a bubble already placed; give up rather than cover it
            int tries = 0;
            boolean clear = false;
            while (tries++ < 4) { clear = true; for (Box o : placed) if (b.overlaps(o)) { clear = false; b.y = o.y - bh - ui.s(4); break; } if (clear) break; }
            if (!clear || b.y < ui.s(4)) { bubblesSkipped++; continue; }
            placed.add(b);
            int rel = CombatFeed.relation(raid, a, a.faction), col = CombatFeed.color(rel);
            ui.b.rect(b.x, b.y, b.w, b.h, Ui.alpha(0xC80E100F, alpha));
            ui.b.rect(b.x, b.y, b.w, ui.s(2), Ui.alpha(col, alpha));
            if (Math.abs(sx - (b.x + b.w / 2)) < b.w / 2 - ui.s(6) && b.y + b.h < sy) ui.b.line(sx, b.y + b.h, sx, Math.min(sy - ui.s(2), b.y + b.h + ui.s(7)), Math.max(2, ui.s(2)), Ui.alpha(0xC80E100F, alpha));
            ui.text(who, b.x + ui.s(8), b.y + ui.s(4), 9, Ui.alpha(col, alpha));
            for (int i = 0; i < lines.size(); i++) ui.text(lines.get(i), b.x + ui.s(8), b.y + ui.s(15) + i * lh, size, Ui.alpha(Ui.TXT_HI, alpha));
            bubblesDrawn++;
        }
    }

    private static float dist2(Actor a, float x, float y, float z) { return (a.x - x) * (a.x - x) + (a.y - y) * (a.y - y) + (a.z - z) * (a.z - z); }

    // ------------------------------------------------------------------ minimap contacts
    /**
     * Contacts on the minimap (brief 10.1): squadmates always, as arrows turned to their facing; everyone else as
     * a dot, and only while the player has reason to know where they are - in line of sight now, or seen in the
     * last few seconds. The map never shows what is behind a wall nobody has looked round.
     */
    public void minimapContacts(Ui ui, float sx, float sy, float sw, float wx0, float wz0, float span) {
        float k = sw / span, t = raid.time;
        Actor p = raid.player;
        ui.b.scissor((int) sx, (int) sy, (int) sw, (int) sw);
        for (Actor a : raid.actors) {
            if (a.isPlayer || a.dead) continue;
            float mx = sx + (a.x - wx0) * k, my = sy + (a.z - wz0) * k;
            if (mx < sx - 6 || my < sy - 6 || mx > sx + sw + 6 || my > sy + sw + 6) continue;
            if (a.mate()) {
                float fx = (float) -Math.sin(a.yaw), fz = (float) -Math.cos(a.yaw), rx = -fz, rz = fx, g = ui.s(5);
                int col = a.downed() ? 0xFFE8CF4A : CombatFeed.color(CombatFeed.SQUAD);
                // an arrowhead: tip ahead, two barbs behind
                ui.b.line(mx + fx * g * 1.5f, my + fz * g * 1.5f, mx - fx * g + rx * g, my - fz * g + rz * g, Math.max(2, ui.s(2.4f)), col);
                ui.b.line(mx + fx * g * 1.5f, my + fz * g * 1.5f, mx - fx * g - rx * g, my - fz * g - rz * g, Math.max(2, ui.s(2.4f)), col);
                ui.b.line(mx - fx * g + rx * g, my - fz * g + rz * g, mx - fx * g - rx * g, my - fz * g - rz * g, Math.max(2, ui.s(2f)), col);
                continue;
            }
            if (a.infected()) continue;                                // the brief's contacts are the human characters
            float d = a.dist(p);
            boolean sees = d < 70 && Physics.los(raid.world, p.x, p.eyeY(), p.z, a.x, a.y + a.height() * 0.8f, a.z);
            if (sees) a.seenByPlayer = t;
            float since = t - a.seenByPlayer;
            if (since > 4f) continue;
            int col = CombatFeed.color(CombatFeed.relation(raid, a, a.faction));
            float alpha = since < 0.5f ? 1 : Math.max(0, 1 - (since - 0.5f) / 3.5f), s = Math.max(3, ui.s(4));
            ui.b.rect(Math.round(mx - s / 2) - 1, Math.round(my - s / 2) - 1, s + 2, s + 2, Ui.alpha(0xFF0A0A0A, alpha));
            ui.b.rect(Math.round(mx - s / 2), Math.round(my - s / 2), s, s, Ui.alpha(col, alpha));
        }
        ui.b.noScissor();
    }

    // ------------------------------------------------------------------ inventory status panel (right side)
    /** The character status panel of the inventory screen: the same gauge, the same numbers, with room to spell them out. */
    public void statusPanel(Ui ui, Box box, ItemInstance held, ActorRenderer.Look look) {
        Actor p = raid.player;
        ui.panelDark(box.x, box.y, box.w, box.h);
        Box in = box.inset(ui.s(14));
        float r = Math.min(ui.s(62), in.w * 0.30f), cx = in.x + in.w / 2, cy = in.y + r + ui.s(18);
        ui.text("STATUS", in.x, in.y - ui.s(2), 11, Ui.TXT_DIM);
        gauge(ui, p, look, cx, cy, r, raid.time);
        Condition cond = cfg.condition(p.hp, p.maxHp);
        float y = cy + r + ui.s(12);
        String name = raid.profile.name == null || raid.profile.name.isEmpty() ? "Survivor" : raid.profile.name;
        float ns = Layout.fitSize(ui, name, in.w, 17, 10);
        ui.textC(Layout.elide(ui, name, in.w, ns), cx, y, ns, Ui.TXT_HI);
        y += ui.s(24);
        ui.textC(raid.profile.prog.title(), cx, y, 10, Ui.TXT_DIM);
        y += ui.s(22);
        y = row(ui, in, y, "Health", Math.max(0, Math.round(p.hp)) + " / " + Math.round(p.maxHp), cfg.color(cond));
        y = row(ui, in, y, "Condition", p.downed() ? "Downed" : cond.label, p.downed() ? cfg.color(Condition.CRITICAL) : cfg.color(cond));
        int herbs = raid.profile.herbs, cap = cfg.herbCap();
        y = row(ui, in, y, "Maximum health", Math.round(p.maxHp) + (herbs >= cap ? "  (limit)" : "  (+" + cfg.perHerb + " per Yellow Herb)"), Ui.TXT);
        if (p.shieldMax > 0) y = row(ui, in, y, "Body armor", Math.round(p.shield) + " / " + Math.round(p.shieldMax), Ui.BLUE);
        y += ui.s(6);
        ui.b.rect(in.x, y, in.w, 1, 0x40FFFFFF);
        y += ui.s(8);
        boolean gun = held != null && held.def().weapon != null && !held.def().weapon.melee();
        if (held != null) {
            icon(ui, held, in.x, y, in.w, ui.s(46), 0xFFFFFFFF);
            y += ui.s(50);
            Layout.fit(ui, held.def().name, in.x, y, in.w, 13, 9, Ui.TXT_HI);
            y += ui.s(20);
            if (gun) {
                y = row(ui, in, y, "Magazine", held.loadedRounds() + " / " + held.capacity(), held.loadedRounds() == 0 ? Ui.RED : Ui.TXT_HI);
                y = row(ui, in, y, "Reserve", String.valueOf(reserve(raid, held)), Ui.TXT);
                y = row(ui, in, y, "Fire mode", held.fireModeName(), Ui.TXT);
            }
            y = row(ui, in, y, "Condition", Math.round(held.condition()) + "%", held.condition() < 25 ? Ui.RED : held.condition() < 50 ? Ui.AMBER : Ui.GREEN);
        } else { ui.text("No weapon in hand", in.x, y, 12, Ui.TXT_DIM); y += ui.s(22); }
        y += ui.s(6);
        ui.b.rect(in.x, y, in.w, 1, 0x40FFFFFF);
        y += ui.s(8);
        // whatever else the body is carrying: only what is true right now
        var s = raid.body;
        y = meter(ui, in, y, "Stamina", s.stamina / 100f, 0xFFE0B830);
        y = meter(ui, in, y, "Focus", s.focus / 100f, 0xFF6AA4D6);
        y = meter(ui, in, y, "Food", s.energy / 100f, s.energy < 20 ? Ui.RED : 0xFFB8935A);
        y = meter(ui, in, y, "Water", s.hydration / 100f, s.hydration < 20 ? Ui.RED : 0xFF5AA0B8);
        List<String> flags = new ArrayList<>();
        if (s.bleedHeavy) flags.add("Heavy bleeding"); else if (s.bleedLight) flags.add("Bleeding");
        if (s.fracture) flags.add("Fracture");
        if (s.armInjury > 0.25f) flags.add("Arm wounded");
        if (s.legInjury > 0.25f) flags.add("Leg wounded");
        if (s.infection > 0) flags.add(InfectionSystem.stage(s.infection));
        if (s.rad > 5) flags.add("Radiation " + Math.round(s.rad));
        if (!flags.isEmpty() && y < in.b() - ui.s(16)) Layout.paragraph(ui, String.join("  -  ", flags), new Box(in.x, y + ui.s(4), in.w, in.b() - y - ui.s(4)), 11, 9, Ui.AMBER);
    }

    private float row(Ui ui, Box in, float y, String label, String value, int col) {
        ui.text(label, in.x, y, 11, Ui.TXT_DIM);
        float lw = ui.tw(label, 11) + ui.s(10);
        ui.textR(Layout.elide(ui, value, in.w - lw, 11), in.r(), y, 11, col);
        return y + ui.s(17);
    }

    private float meter(Ui ui, Box in, float y, String label, float f, int col) {
        ui.text(label, in.x, y, 10, Ui.TXT_DIM);
        float bx = in.x + ui.s(64), bw = in.w - ui.s(64);
        ui.b.rect(bx, y + ui.s(5), bw, ui.s(4), 0xFF1A1C1B);
        ui.b.rect(bx, y + ui.s(5), bw * Math.max(0, Math.min(1, f)), ui.s(4), col);
        return y + ui.s(15);
    }

    public void dispose() { portraits.clear(); }
}
