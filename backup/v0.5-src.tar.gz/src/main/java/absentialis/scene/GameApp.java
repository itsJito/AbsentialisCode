package absentialis.scene;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;

import absentialis.engine.Window;
import absentialis.engine.audio.AudioEngine;
import absentialis.engine.render.Atlas;
import absentialis.engine.render.Batch2D;
import absentialis.engine.render.Font;
import absentialis.engine.render.ModelRenderer;
import absentialis.engine.render.Screenshot;
import absentialis.engine.render.WorldRenderer;
import absentialis.entity.Actor;
import absentialis.gameplay.economy.Economy;
import absentialis.gameplay.inventory.InventoryService;
import absentialis.gameplay.items.Content;
import absentialis.gameplay.items.ItemInstance;
import absentialis.persistence.Profile;
import absentialis.persistence.SaveSystem;
import absentialis.persistence.Settings;
import absentialis.sim.ZoneState;
import absentialis.ui.InventoryUi;
import absentialis.ui.ItemIcons;
import absentialis.ui.MapView;
import absentialis.ui.Ui;
import absentialis.world.Block;
import absentialis.world.District;
import absentialis.world.MapData;
import absentialis.world.World;
import absentialis.world.gen.CityGenerator;
import java.util.ArrayList;
import java.util.List;

/**
 * Application shell: boots every service, generates the Zone in the background while the menus
 * run, and drives the TITLE -> PROFILES -> HIDEOUT <-> RAID -> DEBRIEF state machine with 120 ms
 * screen transitions. Also hosts the developer console and the ABS_AUTOSHOT capture script.
 */
public final class GameApp {
    private enum State { TITLE, PROFILES, CREATE, HIDEOUT, LOADING, RAID, DEBRIEF }

    private final Window win;
    private final Ctx c = new Ctx();
    private State state = State.TITLE;
    private HideoutScreen hideout;
    private RaidScreen raidScreen;
    private SettingsScreen settings;
    private boolean settingsOpen;
    private volatile String genStatus = "Waiting";
    private volatile boolean worldGenerated, worldDirty;
    private volatile Thread prepThread;
    private boolean renderReady;
    private float fade = 1;
    private List<String> debriefLines = new ArrayList<>();
    private Raid lastRaid;
    private final StringBuilder nameField = new StringBuilder();
    private int createSlot, createArm = 4, createSkin = 1, createOutfit;
    private final String autoshot = System.getenv("ABS_AUTOSHOT");
    private int shotFrame, perfFrames;
    private float perfTime, perfWorst;

    public GameApp(Window w) { this.win = w; }

    public void run() {
        init();
        long last = System.nanoTime();
        while (!win.shouldClose()) {
            long now = System.nanoTime();
            float dt = Math.min(0.05f, (now - last) / 1e9f);
            last = now;
            c.time += dt;
            win.poll();
            frame(dt);
            if (autoshot != null) { autoshotStep(); if (state == State.RAID) { perfFrames++; perfTime += dt; perfWorst = Math.max(perfWorst, dt); } }
            win.swap();
            c.in.endFrame();
        }
        if (c.hr != null && !c.hr.profile().isEmpty()) System.out.println(c.hr.profile());
        if (perfFrames > 0) System.out.printf("[Perf] raid frames %d, mean %.2f ms (%.0f fps), worst %.1f ms%n", perfFrames, perfTime / perfFrames * 1000, perfFrames / perfTime, perfWorst * 1000);
        if (c.profile != null && state != State.RAID) SaveSystem.save(c.profile);
        if (c.wr != null) c.wr.shutdown();
        if (c.hr != null) c.hr.dispose();
        if (c.audio != null) c.audio.stop();
    }

    // ------------------------------------------------------------------ boot
    private void init() {
        c.win = win;
        c.in = win.input;
        Content.load();
        c.settings = Settings.load(c.in);
        Batch2D b = new Batch2D();
        b.init();
        Font font = new Font(48);
        font.init();
        c.ui = new Ui(b, font, c.in);
        c.ui.init();
        c.icons = new ItemIcons();
        c.icons.init();
        c.inv = new InventoryUi(c.ui, c.icons);
        c.map = new MapView();
        c.console = new Console();
        c.mr = new ModelRenderer();
        c.mr.init();
        c.ar = new ActorRenderer(c.mr);
        c.audio = new AudioEngine();
        c.audio.buildBank();
        c.audio.start();
        c.settings.applyAudio(c.audio);
        c.ui.sound = c::ui;
        menuMusic(true);
        c.atlas = new Atlas();
        c.atlas.paintAll();
        c.atlas.upload();
        settings = new SettingsScreen(c);
        registerCommands();
        win.setCursorLocked(false);
        glfwSetInputMode(win.handle, GLFW_CURSOR, GLFW_CURSOR_HIDDEN);
        startWorldGeneration();
        if (autoshot != null) autoProfile();
    }

    private void startWorldGeneration() {
        Thread t = new Thread(() -> {
            try {
                World w = new World();
                new CityGenerator(w, 1337L, s -> genStatus = s).generate();
                genStatus = "Lighting the Zone";
                w.lighting.computeAll();
                w.snapshotPristine();
                c.world = w;
                worldGenerated = true;
                genStatus = "Ready";
            } catch (Throwable e) {
                e.printStackTrace();
                genStatus = "World generation failed: " + e;
            }
        }, "worldgen");
        t.setDaemon(true);
        t.start();
    }

    /** GL-side setup once the voxel data exists (main thread). */
    private void ensureRenderer() {
        if (renderReady || !worldGenerated) return;
        c.wr = new WorldRenderer(c.world, c.atlas);
        c.wr.init();
        java.util.Arrays.fill(c.world.dirtyColumns, true);
        c.world.anyDirty = true;
        c.wr.scheduleDirty();
        c.map.build(c.world);
        if (c.profile != null) c.map.rebuildHatch(c.profile.zone);
        if (win.gl45) {
            try {
                c.hr = new absentialis.engine.render.HybridRenderer();
                c.hr.init(c.world, c.atlas, win.width, win.height);
                c.settings.applyGraphics(c.hr, win);
                System.out.println("[Render] Hybrid GI renderer ready (deferred PBR, irradiance probes, compute culling)");
            } catch (Throwable t) {
                // a driver that advertises 4.5 but rejects a shader must not cost the player the game
                System.err.println("[Render] Hybrid renderer unavailable, using the legacy forward path: " + t);
                c.hr = null;
            }
        }
        renderReady = true;
    }

    /** Restores the pristine city and re-applies persistent world state before a deployment. */
    private void prepareWorldForRaid() {
        Profile p = c.profile;
        prepThread = new Thread(() -> {
            if (worldDirty) {
                genStatus = "Resetting the operational slice";
                c.world.restorePristine();
            }
            for (MapData.Point lp : c.world.map.lampsOnPower) {
                District d = c.world.district(lp.x, lp.z);
                int want = p.zone.power[d.ordinal()] || d == District.CIVIC ? Block.LAMP : Block.LAMP_OFF;
                int cur = c.world.get(lp.x, lp.y, lp.z);
                if (cur == Block.LAMP || cur == Block.LAMP_OFF) c.world.setRaw(lp.x, lp.y, lp.z, want);
            }
            genStatus = "Relighting";
            c.world.lighting.computeAll();
            c.world.scanFires();
            java.util.Arrays.fill(c.world.dirtyColumns, true);
            c.world.anyDirty = true;
            worldDirty = true;
            genStatus = "Meshing";
        }, "raid-prep");
        prepThread.setDaemon(true);
        prepThread.start();
    }

    // ------------------------------------------------------------------ frame
    private void frame(float dt) {
        ensureRenderer();
        if (c.wr != null && state != State.RAID) { c.wr.scheduleDirty(); c.wr.uploadResults(48); }
        c.ui.scale = c.settings.uiScale;
        if (c.in.keyPressed(GLFW_KEY_F12)) Screenshot.save(win.width, win.height, "screenshots/shot_" + System.currentTimeMillis() + ".png");
        if (state != State.RAID && c.in.keyPressed(GLFW_KEY_GRAVE_ACCENT)) c.console.toggle();
        if (state != State.RAID && c.console.open) c.console.input(c.in);
        switch (state) {
            case TITLE -> menuFrame(dt, this::title);
            case PROFILES -> menuFrame(dt, this::profiles);
            case CREATE -> menuFrame(dt, this::create);
            case HIDEOUT -> hideoutFrame(dt);
            case LOADING -> loadingFrame(dt);
            case RAID -> raidFrame(dt);
            case DEBRIEF -> menuFrame(dt, this::debrief);
        }
        fade = Math.max(0, fade - dt / Ui.EASE);
        if (fade > 0) {
            c.ui.b.begin(win.width, win.height);
            c.ui.b.rect(0, 0, win.width, win.height, Ui.alpha(0xFF000000, fade));
            c.ui.b.end();
        }
    }

    private void go(State s) { state = s; fade = 1; c.inv.drag = null; c.inv.menu.clear(); }

    private void menuFrame(float dt, Runnable body) {
        glViewport(0, 0, win.width, win.height);
        glClearColor(0.04f, 0.045f, 0.04f, 1);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        Ui ui = c.ui;
        ui.b.begin(win.width, win.height);
        ui.begin(dt, win.width, win.height);
        ui.showCursor = true;
        menuBackdrop(ui);
        if (settingsOpen) ui.block = true;
        body.run();
        ui.block = false;
        if (settingsOpen) { settings.draw(ui); if (settings.close) { settings.close = false; settingsOpen = false; } }
        c.console.draw(ui, dt);
        ui.end();
        ui.b.end();
    }

    private void menuBackdrop(Ui ui) {
        // slow drifting voxel skyline silhouette in pixel blocks
        int px = Math.max(4, ui.s(6));
        for (int x = 0; x < ui.w; x += px) {
            int hgt = (int) (ui.h * 0.18f + Math.abs(Math.sin(x * 0.013 + 1) * 90 + Math.sin(x * 0.051) * 40) * ui.scale);
            hgt = hgt / px * px;
            ui.b.rect(x, ui.h - hgt, px, hgt, 0xFF0C0E0C);
            if (((x / px) * 7 + (int) (c.time * 0.2)) % 23 == 0) ui.b.rect(x, ui.h - hgt + px * 3, px, px, 0xFF6A5420);
        }
        ui.b.rect(0, ui.h - ui.s(3), ui.w, ui.s(3), 0xFF8A6420);
    }

    // ------------------------------------------------------------------ title & profiles
    private void title() {
        Ui ui = c.ui;
        float cx = ui.w / 2f;
        ui.textC("ABSENTIALIS", cx, ui.h * 0.16f, 64, Ui.TXT_HI);
        ui.textC("A PERSISTENT VOXEL EXTRACTION SURVIVAL", cx, ui.h * 0.16f + ui.s(76), 14, Ui.AMBER);
        ui.textC(absentialis.Version.LABEL.toUpperCase(), cx, ui.h * 0.16f + ui.s(100), 13, Ui.TXT_DIM);
        if (ironLost != null) {
            ui.textC("IRONMAN  -  " + ironLost + " died in the Zone. The profile has been deleted.", cx, ui.h * 0.16f + ui.s(132), 14, Ui.RED);
        }
        ui.textR(absentialis.Version.LABEL, ui.w - ui.s(12), ui.h - ui.s(22), 12, Ui.TXT_DIM);
        float bw = ui.s(320), bh = ui.s(48), y = ui.h * 0.42f;
        int last = lastProfile();
        if (ui.button("t_continue", cx - bw / 2, y, bw, bh, last >= 0 ? "CONTINUE  (" + SaveSystem.summary(last)[0] + ")" : "CONTINUE", "arrow", last >= 0)) { loadProfile(last); }
        if (ui.button("t_profiles", cx - bw / 2, y + bh + ui.s(10), bw, bh, "SURVIVOR PROFILES", "inv", true)) { ironLost = null; go(State.PROFILES); }
        if (ui.button("t_settings", cx - bw / 2, y + (bh + ui.s(10)) * 2, bw, bh, "SETTINGS", "cog", true)) settingsOpen = true;
        if (ui.button("t_quit", cx - bw / 2, y + (bh + ui.s(10)) * 3, bw, bh, "QUIT", "cross", true)) win.requestClose();
        // audio health, in plain sight: which device, and whether Windows had the game turned down to nothing
        if (c.audio != null) ui.text(c.audio.status, ui.s(12), ui.h - ui.s(22), 11, c.audio.repaired ? Ui.AMBER : !c.audio.available || c.audio.session.silenced() ? Ui.RED : Ui.TXT_DIM);
        ui.textC(worldGenerated ? (renderReady && c.wr.busy() ? "Meshing the city... " + c.wr.pending.get() : "The Zone is ready.") : "Generating the Zone: " + genStatus + "...", cx, ui.h - ui.s(48), 12, Ui.TXT_DIM);
    }

    private int lastProfile() { for (int i = 0; i < SaveSystem.SLOTS; i++) if (SaveSystem.exists(i)) return i; return -1; }

    private final String[][] summaries = new String[SaveSystem.SLOTS][];
    private float summaryAge = 99;

    private void profiles() {
        Ui ui = c.ui;
        summaryAge += ui.dt;
        if (summaryAge > 2) { for (int i = 0; i < SaveSystem.SLOTS; i++) summaries[i] = SaveSystem.summary(i); summaryAge = 0; }
        float w = ui.s(860), h = ui.s(520), x = (ui.w - w) / 2, y = (ui.h - h) / 2;
        float cy = ui.window("Survivor Profiles  (4 isolated slots)", "inv", x, y, w, h);
        for (int i = 0; i < SaveSystem.SLOTS; i++) {
            float ry = cy + i * ui.s(96);
            ui.nine("slot", x + ui.s(20), ry, w - ui.s(40), ui.s(86), 0xFFFFFFFF);
            String[] s = summaries[i];
            if (s == null) {
                ui.text("SLOT " + (i + 1) + "  -  empty", x + ui.s(40), ry + ui.s(30), 16, Ui.TXT_DIM);
                if (ui.button("p_new" + i, x + w - ui.s(220), ry + ui.s(22), ui.s(180), ui.s(42), "NEW SURVIVOR", "star", true)) { createSlot = i; nameField.setLength(0); createIronman = false; go(State.CREATE); }
            } else {
                ui.text(s[0], x + ui.s(40), ry + ui.s(14), 20, Ui.TXT_HI);
                ui.text(s[1] + "   -   " + s[2] + "   -   " + s[3], x + ui.s(40), ry + ui.s(46), 13, Ui.TXT);
                if (ui.button("p_load" + i, x + w - ui.s(330), ry + ui.s(22), ui.s(150), ui.s(42), "PLAY", "arrow", true)) loadProfile(i);
                if (ui.button("p_del" + i, x + w - ui.s(170), ry + ui.s(22), ui.s(130), ui.s(42), ui.shift ? "CONFIRM" : "DELETE", "cross", true)) {
                    if (ui.shift) { SaveSystem.delete(i); summaryAge = 99; } else c.inv.say("Hold Shift and click DELETE to erase this profile", Ui.AMBER);
                }
            }
        }
        if (ui.button("p_back", x + ui.s(20), y + h - ui.s(60), ui.s(160), ui.s(42), "BACK", "arrow", true) || c.in.keyPressed(GLFW_KEY_ESCAPE)) go(State.TITLE);
        c.inv.flashTime -= ui.dt;
        if (c.inv.flashTime > 0) ui.textC(c.inv.flash, ui.w / 2f, y + h + ui.s(12), 14, c.inv.flashColor);
    }

    private CharacterCreator creator;
    private boolean createIronman;
    private absentialis.character.Appearance createApp = absentialis.character.Appearance.legacy(1, 0);
    private AudioEngine.Voice menuMusic;

    private void menuMusic(boolean on) {
        if (c.audio == null) return;
        if (on && menuMusic == null) menuMusic = c.audio.loop("music_hideout", 1.6f, AudioEngine.MUSIC);
        if (!on && menuMusic != null) { menuMusic.fadeTo(0, 2.5f); menuMusic = null; }
    }

    private void create() {
        Ui ui = c.ui;
        while (!c.in.typed.isEmpty()) { char ch = c.in.typed.poll(); if (nameField.length() < 18 && ch >= 32 && ch < 127) nameField.append(ch); }
        if (c.in.keyPressed(GLFW_KEY_BACKSPACE) && nameField.length() > 0) nameField.setLength(nameField.length() - 1);
        float w = Math.min(ui.w - ui.s(40), ui.s(1100)), h = Math.min(ui.h - ui.s(40), ui.s(760)), x = (ui.w - w) / 2, y = (ui.h - h) / 2;
        float cy = ui.window("New Survivor  -  Slot " + (createSlot + 1), "star", x, y, w, h);
        ui.text("CALLSIGN", x + ui.s(24), cy, 13, Ui.TXT_HI);
        ui.nine("slot", x + ui.s(24), cy + ui.s(20), ui.s(360), ui.s(40), 0xFFFFFFFF);
        ui.text(nameField + ((System.currentTimeMillis() / 450) % 2 == 0 ? "_" : ""), x + ui.s(36), cy + ui.s(30), 18, Ui.AMBER);
        // Ironman is a choice made once, here: one life, and death deletes the profile
        createIronman = ui.toggle("c_iron", x + ui.s(420), cy + ui.s(24), ui.s(200), "IRONMAN", createIronman);
        ui.wrap(createIronman ? "One life. When this survivor dies the profile is deleted - no respawn, no second chance." : "Standard: dying costs what you carried in; you respawn at the hideout.", x + ui.s(640), cy + ui.s(20), w - ui.s(680), 11, createIronman ? Ui.RED : Ui.TXT_DIM);
        cy += ui.s(80);
        if (creator == null) creator = new CharacterCreator(c);
        creator.draw(ui, createApp, null, x + ui.s(24), cy, w - ui.s(48), h - (cy - y) - ui.s(84));
        boolean ok = nameField.toString().trim().length() >= 2;
        if (ui.button("c_go", x + ui.s(24), y + h - ui.s(64), ui.s(260), ui.s(44), "ENTER THE ZONE", "arrow", ok) || ok && c.in.keyPressed(GLFW_KEY_ENTER)) {
            Profile p = new Profile();
            p.slot = createSlot;
            p.name = nameField.toString().trim();
            p.appearance = createApp.copy();
            p.ironman = createIronman;
            p.seed = 1337L;
            p.starterKit();
            p.contracts.refill(p.seed, 1);
            SaveSystem.save(p);
            loadProfile(createSlot);
        }
        if (ui.button("c_back", x + w - ui.s(184), y + h - ui.s(64), ui.s(160), ui.s(44), "BACK", "cross", true) || c.in.keyPressed(GLFW_KEY_ESCAPE)) go(State.PROFILES);
    }

    private void loadProfile(int slot) {
        Profile p = SaveSystem.load(slot);
        if (p == null) return;
        c.profile = p;
        String err = p.verify();
        if (err != null) System.err.println("[Profile] integrity warning: " + err);
        InventoryService.listener = null;
        hideout = new HideoutScreen(c);
        hideout.enter();
        go(State.HIDEOUT);
    }

    // ------------------------------------------------------------------ hideout
    private void hideoutFrame(float dt) {
        if (settingsOpen) { menuFrame(dt, () -> {}); return; }
        hideout.render(dt);
        String a = hideout.action;
        hideout.action = null;
        if ("settings".equals(a)) settingsOpen = true;
        else if ("title".equals(a)) go(State.TITLE);
        else if ("deploy".equals(a)) deploy(hideout.deployInsertion, hideout.deployMinutes);
    }

    private int pendingInsertion;
    private float pendingMinutes;

    private void deploy(int insertion, float minutes) {
        if (!worldGenerated) return;
        pendingInsertion = insertion;
        pendingMinutes = minutes;
        prepareWorldForRaid();
        lightReady = 0; lightWait = 0;
        go(State.LOADING);
    }

    private float lightReady, lightWait;
    private final WorldRenderer.Env loadEnv = new WorldRenderer.Env();

    /** Lights the irradiance probes around the insertion before the raid begins, so the first frame is already lit. */
    private boolean prelight(float dt) {
        if (c.hr == null) return true;
        MapData.Point ins = c.world.map.insertions.get(Math.floorMod(pendingInsertion, c.world.map.insertions.size()));
        double h = c.profile.zone.hour;
        double sa = (h % 24 - 6) / 12.0 * Math.PI;
        loadEnv.daylight = ZoneState.daylightAt(h);
        loadEnv.sunX = (float) Math.cos(sa) * 0.8f; loadEnv.sunY = (float) Math.sin(sa); loadEnv.sunZ = 0.35f;
        District d = c.world.district(ins.x, ins.z);
        float nightK = 0.12f + 0.88f * loadEnv.daylight;
        loadEnv.fogR = d.fogR * nightK; loadEnv.fogG = d.fogG * nightK; loadEnv.fogB = d.fogB * nightK;
        loadEnv.rain = c.profile.zone.weatherRain > 0.5f ? (c.profile.zone.weatherRain - 0.5f) * 2 : 0;
        lightReady = c.hr.prepare(c.wr, loadEnv, ins.x, ins.z, 192);
        lightWait += dt;
        return lightReady >= 0.92f || lightWait > 25;
    }

    private void loadingFrame(float dt) {
        boolean prepDone = prepThread == null || !prepThread.isAlive();
        if (prepDone && c.wr != null) { c.wr.scheduleDirty(); c.wr.uploadResults(0); }
        boolean meshed = prepDone && c.wr != null && !c.wr.busy();
        boolean lit = meshed && prelight(dt);
        menuFrame(dt, () -> {
            Ui ui = c.ui;
            ui.textC("DEPLOYING", ui.w / 2f, ui.h * 0.38f, 36, Ui.TXT_HI);
            String s = !prepDone ? genStatus : !meshed ? "Meshing the city (" + (c.wr == null ? "?" : c.wr.pending.get()) + " columns left)" : "Lighting the insertion area (" + Math.round(lightReady * 100) + "%)";
            float bw = ui.s(360), bx = ui.w / 2f - bw / 2, by = ui.h * 0.38f + ui.s(84);
            ui.b.rect(bx, by, bw, ui.s(6), 0xFF1A1C1B);
            ui.b.rect(bx, by, bw * (!prepDone ? 0.15f : !meshed ? 0.45f : 0.5f + 0.5f * lightReady), ui.s(6), Ui.AMBER);
            ui.textC(s, ui.w / 2f, ui.h * 0.38f + ui.s(56), 14, Ui.TXT_DIM);
            String[] tips = {"Sound carries. Sprinting on metal is heard a block away; crouching on carpet is not.", "A tactical reload keeps the chambered round. Double-tap R to drop the magazine and go faster.",
                    "Weapons under 50 condition jam. Under 25 they need a workbench.", "Faction hostility needs evidence. Unwitnessed is not forgiven - only unknown.",
                    "Treasures and keys take no case space. Combine treasures for value.", "Missing extraction is a failed raid. Watch the clock: amber at 10:00, red at 3:00."};
            ui.textC(tips[(int) (c.time / 6) % tips.length], ui.w / 2f, ui.h * 0.62f, 14, Ui.AMBER);
        });
        if (lit) startRaid();
    }

    private void startRaid() {
        Profile p = c.profile;
        c.bus.clear();
        Raid r = new Raid(c.world, p, c.settings, c.bus, pendingInsertion, pendingMinutes);
        c.map.rebuildHatch(p.zone);
        raidScreen = new RaidScreen(c, r);
        lastRaid = r;
        menuMusic(false);
        go(State.RAID);
    }

    private void raidFrame(float dt) {
        if (settingsOpen) { win.setCursorLocked(false); menuFrame(dt, () -> {}); if (!settingsOpen) raidScreen.paused = true; return; }
        raidScreen.update(dt);
        raidScreen.render(dt);
        if ("settings".equals(raidScreen.pauseAction)) { raidScreen.pauseAction = null; settingsOpen = true; }
        if ("quit".equals(raidScreen.pauseAction)) { raidScreen.raid.debrief.outcome = Raid.Debrief.Outcome.MIA; raidScreen.raid.debrief.reason = "Left the Zone (quit)"; endRaid(); win.requestClose(); return; }
        if (raidScreen.done) endRaid();
    }

    /** Callsign of an Ironman survivor who has just been lost (shown once on the title screen). */
    private String ironLost;

    private void endRaid() {
        raidScreen.stopAudio();
        win.setCursorLocked(false);
        Raid r = raidScreen.raid;
        String choice = raidScreen.deathChoice;
        boolean killed = r.debrief.outcome == Raid.Debrief.Outcome.KILLED;
        debriefLines = RaidResolver.resolve(r);
        // Ironman: one life. The profile and its backup are deleted the moment the death resolves.
        boolean ironDeath = killed && c.profile.ironman;
        if (ironDeath) {
            ironLost = c.profile.name;
            SaveSystem.delete(c.profile.slot);
            c.profile = null;
            hideout = null;
            summaryAge = 99;
        } else SaveSystem.save(c.profile);
        menuMusic(true);
        if (r.debrief.outcome == Raid.Debrief.Outcome.EXTRACTED) c.sfx("extract_done", 0.6f);
        if ("quit".equals(choice)) { win.requestClose(); return; }
        if (ironDeath || "menu".equals(choice)) { go(State.TITLE); return; }
        go(State.DEBRIEF);
    }

    private void debrief() {
        Ui ui = c.ui;
        Raid.Debrief d = lastRaid.debrief;
        boolean ok = d.outcome == Raid.Debrief.Outcome.EXTRACTED;
        float w = Math.min(ui.w - ui.s(40), ui.s(980)), h = ui.h - ui.s(80), x = (ui.w - w) / 2, y = ui.s(40);
        float cy = ui.window("Debrief", ok ? "flag" : "skull", x, y, w, h);
        int col = ok ? Ui.GREEN : d.outcome == Raid.Debrief.Outcome.MIA ? Ui.AMBER : Ui.RED;
        ui.text(ok ? "EXTRACTED" : d.outcome == Raid.Debrief.Outcome.MIA ? "MISSING IN ACTION" : "KILLED IN ACTION", x + ui.s(24), cy, 32, col);
        ui.text(d.reason + String.format("   -   %d:%02d in the Zone", (int) lastRaid.time / 60, (int) lastRaid.time % 60), x + ui.s(24), cy + ui.s(42), 14, Ui.TXT);
        cy += ui.s(80);
        float colW = (w - ui.s(72)) / 2;
        ui.text("EXPERIENCE", x + ui.s(24), cy, 14, Ui.TXT_HI);
        float ly = cy + ui.s(24);
        for (String[] xp : d.xp) { ui.text(xp[0], x + ui.s(24), ly, 13, Ui.TXT); ui.textR("+" + xp[1], x + ui.s(24) + colW, ly, 13, Ui.AMBER); ly += ui.s(20); }
        ly += ui.s(8);
        ui.text(String.format("Shots %d  -  hits %d  -  containers %d  -  noise %.0f", d.shotsFired, d.hits, d.containersSearched, d.noise), x + ui.s(24), ly, 12, Ui.TXT_DIM);
        ly += ui.s(26);
        ui.text(c.profile.prog.title() + "  -  " + absentialis.Version.coins(c.profile.scrip), x + ui.s(24), ly, 16, Ui.TXT_HI);
        ui.bar(x + ui.s(24), ly + ui.s(26), colW, ui.s(10), c.profile.prog.rankProgress(), 0xFFE2A034);
        float rx = x + ui.s(48) + colW;
        ui.text("CONSEQUENCES", rx, cy, 14, Ui.TXT_HI);
        float ry = cy + ui.s(24);
        for (String l : debriefLines) {
            if (ry > y + h - ui.s(90)) break;
            ry += ui.wrap("- " + l, rx, ry, colW, 13, l.startsWith("NEWS") ? Ui.AMBER : l.startsWith("Lost") ? Ui.RED : Ui.TXT) + ui.s(4);
        }
        if (ui.button("d_cont", x + w - ui.s(300), y + h - ui.s(64), ui.s(276), ui.s(44), ok ? "RETURN TO HIDEOUT" : "RESPAWN AT THE HIDEOUT", "arrow", true) || c.in.keyPressed(GLFW_KEY_ENTER)) {
            hideout.enter();
            go(State.HIDEOUT);
        }
    }

    // ------------------------------------------------------------------ console
    private Raid raid() { return state == State.RAID && raidScreen != null ? raidScreen.raid : null; }

    private void registerCommands() {
        Console k = c.console;
        k.register("help", "list commands", a -> k.help(), null);
        k.register("god", "toggle invulnerability", a -> { Raid r = raid(); if (r == null) return "Only in a raid"; r.god = !r.god; return "god " + (r.god ? "ON" : "OFF"); }, null);
        k.register("noclip", "toggle noclip flight", a -> { Raid r = raid(); if (r == null) return "Only in a raid"; r.noclip = !r.noclip; return "noclip " + (r.noclip ? "ON" : "OFF"); }, null);
        k.register("thirdperson", "toggle third-person camera", a -> { if (raidScreen == null) return "Only in a raid"; raidScreen.thirdPerson = !raidScreen.thirdPerson; return "third person " + raidScreen.thirdPerson; }, null);
        k.register("give", "give <itemId> [qty] - creates a new instance in your case (or stash)", a -> {
            if (c.profile == null) return "No profile loaded";
            if (a.length < 2 || Content.def(a[1]) == null) return "Unknown item. Tab completes ids.";
            ItemInstance it = new ItemInstance(a[1]);
            it.qty = a.length > 2 ? Math.max(1, Math.min(it.def().maxStack, Integer.parseInt(a[2]))) : 1;
            it.origin = "console";
            if (it.def().weapon != null && !it.def().weapon.melee()) { it.rounds = it.capacity(); it.ammoId = Content.ammoFor(it.def().weapon.caliber).id; }
            var res = state == State.RAID ? InventoryService.store(it, c.profile.loadout) : InventoryService.add(it, c.profile.stash);
            return res.ok() ? "Gave " + it : res.msg();
        }, i -> i == 0 ? new ArrayList<>(Content.ITEMS.keySet()) : null);
        k.register("tp", "tp <district|exit id> - teleport", a -> {
            Raid r = raid();
            if (r == null || a.length < 2) return "Usage in raid: tp <district|exit>";
            for (MapData.Exit e : c.world.map.exits) if (e.id.equalsIgnoreCase(a[1])) { place(r, e.x + 0.5f, e.y, e.z + 2.5f); return "Teleported to " + e.name; }
            District d = District.byName(a[1]);
            if (d == null) return "Unknown destination";
            for (MapData.Point p : c.world.map.insertions) if (p.district == d) { place(r, p.x + 0.5f, p.y, p.z + 0.5f); return "Teleported to " + p.name; }
            for (MapData.Node n : c.world.map.nodes) if (n.district == d) { place(r, n.x + 0.5f, n.y, n.z + 0.5f); return "Teleported to " + d.display; }
            return "No spot found";
        }, i -> { List<String> l = new ArrayList<>(); for (District d : District.values()) l.add(d.name().toLowerCase()); if (c.world != null) for (MapData.Exit e : c.world.map.exits) l.add(e.id); return l; });
        k.register("setrep", "setrep <faction> <value>", a -> { if (c.profile == null || a.length < 3) return "Usage: setrep <faction> <value>"; c.profile.rep.put(a[1], Float.parseFloat(a[2])); return a[1] + " = " + a[2]; }, i -> i == 0 ? List.of(ZoneState.FACTIONS) : null);
        k.register("econ", "econ audit [graph] - verify no buy/sell loop, show price curves", a -> {
            if (c.profile == null) return "No profile";
            StringBuilder b = new StringBuilder(Economy.audit(c.profile.zone, c.profile.rep));
            if (a.length > 2 && "graph".equals(a[2])) {
                b.append("\nSale saturation (repeated sales of one item):");
                ItemInstance probe = new ItemInstance(-1, "val.watch");
                for (int s = 0; s <= 10; s += 2) {
                    int v = Economy.sellPrice(probe, Economy.trader("mara"), c.profile.zone, 0, s);
                    b.append("\n  sale ").append(s).append(": ").append(v).append(" ").append("#".repeat(Math.max(1, v / 4)));
                }
            }
            return b.toString();
        }, i -> i == 0 ? List.of("audit") : i == 1 ? List.of("graph") : null);
        k.register("skip", "skip hour [n] - advance the strategic world clock", a -> {
            if (c.profile == null) return "No profile";
            int n = a.length > 2 ? Integer.parseInt(a[2]) : 1;
            String[] before = c.profile.zone.controllers();
            c.profile.zone.advance(n, c.profile.seed);
            c.profile.zone.announceFlips(before);
            if (c.map.ready()) c.map.rebuildHatch(c.profile.zone);
            return "Advanced " + n + "h -> day " + c.profile.zone.day + " " + (int) c.profile.zone.hour + ":00";
        }, i -> i == 0 ? List.of("hour") : null);
        k.register("ai", "ai debug - toggle AI state overlay", a -> { Raid r = raid(); if (r == null) return "Only in a raid"; r.aiDebug = !r.aiDebug; return "AI debug " + r.aiDebug; }, i -> i == 0 ? List.of("debug") : null);
        k.register("noise", "noise debug - show sound propagation rings", a -> { Raid r = raid(); if (r == null) return "Only in a raid"; r.noiseDebug = !r.noiseDebug; return "noise debug " + r.noiseDebug; }, i -> i == 0 ? List.of("debug") : null);
        k.register("save", "save the profile now", a -> { if (c.profile == null) return "No profile"; if (state == State.RAID) return "Saving is disabled mid-raid (raid state resolves on exit)"; SaveSystem.save(c.profile); return "Saved slot " + c.profile.slot; }, null);
        k.register("load", "reload the profile from disk", a -> { if (c.profile == null || state == State.RAID) return "Not available"; loadProfile(c.profile.slot); return "Loaded"; }, null);
        k.register("xp", "xp <amount> - grant XP", a -> { if (c.profile == null) return "No profile"; int r = c.profile.prog.addXp(Long.parseLong(a[1])); return "Rank " + c.profile.prog.rank() + (r > 0 ? " (+" + r + ")" : ""); }, null);
        k.register("heal", "full heal (raid) / health (hideout)", a -> { Raid r = raid(); if (r != null) { r.player.hp = 100; r.body.bleedHeavy = r.body.bleedLight = r.body.fracture = false; } else if (c.profile != null) c.profile.health = 100; return "Healed"; }, null);
        k.register("extract", "force a successful extraction", a -> { Raid r = raid(); if (r == null) return "Only in a raid"; r.debrief.outcome = Raid.Debrief.Outcome.EXTRACTED; r.debrief.exitName = "Console"; r.debrief.reason = "Extracted (console)"; return "Extracting"; }, null);
        k.register("time", "time <minutesLeft> - set the raid clock", a -> { Raid r = raid(); if (r == null) return "Only in a raid"; r.duration = r.time + Float.parseFloat(a[1]) * 60; return "Clock set"; }, null);
        k.register("spawn", "spawn <archetype|faction> - spawn an infected archetype or a faction member 12m ahead", a -> {
            Raid r = raid();
            if (r == null || a.length < 2) return "Only in a raid";
            float x = r.player.x - (float) Math.sin(r.player.yaw) * 12, z = r.player.z - (float) Math.cos(r.player.yaw) * 12;
            Actor sp = r.debugSpawn(a[1], x, z, r.player.y);
            return "Spawned " + (sp.infected() ? absentialis.ai.Brain.displayName(sp.archetype) + " infected" : ZoneState.cap(sp.faction) + " " + sp.archetype);
        }, i -> { List<String> l = new ArrayList<>(); for (var ar : absentialis.ai.Brain.ARCHS) if (ar.infected()) l.add(ar.id()); l.addAll(List.of(ZoneState.FACTIONS)); return l; });
        k.register("freeze", "toggle AI decisions (bodies and animation keep running)", a -> { Raid r = raid(); if (r == null) return "Only in a raid"; r.freezeAI = !r.freezeAI; return "AI " + (r.freezeAI ? "frozen" : "running"); }, null);
        k.register("alife", "alife [log] - strategic squads and the off-screen event log", a -> {
            if (c.profile == null) return "No profile";
            StringBuilder sb = new StringBuilder();
            for (var sq : c.profile.zone.squads) sb.append(String.format("#%d %s x%d in %s -> %s%n", sq.id, ZoneState.cap(sq.faction), sq.size, District.values()[sq.district].display, District.values()[sq.goal].display));
            for (int i = 0; i < Math.min(10, c.profile.zone.log.size()); i++) { var e = c.profile.zone.log.get(i); sb.append(String.format("  d%d %02d:00 [%s] %s%n", e.day(), e.hour(), e.type(), e.text())); }
            Raid r = raid();
            if (r != null) sb.append("raid: noise events ").append(r.noiseEvents).append(", migrations ").append(r.migrations).append(", dispatches ").append(r.dispatches).append(", evidence ").append(r.evidence.size());
            return sb.length() == 0 ? "No strategic state yet - skip hour to advance" : sb.toString().trim();
        }, i -> i == 0 ? List.of("log") : null);
        k.register("selftest", "run the quality gates now", a -> { int f = absentialis.tools.SelfTests.runHeadless("all"); return f == 0 ? "All gates passed" : f + " gate(s) FAILED - see stdout"; }, null);
        k.print("ABSENTIALIS console. Type 'help'. Tab autocompletes.");
    }

    private static void place(Raid r, float x, float y, float z) { r.player.x = x; r.player.y = y + 0.1f; r.player.z = z; r.player.vy = 0; }

    // ------------------------------------------------------------------ autoshot (scripted visual verification)
    private void autoProfile() {
        Profile p = new Profile();
        p.slot = 3;
        p.name = "Autoshot";
        p.starterKit();
        p.contracts.refill(p.seed, 1);
        p.scrip += 60000;
        p.garage.add("car.kolos");
        p.deployVehicle = "car.kolos";
        SaveSystem.save(p);
    }

    private void autoshotStep() {
        shotFrame++;
        String dir = autoshot;
        switch (state) {
            case TITLE -> { if (shotFrame == 20) shot(dir, "01_title"); if (shotFrame > 25 && worldGenerated) loadProfile(3); }
            case HIDEOUT -> {
                int f = shotFrame;
                if (hideoutT == 0) { hideoutT = f; equipForAuto(); }
                int rel = f - hideoutT;
                int nt = HideoutScreen.TABS.length;
                for (int t = 0; t < nt; t++) if (rel == 10 + t * 12) { hideout.tab = t; }
                for (int t = 0; t < nt; t++) if (rel == 20 + t * 12) shot(dir, "02_hideout_" + HideoutScreen.TABS[t].toLowerCase());
                if (rel == 24 + nt * 12) hideout.debugShow(7, false);
                if (rel == 34 + nt * 12) shot(dir, "02b_shop_vehicles");
                if (rel == 36 + nt * 12) hideout.debugShow(-1, true);
                if (rel == 46 + nt * 12) shot(dir, "02c_operation_briefing");
                if (rel == 48 + nt * 12) hideout.debugShow(-1, false);
                if (rel >= 52 + nt * 12 && renderReady && raidT == 0 && state == State.HIDEOUT && !deployed) { deployed = true; deploy(0, 30); }
            }
            case RAID -> {
                if (raidT == 0) raidT = shotFrame;
                int rel = shotFrame - raidT;
                Raid r = raidScreen.raid;
                var in = c.in;
                if (rel == 1) stageSpot(r.world);
                if (tour >= 0) { raidT++; tourStep(r, dir); break; }
                int fire = absentialis.engine.Input.MOUSE_OFFSET + GLFW_MOUSE_BUTTON_LEFT;
                // staged on an open stretch of street found in the generated city: one of everyone in a line-up, AI frozen so they hold the pose
                if (rel == 3) { r.freezeAI = true; r.god = true; place(r, sx, World.GROUND, sz); r.player.yaw = 0; r.player.pitch = 0; }
                if (rel == 6) {
                    String[] cast = {"military", "mercenaries", "raiders", "survivors", "walker", "sprinter", "boomer", "tank"};
                    for (int i = 0; i < cast.length; i++) { Actor a = r.debugSpawn(cast[i], sx - 7f + i * 1.5f, sz - 8f - (i >= 4 ? 2 : 0), World.GROUND); a.yaw = (float) Math.PI; a.homeX = a.x; a.homeZ = a.z; lineup.add(a); }
                }
                if (rel == 40) shot(dir, "03_raid_start");
                if (rel == 44) r.player.pitch = -1.25f;
                if (rel == 56) shot(dir, "03b_first_person_legs");
                if (rel == 58) { r.player.pitch = 0; raidScreen.thirdPerson = true; }
                if (rel == 80) shot(dir, "06_raid_thirdperson");
                if (rel == 82) in.inject(GLFW_KEY_W, true);
                if (rel == 104) shot(dir, "06b_thirdperson_walk");
                if (rel == 106) { in.inject(GLFW_KEY_W, false); raidScreen.thirdPerson = false; place(r, sx, World.GROUND, sz); }
                if (rel >= 112 && rel < 116) in.inject(fire, rel % 2 == 1);
                if (rel == 116) { shot(dir, "05_firing"); in.inject(fire, false); }
                if (rel == 120) in.inject(GLFW_KEY_R, true);
                if (rel == 121) in.inject(GLFW_KEY_R, false);
                if (rel == 150) shot(dir, "05b_reload");
                if (rel == 200) { for (int i = 0; i < 4 && i < lineup.size(); i++) r.damageActor(lineup.get(i), r.player, 500, absentialis.gameplay.items.Content.def("ammo.rifle"), i % 2 == 0 ? "torso" : "head", lineup.get(i).x, lineup.get(i).y + 1, lineup.get(i).z); }
                if (rel == 212) shot(dir, "10a_ragdoll_falling");
                if (rel == 290) shot(dir, "10b_ragdoll_settled");
                if (rel == 292) in.inject(GLFW_KEY_TAB, true);
                if (rel == 312) shot(dir, "07_weapon_wheel");
                if (rel == 313) in.inject(GLFW_KEY_TAB, false);
                if (rel == 320) { if (!raidScreen.debugOpenNearestContainer(25)) raidScreen.invOpen = true; }
                if (rel == 340) shot(dir, "08_inventory_loot");
                if (rel == 345) { in.inject(GLFW_KEY_I, true); }
                if (rel == 346) { in.inject(GLFW_KEY_I, false); raidScreen.invOpen = false; raidScreen.mapOpen = true; }
                if (rel == 365) shot(dir, "09_map");
                if (rel == 370) { raidScreen.mapOpen = false; tour = 0; }
                if (rel == 372) { place(r, sx, World.GROUND, sz); r.player.yaw = 0; r.player.pitch = 0; }
                if (rel == 405) { c.console.exec("time 2.5"); r.player.pitch = 0; r.player.hp = 60; r.body.healthChanged = r.time; r.body.staminaChanged = r.time; r.body.stamina = 40; }
                if (rel == 425) shot(dir, "11_hud_red_timer");
                // v0.4: a fire at night, then the vehicle brought in from the garage - outside, inside, and on the move
                if (rel == 430) { c.console.exec("time 22"); place(r, sx, World.GROUND, sz); r.player.yaw = 0; r.player.pitch = 0; r.fire.ignite(sx, World.GROUND, sz - 5f, 1.2f, 60, 0, 0); r.fire.ignite(sx - 3f, World.GROUND, sz - 7f, 0.6f, 60, 0, 0); }
                if (rel == 480) shot(dir, "15_fire_night");
                if (rel == 482) {
                    c.console.exec("time 12");
                    r.fire.clear();
                    VehicleSystem.Car car = null;
                    for (VehicleSystem.Car v : r.vehicles.cars) if (v.owned) car = v;
                    if (car == null) car = r.vehicles.spawn("car.kolos", sx, World.GROUND, sz - 20f, 0f, 3);
                    if (car != null) { car.sim.place(sx, World.GROUND, sz - 20f, 0f); car.sim.wake(); }
                    place(r, sx - 4.5f, World.GROUND, sz - 13.5f); r.player.yaw = -0.6f;
                }
                if (rel == 510) shot(dir, "16_vehicle");
                if (rel == 512) { place(r, sx - 2f, World.GROUND, sz - 20f); }
                if (rel == 516) r.vehicles.enter();
                if (rel == 570) shot(dir, "17_vehicle_driver_seat");
                if (rel == 572) in.inject(GLFW_KEY_W, true);
                if (rel == 600) in.inject(GLFW_KEY_D, true);
                if (rel == 612) { shot(dir, "18_vehicle_driving"); c.settings.vehicleDebug = true; }
                if (rel == 613) raidScreen.thirdPerson = false;
                if (rel == 616) { shot(dir, "18b_vehicle_cockpit_debug"); c.settings.vehicleDebug = false; in.inject(GLFW_KEY_W, false); in.inject(GLFW_KEY_D, false); raidScreen.thirdPerson = true; }
                if (rel == 618) r.vehicles.exit();
                // v0.3: a live contact for the squad (torches, gore, severed limbs), then the player's death sequence
                if (rel == 628) {
                    c.console.exec("time 25");
                    r.freezeAI = false;
                    place(r, sx, World.GROUND, sz); r.player.yaw = 0; r.player.pitch = 0;
                    for (Actor m : r.mates) { m.x = sx - 2f + r.mates.indexOf(m) * 1.5f; m.z = sz + 3f; m.y = World.GROUND; }
                    for (int i = 0; i < 3; i++) { Actor e = r.debugSpawn("raiders", sx - 4f + i * 4f, sz - 18f, World.GROUND); e.hostileToPlayer = true; e.yaw = (float) Math.PI; if (i == 0) r.gore.sever(e, Gore.ARM_L, 0, 1, 4); }
                }
                if (rel == 760) shot(dir, "13_squad_contact");
                if (rel == 764) { r.god = false; r.player.hp = 0; }
                if (rel == 840) shot(dir, "14_death_cam");
                if (rel == 1210) shot(dir, "14b_death_menu");
                if (rel == 1214) raidScreen.chooseDeath("respawn");
            }
            case DEBRIEF -> { if (debriefT == 0) debriefT = shotFrame; if (shotFrame - debriefT == 20) { shot(dir, "12_debrief"); win.requestClose(); } }
            default -> {}
        }
        if (shotFrame > 20000) win.requestClose();
    }

    /** Where the scripted scenes are staged: the first stretch of open ground in the city wide and long enough for them. */
    private float sx = 250.5f, sz = 300.5f;
    private int tour = -1;
    private Actor tourCasualty;
    private absentialis.scene.Doors.Door tourDoor;

    private void stageSpot(World w) {
        int g = World.GROUND;
        for (int ring = 0; ring < 200; ring += 2) for (int x = 352 - ring; x <= 352 + ring; x += 2) for (int z = 352 - ring; z <= 352 + ring; z += 2) {
            if (Math.max(Math.abs(x - 352), Math.abs(z - 352)) != ring) continue;
            boolean ok = w.block(x, g - 1, z).mat == absentialis.world.Material.ASPHALT;
            for (int ix = x - 8; ix <= x + 6 && ok; ix++) for (int iz = z - 22; iz <= z + 5 && ok; iz++) {
                if (!w.solid(ix, g - 1, iz)) ok = false;
                for (int y = g; y < g + 4 && ok; y++) if (w.get(ix, y, iz) != 0) ok = false;
            }
            if (ok) { sx = x + 0.5f; sz = z + 0.5f; System.out.println("[Autoshot] staged at " + x + ", " + z); return; }
        }
        System.out.println("[Autoshot] no open stretch found; staging at the default spot");
    }

    /** A flight over the generated city: overview, boundary, each landmark compound, then a door and a casualty at street level. */
    private void tourStep(Raid r, String dir) {
        final int each = 50;
        var anchors = r.world.map.anchors;
        int views = 2 + anchors.size(), k = tour / each, f = tour % each;
        Actor p = r.player;
        if (k < views) {
            if (f == 0) {
                r.noclip = true;
                if (k == 0) { place(r, 352, 88, 520); p.yaw = 0; p.pitch = -0.62f; }
                else if (k == 1) { place(r, 660, World.GROUND + 16, 300); p.yaw = (float) Math.PI / 2; p.pitch = -0.2f; }
                else { var l = anchors.get(k - 2); place(r, l.cx(), World.GROUND + 36, l.z1 + 30); p.yaw = 0; p.pitch = -0.72f; }
            }
            p.vx = p.vy = p.vz = 0;
            if (f == each - 6) shot(dir, k == 0 ? "20_city_overview" : k == 1 ? "21_boundary_east" : String.format("22_%02d_%s", k - 1, anchors.get(k - 2).id));
        } else {
            int t = tour - views * each;
            if (t == 0) {
                r.noclip = false;
                // the nearest unlocked wooden door with standing room in front of it
                float best = 1e9f;
                for (var d : r.doors.doors) {
                    if (d.locked || d.destroyed || d.kind != absentialis.scene.Doors.WOOD || d.y != World.GROUND) continue;
                    int nx = d.alongX ? 0 : 1, nz = d.alongX ? 1 : 0;
                    boolean free = true;
                    for (int i = 1; i <= 3 && free; i++) free = !r.world.solid(d.x + nx * i, d.y, d.z + nz * i) && !r.world.solid(d.x + nx * i, d.y + 1, d.z + nz * i) && r.world.solid(d.x + nx * i, d.y - 1, d.z + nz * i);
                    if (!free) continue;
                    float dd = (d.x - sx) * (d.x - sx) + (d.z - sz) * (d.z - sz);
                    if (dd < best) { best = dd; tourDoor = d; }
                }
                if (tourDoor != null) {
                    var d = tourDoor;
                    int nx = d.alongX ? 0 : 1, nz = d.alongX ? 1 : 0;
                    place(r, d.cx() + nx * 2.4f, d.y, d.cz() + nz * 2.4f);
                    p.yaw = (float) Math.atan2(nx, nz); p.pitch = -0.05f;
                }
            }
            if (t == 30) shot(dir, "23_door_closed");
            if (t == 32 && tourDoor != null) r.doors.open(tourDoor, p);
            if (t == 75) shot(dir, "23b_door_open");
            if (t == 77 && tourDoor != null) r.doors.blast(tourDoor, 60, 0, 0, p.id);
            if (t == 79 && tourDoor != null) r.doors.use(tourDoor, p);
            if (t == 120) shot(dir, "23c_door_damaged");
            if (t == 122) {
                place(r, sx, World.GROUND, sz); p.yaw = 0; p.pitch = -0.25f;
                tourCasualty = r.debugSpawn("survivors", sx, sz - 3.2f, World.GROUND);
                Actor foe = r.debugSpawn("raiders", sx + 2.5f, sz - 6f, World.GROUND);
                r.casualty.down(tourCasualty, p, "bullet");
                r.bus.emit(new absentialis.engine.events.Events.HitConfirmed(p.id, foe.id, "torso", 10, r.time));
                r.damageActor(foe, p, 5000, absentialis.gameplay.items.Content.def("ammo.rifle"), "head", foe.x, foe.y + 1.6f, foe.z);
            }
            if (t == 134) shot(dir, "24_downed_marker_killfeed");
            if (t == 200) shot(dir, "24b_downed_bleeding");
            if (t == 202) { r.aiDebug = true; }
            if (t == 215) { shot(dir, "25_ai_debug"); r.aiDebug = false; }
            if (t == 217) { if (tourCasualty != null) r.actors.remove(tourCasualty); tour = -1; return; }
        }
        tour++;
    }

    private final List<Actor> lineup = new ArrayList<>();
    private int hideoutT, raidT, debriefT;
    private boolean deployed;

    private void equipForAuto() {
        Profile p = c.profile;
        for (ItemInstance i : new ArrayList<>(p.stash.items)) {
            if (i.def().slot != null && p.loadout.slot(i.def().slot) == null) InventoryService.equip(i, p.loadout, i.def().slot);
        }
        for (ItemInstance i : new ArrayList<>(p.stash.items)) if (i.def().medical != null || i.def().ammo != null || i.def().food != null || i.def().throwable != null) InventoryService.store(i, p.loadout);
        ItemInstance rifle = p.loadout.slot("primary");
        if (rifle != null) { absentialis.gameplay.weapons.Gunsmith.install(rifle, "att.optic.reddot"); absentialis.gameplay.weapons.Gunsmith.install(rifle, "att.muzzle.compensator"); }
    }

    private void shot(String dir, String name) { Screenshot.save(win.width, win.height, dir + "/" + name + ".png"); }
}
