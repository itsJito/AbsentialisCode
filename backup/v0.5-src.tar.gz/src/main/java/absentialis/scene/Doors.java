package absentialis.scene;

import absentialis.engine.events.Events;
import absentialis.engine.math.Mat4;
import absentialis.engine.render.ModelRenderer;
import absentialis.engine.util.Rng;
import absentialis.engine.voxel.VoxModel;
import absentialis.entity.Actor;
import absentialis.world.Block;
import absentialis.world.World;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Doors as physical things (0.5, brief section 8).
 *
 * Every door in the world - generated, or found by scanning a world that was built some other way - is an entity:
 * a leaf two cells tall on a hinge, with an angle and an angular velocity, a material, structural health, four
 * damage regions (upper panel, lower panel, hinge side, latch side), a latch that can be locked or broken, and a
 * state the AI can ask for. A door swings; it never switches. A round that hits it is located on the leaf: enough
 * on the latch and the door is forced and hangs open, enough on the hinge side and it comes off and falls as a
 * slab, enough anywhere and it breaks up. Blast does the same in one go.
 *
 * The voxel cells a door stands in remain the collision, sight and light proxy (solid while the leaf is within a
 * few degrees of shut, open beyond that, empty once it is gone), so physics, line of sight, navigation, cover and
 * lighting all follow the door through the code they already have; the chunk mesher no longer draws door blocks,
 * the leaf drawn here is the only door you see.
 */
public final class Doors implements World.DoorOracle {
    public static final int WOOD = 0, METAL = 1, GLASS = 2;
    public static final int R_UPPER = 0, R_LOWER = 1, R_HINGE = 2, R_LATCH = 3;
    public static final String[] REGION = {"upper panel", "lower panel", "hinge", "latch"};
    public static final float OPEN = 1.45f, SOLID_BELOW = 0.30f;

    public enum State { OPEN, CLOSED, LOCKED, BLOCKED, DAMAGED, DESTROYED }

    public static final class Door {
        public int id, x, y, z, kind, hinge;
        /** The wall the door is in runs along x (so the shut leaf lies along x). */
        public boolean alongX, exterior;
        /** Hinge angle in radians (0 = shut; the sign is the way it has swung), angular velocity, and where it is heading. */
        public float angle, vel, target;
        public float health, maxHealth;
        public final float[] region = new float[4];
        public boolean locked, latchBroken, hingeBroken, destroyed, solid = true;
        public float blockedUntil = -99, lastUse = -99, forcedAt = -99;
        public int lastUser, hits;
        int closedBlock, openBlock;

        public float pivotX() { return alongX ? x + (hinge == 0 ? 0 : 1) : x + 0.5f; }
        public float pivotZ() { return alongX ? z + 0.5f : z + (hinge == 0 ? 0 : 1); }
        /** Unit direction of the shut leaf from the hinge. */
        public float dirX() { return alongX ? (hinge == 0 ? 1 : -1) : 0; }
        public float dirZ() { return alongX ? 0 : (hinge == 0 ? 1 : -1); }
        public float cx() { return x + 0.5f; }
        public float cz() { return z + 0.5f; }
        public boolean damaged() { return health < maxHealth * 0.6f || latchBroken; }
        public int damageLevel() { return health < maxHealth * 0.3f ? 2 : health < maxHealth * 0.6f ? 1 : 0; }
    }

    /** A leaf off its hinges, or a piece of one: a rigid slab that falls, slides and comes to rest. */
    public static final class Slab { public float x, y, z, vx, vy, vz, yaw, pitch, spin, life = 60, w, h; public int kind, level; public boolean rest; }

    private final Raid raid;
    public final List<Door> doors = new ArrayList<>();
    public final List<Slab> slabs = new ArrayList<>();
    private final Map<Integer, Door> byCell = new HashMap<>();
    private final List<Door> moving = new ArrayList<>();
    /** Counters for the gates and the overlay. */
    public int swings, forced, detached, shattered, hitsTaken;

    Doors(Raid raid) { this.raid = raid; }

    // ------------------------------------------------------------------ setup
    private static int kindOf(int block) {
        return block == Block.DOOR_METAL || block == Block.DOOR_METAL_OPEN ? METAL : block == Block.DOOR_GLASS || block == Block.DOOR_GLASS_OPEN ? GLASS : WOOD;
    }

    /** Finds every door in the world as it stands and makes an entity of it. Cheap enough to run once per deployment. */
    public void scan() {
        World w = raid.world;
        doors.clear(); byCell.clear(); moving.clear(); slabs.clear();
        byte[] bl = w.blocks;
        boolean[] isDoor = new boolean[256];
        for (Block b : Block.all()) if (b.is(Block.DOOR)) isDoor[b.id] = true;
        for (int x = 1; x < World.W - 1; x++) for (int z = 1; z < World.D - 1; z++) {
            int base = (x * World.D + z) * World.H;
            for (int y = 1; y < World.H - 2; y++) {
                int id = bl[base + y] & 0xFF;
                if (!isDoor[id] || isDoor[bl[base + y - 1] & 0xFF]) continue;      // the lower cell of each leaf
                add(x, y, z, id);
            }
        }
        w.doors = this;
    }

    private Door add(int x, int y, int z, int id) {
        World w = raid.world;
        Door d = new Door();
        d.id = doors.size(); d.x = x; d.y = y; d.z = z;
        d.kind = kindOf(id);
        boolean wx = wall(w, x - 1, y, z) || wall(w, x + 1, y, z), wz = wall(w, x, y, z - 1) || wall(w, x, y, z + 1);
        d.alongX = !(wz && !wx);
        float h = Rng.hash(x, y, z, 5113), h2 = Rng.hash(x, y, z, 977);
        d.hinge = h < 0.5f ? 0 : 1;
        d.closedBlock = d.kind == METAL ? Block.DOOR_METAL : d.kind == GLASS ? Block.DOOR_GLASS : Block.DOOR_WOOD;
        d.openBlock = d.kind == METAL ? Block.DOOR_METAL_OPEN : d.kind == GLASS ? Block.DOOR_GLASS_OPEN : Block.DOOR_WOOD_OPEN;
        d.maxHealth = d.health = d.kind == METAL ? 900 : d.kind == GLASS ? 45 : 140;
        // out of doors on at least one side: the sky reaches the cell in front or behind
        int nx = d.alongX ? 0 : 1, nz = d.alongX ? 1 : 0;
        d.exterior = w.heightAt(x + nx, z + nz) < y || w.heightAt(x - nx, z - nz) < y;
        boolean shut = Block.ALL[id].solid();
        if (!shut) { d.angle = d.target = (h2 < 0.5f ? 1 : -1) * OPEN; d.solid = false; }
        else {
            // left as people left them: most pulled to, some ajar, a few locked
            if (h2 < (d.kind == METAL ? 0.14f : d.exterior ? 0.12f : 0.04f)) d.locked = true;
            else if (h2 > 0.62f && !d.exterior) { d.angle = d.target = (h < 0.5f ? 1 : -1) * (h2 > 0.82f ? OPEN : 0.55f); }
        }
        doors.add(d);
        byCell.put(World.idx(x, y, z), d);
        byCell.put(World.idx(x, y + 1, z), d);
        if (shut && Math.abs(d.angle) >= SOLID_BELOW) {
            // found ajar: the proxy cells say so from the start (no relight for a state the world begins in)
            d.solid = false;
            w.setRaw(x, y, z, d.openBlock); w.setRaw(x, y + 1, z, d.openBlock);
            w.cover.invalidate(x, z);
        }
        return d;
    }

    private static boolean wall(World w, int x, int y, int z) { Block n = w.block(x, y, z); return n != null && n.solid() && n.shape == 0 && !n.is(Block.DOOR); }

    public Door at(int x, int y, int z) { return World.inBounds(x, y, z) ? byCell.get(World.idx(x, y, z)) : null; }

    /** The door a body at a position would use next: the nearest live one within reach. */
    public Door near(float x, float y, float z, float reach) {
        Door best = null;
        float bd = reach * reach;
        int ix = (int) Math.floor(x), iy = (int) Math.floor(y), iz = (int) Math.floor(z), r = (int) Math.ceil(reach);
        for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) for (int dy = 0; dy <= 1; dy++) {
            Door d = at(ix + dx, iy + dy, iz + dz);
            if (d == null || d.destroyed) continue;
            float dd = (d.cx() - x) * (d.cx() - x) + (d.cz() - z) * (d.cz() - z);
            if (dd < bd) { bd = dd; best = d; }
        }
        return best;
    }

    // ------------------------------------------------------------------ state for the AI and navigation
    public State state(Door d) {
        if (d.destroyed) return State.DESTROYED;
        if (!d.solid) return State.OPEN;
        if (d.locked && !d.latchBroken) return State.LOCKED;
        if (raid.time < d.blockedUntil) return State.BLOCKED;
        return d.damaged() ? State.DAMAGED : State.CLOSED;
    }

    /** World.DoorOracle: a shut door a walker cannot simply open (locked and still latched). */
    @Override public boolean sealed(int x, int y, int z) {
        Door d = at(x, y, z);
        return d != null && !d.destroyed && d.solid && d.locked && !d.latchBroken;
    }

    private void setSolid(Door d, boolean solid) {
        d.solid = solid;
        int id = d.destroyed ? Block.AIR : solid ? d.closedBlock : d.openBlock;
        // the two cells are the collision, sight and light proxy; World.set tells navigation, cover and the lighting
        raid.world.set(d.x, d.y, d.z, id);
        raid.world.set(d.x, d.y + 1, d.z, id);
        if (d.destroyed) { byCell.remove(World.idx(d.x, d.y, d.z)); byCell.remove(World.idx(d.x, d.y + 1, d.z)); }
    }

    private void wake(Door d) { if (!moving.contains(d)) moving.add(d); }

    // ------------------------------------------------------------------ use
    /** Which way the leaf must swing to move away from a point: the sign of the open angle. */
    private static float away(Door d, float fromX, float fromZ) {
        // a positive angle carries the free edge toward (-dirZ, dirX)
        float px = -d.dirZ(), pz = d.dirX();
        float side = (fromX - d.cx()) * px + (fromZ - d.cz()) * pz;
        return side > 0 ? -1 : 1;
    }

    /**
     * Someone works the handle. Returns null when the door answered (it is now opening or closing), or a short
     * reason when it did not ("Locked").
     */
    public String use(Door d, Actor by) {
        if (d == null || d.destroyed) return null;
        if (d.locked && !d.latchBroken && d.solid) {
            raid.emitSound(d.cx(), d.y + 1, d.cz(), 6, "door_locked", by == null ? 0 : by.id, false);
            return "Locked";
        }
        boolean opening = Math.abs(d.target) < 0.1f;
        d.target = opening ? away(d, by == null ? d.cx() : by.x, by == null ? d.cz() + 1 : by.z) * OPEN : 0;
        d.lastUse = raid.time; d.lastUser = by == null ? 0 : by.id;
        swings++;
        wake(d);
        raid.emitSound(d.cx(), d.y + 1, d.cz(), d.kind == METAL ? 12 : 9, opening ? "door_open" : "door_close", by == null ? 0 : by.id, false);
        return null;
    }

    /** Opens a door for someone passing through it (agents on a path): no-op if it is already open or opening. */
    public boolean open(Door d, Actor by) {
        if (d == null || d.destroyed || Math.abs(d.target) > 0.1f) return true;
        return use(d, by) == null;
    }

    /** A boot or a shoulder against the latch side: how doors are forced without a key. Returns true when it gave. */
    public boolean kick(Door d, Actor by) {
        if (d == null || d.destroyed || !d.solid) return true;
        float nx = by == null ? 0 : d.cx() - by.x, nz = by == null ? 1 : d.cz() - by.z;
        float force = d.kind == METAL ? 26 : d.kind == GLASS ? 60 : 44;
        raid.emitSound(d.cx(), d.y + 1, d.cz(), d.kind == METAL ? 34 : 26, "door_kick", by == null ? 0 : by.id, false);
        damage(d, R_LATCH, force, nx, nz, by == null ? 0 : by.id, "blunt");
        return d.destroyed || d.latchBroken;
    }

    // ------------------------------------------------------------------ damage
    /** Region of the leaf a world-space point lies on. */
    public static int regionAt(Door d, float hx, float hy, float hz) {
        float along = d.alongX ? hx - d.x : hz - d.z;
        float t = d.hinge == 0 ? along : 1 - along, rel = hy - d.y;
        if (t < 0.2f) return R_HINGE;
        if (t > 0.78f && rel > 0.6f && rel < 1.4f) return R_LATCH;
        return rel >= 1f ? R_UPPER : R_LOWER;
    }

    /** A projectile, a blade or debris struck the shut leaf at a point. */
    public void hit(Door d, float hx, float hy, float hz, float dmg, float dirX, float dirZ, int by, String kind) {
        if (d == null || d.destroyed) return;
        damage(d, regionAt(d, hx, hy, hz), dmg, dirX, dirZ, by, kind);
    }

    /** Blast: every region at once, scaled by distance by the caller. */
    public void blast(Door d, float dmg, float dirX, float dirZ, int by) {
        if (d == null || d.destroyed) return;
        for (int r = 0; r < 4 && !d.destroyed; r++) damage(d, r, dmg * (r == R_HINGE ? 0.9f : 0.6f), dirX, dirZ, by, "blast");
    }

    private void damage(Door d, int region, float dmg, float dirX, float dirZ, int by, String kind) {
        // what a material shrugs off: small arms barely mark plate, anything breaks glass
        float taken = dmg * (d.kind == METAL ? ("bullet".equals(kind) ? 0.22f : "blast".equals(kind) ? 1f : 0.55f) : 1f);
        d.region[region] += taken;
        d.health -= taken;
        d.hits++; hitsTaken++;
        // the blow shoves the leaf: a latched door shudders, an unlatched one swings
        float px = -d.dirZ(), pz = d.dirX();
        float push = (dirX * px + dirZ * pz) * Math.min(6f, taken * 0.08f);
        d.vel += push;
        wake(d);
        if (d.kind == GLASS && d.health < d.maxHealth * 0.5f || d.health <= 0) { shatter(d, dirX, dirZ, by); return; }
        if (!d.hingeBroken && d.region[R_HINGE] >= d.maxHealth * 0.45f) { detach(d, dirX, dirZ, by); return; }
        if (!d.latchBroken && d.region[R_LATCH] >= d.maxHealth * 0.30f) {
            // forced: the latch has gone, the door swings away from the blow and will not stay shut again
            d.latchBroken = true; d.locked = false; d.forcedAt = raid.time;
            float dir = push != 0 ? Math.signum(push) : away(d, d.cx() - dirX, d.cz() - dirZ);
            d.target = dir * OPEN * 0.9f;
            d.vel += dir * 5.5f;
            forced++;
            raid.emitSound(d.cx(), d.y + 1, d.cz(), 30, "door_break", by, false);
        }
    }

    /** The leaf comes off its hinges and goes where the blow sends it. */
    private void detach(Door d, float dirX, float dirZ, int by) {
        d.hingeBroken = true; d.destroyed = true;
        detached++;
        Slab s = new Slab();
        s.kind = d.kind; s.level = d.damageLevel(); s.w = 1; s.h = 2;
        s.x = d.cx(); s.y = d.y + 1; s.z = d.cz();
        float l = Math.max(0.2f, (float) Math.sqrt(dirX * dirX + dirZ * dirZ));
        s.vx = dirX / l * 3.2f; s.vz = dirZ / l * 3.2f; s.vy = 1.6f;
        s.yaw = (float) Math.atan2(-d.dirZ(), d.dirX()); s.spin = 2.4f;
        slabs.add(s);
        gone(d, by, "door_break");
    }

    /** The leaf breaks up: fragments and splinters where it stood. */
    private void shatter(Door d, float dirX, float dirZ, int by) {
        d.destroyed = true;
        shattered++;
        float l = Math.max(0.2f, (float) Math.sqrt(dirX * dirX + dirZ * dirZ));
        for (int i = 0; i < (d.kind == GLASS ? 0 : 4); i++) {
            Slab s = new Slab();
            s.kind = d.kind; s.level = 2; s.w = 0.45f; s.h = 0.5f + raid.rng.nextFloat() * 0.5f;
            s.x = d.cx() + (raid.rng.nextFloat() - 0.5f) * 0.6f; s.y = d.y + 0.4f + i * 0.4f; s.z = d.cz() + (raid.rng.nextFloat() - 0.5f) * 0.6f;
            s.vx = dirX / l * (2 + raid.rng.nextFloat() * 3) + (raid.rng.nextFloat() - 0.5f) * 2; s.vz = dirZ / l * (2 + raid.rng.nextFloat() * 3) + (raid.rng.nextFloat() - 0.5f) * 2; s.vy = 1 + raid.rng.nextFloat() * 2.5f;
            s.yaw = raid.rng.nextFloat() * 6.28f; s.spin = (raid.rng.nextFloat() - 0.5f) * 9; s.life = 45;
            slabs.add(s);
        }
        int col = d.kind == METAL ? 0xFF7C8088 : d.kind == GLASS ? 0xFFBFE0EA : 0xFF7A5630;
        for (int i = 0; i < 22; i++) {
            Raid.Effect e = new Raid.Effect();
            e.x = d.cx(); e.y = d.y + raid.rng.nextFloat() * 2; e.z = d.cz();
            e.vx = dirX / l * 3 + (raid.rng.nextFloat() - 0.5f) * 5; e.vy = raid.rng.nextFloat() * 4; e.vz = dirZ / l * 3 + (raid.rng.nextFloat() - 0.5f) * 5;
            e.life = e.max = 0.5f + raid.rng.nextFloat() * 0.6f; e.size = 0.05f + raid.rng.nextFloat() * 0.07f; e.color = col;
            raid.effects.add(e);
        }
        gone(d, by, d.kind == GLASS ? "glass_break" : "door_break");
    }

    private void gone(Door d, int by, String sound) {
        setSolid(d, false);
        moving.remove(d);
        raid.emitSound(d.cx(), d.y + 1, d.cz(), 34, sound, by, false);
        raid.bus.emit(new Events.BlockDestroyed(d.x, d.y, d.z, d.closedBlock, by));
    }

    // ------------------------------------------------------------------ simulation
    void update(float dt) {
        for (int i = moving.size() - 1; i >= 0; i--) {
            Door d = moving.get(i);
            if (d.destroyed) { moving.remove(i); continue; }
            float acc;
            if (!d.latchBroken) {
                // a door closer and a hand on the handle: critically damped toward where it was sent
                acc = 46f * (d.target - d.angle) - 11f * d.vel;
            } else {
                // no latch: it goes where it is pushed and drifts toward where it was left
                acc = 5f * (d.target - d.angle) - 2.4f * d.vel;
            }
            // somebody standing in the opening holds a closing door off them
            if (Math.abs(d.target) < 0.1f && Math.abs(d.angle) > SOLID_BELOW && occupied(d)) { acc = -8f * d.vel; d.blockedUntil = raid.time + 0.5f; }
            d.vel += acc * dt;
            d.angle += d.vel * dt;
            if (d.angle > OPEN + 0.08f) { d.angle = OPEN + 0.08f; d.vel = -d.vel * 0.25f; }
            if (d.angle < -OPEN - 0.08f) { d.angle = -OPEN - 0.08f; d.vel = -d.vel * 0.25f; }
            boolean solid = Math.abs(d.angle) < SOLID_BELOW;
            if (solid != d.solid) setSolid(d, solid);
            boolean settled = Math.abs(d.vel) < 0.04f && Math.abs(d.target - d.angle) < 0.015f;
            if (settled) { if (!d.latchBroken) d.angle = d.target; d.vel = 0; moving.remove(i); }
        }
        for (int i = slabs.size() - 1; i >= 0; i--) {
            Slab s = slabs.get(i);
            s.life -= dt;
            if (s.life <= 0) { slabs.remove(i); continue; }
            if (s.rest) continue;
            s.vy -= 20 * dt;
            float nx = s.x + s.vx * dt, ny = s.y + s.vy * dt, nz = s.z + s.vz * dt;
            World w = raid.world;
            if (w.solid((int) Math.floor(nx), (int) Math.floor(s.y), (int) Math.floor(s.z))) { s.vx = -s.vx * 0.3f; nx = s.x; }
            if (w.solid((int) Math.floor(s.x), (int) Math.floor(s.y), (int) Math.floor(nz))) { s.vz = -s.vz * 0.3f; nz = s.z; }
            float half = 0.07f;
            if (w.solid((int) Math.floor(nx), (int) Math.floor(ny - half), (int) Math.floor(nz))) {
                ny = (float) Math.floor(ny - half) + 1 + half;
                if (Math.abs(s.vy) > 3) raid.emitSound(nx, ny, nz, 14, "debris", 0, false);
                s.vy = 0; s.vx *= 0.55f; s.vz *= 0.55f; s.spin *= 0.5f;
                s.pitch += (1.5708f - s.pitch) * Math.min(1, dt * 14);       // it lies down flat
                if (Math.abs(s.vx) + Math.abs(s.vz) < 0.15f && s.pitch > 1.5f) { s.rest = true; s.pitch = 1.5708f; }
            } else s.pitch = Math.min(1.5708f, s.pitch + dt * 2.6f);
            s.yaw += s.spin * dt;
            s.x = nx; s.y = ny; s.z = nz;
        }
    }

    private boolean occupied(Door d) {
        for (Actor a : raid.actors) if (!a.dead && Math.abs(a.x - d.cx()) < 0.62f && Math.abs(a.z - d.cz()) < 0.62f && a.y < d.y + 1.9f && a.y + 1.7f > d.y) return true;
        return false;
    }

    // ------------------------------------------------------------------ rays against open leaves
    /**
     * Distance along a ray to the first swung-open leaf it strikes, or -1. Shut doors are met through their voxel
     * cells; this covers the leaf standing open in a doorway or hanging off a broken latch.
     */
    public float ray(float ox, float oy, float oz, float dx, float dy, float dz, float len, Door[] hitOut) {
        float best = -1;
        int x0 = (int) Math.floor(Math.min(ox, ox + dx * len)) - 1, x1 = (int) Math.floor(Math.max(ox, ox + dx * len)) + 1;
        int z0 = (int) Math.floor(Math.min(oz, oz + dz * len)) - 1, z1 = (int) Math.floor(Math.max(oz, oz + dz * len)) + 1;
        if ((x1 - x0) * (z1 - z0) > 400) return -1;
        int yc = (int) Math.floor(oy + dy * len * 0.5f);
        for (int x = x0; x <= x1; x++) for (int z = z0; z <= z1; z++) for (int y = yc - 2; y <= yc + 1; y++) {
            Door d = at(x, y, z);
            if (d == null || d.destroyed || d.solid || d.y != y) continue;
            // into the leaf's frame: origin at the hinge, x along the leaf as it now stands
            float c = (float) Math.cos(d.angle), s = (float) Math.sin(d.angle);
            float lx = d.dirX() * c - d.dirZ() * s, lz = d.dirX() * s + d.dirZ() * c;
            float rx = ox - d.pivotX(), rz = oz - d.pivotZ();
            float o1 = rx * lx + rz * lz, o2 = -rx * lz + rz * lx, d1 = dx * lx + dz * lz, d2 = -dx * lz + dz * lx;
            if (Math.abs(d2) < 1e-5f) continue;
            float t = -o2 / d2;
            if (t < 0 || t > len) continue;
            float u = o1 + d1 * t, v = oy + dy * t - d.y;
            if (u < 0 || u > 1 || v < 0 || v > 2) continue;
            if (best < 0 || t < best) { best = t; if (hitOut != null) hitOut[0] = d; }
        }
        return best;
    }

    /** A round met an open leaf: damage where it struck. Returns the fraction of its energy that carries on. */
    public float strikeOpen(Door d, float hx, float hy, float hz, float dmg, float dirX, float dirZ, int by) {
        float c = (float) Math.cos(d.angle), s = (float) Math.sin(d.angle);
        float lx = d.dirX() * c - d.dirZ() * s, lz = d.dirX() * s + d.dirZ() * c;
        float u = (hx - d.pivotX()) * lx + (hz - d.pivotZ()) * lz, rel = hy - d.y;
        int region = u < 0.2f ? R_HINGE : u > 0.78f && rel > 0.6f && rel < 1.4f ? R_LATCH : rel >= 1 ? R_UPPER : R_LOWER;
        damage(d, region, dmg, dirX, dirZ, by, "bullet");
        return d.kind == METAL ? 0f : d.kind == GLASS ? 0.95f : 0.6f;
    }

    // ------------------------------------------------------------------ drawing
    private static int[] leafColours(int kind) {
        return kind == METAL ? new int[]{0xFF6E747C, 0xFF575C63, 0xFFB8BCC2} : kind == GLASS ? new int[]{0xFF4A4F56, 0x809CC8D8, 0xFFB8BCC2} : new int[]{0xFF7A5630, 0xFF5E4024, 0xFFC8B070};
    }

    /** The leaf as a voxel model: sixteen by thirty-two by two. Damage levels knock real holes in it. */
    static VoxModel leaf(int kind, int level) {
        VoxModel m = new VoxModel(16, 32, 2);
        int[] c = leafColours(kind);
        for (int x = 0; x < 16; x++) for (int y = 0; y < 32; y++) for (int z = 0; z < 2; z++) {
            boolean frame = x == 0 || x == 15 || y == 0 || y == 31 || y == 15 || y == 16;
            int col = frame ? c[0] : c[1];
            if (kind == WOOD && !frame && (x == 4 || x == 11)) col = c[0];
            if (kind == METAL && !frame && y < 6) col = 0xFF4C5056;                       // kick plate
            if (kind == METAL && (x == 2 || x == 13) && y % 6 == 3) col = c[2];            // rivets
            if (kind == GLASS && !frame && y > 2) col = c[1];
            m.set(x, y, z, col);
        }
        // handle on the latch side
        m.set(13, 15, 0, c[2]); m.set(13, 15, 1, c[2]); m.set(13, 16, 0, c[2]); m.set(13, 16, 1, c[2]);
        if (level > 0) {
            int holes = level == 1 ? 3 : 7;
            for (int i = 0; i < holes; i++) {
                int hx = 2 + (int) (Rng.hash(i, kind, level, 31) * 12), hy = 2 + (int) (Rng.hash(i, kind, level, 57) * 28), r = level == 1 ? 1 : 1 + (i & 1);
                for (int x = hx - r; x <= hx + r; x++) for (int y = hy - r; y <= hy + r; y++) if ((x - hx) * (x - hx) + (y - hy) * (y - hy) <= r * r + (i & 1)) { m.set(x, y, 0, 0); m.set(x, y, 1, 0); }
            }
        }
        return m;
    }

    private ModelRenderer.Mesh mesh(ModelRenderer mr, int kind, int level) {
        String key = "door:" + kind + ":" + level;
        ModelRenderer.Mesh me = mr.cached(key);
        return me != null ? me : mr.meshAt(key, leaf(kind, level), 0, 0, 1);
    }

    /** Draws every leaf and every fallen slab near the camera. */
    public void draw(ModelRenderer mr, Mat4 tmp, float camX, float camZ, java.util.function.Function<float[], Float> lightAt) {
        float[] pos = new float[3];
        float k = 1 / 16f;
        for (Door d : doors) {
            if (d.destroyed || Math.abs(d.x - camX) > 90 || Math.abs(d.z - camZ) > 90) continue;
            float c = (float) Math.cos(d.angle), s = (float) Math.sin(d.angle);
            float lx = d.dirX() * c - d.dirZ() * s, lz = d.dirX() * s + d.dirZ() * c;
            // light from the lit side of the doorway
            float nx = d.alongX ? 0 : 1, nz = d.alongX ? 1 : 0;
            pos[0] = d.cx() + nx; pos[1] = d.y + 1; pos[2] = d.cz() + nz;
            float la = lightAt.apply(pos);
            pos[0] = d.cx() - nx; pos[2] = d.cz() - nz;
            float light = Math.max(la, lightAt.apply(pos));
            mr.material(d.kind == METAL ? 0.45f : d.kind == GLASS ? 0.2f : 0.8f, d.kind == METAL ? 0.8f : 0f);
            tmp.identity().translate(d.pivotX(), d.y, d.pivotZ()).rotateY((float) Math.atan2(-lz, lx)).scale(k, k, k);
            mr.draw(mesh(mr, d.kind, d.damageLevel()), tmp, light, 0xFFFFFFFF, 0);
        }
        for (Slab sl : slabs) {
            if (Math.abs(sl.x - camX) > 70 || Math.abs(sl.z - camZ) > 70) continue;
            pos[0] = sl.x; pos[1] = sl.y + 0.3f; pos[2] = sl.z;
            mr.material(sl.kind == METAL ? 0.45f : 0.8f, sl.kind == METAL ? 0.8f : 0f);
            tmp.identity().translate(sl.x, sl.y, sl.z).rotateY(sl.yaw).rotateX(sl.pitch).scale(k * sl.w, k * sl.h * 0.5f, k).translate(-8, -16, 0);
            mr.draw(mesh(mr, sl.kind, sl.level), tmp, lightAt.apply(pos), sl.life < 2 ? Ui.alpha(0xFFFFFFFF, sl.life / 2) : 0xFFFFFFFF, 0);
        }
        mr.material();
    }

    private static final class Ui { static int alpha(int argb, float a) { return (argb & 0xFFFFFF) | ((int) (Math.max(0, Math.min(1, a)) * 255) << 24); } }
}
