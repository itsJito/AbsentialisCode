package absentialis.scene;

import absentialis.anatomy.DamageProcessor;
import absentialis.character.Ragdoll;
import absentialis.character.Rig;
import absentialis.entity.Actor;
import java.util.ArrayList;
import java.util.List;

/**
 * How a body answers a blow, and the hand-over between authored animation and physics.
 *
 * The response is graded by the force of the hit, where it landed and what the character was doing - it is not
 * one flinch animation played on every hit:
 *   a light hit        an additive flinch away from the blow; nothing the character was doing is interrupted
 *   a solid hit        a stagger: movement and the current attack are interrupted for a moment
 *   a leg taken out    loss of balance: the character goes down
 *   a limb broken      partial ragdoll: that limb goes limp and hangs while the rest of the body keeps its animation
 *   a heavy hit        a full knock-down: the living body is handed to the ragdoll with the momentum of the blow,
 *                      lies where physics leaves it, and gets back up if it still can
 *   death              the ragdoll takes the body for good (Raid does this; the pose and wounds carry over)
 * A character already committed to something heavy (a giant winding up) shrugs off what would stagger anyone else.
 */
public final class RagdollController {
    private final Raid raid;
    /** Living characters currently on the ground under physics. */
    private final List<Actor> down = new ArrayList<>();
    public int flinches, staggers, knockdowns, recoveries;
    /** 0.6: staggers answered physically, blows taken while physics had the body, bodies that got up by themselves, and those left crawling. */
    public int physicalStaggers, blowsOnTheGround, selfRecoveries, leftCrawling;

    /** Whether this body is one Sydney simulates: alive, not the player, brought fully online and near enough to be seen. */
    private boolean physical(Actor v) {
        return raid.sydneyEnabled && !v.isPlayer && !v.dead && v.tier == 0 && v.anim != null && v.distXZ(raid.player.x, raid.player.z) <= SIMULATED_WITHIN && !v.seated && !v.crawling;
    }

    /** How near the player a living body has to be for its loss of balance to be simulated (0.9: 90 m; it was 55, and past that a blow was answered with a clip). */
    public static float SIMULATED_WITHIN = 90;
    /** 0.9: bodies thrown off balance by something that was not a wound and answered with physics; and how many times a clip had to stand in because the body was out of range. */
    public int unbalanced, clipFallbacks;

    /**
     * 0.9: a body is thrown off balance by something other than a wound - a flash, a slip in blood, a shove. Where the body
     * can be simulated it is given to Sydney with that push and keeps or loses its feet on its own account; nothing is played.
     * Returns false only when it cannot be simulated (too far off to be seen, or not brought fully online), and the caller
     * falls back to its clip.
     */
    public boolean unbalance(Actor v, float dx, float dz, float force, String region) {
        if (v.dead || v.isPlayer) return false;
        if (v.ragdoll != null) return true;
        if (!physical(v)) { clipFallbacks++; return false; }
        v.hitDirX = dx; v.hitDirZ = dz; v.hitForce = force; v.hitRegion = region;
        v.fireCooldown = Math.max(v.fireCooldown, 0.45f);
        v.burstLeft = 0;
        raid.startRagdoll(v);
        absentialis.sydney.SydneyCharacter sc = absentialis.sydney.SydneyCharacter.of(v.ragdoll);
        if (sc == null) { v.ragdoll = null; clipFallbacks++; return false; }
        sc.wound = absentialis.sydney.SydneyCharacter.particleOf("legs".equals(region) ? Rig.L_THIGH : "head".equals(region) ? Rig.HEAD : Rig.TORSO, false);
        down.add(v); v.downUntil = raid.time; unbalanced++; physicalStaggers++;
        return true;
    }

    RagdollController(Raid raid) { this.raid = raid; }

    /** Force thresholds, in damage points of the hit as delivered (before health multipliers). */
    public static final float STAGGER = 24, KNOCKDOWN = 78;

    void react(Actor v, float dx, float dz, float force, int group, int type, Gore.Impact im) {
        if (v.dead || v.isPlayer) return;
        boolean giant = "tank".equals(v.archetype), heavy = giant || "bomber".equals(v.archetype) || "gladiator".equals(v.archetype) || "butcher".equals(v.archetype) || "tyrant".equals(v.archetype);
        float mass = giant ? 5f : heavy ? 1.8f : 1f;
        // blasts and blunt blows shove; a bullet's push is small for the harm it does
        float shove = force * (type == DamageProcessor.BLAST ? 1.6f : type == DamageProcessor.BLUNT ? 1.25f : type == DamageProcessor.BULLET ? 0.75f : 0.6f) / mass;
        boolean leg = group >= Rig.L_THIGH;
        boolean committed = raid.telegraphing(v, "charge") || raid.telegraphing(v, "throw");
        absentialis.sydney.SydneyConfig sy = absentialis.sydney.SydneyConfig.of(giant ? "giant" : v.infected() ? "infected" : "human");
        if (v.ragdoll != null) {
            // physics already has the body: the blow lands on it where it landed, and what that does is Sydney's to find out
            absentialis.sydney.SydneyCharacter sc = absentialis.sydney.SydneyCharacter.of(v.ragdoll);
            if (sc != null && sc.alive) {
                if (v.anat != null) sc.setBody(v.anat.missingMask, v.limpMask);
                sc.hit(absentialis.sydney.SydneyCharacter.particleOf(group, false), dx, 0.12f, dz, sc.rig.totalMass * Math.min(2.2f, 0.15f + shove / 70f) * 0.5f, shove);
                blowsOnTheGround++;
            }
            return;
        }
        if (shove >= KNOCKDOWN * sy.knockMul || leg && (im.severed || im.fractured) && !giant || im.severed && group == Rig.HEAD) {
            knockDown(v, dx, dz, shove, leg && (im.severed || im.fractured) ? 1.4f : 2.2f + Math.min(2.5f, shove / 60f));
            return;
        }
        if (shove >= STAGGER * sy.staggerMul && !committed || leg && force > 14 && !heavy) {
            staggers++;
            // 0.6: a blow that staggers is no longer answered with the stumble animation. The body is given to Sydney
            // with the momentum of the blow where it landed, and keeps its feet or loses them on its own account.
            if (physical(v)) {
                v.fireCooldown = Math.max(v.fireCooldown, 0.45f);
                v.burstLeft = 0;
                v.hitDirX = dx; v.hitDirZ = dz;
                v.hitForce = Math.min(shove * 0.45f, 26f);
                v.hitRegion = group == Rig.HEAD ? "head" : leg ? "legs" : group >= Rig.L_UPPER_ARM && group < Rig.L_THIGH ? "arms" : "torso";
                raid.startRagdoll(v);
                absentialis.sydney.SydneyCharacter sc = absentialis.sydney.SydneyCharacter.of(v.ragdoll);
                if (sc != null) { sc.wound = absentialis.sydney.SydneyCharacter.particleOf(group, false); down.add(v); v.downUntil = raid.time; physicalStaggers++; raid.emitSound(v.x, v.y + 1, v.z, 6, "stagger", v.id, false); return; }
                v.ragdoll = null;      // too far to be simulated after all: fall through to the authored stumble
            }
            v.staggerUntil = Math.max(v.staggerUntil, raid.time + (type == DamageProcessor.BLAST ? 1.6f : 0.75f));
            v.fireCooldown = Math.max(v.fireCooldown, 0.45f);            // the attack in progress is lost
            v.burstLeft = 0;
            if (v.anim != null && !v.anim.playing("stumble")) v.anim.play("stumble", type == DamageProcessor.BLAST ? 1.1f : 0.65f);
            // knocked a step in the direction of the blow
            v.vx += dx * Math.min(3f, shove * 0.04f); v.vz += dz * Math.min(3f, shove * 0.04f);
            raid.emitSound(v.x, v.y + 1, v.z, 6, "stagger", v.id, false);
            return;
        }
        flinches++;
        if (v.anim != null) v.anim.hit((float) Math.atan2(dx, dz));
    }

    /** Hands a living character to the ragdoll for a while. */
    public void knockDown(Actor v, float dx, float dz, float shove, float seconds) {
        if (v.dead || v.ragdoll != null || v.isPlayer) return;
        knockdowns++;
        v.hitDirX = dx; v.hitDirZ = dz;
        v.hitForce = Math.max(v.hitForce, shove);
        raid.startRagdoll(v);
        v.downUntil = raid.time + seconds;
        { absentialis.sydney.SydneyCharacter sc = absentialis.sydney.SydneyCharacter.of(v.ragdoll); if (sc != null) { sc.mind.onHit(sc, shove); sc.mind.stun = Math.max(sc.mind.stun, 0.9f); } }
        v.fireCooldown = Math.max(v.fireCooldown, seconds + 0.6f);
        v.burstLeft = 0;
        v.vx = v.vz = 0;
        down.add(v);
        raid.emitSound(v.x, v.y + 0.5f, v.z, 9, "body_fall", v.id, false);
    }

    public boolean isDown(Actor a) { return !a.dead && a.ragdoll != null; }

    /** Physics for the living who are down, and getting them back up. */
    void update(float dt) {
        for (int i = down.size() - 1; i >= 0; i--) {
            Actor a = down.get(i);
            if (a.dead || a.ragdoll == null) { down.remove(i); continue; }   // died on the ground: the ragdoll is the corpse now
            Ragdoll r = a.ragdoll;
            if (!r.settled) r.update(raid.world, dt);
            a.x = r.x[Ragdoll.PELVIS]; a.z = r.z[Ragdoll.PELVIS]; a.y = Math.max(0, r.lowestY());
            a.vx = a.vz = 0;
            absentialis.sydney.SydneyCharacter sc = absentialis.sydney.SydneyCharacter.of(r);
            if (sc != null) {
                // Sydney has the body: it is up when it has got itself up, not when a timer says so
                if (a.anat != null) sc.setBody(a.anat.missingMask, a.limpMask);
                absentialis.sydney.BehaviorCoordinator.Outcome o = sc.outcome();
                boolean overdue = raid.time > a.downUntil + 25;
                if (o == absentialis.sydney.BehaviorCoordinator.Outcome.NONE && !overdue) continue;
                sc.release();
                if (o == absentialis.sydney.BehaviorCoordinator.Outcome.RECOVERED) {
                    // on its feet: animation takes the body back where it stands, facing the way it faces
                    a.x = absentialis.sydney.AnimationBridge.standX(sc); a.z = absentialis.sydney.AnimationBridge.standZ(sc);
                    a.yaw = absentialis.sydney.AnimationBridge.yaw(sc); a.faceSet = false;
                    int gy = raid.groundY((int) Math.floor(a.x), (int) Math.floor(a.z));
                    a.y = gy >= 0 && Math.abs(gy - sc.sense.groundY) < 1.5f ? gy : sc.sense.groundY;
                    a.ragdoll = null;
                    a.staggerUntil = raid.time + 0.25f;
                    a.hasGoal = false; a.path = null;
                    recoveries++; selfRecoveries++;
                    down.remove(i);
                    continue;
                }
                if (o == absentialis.sydney.BehaviorCoordinator.Outcome.CRAWL) leftCrawling++;
                a.downUntil = 0;       // down for good, or unable to rise where it lies: the 0.5 hand-back below (it crawls if its legs will not carry it)
            }
            boolean time = raid.time >= a.downUntil;
            if (!time || !r.settled && raid.time < a.downUntil + 2.5f) continue;
            // back to animation: stand where the body came to rest (or stay down and crawl if the legs will not carry it)
            int gy = raid.groundY((int) Math.floor(a.x), (int) Math.floor(a.z));
            if (gy >= 0 && Math.abs(gy - a.y) < 2.5f) a.y = gy;
            a.ragdoll = null;
            a.staggerUntil = raid.time + 1.1f;
            if (a.anat != null && !a.anat.canWalk) a.crawling = true;
            if (a.anim != null) a.anim.play("stumble", 1.1f);
            a.hasGoal = false; a.path = null;
            recoveries++;
            down.remove(i);
        }
    }
}
