package absentialis.scene;

import absentialis.gameplay.progression.Progression;
import absentialis.ui.Ui;
import java.util.ArrayList;
import java.util.List;

/**
 * Experience, seen as it is earned (0.6) - and, since 0.8, only then. The bar is not part of the HUD: it is not on
 * screen at all until something earns experience, comes up small in the top corner with the Rank's insignia for a few
 * seconds, and goes again. The minutes simply spent in the Zone still count, but say nothing. When what has been
 * earned carries the survivor over a Rank, that is announced once - the new insignia, the new title, and the sound
 * of it.
 *
 * Nothing here awards anything. Experience is still settled once, at the debrief, by {@link RaidResolver}; this
 * class watches the same counters the resolver will read and prices them with the resolver's own constants, so the
 * figure on screen is the figure that will be paid (halved if the operation fails).
 */
public final class XpFeed {
    /** One line of feedback: how much, what for, and when it appeared. */
    public static final class Toast { public String label; public int amount; public float at; }

    private final Raid raid;
    public final List<Toast> toasts = new ArrayList<>();
    private int containers, cells, documents, aided, minutes, stealth, hotspots;
    private boolean power;
    private float lastGain = -99, shownProgress = -1;
    /** Seconds a line stays, how long the bar stays after a gain, how long it takes to come and go, and how long a rank-up is announced. */
    public static float TOAST_LIFE = 3.2f, HOLD = 4.5f, FADE = 0.45f, RANK_NOTICE = 3.2f;
    /** The Rank the bar last showed, and the rank-up being announced (0 = none). */
    private int shownRank = -1;
    public int noticeRank;
    public float noticeAt = -99;
    /** Rank-ups announced this operation (tests). */
    public int notices;
    /** Asked to play a sound by name (the screen that owns the feed supplies it). */
    public java.util.function.Consumer<String> sound;

    public XpFeed(Raid raid) { this.raid = raid; }

    /** Experience this operation has earned so far, by the resolver's own prices (the extraction bonus and loot value come at the debrief). */
    public int pending() {
        Raid.Debrief d = raid.debrief;
        return d.containersSearched * RaidResolver.XP_CONTAINER + d.cellsRevealed * RaidResolver.XP_CELL + d.documents * RaidResolver.XP_DOCUMENT + d.aided * RaidResolver.XP_AID
                + (d.powerRestored ? RaidResolver.XP_POWER : 0) + d.hotspots * raid.events.xp + Math.min(d.stealthKills, RaidResolver.XP_STEALTH_CAP) * RaidResolver.XP_STEALTH_KILL + Math.round(Math.min(raid.time, RaidResolver.XP_TIME_CAP) / 60f * RaidResolver.XP_PER_MINUTE);
    }

    private void post(String label, int amount) {
        if (amount <= 0) return;
        lastGain = raid.time;
        // a run of the same thing (map cells while walking) adds to the line already showing instead of stacking a column of them
        for (Toast t : toasts) if (t.label.equals(label) && raid.time - t.at < TOAST_LIFE * 0.75f) { t.amount += amount; t.at = raid.time; return; }
        Toast t = new Toast();
        t.label = label; t.amount = amount; t.at = raid.time;
        toasts.add(t);
        while (toasts.size() > 3) toasts.remove(0);
    }

    /** How visible the bar is right now, 0 to 1: nothing until experience is earned, then up, held, and away. */
    public float visible() {
        float since = raid.time - lastGain;
        if (since < 0 || since > HOLD + FADE) return 0;
        return Math.min(1, since / (FADE * 0.4f)) * Math.min(1, (HOLD + FADE - since) / FADE);
    }

    /** True while a rank-up is being announced. */
    public boolean announcing() { return noticeRank > 0 && raid.time - noticeAt < RANK_NOTICE; }

    /** Looks at what has been done since the last frame and posts a line for each thing that earned experience. */
    public void update() {
        Raid.Debrief d = raid.debrief;
        if (d.containersSearched > containers) post("Container searched", (d.containersSearched - containers) * RaidResolver.XP_CONTAINER);
        if (d.cellsRevealed > cells) post("Reconnaissance", (d.cellsRevealed - cells) * RaidResolver.XP_CELL);
        if (d.documents > documents) post("Intel recovered", (d.documents - documents) * RaidResolver.XP_DOCUMENT);
        if (d.aided > aided) post("Aided a loner", (d.aided - aided) * RaidResolver.XP_AID);
        if (d.powerRestored && !power) post("Restored district power", RaidResolver.XP_POWER);
        if (d.hotspots > hotspots) { post("Hotspot settled", (d.hotspots - hotspots) * raid.events.xp); hotspots = d.hotspots; }
        if (d.stealthKills > stealth) { post("Silent takedown", (Math.min(d.stealthKills, RaidResolver.XP_STEALTH_CAP) - Math.min(stealth, RaidResolver.XP_STEALTH_CAP)) * RaidResolver.XP_STEALTH_KILL); stealth = d.stealthKills; }
        // time in the Zone is counted and paid, and is not news: it does not bring the bar up
        containers = d.containersSearched; cells = d.cellsRevealed; documents = d.documents; aided = d.aided; power = d.powerRestored; minutes = (int) (raid.time / 60f);
        toasts.removeIf(t -> raid.time - t.at > TOAST_LIFE);
        // over a Rank? Said once.
        float xpMul = 1 + raid.profile.loadout.charm("xp");
        int rank = (int) raid.profile.prog.preview(Math.round(pending() * xpMul))[0];
        if (shownRank < 0) shownRank = rank;
        if (rank > shownRank) {
            shownRank = rank; noticeRank = rank; noticeAt = raid.time; notices++;
            lastGain = raid.time;
            if (sound != null) sound.accept("rank_up");
        }
    }

    /** The bar and its lines: top right, small, and only while there is something to say. */
    public float draw(Ui ui) {
        float bottom = ui.s(16);
        Progression pr = raid.profile.prog;
        float xpMul = 1 + raid.profile.loadout.charm("xp");
        int pend = Math.round(pending() * xpMul);
        float[] pv = pr.preview(pend);
        int rank = (int) pv[0];
        float target = pv[1];
        if (shownProgress < 0) shownProgress = target;
        // the fill eases to its new place; over a Rank boundary it runs to the end and starts again
        shownProgress += ((target < shownProgress - 0.5f ? 1.02f : target) - shownProgress) * Math.min(1, ui.dt * 4);
        if (shownProgress > 1) shownProgress = 0;
        float lit = visible();
        if (lit > 0.01f) {
            // 1.0: at the head of the notification column (top left), with everything else that is routine
            float w = ui.s(200), h = ui.s(4), ins = ui.s(24), x = ui.s(14) + ins + ui.s(14), y = ui.s(30) - (1 - lit) * ui.s(8);
            StatusHud.plate(ui, x - ins - ui.s(14), y - ui.s(14), w + ins + ui.s(24), ui.s(34), lit);
            absentialis.ui.Insignia.draw(ui, rank, x - ins - ui.s(8), y - ui.s(9), ins, Ui.alpha(0xFFD6CEB8, lit));
            ui.text(Progression.rankName(rank) + " " + rank, x, y - ui.s(10), 12, Ui.alpha(Ui.TXT_HI, lit));
            ui.textR(pr.master() ? "MAX" : Math.round(target * 100) + "%", x + w, y - ui.s(10), 12, Ui.alpha(Ui.TXT, lit));
            ui.b.rect(x, y + ui.s(6), w, h, Ui.alpha(0xFF24262A, lit));
            float banked = rank == pr.rank() ? Math.max(0, Math.min(1, pr.rankProgress())) : 0;
            ui.b.rect(x, y + ui.s(6), w * banked, h, Ui.alpha(0xFF8A6420, lit));                                                    // what is banked
            ui.b.rect(x + w * banked, y + ui.s(6), w * Math.max(0, Math.min(1, shownProgress) - banked), h, Ui.alpha(0xFFE2A034, lit));   // what this operation adds
            float ty = y + ui.s(26), px = x - ins - ui.s(14);
            for (int i = toasts.size() - 1; i >= 0; i--) {
                Toast t = toasts.get(i);
                float age = raid.time - t.at, a = Math.min(1, age / 0.12f) * Math.min(1, (TOAST_LIFE - age) / 0.6f) * lit;
                if (a <= 0.02f) continue;
                String sx = "+" + String.format("%,d", Math.round(t.amount * xpMul)) + " XP";
                float tw = ui.tw(sx, 13) + ui.s(10) + ui.tw(t.label, 13) + ui.s(18);
                StatusHud.plate(ui, px, ty, tw, ui.s(22), a);
                ui.text(sx, px + ui.s(9), ty + ui.s(4), 13, Ui.alpha(0xFFD6CEB8, a));
                ui.text(t.label, px + ui.s(9) + ui.tw(sx, 13) + ui.s(10), ty + ui.s(4), 13, Ui.alpha(Ui.TXT_DIM, a));
                ty += ui.s(25);
            }
            bottom = ty + ui.s(2);
        }
        // ---- 1.0, the rank-up: said once, briefly, at the edge of the screen with the other notifications - not across the middle of it
        if (announcing()) {
            float age = raid.time - noticeAt, a = Math.min(1, age / 0.2f) * Math.min(1, (RANK_NOTICE - age) / 0.6f);
            String txt = "RANK UP   " + Progression.rankName(noticeRank) + " " + noticeRank;
            float is = ui.s(26), w = ui.tw(txt, 15) + is + ui.s(30), h = ui.s(36), x = ui.s(14) - (1 - Math.min(1, age / 0.2f)) * ui.s(24), y = bottom;
            StatusHud.plate(ui, x, y, w, h, a);
            ui.b.rect(x, y, ui.s(3), h, Ui.alpha(0xFFE2A034, a));
            absentialis.ui.Insignia.draw(ui, noticeRank, x + ui.s(11), y + (h - is) / 2, is, Ui.alpha(0xFFE2A034, a));
            ui.text(txt, x + ui.s(17) + is, y + ui.s(10), 15, Ui.alpha(Ui.TXT_HI, a));
            bottom = y + h + ui.s(4);
        }
        return bottom;
    }
}
