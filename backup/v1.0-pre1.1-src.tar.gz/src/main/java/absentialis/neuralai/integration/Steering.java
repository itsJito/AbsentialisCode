package absentialis.neuralai.integration;

import absentialis.entity.Actor;
import absentialis.entity.Physics;
import absentialis.scene.Raid;

/**
 * How a body gets from where it is to where it was told to go (0.8: this is the steering the old AI carried, now the
 * body side of NeuralAI's bridge and nothing else). No decision is made here: a destination and a speed come in, and
 * what goes out is a heading and a velocity for the voxel controller - straight when the way is open, otherwise the
 * next cell of a grid path, with long trips riding the street graph. Doors on the way are opened by people and not by
 * the dead; a ledge is jumped, once; a ladder is climbed; a locked door between an agent and its quarry is kicked
 * when its side allows the noise; and the dead take the short way through a hole in a wall (see {@link Breach}).
 */
public final class Steering {
    private Steering() {}

    public static float wrapPi(float d) { while (d > Math.PI) d -= Math.PI * 2; while (d < -Math.PI) d += Math.PI * 2; return d; }

    /** Radians a second a body comes round to its heading, and how far out it starts easing down for where it is going (0.9). */
    public static final float TURN_RATE = 9f, ARRIVE = 2.4f;

    public static void stop(Actor a) { a.vx *= 0.5f; a.vz *= 0.5f; }

    /** Steering with simple obstacle avoidance; long detours handled by walking the street graph. */
    public static void goTo(Raid r, Actor a, float tx, float tz, float speed, float dt) {
        boolean otherFloor = !Float.isNaN(a.goalY) && a.goalYAt == r.time && Math.abs(a.goalY - a.y) > 1.6f;
        if (a.distXZ(tx, tz) < 0.3f && !otherFloor) { stop(a); return; }
        // 0.7: the dead take the short way. With a wall between it and where it is going, an infected looks for an opening it
        // can climb through before it thinks about walking round to a door
        if (a.infected() && a.tier == 0 && a.breachT <= 0) {
            if (r.time < a.holeUntil) { if (Breach.approach(r, a, speed, dt)) return; }
            else if (r.time >= a.holeScanAt && a.onGround) {
                a.holeScanAt = r.time + 0.8f + (a.id % 7) * 0.05f;
                float dd = a.distXZ(tx, tz);
                if (dd > 1.5f && dd < 40 && !r.world.nav.clear(a.x, a.y, a.z, tx, tz, false) && Breach.seek(r, a, tx, tz) && Breach.approach(r, a, speed, dt)) return;
            }
        }
        // route: straight when the way is open, otherwise the next cell of a grid path (long trips ride the waypoint graph)
        float[] wp = waypoint(r, a, tx, tz);
        float dx = wp[0] - a.x, dz = wp[1] - a.z, d = (float) Math.sqrt(dx * dx + dz * dz);
        if (d < 0.05f) { stop(a); return; }
        float want = (float) Math.atan2(-dx, -dz);
        // 1.0, getting off an obstacle. The side-step used to be chosen afresh every frame the body was "stuck" and dropped the
        // frame it was not - so a body against a corner turned away, came unstuck, turned back, stuck again: the turning on
        // the spot of 0.9. A side-step is now chosen once and kept for most of a second, whichever way the stuck timer goes;
        // each body prefers its own side (two meeting in a doorway do not mirror each other); and one that is still stuck after
        // that asks for a new route instead of trying the same wall again.
        if (a.stuckTime > 0.5f && r.time >= a.detourUntil) {
            float sign = (a.id & 1) == 0 ? 1 : -1;
            a.detourOff = 0;
            for (float off : new float[]{0.8f * sign, -0.8f * sign, 1.5f * sign, -1.5f * sign, 2.3f * sign}) {
                float h = want + off;
                float px = a.x - (float) Math.sin(h) * 1.1f, pz = a.z - (float) Math.cos(h) * 1.1f;
                if (Physics.bodyFree(r.world, px, a.y, pz, a.radius, 1.7f) || Physics.bodyFree(r.world, px, a.y + 0.6f, pz, a.radius, 1.7f)) { a.detourOff = off; break; }
            }
            a.detourUntil = r.time + 0.75f;
            if (a.stuckTime > 1.4f) { a.path = null; a.pathAt = -99; a.partialUntil = r.time + 10f; }
            if (a.stuckTime > 3) { a.hasGoal = false; a.stuckTime = 0; }
        }
        if (r.time < a.detourUntil && a.detourOff != 0) want += a.detourOff;
        // 0.7: a wall with a hole in it is not a wall to the dead. Stopped against one while going somewhere, an infected
        // looks for a one-block opening it can reach and climbs through it.
        if (a.infected() && a.stuckTime > 0.3f && a.onGround && a.breachT <= 0 && r.time >= a.jumpAt && Breach.start(r, a, dx / d, dz / d)) return;
        // 0.9: a body used to turn at a fixed rate while always moving at full speed along its heading - so anything inside its
        // turning circle (a cover point a metre to the side of a sprinting man) was orbited instead of reached: the "running in
        // circles" of 0.8. Now it turns faster, it slows by how far its heading is off the way it wants to go, it eases down as it
        // arrives, and when what it wants is closer than it could turn onto, it simply steps there.
        a.yaw = turn(a.yaw, want, dt * TURN_RATE);
        float off = Math.abs(wrapPi(want - a.yaw));
        float sp = speed * (off > 1.9f ? 0.25f : Math.max(0.35f, (float) Math.cos(off)));
        float left = a.distXZ(tx, tz);
        if (left < ARRIVE) sp = Math.min(sp, Math.max(1.3f, left * 2.8f));
        float heading = off > 0.3f && d < Math.max(1.2f, sp / TURN_RATE * 2.4f) ? want : a.yaw;
        a.vx = (float) -Math.sin(heading) * sp;
        a.vz = (float) -Math.cos(heading) * sp;
        // 0.6: nobody is lifted onto a block by walking at it. A ledge in the way is jumped - once, with a pause before
        // the next - exactly as the player has to; stairs are simply walked.
        if (a.onGround && !a.climbing && r.time >= a.jumpAt && a.vital == absentialis.entity.Vital.ACTIVE && !a.crawling && Physics.ledgeAhead(r.world, a, dx, dz)) {
            a.vy = Physics.JUMP * ("tank".equals(a.archetype) ? 1.12f : 1f);
            a.onGround = false;
            a.jumpAt = r.time + (a.infected() ? 0.9f : 1.1f);
            a.crouch = false;
            // carry the run-up over the edge
            a.vx = dx / d * Math.max(speed, 2.2f); a.vz = dz / d * Math.max(speed, 2.2f);
            a.pvx = a.vx; a.pvz = a.vz;
            if (a.anim != null) a.anim.play("jump", 0.5f);
        }
    }

    private static final float[] WP = new float[2];

    /** Where to head right now to reach (tx, tz): the target itself, or the next point of the agent's path. */
    private static float[] waypoint(Raid r, Actor a, float tx, float tz) {
        absentialis.world.Nav nav = r.world.nav;
        boolean doors = !a.infected();
        WP[0] = tx; WP[1] = tz;
        float d = a.distXZ(tx, tz);
        if (!a.onGround && a.path == null) return WP;
        // 0.9: somewhere on another floor is never "straight ahead", however clear the ground between is
        boolean otherFloor = !Float.isNaN(a.goalY) && a.goalYAt == r.time && Math.abs(a.goalY - a.y) > 1.6f;
        if (!otherFloor && d < 16 && nav.clearBody(a.x, a.y, a.z, tx, tz, false, a.radius * 0.9f)) { a.path = null; a.hasVia = false; return WP; }
        float gx = tx, gz = tz;
        // 1.0: the street graph is used for anything far - and for anything a grid route has just failed to reach (a search
        // that runs out stops at the cell nearest the goal as the crow flies, which is usually the wrong side of a building:
        // a body sent back there again and again was "stuck pathfinding")
        if (d > 44 || r.time < a.partialUntil && d > 9) {
            if (!a.hasVia || r.time - a.routeAt > 5 || a.distXZ(a.viaX, a.viaZ) < 5) {
                float[] v = nav.via(a.x, a.z, tx, tz, 30);
                a.routeAt = r.time;
                a.hasVia = v != null;
                if (v != null) { a.viaX = v[0]; a.viaZ = v[1]; }
            }
            if (a.hasVia) { gx = a.viaX; gz = a.viaZ; }
        } else a.hasVia = false;
        boolean moved = Math.abs(gx - a.pathTX) + Math.abs(gz - a.pathTZ) > 3;
        boolean stale = a.path == null ? r.time - a.pathAt > 0.6f : moved || r.time - a.pathAt > 4 || a.stuckTime > 1.2f && r.time - a.pathAt > 1;
        // the world changed along the way (a wall down, a door forced or blown): the old route is no longer trusted
        if (!stale && a.path != null && r.world.navTouched(a.pathNav, a.path, a.pathI)) stale = true;
        if (stale && nav.budget > 0) {
            nav.budget--;
            int expand = a.tier == 1 ? 900 : a.mate() ? 9000 : r.time < a.partialUntil ? 7000 : 3600;
            a.path = otherFloor && !a.hasVia ? nav.path(a.x, a.y, a.z, gx, a.goalY, gz, expand, doors) : nav.path(a.x, a.y, a.z, gx, gz, expand, doors);
            a.pathI = 0; a.pathAt = r.time; a.pathTX = gx; a.pathTZ = gz; a.pathNav = r.world.navVersion;
            // did it get there? If the route ends well short of where it was going, the next one goes by the streets
            if (a.path != null && !a.hasVia) { int pn = a.path.length / 3; float ex = a.path[(pn - 1) * 3] + 0.5f - gx, ez = a.path[(pn - 1) * 3 + 2] + 0.5f - gz; if (ex * ex + ez * ez > 3.5f * 3.5f) a.partialUntil = r.time + 12f; }
            else if (a.path == null && a.tier == 0) a.partialUntil = r.time + 12f;
            // the route stops short of where it was going, at a locked door: force it if this is that kind of moment
            if (doors && a.path != null && !a.mate()) forceEntry(r, a, gx, gz);
        }
        int[] p = a.path;
        if (p == null) { WP[0] = gx; WP[1] = gz; return WP; }
        int n = p.length / 3;
        // a path is followed in three dimensions: a cell is reached when the feet are at its height, not merely under it
        // (1.0: a doorway is gone through squarely - its cell is not "reached" until the body is nearly at the middle of it)
        while (a.pathI < n - 1 && a.distXZ(p[a.pathI * 3] + 0.5f, p[a.pathI * 3 + 2] + 0.5f) < (nav.choke(p[a.pathI * 3], p[a.pathI * 3 + 1], p[a.pathI * 3 + 2]) ? 0.32f : 0.75f) && Math.abs(p[a.pathI * 3 + 1] - a.y) < 1.15f) a.pathI++;
        // look a few cells ahead and cut the corner when the line to them is open - never across a ladder or a jump, never
        // past a doorway (1.0), and only where the whole width of the body can go (1.0: it was the width of a point)
        int pick = a.pathI, lim = a.pathI;
        boolean rungs = Physics.inClimb(r.world, a.x, a.y, a.z) && !a.onGround;
        while (!rungs && lim < Math.min(n - 1, a.pathI + 4) && p[(lim + 1) * 3 + 1] == p[lim * 3 + 1] && !nav.climb(p[(lim + 1) * 3], p[(lim + 1) * 3 + 1], p[(lim + 1) * 3 + 2]) && !nav.choke(p[lim * 3], p[lim * 3 + 1], p[lim * 3 + 2])) lim++;
        if (Math.abs(p[a.pathI * 3 + 1] - a.y) < 0.6f) for (int k = lim; k > a.pathI; k--) if (nav.clearBody(a.x, a.y, a.z, p[k * 3] + 0.5f, p[k * 3 + 2] + 0.5f, false, a.radius * 0.9f)) { pick = k; break; }
        int cx = p[pick * 3], cy = p[pick * 3 + 1], cz = p[pick * 3 + 2];
        // 0.9: the way leads up a wall two or three blocks high: hands on the edge and up (people only - the route was only
        // offered to them). The next cell of the path is the top of it; the body has to be at the foot and on its feet
        if (doors && a.pathI < n && a.onGround && !a.mantling() && r.time >= a.jumpAt && a.vital == absentialis.entity.Vital.ACTIVE && !a.crawling) {
            int ux = p[a.pathI * 3], uy = p[a.pathI * 3 + 1], uz = p[a.pathI * 3 + 2];
            if (uy >= a.y + 1.6f && uy <= a.y + Physics.MANTLE_MAX + 0.3f && a.distXZ(ux + 0.5f, uz + 0.5f) < 1.7f) {
                float[] to = Physics.ledge(r.world, a, ux + 0.5f - a.x, uz + 0.5f - a.z);
                if (to != null && Math.abs(to[1] - uy) < 0.6f) { Physics.mantle(a, to); a.jumpAt = r.time + a.mantleDur + 0.4f; r.mantles++; a.pathI = Math.min(n - 1, a.pathI + 1); if (a.anim != null) a.anim.action = ""; }
            }
        }
        // a closed door on the way: people open it, the dead do not
        if (doors) for (int k = a.pathI; k <= Math.min(n - 1, a.pathI + 1); k++) {
            int qx = p[k * 3], qy = p[k * 3 + 1], qz = p[k * 3 + 2];
            if (a.distXZ(qx + 0.5f, qz + 0.5f) < 1.9f && r.world.solid(qx, qy, qz)) { absentialis.scene.Doors.Door dr = r.doors.at(qx, qy, qz); if (dr != null) r.doors.open(dr, a); }
        }
        // ladders: with rungs in reach and the way leading up or down, take hold and climb (forward climbs, as for the player)
        if (Physics.inClimb(r.world, a.x, a.y, a.z)) {
            // up: until the feet are clear of the level being climbed to (stopping level with it leaves the body hanging
            // on the top rung, a hand short of the roof); down: only once off the ground and above where the way leads
            if (cy > a.y + 0.3f || !a.onGround && cy > a.y - 0.25f) { a.wantClimb = true; a.climbDir = 1; }
            else if (cy < a.y - 0.6f && !a.onGround) { a.wantClimb = true; a.climbDir = -1; }
        }
        WP[0] = cx + 0.5f; WP[1] = cz + 0.5f;
        if (pick == n - 1 && a.distXZ(WP[0], WP[1]) < 0.6f && !a.hasVia && !otherFloor && Math.abs(gx - tx) + Math.abs(gz - tz) < 0.01f) { WP[0] = tx; WP[1] = tz; a.path = null; a.pathAt = r.time; }
        return WP;
    }

    /**
     * Forced entry. A locked door is an obstacle navigation routes round; an agent only puts a boot through one
     * when it has a reason - it is in a fight or hunting someone it believes is on the other side - and when its
     * doctrine allows the noise: soldiers and contractors breach, bandits kick anything in, loners never do.
     */
    private static void forceEntry(Raid r, Actor a, float gx, float gz) {
        if (r.time < a.kickAt) return;
        int n = a.path.length / 3;
        float ex = a.path[(n - 1) * 3] + 0.5f, ez = a.path[(n - 1) * 3 + 2] + 0.5f;
        if (Math.abs(ex - gx) + Math.abs(ez - gz) < 2.5f) return;                       // the path gets there
        absentialis.scene.Doors.Door d = r.doors.near(a.x, a.y, a.z, 1.8f);
        if (d == null || r.doors.state(d) != absentialis.scene.Doors.State.LOCKED) return;
        // the door has to be between here and where it is going
        float tx = gx - a.x, tz = gz - a.z, dx = d.cx() - a.x, dz = d.cz() - a.z;
        if (tx * dx + tz * dz <= 0) return;
        Relations.Doctrine dc = Relations.doc(a.faction).d();
        boolean hunting = "engage".equals(a.state) || "search".equals(a.state) && a.awareLevel >= NeuralHost.THREAT_AWARE;
        boolean may = dc == Relations.Doctrine.BANDIT && (hunting || "loot".equals(a.state)) || (dc == Relations.Doctrine.MILITARY || dc == Relations.Doctrine.MERC) && hunting;
        if (!may) return;
        a.kickAt = r.time + 0.9f;
        a.yaw = (float) Math.atan2(-dx, -dz);
        if (a.anim != null) a.anim.play("melee", 0.45f);
        if (r.doors.kick(d, a) && r.time - a.lastSay > 6) r.say(a, "Door's open - go!", "shout");
    }

    public static float turn(float cur, float target, float maxStep) {
        float d = target - cur;
        while (d > Math.PI) d -= Math.PI * 2;
        while (d < -Math.PI) d += Math.PI * 2;
        return cur + Math.max(-maxStep, Math.min(maxStep, d));
    }
}
