package absentialis.engine;

import absentialis.engine.render.Batch2D;

/**
 * The Astratto Engine (0.8): the technology Absentialis is built on, named and kept apart from the game so that it
 * outlives it. Everything under {@code absentialis.engine} (window and input, the hybrid GI renderer, voxel models,
 * the event bus, UltraEngine audio), the NeuralAI engine ({@code absentialis.neuralai}) and the Sydney Engine
 * ({@code absentialis.sydney}) belong to it; nothing in those packages names a place, a faction or an item of the
 * game. The game is what is built with it: {@code scene}, {@code gameplay}, {@code world}, {@code sim}, {@code rivalry}.
 *
 * Copyright Astratto North of LudusValley Recreations, under VEIN Enterprises.
 *
 * The engine's mark is the silhouette of a human brain, seen from the side. It is drawn from the grid below - one
 * shape, one colour - wherever the engine is credited: the title screen, the loading screen, the window title.
 */
public final class Astratto {
    private Astratto() {}

    public static final String NAME = "Astratto Engine";
    public static final String SHORT = "ASTRATTO";
    /** The engine's own version: it moves when the engine does, not when the game ships a build. */
    public static final String VERSION = "1.0";
    public static final String COPYRIGHT = "Astratto North of LudusValley Recreations, under VEIN Enterprises";
    public static final String NOTICE = "Copyright (c) " + COPYRIGHT;
    /** The systems that make it up, as they are credited. */
    public static final String[] SYSTEMS = {"Hybrid GI renderer", "NeuralAI", "Sydney Engine", "UltraEngine audio"};

    /**
     * The mark (1.0): Atlas, small, with the Earth held up on the palm of one hand - a figure standing braced, one arm
     * raised, and the globe resting on the flat of the hand above it. '#' is the silhouette; '.' is clear; '-' is a line
     * cut into the globe (drawn clear, so the continents read at any size).
     */
    public static final String[] LOGO = {
            "................######......",
            "..............##########....",
            ".............###-####-###...",
            "............####--###--###..",
            "............##-#####-#####..",
            "............#####--#######..",
            "............###-######-###..",
            ".............####-###-###...",
            "..............##########....",
            "................######......",
            "..................##........",
            "...............########.....",
            "....####.........###........",
            "...######........###........",
            "...######.......###.........",
            "....####.......###..........",
            "...########..####...........",
            "..##############............",
            "..#############.............",
            "..####.#######..............",
            "..###..#######..............",
            "..###..######...............",
            ".###...######...............",
            ".......#######..............",
            "......####.####.............",
            ".....####...####............",
            "....####.....###............",
            "...####......###............",
            "..####.......####...........",
            ".#####.......######.........",
    };

    public static int logoWidth() { return LOGO[0].length(); }
    public static int logoHeight() { return LOGO.length; }

    /** Draws the mark with its top-left corner at (x, y), each cell of the grid a square of the given size in pixels. */
    public static void drawLogo(Batch2D b, float x, float y, float cell, int argb) {
        for (int r = 0; r < LOGO.length; r++) {
            String row = LOGO[r];
            int run = -1;
            for (int c = 0; c <= row.length(); c++) {
                boolean on = c < row.length() && row.charAt(c) == '#';
                if (on && run < 0) run = c;
                if (!on && run >= 0) { b.rect(Math.round(x + run * cell), Math.round(y + r * cell), Math.round((c - run) * cell), Math.max(1, Math.round(cell)), argb); run = -1; }
            }
        }
    }

    /** The mark as pixels (ARGB, row-major, clear where it is not): for a window icon or anything else that wants an image. */
    public static int[] logoPixels(int scale, int argb) {
        int w = logoWidth() * scale, h = logoHeight() * scale;
        int[] px = new int[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) if (LOGO[y / scale].charAt(x / scale) == '#') px[y * w + x] = argb;
        return px;
    }
}
