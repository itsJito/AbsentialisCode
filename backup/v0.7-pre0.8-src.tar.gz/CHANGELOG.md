# Changelog

Newest first. Each version lists what changed for the player; file names are given where they help find the work.
What was verified for each version, and how, is in `docs/V0.7_IMPLEMENTATION.md` and `docs/V0.6_IMPLEMENTATION.md`.

## Version 0.7

What was verified for 0.7, how, and what was not, is in `docs/V0.7_IMPLEMENTATION.md`. Read its "Not done, partly
done, and not verified" section before trusting any line below.

### Human AI: the NeuralAI engine
- Every human NPC - hostile, neutral and the player's own squad - now thinks in a dedicated engine
  (`absentialis.neuralai.*`, tuning in `content/neuralai.json`, guide in `docs/neuralai-tuning-guide.md`), built to
  `NeuralAI.md`. Nobody reads a target's position: each mind has what its own eyes and ears gave it (a vision
  meter that fills with exposure, sounds with an error that grows with distance and walls), what it was told
  (reports that arrive by voice or radio, late and second-hand) and what it found (bodies, blood), held as beliefs
  with an uncertainty that grows while the target is unseen.
- From that it searches (a shared grid of regions, divided between the squad), takes cover it has reserved, is
  dealt a role (hold, suppress, advance, flank left or right, retreat) that is re-dealt as the fight changes,
  fights from cover in bursts, fires at where it believes the target is, holds fire when a friend is in the line,
  closes to a blow at arm's length, and gives up a route the body reports blocked.
- **Squadmates no longer see through walls** (they were simply told who shot them, and where). They use the same
  engine as everyone else, follow behind the leader in two files, and keep to the order they were given.
- NPCs and squadmates **sprint** when the situation calls for it, and tire.
- Twelve acceptance scenarios from `NeuralAI.md` section 15 run with the gates (`ABS_SELFTEST=neural`).
- Console `ai`: an overlay of each mind's cone of sight, believed position and uncertainty ring, cover, destination
  and search regions - and, in magenta and labelled as developer-only, where the target really is.

### The infected
- They **wander** when they have nothing to hunt, turn their **heads** to a noise before their bodies, and go to
  look. They are all called **Infected**, and only the special ones appear in the kill feed.
- They **climb through one-block openings** up to three blocks above their feet (up the wall, through on the
  belly, down the far side), and choose an opening over a long walk round. A **Wooden Plank** boards one up ([F]).
- **Special infected**: the Boomer is the **Bomber** (it bursts into bile and no longer spits); the **Spewer**
  spits pools that burn; the **Tank** knuckle-walks, and picks anyone up in one hand and throws them fifteen feet;
  the **Gladiator** is blind, armoured everywhere but its back, comes at a run to any noise and takes heads at
  head height (crouch, or stand still); the **Butcher** rushes what it sees with a chainsaw - a round to its head
  during the wind-up stops the swing. Every attack has a wind-up you can see and hear.
- **Infected bile**: dark green, on the blood system. It does no damage; whoever wears it is hunted by every
  infected within 45 m for 15 seconds and sees through a green blur for as long.

### Sydney Engine and bodies
- Fall study: ten kinds of hit photographed every fourth frame and tiled into contact sheets
  (`docs/v0.7/falls/`, `ABS_SCENARIO=falls`). From it: a dying body **collapses from the ground up** (knees, hips,
  then the trunk) instead of tipping like a plank; a body keeps its **momentum** (the air used to take three
  quarters of its speed every second and the ground all of it); blood pools are a metre across, darker, and no
  longer glow.
- **Vehicles and people**: above a walking pace of closing speed a pedestrian is knocked down and carried by the
  bodywork - legs taken at town speed, the whole body thrown at speed - and a body lying in the road is shoved and
  rolled by a car driven over it.
- **Car doors** lead: to the door while it opens, in through it, and it is pulled shut; out the same way.

### World
- The map, districts, roads and building positions are unchanged.
- **Ceilings are four blocks** everywhere (storeys are five blocks slab to slab; stairs have a fifth tread).
- **Interiors refurnished**: furniture has the shape of furniture (desks, screens, monitors, basins, bins, racks,
  plants, standing lamps, bedside tables, a ceiling fitting that is a fitting); shop shelving is short broken runs,
  mostly bare frames with a few stocked units, heaps and counters; no row of three of the same container anywhere;
  homes are plastered and papered where they were shuttered concrete; daylight reaches indoors.
- **Procedural foliage**: boughs, overlapping noise-shaped leaf clusters, four tones of leaf, soft shading among
  leaves, faces between leaves culled. Trees no longer reach into rooms or over stair heads.
- **Fog** is heavier outdoors (from 30 m, complete by 118 m) and thin under a roof.
- **devmap** (console `devmap [0-3]`, `devmap off`): a walled test field with a 170 m road, an 11 x 11 maze, the
  Zone's mansion on two storeys with a double door, and a yard of cover, openings, glass, containers and ladders.

### Operator, squad, shop
- **No deployment time limit.** Choose **Morning, Afternoon or Midnight**. Abandoning an operation keeps your gear.
- **Coins are Cash ($).** Shop departments: Weapons, Medical, Supplies, Armor, Vehicles, and Sell. Rank-locked
  items are hidden until unlocked; unlocks are announced after an operation. Prices and ammunition per the 0.7
  table; new **Assault Rifle Ammo** for the Semi-Auto and Full-Auto Rifle; the Matilda fires single shots.
- **Rank 1 starts with** a loaded Handgun, 30 rounds, a knife and a First Aid Spray. The Shotgun opens at Rank 2.
- **No squadmates at Rank 1.** A slot opens at Rank 4 and every fourth rank to 36; squadmates are hired in the
  shop and come with the standard kit of their type, shown as equipment rather than a weapon list. The squad
  deploys behind you.
- The character is fixed at creation; the old Operator tab is gone and Rank is now Operator. Treatment is gone
  from it. The player is a third party who declares an allegiance rather than joining a group.
- **Crafting**: ten new recipes (powders, plank, casing); the craft list shows only what can be made now, as
  cards, counts the stash at home, scrolls inside its panel. **Shift-click** equips when nothing else is open.
- New items, armour, hats and gems with their models; corpses carry what they wore and are drawn without it once
  it is taken.

### Handling
- No shot on the click that closes a menu. Hold crouch to go **prone**; crawl any way; sprint from crouch or prone.
- Grenades are **equipped** and thrown along a drawn arc. The knife is larger and stays in the hand.
- Cover is taken side-on with free look. A handgun hangs at rest and is held in both hands to aim.
- A weapon light is a light on the weapon. Guns eject brass their own way and smoke at the muzzle. The First Aid
  Spray is sprayed. Eyes blink, and close in death. The HUD portrait faces front.

### Audio
- **Removed**: every synthesised district bed (the Outskirts hiss, the Residential air, Downtown's bells, the
  hum and drone), and the failed-reload noise.
- **Recorded voices** for the infected and for people, 39 takes from three CC0 packs (`ATTRIBUTION.md`); people cry
  out when hit and when they die. Chosen by measurement, not by ear - see the tracker.
- Weapon sounds were **not** replaced (see the tracker).

### Developer
- `ABS_SCENARIO=<name>` runs a short scripted visual check (`shop`, `menus`, `specials`, `falls`, `car`,
  `interiors`, `devmap`). A gate group that throws is one failed gate, and the suite goes on.
- Console: `devmap`, `time <hour>`, `weaponlevel`, `ai`.

## Version 0.6

### World and buildings
- The map, its districts and its roads are unchanged. **Buildings were rebuilt**: a late-Soviet street - panel
  blocks with balconies, sand-lime and red brick, dark plinths, concrete entrance canopies, windows two panes tall.
- **Stairs fixed.** Every flight has a fourth tread level with the floor it reaches and clear head room over every
  tread (0.5 stopped one rise short and left the slab over the first step).
- Two-cell entrances are **double doors**: one object, two leaves.
- Interiors are **furnished densely** (about half of every room's wall is taken), storage stands two tiers high,
  corridors have the two-tone painted wall, and every room has its light fitting, lit or dead.
- **Textures redrawn at 64 x 64** (were 32 x 32): masonry, panels, plaster, roofing, floors, carpets, ceilings.
  Windows are a casement round a pane. No redrawn texture carries lettering; torn wallpaper and the ringed lamp
  are gone.
- **Fog bank**: the world dissolves from 48 m and is gone by 165 m, inside the draw distance, so nothing is drawn
  at its edge. Nearer at night and in rain. Nobody sees or shoots through it either (`content/combat.json`).
- A broken window leaves **physical shards**, thrown the way the round was going.

### Movement and camera
- **No auto-jump**, for the player or anyone else: a block in the way is jumped, stairs are walked.
- **Third person rebuilt**: right-shoulder camera with free look, smooth tracking, aim zoom, and framing that
  follows what the body is doing; movement relative to the camera in every direction; the body turns to its
  travel; weighted acceleration and turning; a **slide** from crouching after two seconds of sprint. Sprint can be
  held or toggled; distance, shoulder and smoothing are settings.
- Characters **do not pass through each other**. Bodies push doors open; a door rests against someone standing in it.
- Fixed: a door could push you up a floor. Fixed: A steered the car right.

### Combat
- **Sydney Engine** (`sydney/*`, `content/sydney.json`): the passive ragdoll became an active one. A hit body is
  given to physics with the momentum of the blow where it landed; sensors read its balance, virtual muscles
  (bounded PD torques) work to keep it up, and the solver decides. It sways, catches itself with a step, or goes
  down reaching for the ground, lies there, and gets up under its own strength - or is left to crawl if a leg is
  gone. People put a hand to the wound; the infected take more to put down and do not. The player's character is
  given to it only by death. Console: `sydney on|off|stats`.
- **Shotguns** hit much harder; a close-range head shot takes the head off. **Handguns never do.**
- A pump shotgun is **racked after a full reload** before it will fire.
- Firing has weight by weapon: a handgun snaps, a shotgun or a magnum rocks the upper body and settles more slowly.
- **Optics help**: the red dot and the holographic sight are open windows with a projected reticle; scopes have a
  proper sight picture.
- **Gun audio** levelled by measurement: no firearm is quiet, shotguns are the heaviest report, the crossbow has
  its own sound. The industrial hum and static are gone.
- Fixed: crash when drawing a weapon from the Tab wheel. Fixed: the AI could not use ladders.

### People
- **Male or female** bodies (narrower arms, trunk and head; six more hairstyles). Generated names are American
  and match the body.
- **Name tags** over heads in the colour the minimap gives them; squadmates' are always shown.
- The dead **close their eyes**. The infected **eat human corpses**, which waste away and are finally gone.
- AI sight uses three lines to a body (half hidden is half as noticeable), registers the edge of its vision more
  slowly, and looks along the ground until alerted; a floor between muffles sound; the alerted hear further.
- **Barter** with anyone not hostile - goods for goods, on terms set by what their group thinks of you - and pass
  kit freely to and from **squadmates** ([F], facing them).
- **Squadmate permadeath**: a squadmate who dies is gone, with rank and record; replacements are recruited and
  paid for.

### Vehicles
- The driver's door is a **real door** on the door engine: it opens to let you in, shuts behind you, takes damage
  on its hinge and its latch, and can be shot off - after which there is no door to open.
- Getting in and out have their own animations. **Squadmates ride along** (up to three) and get out when you do.

### Items and interface
- The **flashlight is an object**: carry one in the case (one is issued to every profile) or fit the Mounted
  Flashlight to any firearm from the first day. [L], rebindable.
- Herbs are the colour they are called; **Green + Red + Yellow** is a new mixture and shows all three.
- **Six ammunition models**, one per calibre. Shop tabs: a handgun for Weapons, cartridges for Ammo.
- **XP bar** with the percentage to the next Rank, and a line for every award as it is earned.
- **Profile card** with ten backgrounds unlocked by Rank; squadmates have the same card.
- [F] closes the loot menu. Dev console: `money`, `vehicle`.

### The Zone
- **Alliance**, chosen once after creating a profile (Military, Bandits, Loners, Mercenaries): it decides where
  you can deploy from and what work you are offered.
- **Population** sliders before profile creation, overall and per group.
- **Leaderboard** tab on the deployment screen: everyone alive, ranked. Every NPC has a Rank.
- **Group Rivalry System** (`rivalry/*`, `content/rivalry.json`): groups and their leaders remember what you do
  and what they hear of it, adapt to it and act on it; a Rivalries tab shows where you stand and what you can do.
- Fixed: extraction points on the city wall read as Wilderness and irradiated you.

### Project
- Version 0.6 in one place (`absentialis.Version`); save format 6 with migration from 5 (nothing is lost: a
  flashlight is issued, generated squad names are redrawn, typed names are kept).
- 483 quality gates (89 new for 0.6).

## Version 0.5

### World
- Rewrote city generation as a twelve-stage, data-driven pipeline (`content/districts.json`,
  `content/buildings.json`): district layout by terrain suitability, protected road network, lots, landmark
  compounds, room-graph interiors, furnishing, validation with repair or rejection, and a generation report.
- Six environments: Residential, Industrial, Governmental, Downtown, Outskirts, Wilderness. Each developed district
  has exactly two landmark compounds and one faction headquarters.
- Every room of every building is reachable from the street; buildings that cannot be made so are repaired or removed.
- Fixed: the perimeter trench; glass-like towers outside the boundary; floating dead-tree canopies; canopies
  blocking road cells.
- Cover points generated from world geometry, per chunk, invalidated when blocks change.
- Debug layers as PNGs (`ABS_GENDUMP`): plan, footprints, rooms, navigation, invalid cells, materials, cover.

### Combat and characters
- Tactical AI: utility-scored intents (hold, peek, suppress, advance, relocate, withdraw) over a squad blackboard;
  cover selection from the cover map; leaning and pop-up fire; chokepoint awareness; rescue of downed allies.
- Casualty state machine ACTIVE -> DOWNED -> REVIVING -> ACTIVE (or DEAD): 20 s bleed-out, 4 s revive,
  interruptible. Infected are never downed. Fatal regions and catastrophic damage always kill.
- Fixed: the player's body vanished on death.
- Four health conditions with configurable thresholds (`content/combat.json`) affecting speed, sprint, aim and
  animation.
- Cover for the player in first and third person; cover and injury animation layers.
- Physical doors: hinge swing, regional damage, latch and hinge failure, debris, navigation updates, AI door use.
- Aim-down-sights aligned from each weapon model's own sight line, with eased blending.
- Yellow Herbs raise maximum health permanently (saved with the profile, kept through prestige).

### Interface
- Status module (lower right): portrait, health arc that lengthens with maximum health, loaded and reserve ammunition.
- Squad status column and killfeed on the left; one line per confirmed death, none for incapacitation.
- Hit marker from confirmed events only: white hit, yellow incapacitation, red kill.
- Minimap contacts coloured by relation (blue squad with facing, green friendly, yellow neutral, red hostile).
- World-space speech bubbles driven by the existing dialogue.
- Resolution-independent layout helpers; fixed the Insertion Point text overflow in the hideout.

### Audio
- Layered gun audio (`engine/audio/gun`): per-weapon profiles, sample-accurate shot scheduling, transient / body /
  tail / distant / mechanical layers, voice budgets, occlusion, early reflections, one shared late reverb,
  compressor and limiter. Player and NPC fire use the same path.
- Recorded assets with documented licences (`ATTRIBUTION.md`, `docs/audio/weapon_asset_manifest.md`), a reproducible
  pipeline (`gradlew prepareAudio`), originals preserved in `tools/audio/originals/`.
- Recorded footsteps for nine surfaces, with variation. Reload cues play recorded handling sounds on the reload
  animation's clock. Door latch, kick and break sounds.

### Project
- Version 0.5 in one place (`absentialis.Version`); save format 5 with migration from 4.
- 394 quality gates (81 new for 0.5).

## Version 0.4

### Fixed
- **No audio.** The Windows Volume Mixer entry for the Java runtime was at 0%. The game now checks its own mixer
  session at start-up and restores it (`engine/audio/WinAudioSession`), shows the device and mixer level, and has
  a test-sound button with live meters. The mixer thread survives a device fault.
- **Crash** in the blood system (`ConcurrentModificationException`): the gore, projectile, thrown and zone loops no
  longer change a list while walking it.
- [F] only plays the interact animation when something was interacted with.
- Weapon icons are fitted to the model and drawn side-on, so every gun fills the tile it occupies.
- A container closes itself a moment after the last item is taken.

### Changed
- **Infection** (`scene/InfectionSystem`): bites can break the skin; BITTEN > FEVER > SICK > CRITICAL with
  symptoms; Antiviral Medicine cures it at any stage. Untreated, the player dies and rises; NPCs turn in the body
  they had.
- **Death**: third-person view of the body as the picture drains, then RESPAWN / MAIN MENU / QUIT. Ironman makes
  death permanent.
- **Lighting** (`engine/render/HybridRenderer`): OpenGL 4.5 deferred PBR in HDR - cascaded sun shadows, tiled light
  culling, shadowed local lights, irradiance probes, GTAO, reflections, volumetric fog, TAA, bloom, auto-exposure.
  Four presets; falls back to the 0.3 renderer without GL 4.5 (`ABS_LEGACY_GL=1`).
- **Damage** (`anatomy/*`, `scene/Gore`): bodies are layered voxels; hits remove what they pass through; wounds
  persist; a limb comes away when what joins it fails.
- **Enemy AI** (`ai/Tactics`, `ai/SquadMind`, `ai/CloseCombat`): awareness from sight and sound only, memory that
  goes stale, squads that share information, roles, scored cover and flanks, suppression, coordinated search,
  close combat.
- **Vehicles** (`vehicle/*`): four-wheel rigid-body simulation at 50 Hz; eight vehicles in `content/vehicles.json`;
  bought in the shop, one per operation, at most four in an operation.
- **Deployment**: a one-page Operation Briefing.
- **Squad**: every squadmate can be renamed.
- **Fire** is a particle system with light, heat, rain and sound (`scene/FireSystem`); the fire voxel is gone.

### Added
- Version numbers on the title screen, hideout, HUD footer and saves.
