package absentialis.ai;

import absentialis.ai.Brain.Arch;
import absentialis.ai.Brain.Doc;
import absentialis.ai.Brain.Doctrine;
import absentialis.entity.Actor;
import absentialis.entity.Physics;
import absentialis.scene.AIInjuryAdapter;
import absentialis.scene.Raid;
import absentialis.world.CoverMap;
import java.util.List;

/**
 * Human combat AI (0.4): how armed people fight as a group that is trying to find, outmanoeuvre and kill someone
 * while staying alive - acting only on what each of them has seen, heard, found or been told.
 *
 * <b>Awareness.</b> Unaware (routine) -> Suspicious (something unexplained: go and look) -> Threat aware (a
 * hostile is about, position unknown: weapons up, hold ground, scan) -> Engaged (position confirmed: fight) ->
 * Searching (contact lost: hunt). Nothing resets: a squad that loses its quarry searches, then stays alert.
 *
 * <b>Knowledge.</b> An agent keeps the last place it <i>saw</i> the target, how the target was moving, and where
 * it now <i>assumes</i> the target is. Out of sight, the assumption drifts along the last heading for a moment and
 * then simply grows less certain; fire goes to the last known place, not the true one. Reports from squadmates
 * arrive when they can be heard (see {@link SquadMind}).
 *
 * <b>Roles.</b> Re-dealt every few seconds and after every casualty, loss of contact or flank:
 * aggressor (closes, cover to cover), suppressor (keeps the last known position under fire so others can move),
 * flanker (goes round out of sight and comes in from the side), defender (holds good cover, guards the wounded),
 * searcher (when there is nothing to shoot at). Fire is shared out: not everyone shoots at once.
 *
 * <b>Position.</b> Cover is scored, not found: protection from where the threat is believed to be, a line of fire
 * when standing, the right distance for the weapon, how exposed the run to it is, not on top of a squadmate, and
 * for a flanker the angle it gives. Cover that stops protecting is left: flanked, pinned too long, or a grenade.
 */
public final class Tactics {
    private Tactics() {}

    public static final int UNAWARE = 0, SUSPICIOUS = 1, THREAT_AWARE = 2, ENGAGED = 3, SEARCHING = 4;
    public static final String[] LEVEL = {"unaware", "suspicious", "threat aware", "engaged", "searching"};
    public static final String AGGRESSOR = "aggressor", FLANKER = "flanker", SUPPRESSOR = "suppressor", SEARCHER = "searcher", DEFENDER = "defender";

    // ------------------------------------------------------------------ speech: every line says something true
    private static final String[] COMPASS = {"north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west"};

    /** Compass bearing from one point to another (north is -z, east is +x), as a word the player can act on. */
    public static String bearing(float fx, float fz, float tx, float tz) {
        double a = Math.atan2(tx - fx, -(tz - fz));
        int i = (int) Math.floor((a + Math.PI * 2 + Math.PI / 8) / (Math.PI / 4)) % 8;
        return COMPASS[i];
    }

    private static String pick(Raid r, String... lines) { return lines[r.rng.nextInt(lines.length)]; }

    /** A squadmate to address by name: the nearest living one, or null when alone. */
    private static Actor buddy(Raid r, Actor a) {
        Actor best = null;
        float bd = 40;
        for (Actor m : r.nearby(a.x, a.z, 40)) {
            if (m == a || m.dead || m.isPlayer || m.squad != a.squad || !m.faction.equals(a.faction) || m.infected()) continue;
            float d = a.dist(m);
            if (d < bd) { bd = d; best = m; }
        }
        return best;
    }

    private static String name(Actor m) { return m == null || m.name.isEmpty() ? "" : Brain.callsign(m); }

    /** Says a line if the squad has not just spoken (so callouts do not pile on top of one another). */
    static boolean say(Raid r, Actor a, Raid.Squad sq, String text, String bark, float gap) {
        if (sq != null && r.time - sq.mind.lastSpeech < gap) return false;
        if (r.time - a.lastSay < 2.5f) return false;
        if (sq != null) sq.mind.lastSpeech = r.time;
        r.say(a, text, bark);
        return true;
    }

    // ------------------------------------------------------------------ knowledge
    /** The target is in plain sight this tick: the agent's own knowledge is exact, and it tells the squad. */
    static void sighted(Raid r, Actor a, Raid.Squad sq, Actor t) {
        boolean first = a.awareLevel != ENGAGED;
        a.awareLevel = ENGAGED;
        a.memConfirmed = true;
        a.memVX = t.vx; a.memVZ = t.vz;
        a.suspX = t.x; a.suspZ = t.z; a.suspTime = r.time;
        if (sq == null) return;
        SquadMind m = sq.mind;
        boolean reacquired = !m.inContact && m.lostAt > 0 && r.time - m.lostAt < 90;
        boolean news = !m.inContact || r.time - m.lastEyes > 2.5f;
        m.report(r, a, t.x, t.y, t.z, t.vx, t.vz, t.id, true, 1);
        if (news || first && r.time - m.lastSpeech > 4) {
            String dir = bearing(a.x, a.z, t.x, t.z);
            Doc dc = Brain.doc(a.faction);
            String line = reacquired ? pick(r, "Got him again - " + dir + "!", "There! " + dir + " side!")
                    : t.infected() ? "Infected, " + dir + "!"
                    : dc.d() == Doctrine.MILITARY ? pick(r, "Contact " + dir + "!", "Eyes on, " + dir + "!")
                    : dc.d() == Doctrine.MERC ? pick(r, "Contact, " + dir + ". Moving on him.", "Target " + dir + ".")
                    : dc.d() == Doctrine.BANDIT ? pick(r, "There he is - " + dir + "!", "Got one, " + dir + "!")
                    : pick(r, "Someone's there - " + dir + "!", "I see him, " + dir + "!");
            say(r, a, sq, line, "bark_contact", 1.2f);
        }
    }

    /** Takes in the squad's last report if it has reached this member: a position with error, held as hearsay. */
    static boolean receive(Raid r, Actor a, Raid.Squad sq) {
        if (sq == null) return false;
        SquadMind m = sq.mind;
        if (m.tTime <= a.lastTold || m.targetId == 0 || r.time - m.tTime > 12 || !m.reaches(r, a)) return false;
        a.lastTold = m.tTime;
        // do not let hearsay replace what this agent can see for itself right now
        if (a.memConfirmed && r.time - a.lastSeenTime < 1.0f) return false;
        float err = m.tConfirmed ? 2.5f : 6f;
        Brain.remember(r, a, m.tx + (r.rng.nextFloat() - 0.5f) * err, m.ty, m.tz + (r.rng.nextFloat() - 0.5f) * err, m.tConfirmed ? 0.7f : 0.4f, err);
        a.memConfirmed = false;
        a.memVX = m.tvx; a.memVZ = m.tvz;
        a.targetId = m.targetId;
        m.relays++;
        return true;
    }

    static float lostAfter(Doc dc) { return dc.d() == Doctrine.MERC ? 6f : dc.d() == Doctrine.MILITARY ? 5f : 3.5f; }

    // ------------------------------------------------------------------ roles
    /** Deals the squad's roles from who is fit for what, right now. */
    static void assignRoles(Raid r, Raid.Squad sq, Actor any) {
        SquadMind m = sq.mind;
        m.rolesAt = r.time;
        List<Actor> team = r.squadMembers(any);
        int fit = 0;
        for (Actor a : team) if ((a.impaired & (AIInjuryAdapter.CANT_WALK | AIInjuryAdapter.CANT_SHOOT)) == 0 && a.ragdoll == null) fit++;
        boolean contact = r.time - m.lastEyes < 8;
        float caution = m.caution(r.time);
        boolean staticTarget = m.inContact && r.time - m.staticSince > 6;
        int wantFlank = fit >= 3 && contact ? (staticTarget && fit >= 5 ? 2 : 1) : 0, wantSuppress = fit >= 2 && contact ? 1 : 0;
        int wantAggro = contact ? Math.max(1, Math.round((fit - wantFlank - wantSuppress) * (0.6f - caution * 0.4f))) : 0;
        boolean[] used = new boolean[team.size()];
        // the wounded and the unarmed hold cover; everyone else is ranked for each job in turn
        for (int i = 0; i < team.size(); i++) {
            Actor a = team.get(i);
            if ((a.impaired & (AIInjuryAdapter.CANT_WALK | AIInjuryAdapter.CANT_SHOOT)) != 0 || a.injurySeverity > 0.55f || a.hp < a.maxHp * 0.3f) { role(m, a, DEFENDER); used[i] = true; }
        }
        deal(r, m, team, used, SUPPRESSOR, wantSuppress);
        deal(r, m, team, used, FLANKER, wantFlank);
        deal(r, m, team, used, AGGRESSOR, wantAggro);
        for (int i = 0; i < team.size(); i++) if (!used[i]) role(m, team.get(i), contact ? DEFENDER : SEARCHER);
    }

    private static void deal(Raid r, SquadMind m, List<Actor> team, boolean[] used, String role, int n) {
        for (int k = 0; k < n; k++) {
            int best = -1;
            float bs = -1e9f;
            for (int i = 0; i < team.size(); i++) {
                if (used[i]) continue;
                Actor a = team.get(i);
                float d = a.distXZ(m.tx, m.tz), s = 0;
                boolean shot = "shotgunner".equals(a.archetype), mark = "marksman".equals(a.archetype);
                switch (role) {
                    case SUPPRESSOR -> s = (mark ? -1 : 1) + (a.weapon != null && a.weapon.def().weapon.modes.contains("auto") ? 2 : 0) + (r.time - a.lastSeenTime < 3 ? 1.5f : 0) - Math.abs(d - 22) * 0.05f;
                    case FLANKER -> s = (shot ? 2 : 0) + (mark ? -3 : 0) + a.risk * 2 + a.hp / a.maxHp - d * 0.02f - (role.equals(a.tacRole) ? -1.5f : 0);
                    default -> s = (shot ? 1.5f : 0) + (mark ? -2.5f : 0) + a.risk * 2.5f + a.morale - d * 0.04f;
                }
                // a role already being carried out is worth keeping: squads that reshuffle constantly do nothing
                if (role.equals(a.tacRole)) s += 1.2f;
                if (s > bs) { bs = s; best = i; }
            }
            if (best < 0) return;
            used[best] = true;
            role(m, team.get(best), role);
        }
    }

    private static void role(SquadMind m, Actor a, String role) {
        if (role.equals(a.tacRole)) return;
        a.tacRole = role;
        a.hasCover = false; a.relocateAt = 0;
        m.roleChanges++;
    }

    // ------------------------------------------------------------------ position
    /**
     * Chooses where this agent should be for its role against a threat believed to be at (tx, ty, tz), and stores
     * it as the agent's cover. Returns false when nothing better than where it stands was found.
     */
    static boolean pickPosition(Raid r, Actor a, Raid.Squad sq, String role, float tx, float ty, float tz, float want) {
        float bx = a.x, bz = a.z, best = -1e9f;
        boolean found = false;
        // where the role would ideally stand
        float ax = a.x, az = a.z;
        float toX = tx - a.x, toZ = tz - a.z, tl = Math.max(0.1f, (float) Math.sqrt(toX * toX + toZ * toZ));
        toX /= tl; toZ /= tl;
        if (role.equals(FLANKER)) {
            // round to the side: ninety-odd degrees off the line the squad is fighting along, at assault range
            float side = (a.id & 1) == 0 ? 1 : -1;
            float cx = a.homeX, cz = a.homeZ;
            if (sq != null) { int n = 0; cx = 0; cz = 0; for (Actor m : r.squadMembers(a)) { cx += m.x; cz += m.z; n++; } cx /= Math.max(1, n); cz /= Math.max(1, n); }
            float ang = (float) Math.atan2(cx - tx, cz - tz) + side * 1.65f;
            ax = tx + (float) Math.sin(ang) * 11; az = tz + (float) Math.cos(ang) * 11;
        } else if (role.equals(AGGRESSOR)) {
            float step = Math.min(9f, Math.max(0, tl - Math.max(6f, want * 0.6f)));
            ax = a.x + toX * step; az = a.z + toZ * step;
        } else if (role.equals(DEFENDER)) { ax = a.x * 0.6f + a.homeX * 0.4f; az = a.z * 0.6f + a.homeZ * 0.4f; }
        List<Actor> near = r.nearby(a.x, a.z, 16);
        // ---- real cover first: the points the world's geometry offers, scored on everything that makes cover good
        r.world.cover.release(a.cover, a.id);
        a.cover = null; a.leanTarget = 0;
        CoverMap.Point pick = null;
        POINTS.clear();
        r.world.cover.near(a.x, a.y, a.z, 12, POINTS);
        if (Math.abs(ax - a.x) + Math.abs(az - a.z) > 5) r.world.cover.near(ax, a.y, az, 7, POINTS);
        float[] choke = role.equals(DEFENDER) ? chokepoint(r, a, tx, tz) : null;
        for (int i = 0; i < POINTS.size(); i++) {
            CoverMap.Point p = POINTS.get(i);
            if (!p.freeFor(a.id, r.time)) continue;                                   // occupied: nobody shares a narrow position
            float face = p.facing(tx, tz);
            if (face < 0.3f) continue;                                               // the obstacle is not between this point and the threat
            float px = p.cx(), pz = p.cz();
            if (r.zoneAt(px, p.y, pz) != null || r.fire.at(px, p.y, pz) != null) continue;
            boolean hidden = !Physics.los(r.world, px, p.y + (p.hidesStanding() ? 1.55f : 0.8f), pz, tx, ty + 1.3f, tz);   // it blocks incoming fire
            if (!hidden) continue;
            // a firing angle from here: over the top of low cover, or round an end of high cover
            boolean canFire = false;
            if (p.height == CoverMap.LOW) canFire = Physics.los(r.world, px, p.y + 1.6f, pz, tx, ty + 1.3f, tz);
            else for (int side = -1; side <= 1 && !canFire; side += 2) if (side < 0 ? p.leanLeft : p.leanRight) canFire = Physics.los(r.world, px + p.leftX() * -side * 0.9f, p.y + 1.5f, pz + p.leftZ() * -side * 0.9f, tx, ty + 1.3f, tz);
            float d = (float) Math.sqrt((px - tx) * (px - tx) + (pz - tz) * (pz - tz)), run = a.distXZ(px, pz);
            float s = 4f + face * 1.5f;
            s += canFire ? (role.equals(DEFENDER) ? 1.2f : 2.4f) : role.equals(FLANKER) ? 0.6f : -1.2f;
            s -= Math.abs(d - (role.equals(AGGRESSOR) ? Math.max(6f, want * 0.6f) : role.equals(FLANKER) ? 11f : want)) * 0.16f;       // distance from the threat
            s -= run * (role.equals(SUPPRESSOR) || role.equals(DEFENDER) ? 0.22f : 0.1f);                                                // how far the move is
            if (run > 3 && Physics.los(r.world, (a.x + px) / 2, a.y + 1.2f, (a.z + pz) / 2, tx, ty + 1.3f, tz)) s -= 1.4f;               // exposure on the way there
            s += p.height == CoverMap.HIGH ? 0.5f : 0.25f;                                                                              // height: a standing body is covered too
            s += p.integrity * 1.4f - (p.integrity < 0.3f ? 1.6f : 0);                                                                  // how long it will stand up to fire
            for (Actor o : near) {
                if (o == a || o.dead || o.infected() || !o.faction.equals(a.faction)) continue;
                float od = o.hasCover ? (float) Math.sqrt((o.coverX - px) * (o.coverX - px) + (o.coverZ - pz) * (o.coverZ - pz)) : o.distXZ(px, pz);
                if (od < 1.6f) s -= 3.5f; else if (od < 9) s += 0.25f;                                                                   // spaced out, but within support
            }
            if (p.leanLeft || p.leanRight) s += 0.4f;                                                                                   // an end to go round is also a way out
            if (role.equals(FLANKER)) { float fx = px - tx, fz = pz - tz, fl = Math.max(0.1f, (float) Math.sqrt(fx * fx + fz * fz)); s += (1 - Math.abs(-(fx * toX + fz * toZ) / fl)) * 3f; }
            if (role.equals(DEFENDER)) {
                s -= (float) Math.sqrt((px - a.homeX) * (px - a.homeX) + (pz - a.homeZ) * (pz - a.homeZ)) * 0.05f;
                // a defender takes the position that covers the way in
                if (choke != null) { float cd = (float) Math.sqrt((px - choke[0]) * (px - choke[0]) + (pz - choke[2]) * (pz - choke[2])); if (cd > 3 && cd < 16 && Physics.los(r.world, px, p.y + 1.5f, pz, choke[0], choke[1] + 1f, choke[2])) s += 1.8f; }
            }
            if (s > best) { best = s; bx = px; bz = pz; found = true; pick = p; }
        }
        if (pick != null) {
            a.cover = pick;
            r.world.cover.claim(pick, a.id, r.time + 6);
            a.coverX = bx; a.coverZ = bz; a.hasCover = true;
            a.coverSince = r.time;
            a.coverDirX = toX; a.coverDirZ = toZ;
            a.relocateAt = r.time + 7 + r.rng.nextFloat() * 6;
            return true;
        }
        best = -1e9f; found = false;
        for (int k = 0; k < 34; k++) {
            // half the candidates around where the agent stands, half around where the role wants it
            boolean ideal = k >= 14;
            float ang = k * 2.399963f + a.id, rad = ideal ? 0.5f + ((k - 14) % 7) * 1.1f : 1.2f + (k % 7) * 1.25f;
            float px = (float) Math.floor((ideal ? ax : a.x) + Math.sin(ang) * rad) + 0.5f, pz = (float) Math.floor((ideal ? az : a.z) + Math.cos(ang) * rad) + 0.5f;
            int gy = r.groundY((int) px, (int) pz);
            if (gy < 0 || Math.abs(gy - a.y) > 2.2f || !Physics.boxFree(r.world, px, gy, pz, a.radius, a.stand)) continue;
            if (r.zoneAt(px, gy, pz) != null || r.fire.at(px, gy, pz) != null) continue;
            boolean hidden = !Physics.los(r.world, px, gy + 0.8f, pz, tx, ty + 1.3f, tz);
            boolean canFire = Physics.los(r.world, px, gy + 1.6f, pz, tx, ty + 1.3f, tz);
            float d = (float) Math.sqrt((px - tx) * (px - tx) + (pz - tz) * (pz - tz)), run = a.distXZ(px, pz);
            float s = 0;
            s += hidden ? 4f : 0;                                   // protection from where the threat is believed to be
            s += canFire ? (role.equals(DEFENDER) ? 1.2f : 2.4f) : role.equals(FLANKER) ? 0.6f : -1.2f;   // a firing angle when standing
            s -= Math.abs(d - (role.equals(AGGRESSOR) ? Math.max(6f, want * 0.6f) : role.equals(FLANKER) ? 11f : want)) * 0.16f;   // the right distance
            s -= run * (role.equals(SUPPRESSOR) || role.equals(DEFENDER) ? 0.22f : 0.1f);   // how far, and so how exposed, the move is
            if (run > 3 && Physics.los(r.world, (a.x + px) / 2, a.y + 1.2f, (a.z + pz) / 2, tx, ty + 1.3f, tz)) s -= 1.4f;   // the run crosses open ground in view
            for (Actor o : near) {
                if (o == a || o.dead || o.infected() || !o.faction.equals(a.faction)) continue;
                float od = o.hasCover ? (float) Math.sqrt((o.coverX - px) * (o.coverX - px) + (o.coverZ - pz) * (o.coverZ - pz)) : o.distXZ(px, pz);
                if (od < 1.6f) s -= 3.5f; else if (od < 9) s += 0.25f;      // never the same spot; within support is good
            }
            if (role.equals(FLANKER)) {
                // the angle it gives on the target relative to the squad's line of fire
                float fx = px - tx, fz = pz - tz, fl = Math.max(0.1f, (float) Math.sqrt(fx * fx + fz * fz));
                float cos = -(fx * toX + fz * toZ) / fl;
                s += (1 - Math.abs(cos)) * 3f;
            }
            if (role.equals(DEFENDER)) s -= (float) Math.sqrt((px - a.homeX) * (px - a.homeX) + (pz - a.homeZ) * (pz - a.homeZ)) * 0.05f;
            // a way out: another covered cell next to it
            int ix = (int) Math.floor(px), iz = (int) Math.floor(pz);
            if (hidden && (!r.world.solid(ix + 1, gy, iz) && !Physics.los(r.world, ix + 1.5f, gy + 0.8f, iz + 0.5f, tx, ty + 1.3f, tz) || !r.world.solid(ix - 1, gy, iz) && !Physics.los(r.world, ix - 0.5f, gy + 0.8f, iz + 0.5f, tx, ty + 1.3f, tz))) s += 0.6f;
            if (s > best) { best = s; bx = px; bz = pz; found = true; }
        }
        if (!found) return false;
        a.coverX = bx; a.coverZ = bz; a.hasCover = true;
        a.coverSince = r.time;
        a.coverDirX = toX; a.coverDirZ = toZ;
        a.relocateAt = r.time + 7 + r.rng.nextFloat() * 6;     // nobody stays put for ever
        return true;
    }

    private static final java.util.ArrayList<CoverMap.Point> POINTS = new java.util.ArrayList<>();

    /**
     * The way in that a defender should watch: the doorway of the building it is defending (or stands in) that
     * lies nearest the threat. Null when there is no such building or no door within reach.
     */
    static float[] chokepoint(Raid r, Actor a, float tx, float tz) {
        absentialis.world.MapData.Building b = r.world.map.buildingAt((int) Math.floor(a.homeX), (int) Math.floor(a.homeZ));
        if (b == null) b = r.world.map.buildingAt((int) Math.floor(a.x), (int) Math.floor(a.z));
        if (b == null || !b.valid) return null;
        absentialis.world.MapData.Doorway best = null;
        float bd = Float.MAX_VALUE;
        for (absentialis.world.MapData.Doorway d : b.doors) {
            if (!d.exterior || Math.abs(d.y - a.y) > 2) continue;
            float dd = (d.x - tx) * (d.x - tx) + (d.z - tz) * (d.z - tz);
            if (dd < bd) { bd = dd; best = d; }
        }
        return best == null || a.distXZ(best.x + 0.5f, best.z + 0.5f) > 24 ? null : new float[]{best.x + 0.5f, best.y, best.z + 0.5f};
    }

    // ------------------------------------------------------------------ utility layer
    /** What an engaged agent has decided to do with the next second or so. The role says what it is for; this says what it does now. */
    public static final String HOLD = "hold", PEEK = "peek", SUPPRESS_FIRE = "suppress", ADVANCE = "advance", RELOCATE = "relocate", WITHDRAW = "withdraw";

    /**
     * High-level decision selection by utility (brief 3.1). Each option is scored from what the agent itself
     * knows and feels - whether it can see the target, how sure it is of where the target is, how much fire it is
     * taking, how hurt it is, what its role is for, how the fight is going for the squad - and the best is kept
     * for about a second so a fighter commits to what it started. The behaviour below carries it out.
     */
    static String decide(Raid r, Actor a, Raid.Squad sq, Actor t, boolean seen, float kd, float want, boolean atPost) {
        if (r.time < a.intentUntil && !a.intent.isEmpty()) return a.intent;
        float adv = advantage(r, a, sq, t, seen);
        float hurt = 1f - a.hp / Math.max(1f, a.maxHp), sup = a.suppression, since = r.time - a.lastSeenTime;
        boolean pinned = r.time < a.pinnedUntil, loaded = a.weapon != null && a.weapon.rounds > 0;
        float hold = 0.25f + sup * 1.3f + (pinned ? 0.9f : 0) + (loaded ? 0 : 0.8f) + hurt * 0.5f;
        float peek = (atPost ? 0.9f : 0.2f) + (seen ? 0.5f : 0.25f) + a.risk * 0.5f - sup * 0.9f - (pinned ? 1.2f : 0) + (since < 4 ? 0.3f : 0);
        float suppress = a.tacRole.equals(SUPPRESSOR) && !seen && since < 7 && kd > 6 && kd < 70 ? 1.25f - sup * 0.7f - (pinned ? 1f : 0) : -1;
        float advance = a.tacRole.equals(AGGRESSOR) || a.tacRole.equals(FLANKER) ? 0.35f + adv * 0.9f + a.risk * 0.5f - sup * 1.1f - hurt * 0.9f + (kd > want * 1.2f ? 0.4f : -0.3f) + (r.time - a.coverSince > 4 ? 0.3f : -0.4f) : -1;
        float relocate = (a.cover != null && (!a.cover.valid || a.cover.integrity < 0.25f) ? 1.6f : 0) + (r.time - a.flankedAt < 1 ? 1.8f : 0) + (pinned && r.time - a.coverSince > 4.5f ? 1.1f : 0) + (!a.hasCover ? 0.8f : 0);
        float withdraw = hurt > 0.7f ? 0.6f + hurt + sup * 0.5f - a.risk * 0.6f + (sq != null ? sq.mind.caution(r.time) * 0.6f : 0.3f) : -1;
        String best = HOLD;
        float bs = hold;
        if (peek > bs) { bs = peek; best = PEEK; }
        if (suppress > bs) { bs = suppress; best = SUPPRESS_FIRE; }
        if (advance > bs) { bs = advance; best = ADVANCE; }
        if (relocate > bs) { bs = relocate; best = RELOCATE; }
        if (withdraw > bs) { bs = withdraw; best = WITHDRAW; }
        if (!best.equals(a.intent)) a.intentChanges++;
        a.intent = best; a.intentScore = bs;
        a.intentUntil = r.time + 0.8f + (a.id % 5) * 0.12f;
        return best;
    }

    /**
     * Using the cover point (brief 4.2): the body is at the point and turned to the obstacle; to shoot it has to
     * come out - up over low cover, or out round the end of high cover - and that is a real move of the real body,
     * so it is exposed while it fires and covered again when it goes back. Returns true while it is out.
     */
    static boolean work(Raid r, Actor a, float kx, float ky, float kz, boolean out, float dt) {
        CoverMap.Point p = a.cover;
        if (p == null || !p.valid) { a.coverAmt = 0; a.leanTarget = 0; a.lean += (0 - a.lean) * Math.min(1, dt * 8); return out; }
        r.world.cover.claim(p, a.id, r.time + 3);
        a.coverAmt = 1;
        float side = 0;
        if (out && p.height == CoverMap.HIGH) {
            // the end that gives a line to the target; with neither, stay in
            for (int sgn = -1; sgn <= 1 && side == 0; sgn += 2) if ((sgn < 0 ? p.leanLeft : p.leanRight) && Physics.los(r.world, p.cx() + p.leftX() * -sgn * 0.9f, p.y + 1.5f, p.cz() + p.leftZ() * -sgn * 0.9f, kx, ky + 1.3f, kz)) side = sgn;
            if (side == 0 && (p.leanLeft || p.leanRight)) side = p.leanLeft ? -1 : 1;
        }
        a.leanTarget = side;
        a.lean += (a.leanTarget - a.lean) * Math.min(1, dt * 7);
        // the body goes where the lean goes (left of the obstacle direction is leanX/leanZ; side -1 = left)
        float reach = absentialis.gameplay.CombatConfig.get().coverAiLean;
        float wx = p.cx() + p.leftX() * -a.lean * reach * 2f, wz = p.cz() + p.leftZ() * -a.lean * reach * 2f;
        a.vx = (wx - a.x) * 7f; a.vz = (wz - a.z) * 7f;
        if (p.height == CoverMap.LOW) a.crouch = !out;
        else a.crouch = false;
        return out && (p.height == CoverMap.LOW || Math.abs(a.lean) > 0.6f);
    }

    /** Is the cover this agent chose still doing its job against where the threat is now believed to be? */
    static boolean compromised(Raid r, Actor a, float tx, float ty, float tz, boolean seen) {
        if (!a.hasCover) return true;
        if (a.cover != null && (!a.cover.valid || a.cover.integrity < 0.12f)) return true;       // shot away, blown down, or about to be
        if (r.time > a.relocateAt) return true;
        if (r.zoneAt(a.x, a.y, a.z) != null || r.fire.at(a.x, a.y, a.z) != null) return true;
        if (a.distXZ(a.coverX, a.coverZ) > 1.2f) return false;                // still on the way there
        if (r.time < a.pinnedUntil - 0.2f && r.time - a.coverSince > 4.5f) return true;   // pinned here too long
        // flanked: the threat is now well off the side this cover faces, and can see the crouched body
        float dx = tx - a.x, dz = tz - a.z, dl = Math.max(0.1f, (float) Math.sqrt(dx * dx + dz * dz));
        float cos = (dx * a.coverDirX + dz * a.coverDirZ) / dl;
        if (seen && cos < 0.25f && dl < 30 && Physics.los(r.world, a.x, a.y + 0.8f, a.z, tx, ty + 1.3f, tz)) { a.flankedAt = r.time; return true; }
        return false;
    }

    // ------------------------------------------------------------------ engaged
    static void engage(Raid r, Actor a, Arch ar, Doc dc, Raid.Squad sq, Actor seenTgt, float dt) {
        Actor t = r.actor(a.targetId);
        SquadMind m = sq == null ? null : sq.mind;
        boolean seen = seenTgt != null && seenTgt == t;
        if (t == null || t.dead) {
            // they only know the target is down if they watched it happen (or are standing over the body)
            if (t != null && (seen || a.dist(t) < 6 || r.time - a.lastSeenTime < 1.5f)) {
                say(r, a, sq, pick(r, "Target down.", "He's down.", "Got him."), "bark_clear", 1.5f);
                if (m != null) { m.inContact = false; m.alertUntil = r.time + 60; }
                a.awareLevel = THREAT_AWARE;
                Brain.setState(a, canLoot(dc) && !a.looted ? "loot" : "alert");
            } else lostContact(r, a, dc, sq);
            return;
        }
        if (seen) sighted(r, a, sq, t);
        else {
            receive(r, a, sq);
            float since = r.time - a.lastSeenTime;
            // assumption: out of sight, the target kept going the way it was heading - for a couple of seconds
            if (a.memConfirmed && since < 2.2f) { a.suspX = a.memX + a.memVX * since; a.suspZ = a.memZ + a.memVZ * since; a.suspTime = r.time; }
            float heard = r.time - a.memTime;
            if (since > lostAfter(dc) && heard > lostAfter(dc)) { lostContact(r, a, dc, sq); return; }
        }
        a.awareLevel = ENGAGED;
        if (a.weapon == null) { a.morale = 0; Brain.setState(a, dc.d() == Doctrine.MERC || dc.d() == Doctrine.MILITARY ? "retreat" : "flee"); return; }
        if (m != null && (r.time - m.rolesAt > 2.5f || a.tacRole.isEmpty())) assignRoles(r, sq, a);
        if (a.tacRole.isEmpty() || a.tacRole.equals(SEARCHER)) a.tacRole = m == null ? AGGRESSOR : DEFENDER;

        // the position this agent acts on: the target itself only while it can see it
        float kx = seen ? t.x : a.memX, ky = seen ? t.y : a.memY, kz = seen ? t.z : a.memZ;
        float kd = a.distXZ(kx, kz);
        a.yaw = Brain.turn(a.yaw, (float) Math.atan2(-(kx - a.x), -(kz - a.z)), dt * 6);
        float want = "shotgunner".equals(a.archetype) ? 8 : "marksman".equals(a.archetype) ? 36 : dc.fightDist();
        if (r.night() && !a.light) want *= 0.7f;
        a.suppression = Math.max(0, a.suppression - dt * 0.28f);
        boolean pinned = r.time < a.pinnedUntil;
        a.crouch = false;

        // ---- close quarters has its own rules
        if (seen && a.dist(t) < 2.6f) { CloseCombat.fight(r, a, ar, dc, sq, t, dt); return; }

        // ---- a crippled fighter does what a crippled fighter can: get behind something, shoot from there, call for help
        if ((a.impaired & AIInjuryAdapter.CANT_WALK) != 0) {
            if (!a.hasCover) pickPosition(r, a, sq, DEFENDER, kx, ky, kz, want);
            if (a.hasCover && a.distXZ(a.coverX, a.coverZ) > 0.8f) Brain.goTo(r, a, a.coverX, a.coverZ, ar.speed(), dt); else Brain.stop(a);
            if (seen && a.fireCooldown <= 0) r.npcFire(a, t, dt);
            if (r.time - a.lastSay > 9) say(r, a, sq, pick(r, "I'm down - I can't move!", name(buddy(r, a)).isEmpty() ? "Help me!" : name(buddy(r, a)) + "! Get me out of here!"), "bark_help", 2);
            return;
        }
        // ---- badly hurt and not under the gun: patch up behind cover before doing anything else
        if (a.injurySeverity > 0.4f && a.bleed > 1.5f && !seen && a.hasCover && a.distXZ(a.coverX, a.coverZ) < 1 && r.time > a.selfAidUntil) {
            if (a.selfAidAt <= 0) { a.selfAidAt = r.time + 3.2f; if (a.anim != null) a.anim.play("heal", 3.0f); say(r, a, sq, pick(r, "Patching up - cover me!", "Give me a second, I'm bleeding."), "bark_cover", 2); }
            a.crouch = true; Brain.stop(a);
            if (r.time >= a.selfAidAt) { a.bleed *= 0.25f; r.gore.blood.stop(a.id); a.selfAidAt = 0; a.selfAidUntil = r.time + 40; a.injurySeverity *= 0.6f; }
            return;
        } else if (seen) a.selfAidAt = 0;

        // ---- is where I am still any good?
        boolean bad = compromised(r, a, kx, ky, kz, seen);
        if (bad && r.time > a.positionAt) {
            boolean flanked = r.time - a.flankedAt < 0.5f;
            a.positionAt = r.time + 0.8f;
            boolean hadCover = a.hasCover;
            if (pickPosition(r, a, sq, a.tacRole, kx, ky, kz, want) && hadCover && a.distXZ(a.coverX, a.coverZ) > 3) {
                if (flanked) { if (m != null) m.flankedAt = r.time; say(r, a, sq, pick(r, "He's on my flank!", "He's got round us - " + bearing(a.x, a.z, kx, kz) + "!"), "bark_help", 1); }
                else if (pinned) say(r, a, sq, name(buddy(r, a)).isEmpty() ? "Moving!" : name(buddy(r, a)) + ", cover me - moving!", "bark_cover", 2);
                else if (a.tacRole.equals(FLANKER)) say(r, a, sq, pick(r, "Going round the " + bearing(kx, kz, a.coverX, a.coverZ) + " side.", (name(buddy(r, a)).isEmpty() ? "Keep" : name(buddy(r, a)) + ", keep") + " him busy - I'm flanking."), "bark_flank", 2.5f);
                else if (a.tacRole.equals(AGGRESSOR) && r.rng.chance(0.4)) say(r, a, sq, pick(r, "Pushing up!", "Moving up!"), "bark_move", 3);
            }
        }
        boolean atPost = a.hasCover && a.distXZ(a.coverX, a.coverZ) < (a.cover != null ? 1.5f : 0.9f);
        boolean leashed = a.distXZ(a.homeX, a.homeZ) > dc.leash() && !a.tacRole.equals(FLANKER);
        String intent = decide(r, a, sq, t, seen, kd, want, atPost);
        if (intent.equals(WITHDRAW)) { a.coverAmt = 0; a.lean = 0; r.world.cover.release(a.cover, a.id); a.cover = null; say(r, a, sq, pick(r, "I'm hit bad - falling back!", "Pulling back - cover me!"), "bark_help", 2); Brain.setState(a, dc.d() == Doctrine.BANDIT || dc.d() == Doctrine.LONER ? "flee" : "retreat"); return; }
        if ((intent.equals(ADVANCE) || intent.equals(RELOCATE)) && atPost && !pinned) a.relocateAt = 0;
        if (!atPost) { a.coverAmt = 0; a.leanTarget = 0; a.lean += (0 - a.lean) * Math.min(1, dt * 8); }

        // ---- who may fire right now: the squad shares its fire out so it never all stops and never all exposes itself
        boolean slot = true;
        if (sq != null && sq.alive >= 3 && a.dist(t) > 9) {
            int groups = Math.max(1, Math.round(sq.alive / (float) Math.max(1, 1 + sq.alive / 3)));
            slot = ((int) (r.time / 1.7f) + r.squadRank(a)) % groups == 0;
        }
        boolean ready = a.weapon != null && a.fireCooldown <= 0;
        boolean fire = false;

        // ---- move
        float run = ar.runSpeed() * (a.suppression > 0.5f ? 0.95f : 0.85f);
        if (leashed) {
            if (a.distXZ(a.homeX, a.homeZ) > 4) Brain.goTo(r, a, a.homeX, a.homeZ, ar.speed() * 1.3f, dt); else Brain.stop(a);
            fire = seen && ready;
        } else if (!atPost && a.hasCover) {
            // on the move between positions: fast, low when out of sight, and only the bold shoot while running
            Brain.goTo(r, a, a.coverX, a.coverZ, run, dt);
            a.crouch = !seen && a.tacRole.equals(FLANKER);
            fire = seen && ready && (dc.d() == Doctrine.BANDIT || a.dist(t) < 10) && r.rng.chance(0.5);
        } else if (atPost) {
            Brain.stop(a);
            switch (a.tacRole) {
                case SUPPRESSOR -> {
                    // keep the last known position under fire whether or not anything shows there
                    float since = r.time - a.lastSeenTime;
                    a.crouch = pinned || !slot && !seen;
                    if (seen && ready && !pinned) fire = true;
                    else if (!seen && ready && !pinned && slot && Math.min(since, r.time - a.memTime) < 7 && kd < 70 && kd > 6) {
                        r.npcSuppress(a, a.memX, a.memY + 1.1f, a.memZ);
                        if (r.time - a.lastSay > 7) say(r, a, sq, pick(r, "Suppressing!", "Keeping his head down!", (name(buddy(r, a)).isEmpty() ? "Go" : name(buddy(r, a)) + ", go") + " - I've got him pinned!"), "bark_cover", 3);
                    }
                }
                case FLANKER -> { a.crouch = !seen; fire = seen && ready; }          // in position on the flank: this is what the move was for
                case DEFENDER -> { a.crouch = pinned || !seen || !slot; fire = seen && ready && !pinned && (slot || a.dist(t) < 14); }
                default -> {
                    // aggressor: fire, then move up when the target is not looking or has gone to ground
                    a.crouch = pinned || !seen;
                    fire = seen && ready && !pinned && slot;
                    float adv = advantage(r, a, sq, t, seen);
                    if (!pinned && r.time - a.coverSince > (adv > 0.5f ? 2.2f : 4.5f) && kd > Math.max(6f, want * 0.6f) + 2) a.relocateAt = 0;   // time to close
                }
            }
            // pop up or lean out to shoot, back in to reload and wait: the cycle of someone using cover
            boolean wantOut = fire || !pinned && (intent.equals(PEEK) || intent.equals(SUPPRESS_FIRE)) && ((r.time + a.id * 0.41f) % 3.6f) < 2.1f;
            if (a.cover != null) {
                boolean isOut = work(r, a, kx, ky, kz, wantOut, dt);
                if (fire && !isOut) fire = false;                 // still coming out: nothing to shoot at from behind the wall
            } else if (fire) a.crouch = false;
        } else {
            // nowhere good: fight from where we stand rather than freeze
            if (kd > want * 1.3f || !seen) Brain.goTo(r, a, kx, kz, ar.speed() * 1.3f, dt);
            else Brain.strafe(a, ar.speed() * 0.7f, r);
            fire = seen && ready && slot;
        }

        // ---- doctrine colour
        if (dc.d() == Doctrine.MILITARY && sq != null && !sq.backupCalled && a.stateTime > 8) { sq.backupCalled = true; r.say(a, "Command, troops in contact - send the patrol.", "radio_chatter"); r.dispatch(a.faction, a.memX, a.memZ, a.squad, "reinforce"); }
        if (dc.d() == Doctrine.LONER && a.dist(t) > 26 && a.stateTime > 6 && !seen) { Brain.setState(a, "avoid"); return; }
        if (dc.d() == Doctrine.BANDIT && seen && r.rng.chance(dt * 0.08)) say(r, a, sq, pick(r, "Come out, rat!", "You're dead, you hear me?", "Nowhere to go!"), "bark_taunt", 4);

        // ---- a target that sits still gets a grenade from those who carry them
        if (m != null && !seen && m.inContact && r.time - m.staticSince > 9 && r.time - m.grenadeAt > 28 && kd > 9 && kd < 26 && r.time - a.lastSeenTime < 12
                && (dc.d() == Doctrine.MILITARY || dc.d() == Doctrine.MERC || dc.d() == Doctrine.BANDIT && r.rng.chance(0.3)) && (a.tacRole.equals(SUPPRESSOR) || a.tacRole.equals(AGGRESSOR)) && atPost) {
            m.grenadeAt = r.time;
            r.npcThrow(a, m.anchorX, a.memY, m.anchorZ, dc.d() == Doctrine.BANDIT ? "grenade.pipe" : "grenade.frag");
            say(r, a, sq, pick(r, "Frag out!", "Grenade!"), "bark_cover", 0);
            a.fireCooldown = 1.4f;
            return;
        }
        if (fire) {
            if (a.weapon.rounds <= 0 && r.time - a.lastSay > 6) say(r, a, sq, pick(r, "Reloading!", "Changing mag!"), "bark_reload", 2);
            r.npcFire(a, t, dt);
        }
    }

    /** How much the situation favours pressing the attack, -1 .. 1: numbers, a vulnerable target, certainty, and what it has cost so far. */
    static float advantage(Raid r, Actor a, Raid.Squad sq, Actor t, boolean seen) {
        float mine = sq == null ? 1 : sq.alive, theirs = r.strengthNear(t, a.faction);
        float s = (mine - theirs) / Math.max(1f, mine + theirs);
        if (t.isPlayer && r.time < r.playerVulnerableUntil) s += 0.5f;          // reloading, healing, off balance
        if (seen && t.hp < t.maxHp * 0.4f) s += 0.3f;
        if (!seen) s -= Math.min(0.6f, (r.time - a.lastSeenTime) * 0.08f);
        s -= a.suppression * 0.5f + a.injurySeverity * 0.6f;
        if (sq != null) s -= sq.mind.caution(r.time) * 0.6f;
        // a target moving away invites pursuit from the bold
        float away = (t.vx * (t.x - a.x) + t.vz * (t.z - a.z));
        if (seen && away > 2) s += 0.2f * a.risk * 2;
        return Math.max(-1, Math.min(1, s + (a.risk - 0.5f) * 0.4f));
    }

    private static boolean canLoot(Doc dc) { return dc.d() == Doctrine.MERC || dc.d() == Doctrine.BANDIT; }

    // ------------------------------------------------------------------ contact lost
    static void lostContact(Raid r, Actor a, Doc dc, Raid.Squad sq) {
        a.awareLevel = SEARCHING;
        a.tacRole = SEARCHER;
        a.hasSearch = false;
        a.hasCover = false;
        Brain.setState(a, "search");
        if (sq == null) { say(r, a, null, pick(r, "Where'd he go?", "Lost him."), "bark_lost", 0); return; }
        SquadMind m = sq.mind;
        if (m.inContact && r.time - m.lastEyes > lostAfter(dc) - 0.5f) {
            m.inContact = false;
            m.lostAt = r.time;
            m.escapes++;
            // the search starts where the squad last had eyes, along the way the target was going
            m.buildSearch(r, m.tx, m.ty, m.tz, m.tvx, m.tvz, 14);
            String line = m.escapes >= 3 ? pick(r, "He's slipped us AGAIN!", "Every damn time - find him!")
                    : m.casualties > 0 ? pick(r, "Lost him. Careful - he's already dropped " + (m.casualties == 1 ? "one of us." : m.casualties + " of us."), "No visual. Slow and careful.")
                    : dc.d() == Doctrine.MILITARY ? pick(r, "Lost visual. Sweep the area.", "No contact - search pattern.")
                    : dc.d() == Doctrine.BANDIT ? pick(r, "Where'd he go?!", "He can't have gone far - spread out!")
                    : pick(r, "Lost him. Spread out.", "He was heading " + bearing(a.x, a.z, m.tx + m.tvx * 3, m.tz + m.tvz * 3) + " - check there.");
            say(r, a, sq, line, "bark_lost", 0.5f);
        }
    }

    // ------------------------------------------------------------------ searching
    static void search(Raid r, Actor a, Arch ar, Doc dc, Raid.Squad sq, float dt) {
        a.awareLevel = SEARCHING;
        a.light = r.night() && dc.d() != Doctrine.BANDIT;
        if (receive(r, a, sq)) { a.hasSearch = false; }            // someone has news: go where they say
        SquadMind m = sq == null ? null : sq.mind;
        float limit = dc.d() == Doctrine.BANDIT ? 22 : dc.d() == Doctrine.LONER ? 16 : dc.d() == Doctrine.MILITARY ? 42 : 50;
        if (a.stateTime > limit) {
            // nothing found: the hunt ends, the wariness does not
            if (m != null) m.alertUntil = Math.max(m.alertUntil, r.time + 150);
            a.alertness = 1; a.wakeUntil = r.time + 200;
            say(r, a, sq, m != null && m.escapes >= 2 ? pick(r, "Gone. He'll be back - nobody relax.", "He got away again. Eyes open.") : pick(r, "Nothing. Stay sharp.", "He's gone. Keep your eyes open."), "bark_clear", 2);
            Brain.setState(a, canLoot(dc) && !a.looted ? "loot" : "alert");
            return;
        }
        if (m != null && (m.searchPoints.isEmpty() || r.time - m.searchBuilt > 16 && allCleared(m, r.time))) {
            // the first places are empty: as the information ages, the area to cover grows
            m.buildSearch(r, m.searchBuilt < 0 ? a.memX : m.searchX, a.memY, m.searchBuilt < 0 ? a.memZ : m.searchZ, m.tvx, m.tvz, Math.min(42, (m.searchRadius <= 0 ? 12 : m.searchRadius) + 8));
        }
        if (!a.hasSearch) {
            float[] p = m == null ? null : m.claim(r, a);
            if (p != null) { a.searchX = p[0]; a.searchZ = p[1]; }
            else {
                // alone, or nothing left to claim: sweep the uncertainty around the last known position
                float ang = r.rng.range(0f, 6.28f), rad = r.rng.range(0.3f, 1f) * Math.max(4, a.memErr);
                a.searchX = a.memX + (float) Math.sin(ang) * rad; a.searchZ = a.memZ + (float) Math.cos(ang) * rad;
            }
            a.hasSearch = true;
            a.searchAt = r.time;
        }
        float d = a.distXZ(a.searchX, a.searchZ);
        boolean near = d < 7;
        // the last stretch is slow and low: whoever is hiding may be right there
        float caution = m == null ? 0 : m.caution(r.time);
        float sp = near ? ar.speed() * (1.1f - caution * 0.35f) : ar.runSpeed() * (0.7f - caution * 0.15f);
        a.crouch = near && (dc.d() != Doctrine.BANDIT || caution > 0.3f);
        if (d > 1.5f && r.time - a.searchAt < 14) Brain.goTo(r, a, a.searchX, a.searchZ, sp, dt);
        else {
            // here: look around properly before calling it clear
            Brain.stop(a);
            a.yaw += dt * 2.2f;
            if (a.scanT <= 0) a.scanT = 1.6f + r.rng.nextFloat();
            a.scanT -= dt;
            if (a.scanT <= 0 || r.time - a.searchAt >= 14) {
                if (m != null) m.clear(a.searchX, a.searchZ, r.time);
                a.hasSearch = false; a.searched++;
                if (r.rng.chance(0.3)) say(r, a, sq, pick(r, "Clear here.", "Nothing here.", name(buddy(r, a)).isEmpty() ? "Clear." : name(buddy(r, a)) + ", check the " + bearing(a.x, a.z, m == null ? a.memX : m.searchX, m == null ? a.memZ : m.searchZ) + " side."), "bark_search", 3);
            }
        }
    }

    private static boolean allCleared(SquadMind m, float time) { for (float[] p : m.searchPoints) if (!m.wasCleared(p[0], p[1], time)) return false; return true; }

    // ------------------------------------------------------------------ threat aware: a hostile is about, position unknown
    static void alert(Raid r, Actor a, Arch ar, Doc dc, Raid.Squad sq, float dt) {
        a.awareLevel = THREAT_AWARE;
        a.alertness = Math.max(a.alertness, 0.8f);
        if (receive(r, a, sq)) { a.hasSearch = false; Brain.setState(a, "search"); return; }
        SquadMind m = sq == null ? null : sq.mind;
        boolean still = m == null ? a.stateTime < 60 : r.time < m.alertUntil;
        if (!still) { a.awareLevel = UNAWARE; a.tacRole = ""; a.hasCover = false; Brain.setState(a, "idle"); return; }
        // weapons up, behind something near the post, watching the way the trouble came from
        float fx = a.memTime > -90 ? a.memX : a.homeX, fz = a.memTime > -90 ? a.memZ : a.homeZ;
        if (!a.hasCover || r.time > a.relocateAt) { pickPosition(r, a, sq, DEFENDER, fx, a.memY, fz, dc.fightDist()); a.relocateAt = r.time + 18 + r.rng.nextFloat() * 12; }
        if (a.hasCover && a.distXZ(a.coverX, a.coverZ) > 0.9f) Brain.goTo(r, a, a.coverX, a.coverZ, ar.speed() * 1.2f, dt);
        else {
            Brain.stop(a);
            a.crouch = ((int) (r.time * 0.2f + a.id) & 1) == 0;
            // scan an arc around the direction of the last information
            float base = (float) Math.atan2(-(fx - a.x), -(fz - a.z));
            a.yaw = Brain.turn(a.yaw, base + (float) Math.sin(r.time * 0.6f + a.id) * 1.1f, dt * 1.6f);
        }
    }

    // ------------------------------------------------------------------ incoming fire
    /** A round has struck or passed close to this agent: suppression builds, and an exposed agent goes for cover. */
    public static void nearMiss(Raid r, Actor a, float x, float y, float z, int shooterId) {
        if (a.dead || a.isPlayer || a.infected() || a.tier != 0 || a.ragdoll != null) return;
        a.wakeUntil = r.time + 120;
        Actor sh = r.actor(shooterId);
        if (sh != null && (sh.isPlayer || sh.mate()) && !a.mate()) a.hostileToPlayer = true;
        // 0.7: the round is felt by the mind it nearly hit. NeuralAI turns it into nerves, and - when nothing is known
        // yet - into a bearing: rounds coming in say "hostile" and roughly "from over there", never where the shooter stands
        absentialis.neuralai.api.Vec3 from = sh == null ? null : new absentialis.neuralai.api.Vec3(sh.x - a.x, 0, sh.z - a.z);
        r.neural.onNearMiss(a.id, new absentialis.neuralai.api.Vec3(x, y, z), from, shooterId);
        absentialis.neuralai.runtime.Mind m = r.neural.mind(a.id);
        if (m != null) { a.suppression = (float) m.suppression; a.pinnedUntil = (float) m.pinnedUntil; }     // published at once: the HUD and the animator read these
        nearMisses++;
    }

    /** Rounds that passed close enough to someone to be felt (gates). */
    public static int nearMisses;

    /** What the agent's state means, for the overlay. */
    public static String describe(Actor a) { return LEVEL[Math.max(0, Math.min(4, a.awareLevel))] + (a.tacRole.isEmpty() ? "" : "/" + a.tacRole) + (a.suppression > 0.5f ? " PINNED" : ""); }
}
