package absentialis.ai;

import absentialis.ai.Brain.Arch;
import absentialis.ai.Brain.Doc;
import absentialis.ai.Brain.Doctrine;
import absentialis.entity.Actor;
import absentialis.scene.Raid;

/**
 * Close-quarters fighting for armed humans: physical, reactive, and decided by the situation rather than by a
 * rotation of attacks.
 *
 * What an agent does at arm's length depends on distance, on what its opponent is doing, and on what it has
 * itself just done:
 *   shove ....... when the opponent is too close to bring a long gun to bear - it makes room, and against a wall
 *                 it hurts
 *   strike ...... the default blow (a rifle butt, a blade for those who carry one), with a wind-up that can be seen
 *   grab ........ against an opponent caught reloading, healing or off balance: it holds them for the others
 *   shoot ....... a gun is still a gun at two metres
 *   block ....... raising the weapon against an incoming blow the agent saw coming - followed by a counter
 *   give ground . stepping back out of reach after its own attack, while it recovers
 * A wind-up that is interrupted by a stagger is lost. Only one member of a squad presses the attack at a time;
 * the others circle with their weapons up, which is its own kind of threat.
 */
public final class CloseCombat {
    private CloseCombat() {}

    public static int strikes, shoves, grabs, blocks, counters, interrupted;

    static void fight(Raid r, Actor a, Arch ar, Doc dc, Raid.Squad sq, Actor t, float dt) {
        float d = a.dist(t);
        a.yaw = Brain.turn(a.yaw, (float) Math.atan2(-(t.x - a.x), -(t.z - a.z)), dt * 9);
        SquadMind m = sq == null ? null : sq.mind;
        // ---- one at a time: whoever holds the squad's token attacks, the rest keep their distance and their aim
        boolean mine = true;
        if (m != null) {
            if (m.meleeHolder != a.id && r.time < m.meleeUntil) { Actor h = r.actor(m.meleeHolder); mine = h == null || h.dead || h.dist(t) > 3.4f || h.ragdoll != null; }
            if (mine) { m.meleeHolder = a.id; m.meleeUntil = r.time + 1.4f; }
        }
        // ---- an attack already under way
        if (a.meleeWind > 0) {
            if (r.time < a.staggerUntil) { a.meleeWind = 0; a.fireCooldown = Math.max(a.fireCooldown, 0.6f); interrupted++; return; }   // hit during the wind-up: the attack is lost
            a.meleeWind -= dt;
            Brain.stop(a);
            if (a.meleeWind <= 0) land(r, a, t, sq);
            return;
        }
        if (!mine) {
            orbit(a, t, 2.9f, ar.speed() * 1.1f, r);
            if (a.weapon != null && a.fireCooldown <= 0 && d > 1.8f && r.rng.chance(dt * 0.9)) r.npcFire(a, t, dt);
            return;
        }
        if (a.fireCooldown > 0) {
            // recovering from its own attack: out of reach if it can get there - this is when it can be hit
            float back = d < 2.2f ? 1 : 0;
            a.vx = (float) Math.sin(a.yaw) * ar.speed() * 1.2f * back; a.vz = (float) Math.cos(a.yaw) * ar.speed() * 1.2f * back;
            return;
        }
        boolean vulnerable = t.isPlayer ? r.time < r.playerVulnerableUntil : r.time < t.staggerUntil;
        boolean gun = a.weapon != null && a.weapon.def().weapon != null && !a.weapon.def().weapon.melee() && a.weapon.rounds > 0;
        String move;
        if (vulnerable && (dc.d() == Doctrine.BANDIT || dc.d() == Doctrine.MERC) && r.time - a.lastGrab > 10 && d < 2.0f) move = "grab";
        else if (d < 1.3f) move = "shove";
        else if (gun && !vulnerable && r.rng.chance(0.5)) { r.npcFire(a, t, dt); a.fireCooldown = Math.max(a.fireCooldown, 0.4f); return; }
        else if (d > 2.0f) { Brain.goTo(r, a, t.x, t.z, ar.runSpeed() * 0.7f, dt); return; }      // step in to reach
        else move = "strike";
        a.meleeMove = move;
        a.meleeWind = move.equals("shove") ? 0.2f : move.equals("grab") ? 0.3f : 0.36f;
        if (a.anim != null) a.anim.play("melee", a.meleeWind + 0.3f);
        Brain.stop(a);
    }

    /** The blow arrives (0.7: public - the NeuralAI body adapter opens the contact window, and this is the raid ruling on it). */
    public static void land(Raid r, Actor a, Actor t, Raid.Squad sq) {
        String move = a.meleeMove;
        a.meleeMove = "";
        if (a.dist(t) > 2.4f) { a.fireCooldown = 0.85f; return; }       // the opponent stepped out: a miss, and a long recovery
        switch (move) {
            case "shove" -> { shoves++; r.shove(a, t); a.fireCooldown = 0.55f; }
            case "grab" -> {
                grabs++;
                a.lastGrab = r.time;
                r.grab(a, t);
                a.fireCooldown = 1.3f;
                Tactics.say(r, a, sq, "Got him! Shoot!", "bark_help", 0.5f);
            }
            default -> {
                strikes++;
                boolean blade = a.weapon != null && "melee.knife".equals(a.weapon.defId);
                r.melee(a, t, (blade ? 24 : 17) * r.difficultyDamage());
                a.fireCooldown = 0.75f;
            }
        }
    }

    private static void orbit(Actor a, Actor t, float radius, float speed, Raid r) {
        float dx = a.x - t.x, dz = a.z - t.z, dl = Math.max(0.1f, (float) Math.sqrt(dx * dx + dz * dz));
        float side = (a.id & 1) == 0 ? 1 : -1;
        // tangential, with a correction toward the ring
        float tx = -dz / dl * side, tz = dx / dl * side, k = (radius - dl) * 0.9f;
        a.vx = (tx + dx / dl * k) * speed * 0.7f; a.vz = (tz + dz / dl * k) * speed * 0.7f;
    }

    /**
     * Someone swings at v. An agent who saw it coming may block (most of the blow is stopped, and a counter
     * follows) or step out of it. Returns the share of the damage that gets through: 1, 0.25 or 0.
     */
    public static float defend(Raid r, Actor v, Actor attacker) {
        if (v.dead || v.infected() || v.isPlayer || v.ragdoll != null || r.time < v.staggerUntil || v.meleeWind > 0) return 1;
        if (!"engage".equals(v.state) || v.targetId != attacker.id) return 1;               // not fighting this opponent: caught cold
        float dx = attacker.x - v.x, dz = attacker.z - v.z, dl = Math.max(0.1f, (float) Math.sqrt(dx * dx + dz * dz));
        float cos = (dx * (float) -Math.sin(v.yaw) + dz * (float) -Math.cos(v.yaw)) / dl;
        if (cos < 0.35f) return 1;                                                           // from the side or behind
        Doc dc = Brain.doc(v.faction);
        float skill = dc.d() == Doctrine.MILITARY || dc.d() == Doctrine.MERC ? 0.2f : 0;
        float roll = r.rng.nextFloat();
        if (v.weapon != null && roll < 0.3f + skill - v.injurySeverity * 0.3f) {
            blocks++;
            counters++;
            r.emitSound(v.x, v.y + 1.2f, v.z, 9, "block", v.id, false);
            // the counter: straight back out of the block, quicker than a cold strike
            v.meleeMove = "strike";
            v.meleeWind = 0.28f;
            v.fireCooldown = 0;
            if (v.anim != null) v.anim.play("melee", 0.55f);
            return 0.25f;
        }
        if (roll > 0.86f - (dc.d() == Doctrine.BANDIT ? 0.1f : 0)) {
            // out of reach: a step back along the line of the blow
            v.vx -= dx / dl * 4.5f; v.vz -= dz / dl * 4.5f;
            return 0;
        }
        return 1;
    }
}
