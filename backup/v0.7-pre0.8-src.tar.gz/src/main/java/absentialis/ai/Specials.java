package absentialis.ai;

import static absentialis.ai.Brain.goTo;
import static absentialis.ai.Brain.setState;
import static absentialis.ai.Brain.stop;
import static absentialis.ai.Brain.turn;

import absentialis.entity.Actor;
import absentialis.scene.Raid;

/**
 * The special infected (0.7): the ones with a name, a place in the killfeed and a trick that changes the fight.
 *
 *   Bomber ...... bloated and soaked in bile. It walks up, swells and bursts; the burst hurts little, but everyone
 *                 it reaches is covered in bile - and for fifteen seconds every infected within smelling distance
 *                 comes for them, while their own sight swims.
 *   Spewer ...... lanky, the jaw gone, poison running from the hole. Keeps its distance and spits pools that burn
 *                 whoever stands in them: it is there to move people off the ground they chose.
 *   Tank ........ the giant. Besides the charge and the thrown masonry it had, it now takes hold of whoever it
 *                 reaches - anyone - lifts them in one hand and throws them fifteen feet.
 *   Gladiator ... blind, in a helmet and clawed gauntlets, armoured everywhere but the middle of its back. It walks
 *                 slowly and listens; a noise brings it at a run, and what it finds it swings at, at head height.
 *                 Standing still is safe. So is being below the swing.
 *   Butcher ..... a sack over its head and a chainsaw. It runs at what it sees and takes the head off with one
 *                 swing; the swing has a wind-up, and a round to the head during the wind-up breaks it.
 *
 * Every attack here is telegraphed (a sound and a wind-up animation, never instant) and every one has an answer.
 * The numbers are public so the gates and a tuning pass can reach them.
 */
public final class Specials {
    private Specials() {}

    /** The Tank's throw: how long the victim is held aloft, how far it is thrown (fifteen feet), and the rest between grabs. */
    public static float GRAB_HOLD = 0.75f, THROW_METRES = 4.57f, GRAB_EVERY = 8f, GRAB_REACH = 2.9f;
    /** The Gladiator: reach of the claws, the wind-up, and how close something must be to be found without a sound. */
    public static float CLAW_REACH = 2.6f, CLAW_WINDUP = 0.5f, TOUCH = 1.2f;
    /** The Butcher: reach of the saw, and the wind-up in which a shot to the head stops it. */
    public static float SAW_REACH = 2.7f, SAW_WINDUP = 0.75f, SAW_STAGGER = 2.0f;
    /** What the Gladiator's plate lets through from the front, and what the gap in its back makes of a hit. */
    public static float PLATE = 0.06f, WEAK_POINT = 1.8f;

    public static int grabs, thrown, swings, ducked, spits, deflected, weakHits, interrupted;

    public static float scale(String archetype) {
        return switch (archetype) { case "tank" -> 1.45f; case "gladiator" -> 1.2f; case "spewer" -> 1.1f; case "butcher" -> 1.04f; default -> 1f; };
    }

    // ------------------------------------------------------------------ what they do when nothing is happening
    static void ambient(Raid r, Actor a, float dt) {
        switch (a.archetype) {
            case "spewer" -> {
                // the poison never stops coming out of it: drops from where the jaw was, and the odd one that marks the floor
                if (a.tier == 0 && r.rng.chance(dt * 6)) r.drip(a, 0.82f, 0xFF86D83C, true);
                if (a.tier == 0 && r.rng.chance(dt * 0.5)) r.gore.bile(a.x, a.y + a.height() * 0.8f, a.z, (float) -Math.sin(a.yaw) * 0.6f, 0, (float) -Math.cos(a.yaw) * 0.6f, 0.012f);
            }
            case "bomber" -> { if (a.tier == 0 && r.rng.chance(dt * 1.6)) r.drip(a, 0.55f, absentialis.scene.Gore.BILE, false); }
            case "butcher" -> {
                // the saw is never off: it idles, and it can be heard coming
                a.talkTimer -= dt;
                if (a.talkTimer <= 0) { a.talkTimer = 0.85f; r.emitSound(a.x, a.y + 1, a.z, "engage".equals(a.state) ? 36 : 18, "chainsaw", a.id, false); }
            }
            default -> { }
        }
    }

    // ------------------------------------------------------------------ Spewer
    static boolean spewer(Raid r, Actor a, Brain.Arch ar, Actor t, boolean seen, float d, float dt) {
        if (r.telegraphing(a, "retch")) { stop(a); return true; }
        if (a.burstLeft > 0) { a.burstLeft = 0; r.spit(a, a.goalX, a.memY, a.goalZ); spits++; return true; }
        // the retch is the warning: the pool lands where the target stood when it began
        if (seen && d > 3.5f && d < 15 && a.specialTimer <= 0) { a.specialTimer = 5.5f; a.goalX = t.x; a.goalZ = t.z; a.memY = t.y; r.telegraph(a, "retch", 0.9f); a.burstLeft = 1; return true; }
        if (d < 1.7f && a.fireCooldown <= 0) { a.fireCooldown = 1.3f; if (a.anim != null) a.anim.play("inf_attack", 0); r.melee(a, t, ar.melee() * r.difficultyDamage()); }
        if (seen && d < 5.5f) {
            // it does not want to be close: it backs off the way it came
            float bx = a.x - t.x, bz = a.z - t.z, bl = Math.max(0.01f, (float) Math.sqrt(bx * bx + bz * bz));
            goTo(r, a, a.x + bx / bl * 6, a.z + bz / bl * 6, ar.runSpeed(), dt);
        } else if (!seen || d > 11) goTo(r, a, a.memX, a.memZ, ar.runSpeed() * 0.8f, dt);
        else { stop(a); a.yaw = turn(a.yaw, (float) Math.atan2(-(t.x - a.x), -(t.z - a.z)), dt * 5); }
        return true;
    }

    // ------------------------------------------------------------------ Tank: the grab
    /** One frame of the grab, if one is on. Returns true when it has the Tank's whole attention this frame. */
    static boolean tankGrab(Raid r, Actor a, Actor t, boolean seen, float d, float dt) {
        if (a.grabId != 0) {
            Actor v = r.actor(a.grabId);
            if (v == null || v.dead) { a.grabId = 0; return false; }
            a.grabT -= dt;
            stop(a);
            float fx = (float) -Math.sin(a.yaw), fz = (float) -Math.cos(a.yaw), k = 1 - Math.max(0, a.grabT) / GRAB_HOLD;
            // off the ground and up to arm's length overhead, in one hand
            r.hold(a, v, a.x + fx * 1.3f, a.y + 0.4f + 2.0f * Math.min(1, k * 1.7f), a.z + fz * 1.3f);
            if (a.grabT <= 0) { a.grabId = 0; r.fling(a, v, fx, fz); thrown++; a.fireCooldown = 1.4f; }
            return true;
        }
        if (r.telegraphing(a, "grab")) { stop(a); a.yaw = turn(a.yaw, (float) Math.atan2(-(t.x - a.x), -(t.z - a.z)), dt * 5); return true; }
        if (a.burstLeft == 2) {
            a.burstLeft = 0;
            // the hand closes where the target is now: out of reach by then, and it closes on nothing
            if (seen && !t.dead && d < GRAB_REACH + 0.6f && t.ragdoll == null) { a.grabId = t.id; a.grabT = GRAB_HOLD; grabs++; r.grabbed(a, t, GRAB_HOLD); if (a.anim != null) a.anim.play("giant_throw", GRAB_HOLD + 0.25f); }
            return true;
        }
        if (seen && d < GRAB_REACH && r.time >= a.grabAt && a.fireCooldown <= 0.4f && t.ragdoll == null) { a.grabAt = r.time + GRAB_EVERY; r.telegraph(a, "grab", 0.5f); a.burstLeft = 2; return true; }
        return false;
    }

    // ------------------------------------------------------------------ Gladiator
    /** It cannot see. Everything it does, it does about the last thing it heard. */
    static void gladiator(Raid r, Actor a, Brain.Arch ar, float dt) {
        if (r.time < a.staggerUntil) { stop(a); return; }
        if (r.telegraphing(a, "hark") || r.telegraphing(a, "claw")) { stop(a); return; }
        if (a.burstLeft > 0) { a.burstLeft = 0; sweep(r, a, CLAW_REACH, 0.15f, true, "claw_swing"); a.fireCooldown = 1.3f; return; }
        Actor near = touched(r, a);
        if (near != null && a.fireCooldown <= 0) {
            a.yaw = (float) Math.atan2(-(near.x - a.x), -(near.z - a.z));
            r.telegraph(a, "claw", CLAW_WINDUP); a.burstLeft = 1; stop(a);
            return;
        }
        switch (a.state) {
            case "investigate", "engage", "search", "notice" -> {
                if (r.time - a.memTime > 12) { a.headLookTarget = 0; setState(a, "idle"); break; }
                float d = a.distXZ(a.memX, a.memZ);
                if (d > 1.7f) {
                    // the charge: straight at the noise, and thin cover in the way is not in the way
                    goTo(r, a, a.memX, a.memZ, ar.runSpeed(), dt);
                    a.sprinting = true;
                    if (a.stuckTime > 0.2f) r.smash(a);
                } else {
                    // where the noise was: it cuts at the place, then stands with its head turning, listening
                    stop(a);
                    if (a.specialTimer <= 0 && a.fireCooldown <= 0) { a.specialTimer = 3.2f; r.telegraph(a, "claw", CLAW_WINDUP); a.burstLeft = 1; }
                    a.headLookTarget = (float) Math.sin((a.stateTime + a.id) * 1.4f) * 1.1f;
                    if (r.time - a.memTime > 6) { a.headLookTarget = 0; setState(a, "idle"); }
                }
            }
            default -> {
                // nothing heard: it walks, slowly, head tilting to one side and the other
                a.headLookTarget = (float) Math.sin((r.time + a.id * 1.7f) * 0.5f) * 0.7f;
                Brain.wander(r, a, ar, dt);
            }
        }
    }

    /** Someone the Gladiator has found without hearing them: at arm's length, or a little further off and moving. */
    private static Actor touched(Raid r, Actor a) {
        float fx = (float) -Math.sin(a.yaw), fz = (float) -Math.cos(a.yaw);
        Actor best = null;
        float bd = 1e9f;
        for (Actor o : r.nearby(a.x, a.z, CLAW_REACH + 1)) {
            if (o == a || o.dead || o.infected() || Math.abs(o.y - a.y) > 1.6f) continue;
            float dx = o.x - a.x, dz = o.z - a.z, d = (float) Math.sqrt(dx * dx + dz * dz);
            boolean moving = Math.abs(o.vx) + Math.abs(o.vz) > 0.6f;
            if (d > (moving ? CLAW_REACH - 0.3f : TOUCH) + o.radius) continue;
            if (d > TOUCH && (dx * fx + dz * fz) / Math.max(0.01f, d) < -0.2f) continue;
            if (d < bd) { bd = d; best = o; }
        }
        return best;
    }

    // ------------------------------------------------------------------ Butcher
    static boolean butcher(Raid r, Actor a, Brain.Arch ar, Actor t, boolean seen, float d, float dt) {
        if (r.time < a.staggerUntil) { stop(a); a.burstLeft = 0; return true; }
        if (r.telegraphing(a, "rev")) { stop(a); a.yaw = turn(a.yaw, (float) Math.atan2(-(t.x - a.x), -(t.z - a.z)), dt * 3.5f); return true; }
        if (a.burstLeft > 0) { a.burstLeft = 0; sweep(r, a, SAW_REACH, 0.25f, false, "chainsaw_rev"); a.fireCooldown = 1.5f; a.specialTimer = 1.0f; return true; }
        if (d < SAW_REACH - 0.3f && a.fireCooldown <= 0 && a.specialTimer <= 0) { r.telegraph(a, "rev", SAW_WINDUP); a.burstLeft = 1; stop(a); return true; }
        // no flank, no pause: straight in, at a run
        if (d > 1.4f) { goTo(r, a, a.memX, a.memZ, ar.runSpeed(), dt); a.sprinting = true; if (a.stuckTime > 0.3f) r.smash(a); } else stop(a);
        return true;
    }

    /**
     * A swing at head height across the front: everyone living within reach and in the arc loses their head. A swing
     * that can be ducked (the claws) passes over anyone who is crouched, prone or already on the ground.
     */
    public static void sweep(Raid r, Actor a, float reach, float minCos, boolean duckable, String sound) {
        swings++;
        float fx = (float) -Math.sin(a.yaw), fz = (float) -Math.cos(a.yaw);
        if (a.anim != null) a.anim.play("inf_attack", 0);
        r.emitSound(a.x, a.y + 1.4f, a.z, 24, sound, a.id, false);
        for (Actor o : new java.util.ArrayList<>(r.nearby(a.x, a.z, reach + 1.5f))) {
            if (o == a || o.dead || o.infected() || Math.abs(o.y - a.y) > 1.6f) continue;
            float dx = o.x - a.x, dz = o.z - a.z, d = (float) Math.sqrt(dx * dx + dz * dz);
            if (d > reach + o.radius || d > 0.3f && (dx * fx + dz * fz) / d < minCos) continue;
            if (duckable && (o.crouch || o.prone || o.crawling || o.ragdoll != null || o.height() < 1.3f)) { ducked++; if (o.isPlayer) r.notice("The claws pass over you.", 0xFFB8C8D0); continue; }
            r.decapitate(a, o);
        }
    }

    // ------------------------------------------------------------------ what a hit does to them
    /**
     * A blow on one of the specials, before it is counted: the Gladiator's plate turns nearly everything that does not
     * come in through the gap in its back, and a hard hit on the Butcher's head while the saw is raised stops the swing.
     * dirX/dirZ is the way the blow was travelling; round says it was a bullet.
     */
    public static float struck(Raid r, Actor v, float dmg, float hitY, float dirX, float dirZ, boolean blast, boolean round) {
        if ("gladiator".equals(v.archetype)) {
            if (blast) return dmg * 0.35f;
            float l = (float) Math.sqrt(dirX * dirX + dirZ * dirZ);
            if (l < 1e-3f) return dmg * PLATE * 2;
            // travelling the way it faces = it came in from behind
            float along = (dirX * (float) -Math.sin(v.yaw) + dirZ * (float) -Math.cos(v.yaw)) / l;
            if (along > 0.35f && hitY < v.y + v.height() * 0.85f) { weakHits++; return dmg * WEAK_POINT; }
            deflected++;
            r.spark(v.x - dirX / l * v.radius, hitY, v.z - dirZ / l * v.radius);
            return dmg * PLATE;
        }
        // a round to the head, or anything heavy enough anywhere (a fist is neither)
        if ("butcher".equals(v.archetype) && !blast && r.telegraphing(v, "rev") && (round && hitY > v.y + v.height() * 0.8f || dmg >= 70)) {
            r.cancelTelegraph(v, "rev");
            v.staggerUntil = r.time + SAW_STAGGER; v.specialTimer = SAW_STAGGER + 0.4f; v.burstLeft = 0;
            if (v.anim != null) v.anim.hit((float) Math.atan2(dirX, dirZ));
            r.emitSound(v.x, v.y + 1.5f, v.z, 20, "chainsaw_stall", v.id, false);
            interrupted++;
        }
        return dmg;
    }
}
