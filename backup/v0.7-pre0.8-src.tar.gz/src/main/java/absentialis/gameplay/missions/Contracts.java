package absentialis.gameplay.missions;

import absentialis.engine.util.Json;
import absentialis.engine.util.Rng;
import absentialis.world.District;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Contract board (GDD 13.2): generated jobs from faction contacts. Contracts progress from raid
 * events and pay out only on successful extraction. Each completion moves reputation, XP and
 * scrip, and its target type feeds the strategic layer (e.g. clearing infected lowers pressure).
 */
public final class Contracts {
    public enum Kind { FETCH, CULL, HUNT, RECON, EXTRACT, INTEL }

    public static final class Contract {
        public String id, title, desc, giver, target, district;
        public Kind kind;
        public int need, have, scrip, xp;
        public float rep;
        public boolean done() { return have >= need; }

        Map<String, Object> toJson() {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id", id); m.put("title", title); m.put("desc", desc); m.put("giver", giver); m.put("target", target);
            m.put("district", district); m.put("kind", kind.name()); m.put("need", need); m.put("have", have);
            m.put("scrip", scrip); m.put("xp", xp); m.put("rep", (double) rep);
            return m;
        }

        static Contract fromJson(Map<String, Object> m) {
            Contract c = new Contract();
            c.id = Json.str(m, "id", "?"); c.title = Json.str(m, "title", "?"); c.desc = Json.str(m, "desc", "");
            c.giver = Json.str(m, "giver", "survivors"); c.target = Json.str(m, "target", ""); c.district = Json.str(m, "district", "MARKET");
            c.kind = Kind.valueOf(Json.str(m, "kind", "FETCH")); c.need = Json.integer(m, "need", 1); c.have = Json.integer(m, "have", 0);
            c.scrip = Json.integer(m, "scrip", 100); c.xp = Json.integer(m, "xp", 1000); c.rep = (float) Json.num(m, "rep", 2);
            return c;
        }
    }

    public final List<Contract> board = new ArrayList<>(), active = new ArrayList<>();
    public final List<String> completed = new ArrayList<>();
    public int serial;
    public static final int MAX_ACTIVE = 3;

    /** The faction the survivor is aligned with ("" = none): it decides what kind of work reaches the board (0.6). Set by the profile. */
    public String alliance = "";

    public void refill(long seed, int rank) {
        Rng r = new Rng(seed ^ serial * 7919L);
        while (board.size() < 5) board.add(generate(r, rank));
    }

    public void refill(long seed, int rank, String alliance) { this.alliance = alliance == null ? "" : alliance; refill(seed, rank); }

    /**
     * How often each kind of contract is offered to a survivor of each alliance, in the order of {@link Kind}:
     * FETCH, CULL, HUNT, RECON, EXTRACT, INTEL. The Military is sent to look and to report, the Bandits to hit and to
     * haul, the Loners to supply and to clear, the Mercenaries to eliminate and recover.
     */
    public static int[] kindWeights(String alliance) {
        return switch (alliance == null ? "" : alliance) {
            case "military" -> new int[]{1, 2, 3, 3, 1, 3};
            case "raiders" -> new int[]{3, 1, 4, 0, 3, 0};
            case "survivors" -> new int[]{4, 3, 0, 1, 2, 0};
            case "mercenaries" -> new int[]{1, 0, 4, 2, 2, 2};
            default -> new int[]{1, 1, 1, 1, 1, 1};
        };
    }

    private Kind pickKind(Rng r) {
        int[] w = kindWeights(alliance);
        Kind[] ks = Kind.values();
        int total = 0;
        for (int i = 0; i < ks.length && i < w.length; i++) total += w[i];
        int roll = r.nextInt(Math.max(1, total));
        for (int i = 0; i < ks.length && i < w.length; i++) { roll -= w[i]; if (roll < 0) return ks[i]; }
        return ks[0];
    }

    private Contract generate(Rng r, int rank) {
        Contract c = new Contract();
        c.id = "c" + (++serial);
        District d = r.pick(District.CITY);
        c.district = d.name();
        c.kind = pickKind(r);
        float scale = 1 + rank / 25f;
        switch (c.kind) {
            case FETCH -> {
                String[][] wants = {{"med.bandage", "Bandages", "survivors"}, {"mat.electronics", "Circuit boards", "military"}, {"food.canned", "Canned stew", "survivors"},
                        {"mat.fuel", "Fuel canister", "raiders"}, {"val.hdd", "Hard drives", "military"}, {"mat.gunpowder_s", "Gunpowder", "raiders"}, {"herb.green", "Yarrow", "cultists"}};
                String[] w = r.pick(wants);
                c.target = w[0]; c.giver = w[2];
                c.need = w[0].startsWith("mat.fuel") || w[0].startsWith("val.") ? 1 : r.range(2, 4);
                c.title = "Supply run: " + w[1];
                c.desc = "Extract with " + c.need + "x " + w[1] + ". Delivered from your stash on completion.";
            }
            case CULL -> {
                c.target = "infected"; c.giver = "survivors"; c.need = r.range(4, 9);
                c.title = "Thin the herd: " + d.display;
                c.desc = "Kill " + c.need + " infected in the " + d.display + ". Lowers infected pressure there.";
            }
            case HUNT -> {
                String[] fs = {"raiders", "mercenaries"};
                c.target = r.pick(fs); c.giver = "raiders".equals(c.target) ? "military" : "survivors"; c.need = r.range(2, 4);
                String who = absentialis.sim.ZoneState.cap(c.target);
                c.title = "Bounty: " + who + " in " + d.display;
                c.desc = "Neutralise " + c.need + " " + who.toLowerCase() + " in the " + d.display + ". They will remember.";
            }
            case RECON -> {
                c.target = "explore"; c.giver = "military"; c.need = r.range(25, 60);
                c.title = "Survey the " + d.display;
                c.desc = "Map " + c.need + " new map cells of the " + d.display + " and extract with the data.";
            }
            case EXTRACT -> {
                c.target = "any"; c.giver = "survivors"; c.need = 1;
                c.title = "Courier: out through " + d.display;
                c.desc = "Deploy into the " + d.display + " and extract alive by any route.";
            }
            case INTEL -> {
                c.target = "document"; c.giver = "military"; c.need = r.range(1, 2);
                c.title = "Paper trail";
                c.desc = "Recover and read " + c.need + " document(s) anywhere in the Zone.";
            }
        }
        c.scrip = Math.round((250 + r.range(0, 250) + c.need * 40) * scale);
        c.xp = Math.round((2500 + c.need * 600 + r.range(0, 1500)) * scale);
        c.rep = 2 + r.range(0, 3);
        if (!alliance.isEmpty()) {
            // the work comes from your own side, and is never aimed at it
            c.giver = alliance;
            if (c.kind == Kind.HUNT) {
                String[] targets = switch (alliance) { case "military" -> new String[]{"raiders"}; case "raiders" -> new String[]{"military", "mercenaries", "survivors"}; case "mercenaries" -> new String[]{"raiders"}; default -> new String[]{"raiders"}; };
                c.target = r.pick(targets);
                String who = absentialis.sim.ZoneState.cap(c.target);
                c.title = ("raiders".equals(alliance) ? "Hit: " : "mercenaries".equals(alliance) ? "Contract: " : "Bounty: ") + who + " in " + d.display;
                c.desc = "Neutralise " + c.need + " " + who.toLowerCase() + " in the " + d.display + ". They will remember.";
            }
            if (c.kind == Kind.FETCH) {
                String[][] wants = switch (alliance) {
                    case "military" -> new String[][]{{"mat.electronics", "Circuit boards"}, {"val.hdd", "Hard drives"}};
                    case "raiders" -> new String[][]{{"mat.fuel", "Fuel canister"}, {"mat.gunpowder_s", "Gunpowder"}};
                    case "mercenaries" -> new String[][]{{"val.hdd", "Hard drives"}, {"mat.electronics", "Circuit boards"}};
                    default -> new String[][]{{"med.bandage", "Bandages"}, {"food.canned", "Canned stew"}, {"herb.green", "Green herbs"}};
                };
                String[] w = r.pick(wants);
                c.target = w[0];
                c.need = w[0].startsWith("mat.fuel") || w[0].startsWith("val.") ? 1 : r.range(2, 4);
                c.title = ("raiders".equals(alliance) ? "Haul: " : "Supply run: ") + w[1];
                c.desc = "Extract with " + c.need + "x " + w[1] + ". Delivered from your stash on completion.";
            }
            if (c.kind == Kind.EXTRACT && "raiders".equals(alliance)) { c.title = "Run a load out through " + d.display; c.desc = "Deploy into the " + d.display + " and get out alive by any route. The cordon is not to know."; }
            if ("mercenaries".equals(alliance)) { c.scrip = Math.round(c.scrip * 1.3f); c.rep = Math.max(1, c.rep * 0.5f); }
            if ("survivors".equals(alliance)) { c.scrip = Math.round(c.scrip * 0.85f); c.rep += 1; }
        }
        return c;
    }

    public String accept(String id) {
        if (active.size() >= MAX_ACTIVE) return "Contract limit reached (" + MAX_ACTIVE + ")";
        for (Contract c : board) if (c.id.equals(id)) { board.remove(c); active.add(c); return null; }
        return "Unknown contract";
    }

    public void abandon(String id) { active.removeIf(c -> c.id.equals(id)); }

    /** Raid event hooks. */
    public void onKill(String faction, District d) {
        for (Contract c : active) {
            if (!c.district.equals(d.name())) continue;
            if (c.kind == Kind.CULL && "infected".equals(faction)) c.have = Math.min(c.need, c.have + 1);
            if (c.kind == Kind.HUNT && c.target.equals(faction)) c.have = Math.min(c.need, c.have + 1);
        }
    }

    public void onExplore(District d, int cells) { for (Contract c : active) if (c.kind == Kind.RECON && c.district.equals(d.name())) c.have = Math.min(c.need, c.have + cells); }
    public void onDocument() { for (Contract c : active) if (c.kind == Kind.INTEL) c.have = Math.min(c.need, c.have + 1); }
    public void onExtract(District deployedIn) { for (Contract c : active) if (c.kind == Kind.EXTRACT && c.district.equals(deployedIn.name())) c.have = c.need; }

    public Map<String, Object> toJson() {
        Map<String, Object> m = new LinkedHashMap<>();
        List<Object> b = new ArrayList<>(), a = new ArrayList<>();
        for (Contract c : board) b.add(c.toJson());
        for (Contract c : active) a.add(c.toJson());
        m.put("board", b); m.put("active", a); m.put("completed", new ArrayList<Object>(completed)); m.put("serial", serial);
        return m;
    }

    @SuppressWarnings("unchecked")
    public static Contracts fromJson(Map<String, Object> m) {
        Contracts c = new Contracts();
        if (m == null) return c;
        for (Object o : Json.list(m, "board")) c.board.add(Contract.fromJson((Map<String, Object>) o));
        for (Object o : Json.list(m, "active")) c.active.add(Contract.fromJson((Map<String, Object>) o));
        c.completed.addAll(Json.strList(m, "completed"));
        c.serial = Json.integer(m, "serial", 0);
        return c;
    }
}
