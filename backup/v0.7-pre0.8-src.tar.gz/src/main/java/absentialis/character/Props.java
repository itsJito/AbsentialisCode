package absentialis.character;

import absentialis.engine.render.Tex;
import absentialis.engine.voxel.VoxModel;

/**
 * Things that are part of a creature but too long for a limb's own grid (0.7): the Gladiator's claws, the Butcher's
 * chainsaw. Each is a small voxel model drawn on a hand bone, in that bone's own voxel space, so it swings with the
 * arm and falls with the body. Built once.
 */
public final class Props {
    private Props() {}

    /** Where each model's pivot is, in its own voxels: the point that sits on the hand bone's pivot. */
    public static final float[] CLAWS_AT = {3, 12, 3}, SAW_AT = {3, 20, 3.5f};

    private static VoxModel claws, saw;

    /** Three long steel claws on the back of a gauntlet, running on down past the knuckles. */
    public static VoxModel claws() {
        if (claws != null) return claws;
        VoxModel m = new VoxModel(6, 11, 6);
        int steel = Tex.rgb(176, 180, 188), edge = Tex.rgb(226, 230, 236), dark = Tex.rgb(92, 96, 104), blood = Tex.rgb(112, 20, 20);
        for (int k = 0; k < 3; k++) {
            int x = k * 2 + (k == 2 ? 1 : 0), len = k == 1 ? 11 : 10;
            for (int i = 0; i < len; i++) {
                int y = 10 - i, z = i > len - 3 ? 2 : 1;                 // the last of it curves forward to the point
                m.set(x, y, z, i == 0 ? dark : i > len - 3 ? edge : steel);
                if (i < 3) m.set(x, y, z + 1, dark);                     // the root, where it is riveted to the plate
            }
            m.set(x, 10 - len + 2, 2, blood);
        }
        m.jitter(0.05f, 7);
        return claws = m;
    }

    /** A chainsaw: the engine block in the fist, the bar and its chain running on ahead of the hand. */
    public static VoxModel chainsaw() {
        if (saw != null) return saw;
        VoxModel m = new VoxModel(6, 22, 8);
        int body = Tex.rgb(206, 96, 26), dark = Tex.rgb(38, 38, 42), bar = Tex.rgb(168, 172, 178), chain = Tex.rgb(60, 62, 68), blood = Tex.rgb(118, 16, 16), grip = Tex.rgb(26, 26, 28);
        // engine block and its housing
        for (int x = 0; x < 6; x++) for (int y = 14; y < 21; y++) for (int z = 0; z < 7; z++) m.set(x, y, z, (y == 14 || y == 20) ? dark : body);
        for (int x = 1; x < 5; x++) for (int z = 1; z < 6; z++) m.set(x, 21, z, grip);            // top handle
        m.set(2, 17, 7, dark); m.set(3, 17, 7, dark); m.set(2, 18, 7, dark); m.set(3, 18, 7, dark); // pull-start
        for (int y = 15; y < 20; y += 2) for (int x = 0; x < 6; x += 5) m.set(x, y, 3, dark);     // cooling slots
        // the guide bar, and the chain round its edge
        for (int y = 1; y < 14; y++) for (int z = 2; z < 6; z++) {
            boolean rim = z == 2 || z == 5 || y == 1;
            m.set(2, y, z, rim ? chain : bar); m.set(3, y, z, rim ? chain : bar);
        }
        for (int y = 2; y < 14; y += 2) { m.set(2, y, 1, chain); m.set(3, y, 6, chain); }          // teeth
        m.set(2, 0, 3, chain); m.set(3, 0, 4, chain);
        // it has been used
        for (int y = 1; y < 9; y++) if ((y * 7 + 3) % 3 != 0) { m.set(2, y, 3 + y % 2, blood); m.set(3, y, 4 - y % 2, blood); }
        m.jitter(0.05f, 11);
        return saw = m;
    }
}
