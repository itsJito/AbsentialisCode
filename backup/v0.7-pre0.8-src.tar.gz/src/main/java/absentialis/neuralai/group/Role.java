package absentialis.neuralai.group;

/** What the squad has asked one of its members to be for the next few seconds. */
public enum Role {
    HOLD, SUPPRESS, ADVANCE, FLANK_LEFT, FLANK_RIGHT, INVESTIGATE, SEARCH, REPOSITION, RETREAT;

    public boolean flank() { return this == FLANK_LEFT || this == FLANK_RIGHT; }
}
