package absentialis.neuralai.integration;

import absentialis.ai.Brain;
import absentialis.ai.SquadMind;
import absentialis.entity.Actor;
import absentialis.entity.Physics;
import absentialis.entity.Vital;
import absentialis.neuralai.api.GameWorld;
import absentialis.neuralai.api.Vec3;
import absentialis.scene.AIInjuryAdapter;
import absentialis.scene.Gore;
import absentialis.scene.Raid;
import absentialis.world.CoverMap;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * NeuralAI's view of Absentialis: the existing raid, its actors, its voxel physics, its navigation and its cover
 * map, behind the {@link GameWorld} seam. Nothing is simulated here - every answer is the host's own.
 *
 * Units and axes are the game's and NeuralAI uses them as they are: metres, +y up, a character whose yaw is 0 faces
 * -z, +x is to its right. Everything runs on the raid's update thread.
 */
public final class GameAdapter implements GameWorld {
    private final Raid r;
    private final Map<Long, CoverMap.Point> points = new HashMap<>();
    private final Map<Long, CoverMap.Point> held = new HashMap<>();
    private final ArrayList<CoverMap.Point> scratch = new ArrayList<>();
    /** Lines spoken through NeuralAI, weapon commands refused because a friend was in the way, and shots fired (gates). */
    public int spoken, heldFire, shots;

    public GameAdapter(Raid raid) { this.r = raid; }

    private Actor a(long id) { return r.actor((int) id); }
    private static Vec3 v(float x, float y, float z) { return new Vec3(x, y, z); }

    @Override public double simulationTimeSeconds() { return r.time; }
    @Override public Vec3 actorPosition(long id) { Actor a = a(id); return a == null ? Vec3.ZERO : v(a.x, a.y, a.z); }
    @Override public Vec3 actorForward(long id) { Actor a = a(id); return a == null ? new Vec3(0, 0, -1) : new Vec3(-Math.sin(a.yaw), 0, -Math.cos(a.yaw)); }
    @Override public Vec3 actorVelocity(long id) { Actor a = a(id); return a == null ? Vec3.ZERO : v(a.vx, a.vy, a.vz); }
    @Override public boolean isAlive(long id) { Actor a = a(id); return a != null && !a.dead; }
    @Override public double eyeHeight(long id) { Actor a = a(id); return a == null ? 1.6 : a.eyeY() - a.y; }
    @Override public double bodyHeight(long id) { Actor a = a(id); return a == null ? 1.8 : a.height(); }

    @Override public boolean hostile(long observer, long other) {
        Actor a = a(observer), b = a(other);
        if (a == null || b == null || a == b || b.dead) return false;
        if (Brain.hostile(r, a, b)) return true;
        // someone who has watched the player shoot at people treats the player as a threat, whatever the standing says
        return b.isPlayer && !a.infected() && !a.mate() && !a.hostileToPlayer && a.sawPlayerAggress;
    }

    @Override public boolean rayClear(Vec3 from, Vec3 to) { return Physics.sight(r.world, (float) from.x(), (float) from.y(), (float) from.z(), (float) to.x(), (float) to.y(), (float) to.z()); }
    @Override public int foliageBetween(Vec3 from, Vec3 to) { return Physics.foliage(r.world, (float) from.x(), (float) from.y(), (float) from.z(), (float) to.x(), (float) to.y(), (float) to.z()); }
    @Override public double lightAt(Vec3 p) { return r.world.brightness((float) p.x(), (float) p.y(), (float) p.z(), r.daylight()); }
    @Override public double visibilityRange() { return r.fogSight(); }

    @Override public List<Long> potentialTargetsNear(Vec3 c, double radius) {
        List<Long> out = new ArrayList<>();
        float x = (float) c.x(), z = (float) c.z(), rad = (float) radius;
        for (Actor o : r.actors) if (!o.dead && Math.abs(o.x - x) < rad && Math.abs(o.z - z) < rad) out.add((long) o.id);
        return out;
    }

    @Override public List<SoundEvent> soundEventsSince(long sequence) { return r.soundsSince(sequence); }
    @Override public long soundSequence() { return r.soundSequence(); }

    @Override public List<Evidence> evidenceNear(Vec3 c, double radius) {
        List<Evidence> out = new ArrayList<>();
        float x = (float) c.x(), z = (float) c.z(), rad = (float) radius;
        for (Actor o : r.actors) {
            if (!o.dead || o.isPlayer || o.infected() || Math.abs(o.x - x) > rad || Math.abs(o.z - z) > rad) continue;
            // a body says which side it was on, and the wound says which way the blow came from
            out.add(new Evidence(o.id, v(o.x, o.y, o.z), new Vec3(-o.hitDirX, 0, -o.hitDirZ), 0.5, "body:" + o.faction, o.diedAt));
        }
        for (Gore.Pool p : r.gore.pools) {
            if (Math.abs(p.x - x) > rad || Math.abs(p.z - z) > rad || r.time - p.born > 300) continue;
            out.add(new Evidence(1_000_000L + p.id, v(p.x, p.y, p.z), Vec3.ZERO, 0.4, "blood", p.born));
        }
        return out;
    }

    @Override public NavPath path(Vec3 from, Vec3 to) {
        int[] p = r.world.nav.path((float) from.x(), (float) from.y(), (float) from.z(), (float) to.x(), (float) to.z(), 2600, true);
        if (p == null) return new NavPath(List.of(), 0, false);
        List<Vec3> corners = new ArrayList<>();
        double len = 0;
        Vec3 prev = from;
        for (int i = 0; i < p.length / 3; i++) { Vec3 c = new Vec3(p[i * 3] + 0.5, p[i * 3 + 1], p[i * 3 + 2] + 0.5); len += prev.distance(c); prev = c; corners.add(c); }
        boolean reach = !corners.isEmpty() && corners.get(corners.size() - 1).distanceXZ(to) < 2.5;
        return new NavPath(corners, len, reach);
    }

    @Override public boolean walkable(Vec3 from, Vec3 to) { return r.world.nav.clear((float) from.x(), (float) from.y(), (float) from.z(), (float) to.x(), (float) to.z(), true); }

    private static long pointId(CoverMap.Point p) { return ((long) p.x << 42) ^ ((long) p.z << 20) ^ ((long) p.y << 8) ^ ((p.dx + 1) << 4) ^ (p.dz + 1); }

    @Override public List<TacticalPoint> tacticalPointsNear(Vec3 o, double radius) {
        scratch.clear();
        r.world.cover.near((float) o.x(), (float) o.y(), (float) o.z(), (float) radius, scratch);
        List<TacticalPoint> out = new ArrayList<>(scratch.size());
        if (points.size() > 6000) points.clear();
        for (CoverMap.Point p : scratch) {
            if (!p.valid) continue;
            long id = pointId(p);
            points.put(id, p);
            Vec3 pos = new Vec3(p.cx(), p.y, p.cz());
            boolean low = p.height == CoverMap.LOW;
            // where a body shoots from: over a low obstacle from where it kneels; round a high one from a step out past its end
            Vec3 peek = pos;
            if (!low) { int side = p.leanLeft ? 1 : p.leanRight ? -1 : 0; peek = pos.add(new Vec3(p.leftX() * side * 0.9, 0, p.leftZ() * side * 0.9)); }
            out.add(new TacticalPoint(id, pos, peek, new Vec3(-p.dx, 0, -p.dz), low, p.leanLeft, p.leanRight, p.integrity));
        }
        return out;
    }

    @Override public Vec3 standNear(Vec3 p) { float[] s = r.standSpot((float) p.x(), (float) p.z()); return s == null ? null : v(s[0], s[1], s[2]); }

    @Override public boolean reservePoint(long pointId, long actor, double until) {
        CoverMap.Point p = points.get(pointId);
        if (p == null || !p.valid || !p.freeFor((int) actor, r.time)) return false;
        releasePoints(actor);
        r.world.cover.claim(p, (int) actor, (float) until);
        held.put(actor, p);
        Actor a = a(actor);
        if (a != null) { a.cover = p; a.hasCover = true; a.coverX = p.cx(); a.coverZ = p.cz(); a.coverSince = r.time; }
        return true;
    }

    @Override public void releasePoints(long actor) {
        CoverMap.Point p = held.remove(actor);
        if (p != null) r.world.cover.release(p, (int) actor);
        Actor a = a(actor);
        if (a != null) { a.cover = null; a.hasCover = false; a.coverAmt = 0; a.coverSide = 0; a.lean = 0; a.leanTarget = 0; }
    }

    @Override public boolean hazardAt(Vec3 p) { return r.zoneAt((float) p.x(), (float) p.y(), (float) p.z()) != null || r.fire.at((float) p.x(), (float) p.y(), (float) p.z()) != null; }

    @Override public void issueWeaponCommand(long actor, WeaponCommand c) {
        Actor a = a(actor);
        if (a == null || a.dead || a.weapon == null) return;
        if (c.reload()) { r.npcReload(a); return; }
        if (!c.trigger()) return;
        int res = r.npcCommandFire(a, (float) c.aim().x(), (float) c.aim().y(), (float) c.aim().z(), c.speculative(), (int) c.intendedTarget());
        if (res > 0) shots++; else if (res < 0) heldFire++;
    }

    @Override public SelfState self(long id) {
        Actor a = a(id);
        if (a == null) return new SelfState(Vec3.ZERO, new Vec3(0, 0, -1), 0, 0, "none", false, false, false, false, 0, 0, 0, 0, 0, false, true, Vec3.ZERO, 0, 1, 3);
        Brain.Arch ar = Brain.arch(a.archetype);
        Brain.Doc dc = a.mate() ? null : Brain.doc(a.faction);
        boolean asleep = absentialis.sim.Agents.asleep(a.routine) && r.time > a.wakeUntil;
        String kind = "none";
        double ammo = 0;
        if (a.weapon != null && a.weapon.def().weapon != null && !a.weapon.def().weapon.melee()) {
            var w = a.weapon.def().weapon;
            kind = "marksman".equals(a.archetype) ? "scoped" : "shotgun".equals(w.family) ? "shotgun" : w.modes.contains("auto") ? "auto" : "handgun".equals(w.family) || "magnum".equals(w.family) ? "handgun" : "rifle";
            ammo = a.weapon.rounds / (double) Math.max(1, a.weapon.capacity());
        }
        boolean grounded = a.vital != Vital.ACTIVE || a.ragdoll != null || a.seated || a.crawling;
        float sight = asleep ? 2.2f : ar.sight() * r.difficultySight() * (1 - 0.3f * r.rain());
        return new SelfState(v(a.x, a.y, a.z), new Vec3(-Math.sin(a.yaw), 0, -Math.cos(a.yaw)), Math.max(0, a.hp / Math.max(1, a.maxHp)), ammo, kind,
                (a.impaired & AIInjuryAdapter.CANT_WALK) == 0, a.weapon != null && (a.impaired & AIInjuryAdapter.CANT_SHOOT) == 0 && r.time >= a.blindUntil, a.weapon != null,
                a.mate() || SquadMind.radio(a.faction), sight, Math.toDegrees(Math.acos(Math.max(-1, Math.min(1, ar.fovCos())))), ar.hearing() * (asleep ? 0.4 : 1),
                a.morale, a.mate() || dc == null ? 0.05 : dc.breakAt(), r.time < a.staggerUntil, grounded, v(a.homeX, a.y, a.homeZ), a.mate() || dc == null ? 60 : dc.leash(), ar.speed(), ar.runSpeed());
    }

    @Override public boolean lit(long id) {
        Actor o = a(id);
        if (o == null) return false;
        return o.light || r.time < o.flashUntil || o.isPlayer && (r.playerFlashlight || r.playerLaser || r.time - r.lastPlayerShot < 0.35f);
    }

    @Override public boolean speak(long actor, String event, String detail) {
        Actor a = a(actor);
        if (a == null || a.dead) return false;
        String[] line = Lines.of(r, a, event, detail);
        if (line == null) return false;
        float before = a.lastSay;
        r.say(a, line[0], line[1]);
        if (a.lastSay == before) return false;
        spoken++;
        return true;
    }

    @Override public boolean throwGrenade(long actor, Vec3 at) {
        Actor a = a(actor);
        if (a == null || a.dead || a.mate()) return false;
        Brain.Doctrine d = Brain.doc(a.faction).d();
        if (d == Brain.Doctrine.LONER) return false;
        r.npcThrow(a, (float) at.x(), (float) at.y(), (float) at.z(), d == Brain.Doctrine.BANDIT ? "grenade.pipe" : "grenade.frag");
        a.fireCooldown = 1.4f;
        return true;
    }
}
