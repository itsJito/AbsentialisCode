package absentialis.neuralai.runtime;

import absentialis.engine.util.Json;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Every number NeuralAI is tuned with, read from /content/neuralai.json (profiles, squad roles, search weights) with
 * the defaults below when the file or a key is missing. These are calibration values for this game - none of them is
 * a fact about any other.
 */
public final class NeuralConfig {
    // ---- scheduling (ticks per second)
    public double visionHz = 15, beliefHz = 10, decisionHz = 5, rolesHz = 2, searchHz = 2;
    // ---- vision
    public double gainPerSecond = 0.8, decayPerSecond = 0.22;
    public double lookAt = 0.2, investigate = 0.5, confirm = 1.0, lookAtDown = 0.1, investigateDown = 0.35, confirmDown = 0.8;
    public double nearDistance = 4, farDistance = 26, nearHalfAngleDeg = 105, farHalfAngleDeg = 55, closeSense = 2.2;
    public double crouchExposure = 0.65, proneExposure = 0.38, stillExposure = 0.8, movingExposure = 1.2, sprintExposure = 1.45, foliagePerCell = 0.55, darkFloor = 0.3;
    public double alertMultiplier = 2.4, combatMultiplier = 3.2;
    // ---- hearing
    public double hearErrorPerMetre = 0.14, hearUnambiguous = 5, threatSoundAlert = 0.8, quietSoundAlert = 0.3;
    // ---- beliefs
    public double assumedTargetSpeed = 2.4, maxUncertainty = 34, visibleRadius = 0.4, lostAfter = 4.5, forgetAfter = 75, reportExpiry = 22;
    // ---- search
    public double cell = 4, searchRadius = 26, wLikelihood = 3, wConcealment = 2, wInfoGain = 2, wPathCost = 1, wReservation = 3, emptyFactor = 0.12, diffusion = 0.22, reservationTtl = 14, inspectSeconds = 2.2;
    public double searchPatienceSeconds = 55;
    // ---- cover
    public double wProtection = 3, wFiringAngle = 2, wFlank = 1.5, wTravel = 1, wExposure = 2.5, coverRadius = 16, coverTtl = 7, pinnedRelocate = 5;
    // ---- roles
    public int maxFlankPerSide = 1, maxSuppress = 2;
    public double roleSeconds = 8, switchingCost = 0.35, flankStale = 14, flankDistance = 12;
    // ---- decisions
    public double commitSeconds = 1.1, hysteresis = 0.18, grenadeRadius = 7.5;
    // ---- reports
    public double shoutRange = 26, shoutDelay = 0.45, radioDelay = 1.1, radioRange = 260, signalRange = 30, signalDelay = 0.2;
    // ---- fire
    public double burstMin = 2, burstMax = 5, peekSeconds = 2.0, hideSeconds = 1.5, suppressSeconds = 7, speculativeError = 2.4;
    // ---- squadmates
    public double followBehind = 2.4, followSpacing = 1.5, followLeash = 26, holdLeash = 6, moveLeash = 40, sprintToCatchUp = 9;

    /** Personality by faction: aggression, caution, teamPreference, searchPatience, reactionLatency (seconds). */
    public record Profile(double aggression, double caution, double teamPreference, double searchPatience, double reactionLatency, boolean radio, double preferredRange) {}
    public final Map<String, Profile> profiles = new LinkedHashMap<>();
    /** Role suitability biases by archetype: {role -> bias}. */
    public final Map<String, Map<String, Double>> roleBias = new LinkedHashMap<>();

    private static NeuralConfig instance;

    public static synchronized NeuralConfig get() {
        if (instance == null) instance = load();
        return instance;
    }

    public Profile profile(String faction) { Profile p = profiles.get(faction); return p != null ? p : profiles.get("default"); }

    public double bias(String archetype, String role) {
        Map<String, Double> m = roleBias.get(archetype);
        Double v = m == null ? null : m.get(role);
        return v == null ? 0 : v;
    }

    private static NeuralConfig load() {
        NeuralConfig c = new NeuralConfig();
        c.profiles.put("default", new Profile(0.5, 0.5, 0.5, 1, 0.35, false, 18));
        c.profiles.put("military", new Profile(0.45, 0.65, 0.9, 1.0, 0.30, true, 22));
        c.profiles.put("mercenaries", new Profile(0.6, 0.55, 0.95, 1.3, 0.22, true, 18));
        c.profiles.put("raiders", new Profile(0.8, 0.25, 0.4, 0.5, 0.45, false, 11));
        c.profiles.put("survivors", new Profile(0.25, 0.8, 0.5, 0.35, 0.55, false, 16));
        c.profiles.put("player", new Profile(0.5, 0.6, 1.0, 0.8, 0.25, true, 16));
        try (InputStream in = NeuralConfig.class.getResourceAsStream("/content/neuralai.json")) {
            if (in == null) return c;
            Map<String, Object> root = Json.parseObject(new String(in.readAllBytes(), StandardCharsets.UTF_8));
            for (Map.Entry<String, Object> e : Json.obj(root, "tuning").entrySet()) {
                if (!(e.getValue() instanceof Number n)) continue;
                try {
                    java.lang.reflect.Field f = NeuralConfig.class.getField(e.getKey());
                    if (f.getType() == double.class) f.setDouble(c, n.doubleValue());
                    else if (f.getType() == int.class) f.setInt(c, n.intValue());
                } catch (ReflectiveOperationException ignored) { System.err.println("[NeuralAI] unknown tuning key " + e.getKey()); }
            }
            for (Map.Entry<String, Object> e : Json.obj(root, "profiles").entrySet()) {
                @SuppressWarnings("unchecked") Map<String, Object> m = (Map<String, Object>) e.getValue();
                Profile d = c.profiles.get("default");
                c.profiles.put(e.getKey(), new Profile(Json.num(m, "aggression", d.aggression()), Json.num(m, "caution", d.caution()), Json.num(m, "teamPreference", d.teamPreference()),
                        Json.num(m, "searchPatience", d.searchPatience()), Json.num(m, "reactionLatency", d.reactionLatency()), Json.bool(m, "radio", d.radio()), Json.num(m, "preferredRange", d.preferredRange())));
            }
            for (Map.Entry<String, Object> e : Json.obj(root, "roles").entrySet()) {
                @SuppressWarnings("unchecked") Map<String, Object> m = (Map<String, Object>) e.getValue();
                Map<String, Double> b = new LinkedHashMap<>();
                for (Map.Entry<String, Object> r : m.entrySet()) if (r.getValue() instanceof Number n) b.put(r.getKey(), n.doubleValue());
                c.roleBias.put(e.getKey(), b);
            }
        } catch (Exception ex) {
            System.err.println("[NeuralAI] neuralai.json could not be read (" + ex + "): built-in defaults in use");
        }
        return c;
    }
}
