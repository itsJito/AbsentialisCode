package absentialis.scene;

import static absentialis.scene.Scenarios.*;

import absentialis.persistence.Profile;

/**
 * The scripts {@link Scenarios} can run. Each is a short, named sequence built for one thing that has to be looked
 * at: a screen, a pose, a room. Add one here when a change needs eyes on it.
 */
final class ScenarioScripts {
    private ScenarioScripts() {}

    /** Leave the allegiance question unanswered (to photograph it). */
    static boolean keepUnaligned;

    static void build(String name) {
        switch (name == null ? "" : name) {
            case "shop" -> shop();
            case "menus" -> menus();
            case "shop_user" -> shopUser();
            case "specials" -> specials();
            case "falls" -> falls();
            case "car" -> car();
            case "interiors" -> interiors();
            case "devmap" -> devmap();
            default -> System.out.println("[Scenario] unknown scenario '" + name + "'");
        }
    }

    /** Buying a weapon and seeing it in the stash without reloading the profile (the 0.6 report). */
    private static void shop() {
        profile(p -> p.scrip = 200000);
        hideout(6, h -> h.hideout().tab = HideoutScreen.TAB_INVENTORY);
        hideout(16, h -> shot(h, "shop_00_stash_before"));
        hideout(18, h -> h.hideout().debugShow(0, false));
        hideout(28, h -> shot(h, "shop_01_weapons"));
        hideout(30, h -> { h.hideout().debugBuy("weapon.pm9"); h.console("give weapon.matilda"); });
        hideout(40, h -> shot(h, "shop_02_after_buy"));
        hideout(42, h -> h.hideout().tab = HideoutScreen.TAB_INVENTORY);
        hideout(52, h -> shot(h, "shop_03_stash_after"));
        hideout(54, h -> { Profile p = h.ctx().profile; StringBuilder b = new StringBuilder(); for (var i : p.stash.items) b.append(i.defId).append('@').append(i.x).append(',').append(i.y).append(' '); System.out.println("[Scenario] stash: " + b); });
    }

    /** The same purchase against a profile already in the scratch save directory as slot 3 (a copy of a real one). */
    private static void shopUser() {
        hideout(6, h -> { h.ctx().profile.scrip += 200000; h.hideout().tab = HideoutScreen.TAB_INVENTORY; });
        hideout(16, h -> shot(h, "user_00_stash_before"));
        hideout(18, h -> h.hideout().debugShow(0, false));
        hideout(30, h -> { h.hideout().debugBuy("weapon.pm9"); h.console("give weapon.matilda"); });
        hideout(42, h -> h.hideout().tab = HideoutScreen.TAB_INVENTORY);
        hideout(52, h -> shot(h, "user_01_stash_after"));
        hideout(54, h -> { Profile p = h.ctx().profile; StringBuilder b = new StringBuilder(); for (var i : p.stash.items) b.append(i.defId).append('@').append(i.x).append(',').append(i.y).append(i.rotated ? "r " : " "); System.out.println("[Scenario] stash " + p.stash.w + "x" + p.stash.h + ": " + b + " verify=" + p.verify()); });
    }

    private static final String[] CAST = {"walker", "sprinter", "bomber", "spewer", "tank", "gladiator", "butcher"};
    private static final absentialis.entity.Actor[] cast = new absentialis.entity.Actor[CAST.length];
    private static float cx, cy, cz;

    /** The infected, stood in a row in daylight and walked round: every special's model, front, side and back. */
    private static void specials() {
        profile(null);
        raid(20, h -> {
            Raid r = h.raid().raid;
            r.god = true; r.populate = false; r.freezeAI = true;
            r.actors.removeIf(a -> !a.isPlayer);
            cx = r.player.x; cy = r.player.y; cz = r.player.z;
            for (int i = 0; i < CAST.length; i++) {
                cast[i] = r.debugSpawn(CAST[i], cx + (i - 3) * 2.4f, cz - 7, cy);
                cast[i].yaw = (float) Math.PI;
                cast[i].homeX = cast[i].x; cast[i].homeZ = cast[i].z;
            }
            place(r, cx, cy, cz + 1.5f, 0, -0.02f);
        });
        raid(50, h -> shot(h, "spec_00_row"));
        int f = 54;
        for (int i = 2; i < CAST.length; i++) {
            final int k = i;
            raid(f, h -> place(h.raid().raid, cast[k].x, cast[k].y, cast[k].z + (k == 4 ? 4.2f : 3.0f), 0, k == 4 ? 0.12f : 0.02f));
            raid(f + 12, h -> shot(h, "spec_" + k + "0_" + CAST[k] + "_front"));
            raid(f + 14, h -> place(h.raid().raid, cast[k].x + (k == 4 ? 4.2f : 3.0f), cast[k].y, cast[k].z, (float) Math.PI / 2, k == 4 ? 0.12f : 0.02f));
            raid(f + 26, h -> shot(h, "spec_" + k + "1_" + CAST[k] + "_side"));
            raid(f + 28, h -> place(h.raid().raid, cast[k].x, cast[k].y, cast[k].z - (k == 4 ? 4.2f : 3.0f), (float) Math.PI, k == 4 ? 0.12f : 0.02f));
            raid(f + 40, h -> shot(h, "spec_" + k + "2_" + CAST[k] + "_back"));
            f += 42;
        }
        // bile: what it does to the picture
        raid(f, h -> { Raid r = h.raid().raid; place(r, cx, cy, cz + 1.5f, 0, -0.02f); r.bile(r.player, 15); });
        raid(f + 30, h -> shot(h, "spec_90_biled"));
    }

    private static absentialis.entity.Actor subject;
    private static float sx, sy, sz;

    /** A hit, by name, on the subject standing at the mark. The blow travels +x (left to right across the picture). */
    private static void strike(Raid r, String what) {
        absentialis.entity.Actor from = new absentialis.entity.Actor();
        from.x = sx - 12; from.y = sy; from.z = sz; from.faction = "raiders"; from.archetype = "rifleman";
        absentialis.entity.Actor v = subject;
        switch (what) {
            case "chest" -> r.damageActor(v, from, 9999, absentialis.gameplay.items.Content.def("ammo.556"), "torso", v.x, v.y + 1.25f, v.z);
            case "head_from_behind" -> r.damageActor(v, from, 9999, absentialis.gameplay.items.Content.def("ammo.556"), "head", v.x, v.y + 1.68f, v.z);
            case "leg" -> r.damageActor(v, from, 9999, absentialis.gameplay.items.Content.def("ammo.556"), "legs", v.x, v.y + 0.5f, v.z);
            case "buckshot" -> { r.hitKind = ""; v.hitForce = 160; r.damageActor(v, from, 9999, absentialis.gameplay.items.Content.def("ammo.shells"), "torso", v.x, v.y + 1.2f, v.z); }
            case "running" -> { v.vx = 5.2f; v.pvx = 5.2f; r.damageActor(v, from, 9999, absentialis.gameplay.items.Content.def("ammo.556"), "torso", v.x, v.y + 1.25f, v.z); }
            case "blast" -> r.explode(sx - 2.6f, sy + 0.3f, sz, 6, 400, 0, false);
            case "shove" -> r.gore.ragdolls.knockDown(v, 1, 0, 95, 2.2f);
            case "shove_back" -> r.gore.ragdolls.knockDown(v, 1, 0, 95, 2.2f);
            default -> { }
        }
    }

    /**
     * The fall study (instructions.md, Sydney Engine touching up): one body after another is hit in a named way in
     * front of a fixed camera and photographed every third frame, and each run is tiled into a contact sheet.
     * {cast, facing yaw, the hit, frames to film}. Facing pi/2 looks at the shooter (-x); -pi/2 has its back to it.
     */
    private static final Object[][] FALLS = {
            {"survivors", 1.5708f, "chest", 132}, {"survivors", -1.5708f, "head_from_behind", 132}, {"military", 1.5708f, "leg", 132}, {"raiders", 3.1416f, "buckshot", 132},
            {"survivors", -1.5708f, "running", 132}, {"military", 1.5708f, "blast", 132}, {"survivors", 1.5708f, "shove", 330}, {"mercenaries", -1.5708f, "shove_back", 330},
            {"walker", 1.5708f, "chest", 132}, {"walker", 1.5708f, "shove", 330}};

    private static void falls() {
        profile(null);
        raid(20, h -> {
            Raid r = h.raid().raid;
            r.god = true; r.populate = false; r.freezeAI = true;
            r.actors.removeIf(a -> !a.isPlayer);
            sx = r.player.x; sy = r.player.y; sz = r.player.z - 3.0f;
            place(r, sx + 0.8f, sy, sz + 3.0f, 0, -0.16f);
        });
        int f = 30;
        for (int k = 0; k < FALLS.length; k++) {
            final int n = k;
            final Object[] e = FALLS[k];
            final int frames = (Integer) e[3] > 200 ? 360 : 96, every = frames > 200 ? 15 : 4;
            raid(f, h -> {
                Raid r = h.raid().raid;
                r.actors.removeIf(a -> !a.isPlayer);
                subject = r.debugSpawn((String) e[0], sx, sz, sy);
                subject.yaw = (Float) e[1]; subject.hostileToPlayer = false; subject.homeX = sx; subject.homeZ = sz;
                place(r, sx + 0.8f, sy, sz + 3.0f, 0, -0.16f);
            });
            raid(f + 24, h -> strike(h.raid().raid, (String) e[2]));
            final String name = String.format("fall_%02d_%s_%s", n, e[0], e[2]);
            for (int i = 0; i * every < frames; i++) { final int idx = i; raid(f + 24 + i * every, h -> shot(h, String.format("%s_%03d", name, idx))); }
            raid(f + 24 + frames + 2, h -> sheet(name, 8, 300, 120, 1000, 700, 0.25f));
            f += 24 + frames + 6;
        }
    }

    /** Getting into a car and out of it again, in third person, photographed every fourth frame (the door should lead the body both ways). */
    private static void car() {
        profile(null);
        raid(20, h -> {
            Raid r = h.raid().raid;
            r.god = true; r.populate = false; r.freezeAI = true;
            r.actors.removeIf(a -> !a.isPlayer);
            h.raid().thirdPerson = true;
            h.console("vehicle car.volna");
        });
        raid(60, h -> {
            Raid r = h.raid().raid;
            if (r.vehicles.cars.isEmpty()) { System.out.println("[Scenario] no car"); return; }
            VehicleSystem.Car c = r.vehicles.cars.get(r.vehicles.cars.size() - 1);
            float[] o = new float[3];
            c.sim.origin(o);
            // stand off the driver's side, a few steps from the door
            place(r, o[0] - c.sim.body.rightX() * 2.1f - c.sim.body.fwdX() * 1.2f, r.player.y, o[2] - c.sim.body.rightZ() * 2.1f - c.sim.body.fwdZ() * 1.2f, (float) Math.atan2(c.sim.body.rightX(), c.sim.body.rightZ()), -0.1f);
        });
        raid(90, h -> { boolean ok = h.raid().raid.vehicles.enter(); System.out.println("[Scenario] enter " + ok); });
        for (int i = 0; i < 28; i++) { final int idx = i; raid(90 + i * 4, h -> { shot(h, String.format("car_enter_%03d", idx)); System.out.println(String.format("[Scenario] enter frame %d: progress %.2f door %.2f", idx, h.raid().raid.vehicles.phaseProgress(), h.raid().raid.vehicles.doorOpen())); }); }
        raid(206, h -> sheet("car_enter", 7, 250, 150, 1100, 650, 0.26f));
        raid(240, h -> System.out.println("[Scenario] exit " + h.raid().raid.vehicles.exit()));
        for (int i = 0; i < 28; i++) { final int idx = i; raid(240 + i * 4, h -> { shot(h, String.format("car_exit_%03d", idx)); System.out.println(String.format("[Scenario] exit frame %d: progress %.2f door %.2f", idx, h.raid().raid.vehicles.phaseProgress(), h.raid().raid.vehicles.doorOpen())); }); }
        raid(356, h -> sheet("car_exit", 7, 250, 150, 1100, 650, 0.26f));
    }

    private static final java.util.List<Object[]> ROOMS = new java.util.ArrayList<>();

    /**
     * The interior survey (instructions.md rule 10): one room of every kind in every kind of building, photographed
     * from a corner at eye height looking across it, by day. ABS_ROOMS limits how many (default 60); ABS_ROOM_FILTER
     * keeps only rooms whose "archetype/type" contains the text. Each picture is named for what it shows.
     */
    private static void interiors() {
        profile(null);
        final int max = System.getenv("ABS_ROOMS") != null ? Integer.parseInt(System.getenv("ABS_ROOMS")) : 60;
        final String filter = System.getenv("ABS_ROOM_FILTER");
        raid(20, h -> {
            Raid r = h.raid().raid;
            r.god = true; r.populate = false; r.freezeAI = true;
            r.actors.removeIf(a -> !a.isPlayer);
            java.util.Set<String> seen = new java.util.LinkedHashSet<>();
            for (absentialis.world.MapData.Building b : r.world.map.buildings) for (absentialis.world.MapData.Room rm : b.rooms) {
                String key = (b.landmark.isEmpty() ? b.archetype : b.landmark) + "/" + rm.type;
                if (rm.circulation && !key.contains("hall") || (rm.x1 - rm.x0) < 2 || (rm.z1 - rm.z0) < 2) continue;
                if (filter != null) { boolean hit = false; for (String part : filter.split(",")) hit |= key.endsWith(part) || key.contains(part + "/"); if (!hit) continue; }
                if (!seen.add(System.getenv("ABS_ROOM_ONE") != null ? rm.type : key) || ROOMS.size() >= max) continue;
                ROOMS.add(new Object[]{key.replace('/', '_').replace(' ', '_'), rm, b});
            }
            System.out.println("[Scenario] interiors: " + ROOMS.size() + " rooms of " + seen.size() + " kinds");
        });
        for (int k = 0; k < max; k++) {
            final int n = k;
            raid(30 + k * 170, h -> {
                if (n >= ROOMS.size()) return;
                Raid r = h.raid().raid;
                absentialis.world.MapData.Room rm = (absentialis.world.MapData.Room) ROOMS.get(n)[1];
                // stand in the free corner cell furthest from the middle that has room to stand, and look at the middle
                float cx = (rm.x0 + rm.x1 + 1) / 2f, cz = (rm.z0 + rm.z1 + 1) / 2f, bx = cx, bz = cz, bd = -1;
                for (int x = rm.x0; x <= rm.x1; x++) for (int z = rm.z0; z <= rm.z1; z++) {
                    if (r.world.solid(x, rm.y + 1, z) || r.world.solid(x, rm.y + 2, z) || !r.world.solid(x, rm.y, z)) continue;
                    float d = (x + 0.5f - cx) * (x + 0.5f - cx) + (z + 0.5f - cz) * (z + 0.5f - cz);
                    if (d > bd) { bd = d; bx = x + 0.5f; bz = z + 0.5f; }
                }
                place(r, bx, rm.y + 1, bz, (float) Math.atan2(-(cx - bx), -(cz - bz)), -0.18f);
                h.raid().thirdPerson = false;
            });
            raid(30 + k * 170 + 164, h -> { if (n < ROOMS.size()) shot(h, String.format("room_%02d_%s", n, ROOMS.get(n)[0])); });
        }
    }

    /** The devmap, loaded the way a developer loads it (the console), and looked at from each of its four parts. */
    private static void devmap() {
        profile(null);
        for (int f = 8; f < 3000; f += 30) hideout(f, h -> { if (absentialis.world.gen.DevMap.mansion == null && h.worldReady()) h.console("devmap 0"); });
        raid(60, h -> { Raid r = h.raid().raid; r.god = true; place(r, absentialis.world.gen.DevMap.ROAD_X0 + 4, g(), (absentialis.world.gen.DevMap.ROAD_Z0 + absentialis.world.gen.DevMap.ROAD_Z1) / 2f + 0.5f, -1.5708f, -0.03f); });
        raid(150, h -> shot(h, "dev_00_road"));
        raid(152, h -> place(h.raid().raid, absentialis.world.gen.DevMap.mazeInX + 1, g(), absentialis.world.gen.DevMap.mazeInZ - 7, 3.1416f, -0.02f));
        raid(240, h -> shot(h, "dev_01_maze"));
        raid(242, h -> place(h.raid().raid, absentialis.world.gen.DevMap.mansion.entryX + 0.5f, g(), absentialis.world.gen.DevMap.mansion.entryZ - 9, 3.1416f, 0.12f));
        raid(330, h -> shot(h, "dev_02_mansion"));
        raid(332, h -> place(h.raid().raid, absentialis.world.gen.DevMap.YARD_X + 2, g(), absentialis.world.gen.DevMap.YARD_Z + 12, -1.35f, -0.05f));
        raid(420, h -> shot(h, "dev_03_yard"));
        raid(422, h -> place(h.raid().raid, absentialis.world.gen.DevMap.holesX + 8, g(), absentialis.world.gen.DevMap.holesZ + 7, 0f, 0.15f));
        raid(510, h -> shot(h, "dev_04_openings"));
    }

    /** Every tab of the hideout, the shop departments and the deployment briefing. */
    private static void menus() {
        keepUnaligned = true;
        profile(p -> { p.scrip = 90000; p.prog.addXp(absentialis.gameplay.progression.Progression.xpToReach(9)); });
        hideout(5, h -> shot(h, "menu_00_allegiance"));
        hideout(7, h -> { absentialis.gameplay.Alliance.choose(h.ctx().profile, "survivors"); h.hideout().enter(); });
        int f = 12;
        for (int t = 0; t < HideoutScreen.TABS.length; t++) {
            final int tab = t;
            hideout(f, h -> h.hideout().tab = tab);
            hideout(f + 10, h -> shot(h, "menu_1" + tab + "_" + HideoutScreen.TABS[tab].toLowerCase()));
            f += 12;
        }
        for (int d = 0; d <= ShopPanel.RECRUITS; d++) {
            final int dept = d;
            hideout(f, h -> h.hideout().debugShow(dept, false));
            hideout(f + 10, h -> shot(h, "menu_2" + dept + "_shop"));
            f += 12;
        }
        hideout(f, h -> h.hideout().debugShow(-1, true));
        hideout(f + 10, h -> shot(h, "menu_30_briefing"));
        hideout(f + 12, h -> { h.hideout().debugShow(-1, false); h.hideout().unlocks.show(1, 9); });
        hideout(f + 70, h -> shot(h, "menu_31_unlocked"));
        hideout(f + 72, h -> h.hideout().unlocks.dismiss());
    }
}
