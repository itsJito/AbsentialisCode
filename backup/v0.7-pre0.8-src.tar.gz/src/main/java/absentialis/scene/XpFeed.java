package absentialis.scene;

import absentialis.gameplay.progression.Progression;
import absentialis.ui.Ui;
import java.util.ArrayList;
import java.util.List;

/**
 * Experience, seen as it is earned (0.6). A slim bar at the top of the screen shows the Rank held, how far it is to
 * the next one as a percentage, and what this operation has added so far; every action that earns experience posts a
 * line under it saying how much and what for.
 *
 * Nothing here awards anything. Experience is still settled once, at the debrief, by {@link RaidResolver}; this
 * class watches the same counters the resolver will read and prices them with the resolver's own constants, so the
 * figure on screen is the figure that will be paid (halved, as the bar says, if the operation fails).
 */
public final class XpFeed {
    /** One line of feedback: how much, what for, and when it appeared. */
    public static final class Toast { public String label; public int amount; public float at; }

    private final Raid raid;
    public final List<Toast> toasts = new ArrayList<>();
    private int containers, cells, documents, aided, minutes;
    private boolean power;
    private float lastGain = -99, shownProgress = -1;
    /** Seconds a line stays, and how long the bar stays lit after a gain. */
    public static float TOAST_LIFE = 3.6f, HOLD = 6f;

    public XpFeed(Raid raid) { this.raid = raid; }

    /** Experience this operation has earned so far, by the resolver's own prices (the extraction bonus and loot value come at the debrief). */
    public int pending() {
        Raid.Debrief d = raid.debrief;
        return d.containersSearched * RaidResolver.XP_CONTAINER + d.cellsRevealed * RaidResolver.XP_CELL + d.documents * RaidResolver.XP_DOCUMENT + d.aided * RaidResolver.XP_AID
                + (d.powerRestored ? RaidResolver.XP_POWER : 0) + Math.round(raid.time / 60f * RaidResolver.XP_PER_MINUTE);
    }

    private void post(String label, int amount) {
        if (amount <= 0) return;
        lastGain = raid.time;
        // a run of the same thing (map cells while walking) adds to the line already showing instead of stacking a column of them
        for (Toast t : toasts) if (t.label.equals(label) && raid.time - t.at < TOAST_LIFE * 0.75f) { t.amount += amount; t.at = raid.time; return; }
        Toast t = new Toast();
        t.label = label; t.amount = amount; t.at = raid.time;
        toasts.add(t);
        while (toasts.size() > 5) toasts.remove(0);
    }

    /** Looks at what has been done since the last frame and posts a line for each thing that earned experience. */
    public void update() {
        Raid.Debrief d = raid.debrief;
        if (d.containersSearched > containers) post("Container searched", (d.containersSearched - containers) * RaidResolver.XP_CONTAINER);
        if (d.cellsRevealed > cells) post("Reconnaissance", (d.cellsRevealed - cells) * RaidResolver.XP_CELL);
        if (d.documents > documents) post("Intel recovered", (d.documents - documents) * RaidResolver.XP_DOCUMENT);
        if (d.aided > aided) post("Aided a loner", (d.aided - aided) * RaidResolver.XP_AID);
        if (d.powerRestored && !power) post("Restored district power", RaidResolver.XP_POWER);
        int m = (int) (raid.time / 60f);
        if (m > minutes) post("Time in the Zone", (m - minutes) * RaidResolver.XP_PER_MINUTE);
        containers = d.containersSearched; cells = d.cellsRevealed; documents = d.documents; aided = d.aided; power = d.powerRestored; minutes = m;
        toasts.removeIf(t -> raid.time - t.at > TOAST_LIFE);
    }

    /** The bar and its lines, centred at the top of the screen. */
    public void draw(Ui ui) {
        Progression pr = raid.profile.prog;
        float xpMul = 1 + raid.profile.loadout.charm("xp");
        int pend = Math.round(pending() * xpMul);
        float[] pv = pr.preview(pend);
        int rank = (int) pv[0];
        float target = pv[1];
        if (shownProgress < 0) shownProgress = target;
        // the fill eases to its new place; over a Rank boundary it runs to the end and starts again
        shownProgress += ((target < shownProgress - 0.5f ? 1.02f : target) - shownProgress) * Math.min(1, ui.dt * 4);
        if (shownProgress > 1) shownProgress = 0;
        float since = raid.time - lastGain, lit = since < HOLD ? 1 : Math.max(0.38f, 1 - (since - HOLD) * 0.5f);
        float w = ui.s(300), h = ui.s(7), x = ui.w / 2f - w / 2, y = ui.s(34);
        ui.text(Progression.rankName(rank) + " " + rank, x, y - ui.s(18), 11, Ui.alpha(Ui.TXT_HI, lit));
        ui.textR(pr.master() ? "MAX" : Math.round(target * 100) + "% to Rank " + Math.min(Progression.RANKS, rank + 1), x + w, y - ui.s(18), 11, Ui.alpha(Ui.AMBER, lit));
        ui.b.rect(x - 1, y - 1, w + 2, h + 2, Ui.alpha(0xC0000000, lit));
        ui.b.rect(x, y, w, h, Ui.alpha(0xFF24262A, lit));
        ui.b.rect(x, y, w * Math.max(0, Math.min(1, pr.rankProgress())), h, Ui.alpha(0xFF8A6420, lit));          // what is banked
        float banked = rank == pr.rank() ? pr.rankProgress() : 0;
        ui.b.rect(x + w * banked, y, w * Math.max(0, Math.min(1, shownProgress) - banked), h, Ui.alpha(0xFFE2A034, lit));   // what this operation adds
        for (int i = 1; i < 4; i++) ui.b.rect(x + w * i / 4f, y, 1, h, Ui.alpha(0x60000000, lit));
        ui.textC("+" + String.format("%,d", pend) + " XP this operation", ui.w / 2f, y + h + ui.s(4), 10, Ui.alpha(Ui.TXT_DIM, lit));
        float ty = y + h + ui.s(22);
        for (int i = toasts.size() - 1; i >= 0; i--) {
            Toast t = toasts.get(i);
            float age = raid.time - t.at, a = Math.min(1, age / 0.12f) * Math.min(1, (TOAST_LIFE - age) / 0.6f);
            if (a <= 0.02f) continue;
            float rise = (1 - Math.min(1, age / 0.25f)) * ui.s(8);
            String s = "+" + String.format("%,d", Math.round(t.amount * xpMul)) + " XP";
            float sw = ui.tw(s, 14), lw = ui.tw(t.label, 12), tw = sw + ui.s(10) + lw;
            ui.b.rect(ui.w / 2f - tw / 2 - ui.s(8), ty + rise - ui.s(2), tw + ui.s(16), ui.s(22), Ui.alpha(0xB0101214, a));
            ui.text(s, ui.w / 2f - tw / 2, ty + rise, 14, Ui.alpha(0xFFE2A034, a));
            ui.text(t.label, ui.w / 2f - tw / 2 + sw + ui.s(10), ty + rise + ui.s(2), 12, Ui.alpha(Ui.TXT, a));
            ty += ui.s(25);
        }
    }
}
