package absentialis.scene;

import absentialis.engine.voxel.VoxModel;
import absentialis.gameplay.Alliance;
import absentialis.gameplay.squad.Roster;
import absentialis.persistence.Profile;
import absentialis.ui.Ui;
import java.util.ArrayList;
import java.util.List;

/**
 * The profile card (0.6): one layout for the player and for every squadmate - who they are, what Rank they hold,
 * and what they have done. The player's card background is theirs to choose from the ones their Rank has unlocked;
 * a squadmate's card wears the best background their own Level has earned.
 *
 * The card is drawn, not stored: every figure on it is read from the profile or the roster at the moment it is shown.
 */
public final class ProfileCard {
    private ProfileCard() {}

    /** A card background and the Rank that unlocks it. */
    public record Background(String id, String name, int rank, int top, int bottom, int accent, String pattern) {}

    public static final Background[] BACKGROUNDS = {
            new Background("field", "Field Drab", 1, 0xFF3A4230, 0xFF1C2018, 0xFF9AA86A, "topo"),
            new Background("concrete", "Bunker Concrete", 5, 0xFF4A4C4E, 0xFF202224, 0xFFB8BCC0, "panels"),
            new Background("rust", "Rail Yard Rust", 10, 0xFF6A3A22, 0xFF24140E, 0xFFE08A4A, "rivets"),
            new Background("cordon", "Cordon Tape", 15, 0xFF3C3A20, 0xFF16150C, 0xFFE2B030, "hazard"),
            new Background("night", "Night Watch", 20, 0xFF1A2438, 0xFF080B14, 0xFF7AA0E0, "stars"),
            new Background("frost", "First Frost", 25, 0xFF4E6470, 0xFF182026, 0xFFCFE6F0, "panels"),
            new Background("ember", "Ember", 30, 0xFF7A3A14, 0xFF1E0C06, 0xFFFFB050, "embers"),
            new Background("blood", "Red Ledger", 35, 0xFF5A1818, 0xFF180606, 0xFFE05048, "rivets"),
            new Background("brass", "Spent Brass", 40, 0xFF6A5A28, 0xFF1E1A0C, 0xFFE8D080, "topo"),
            new Background("gold", "Field Marshal", 50, 0xFF8A7020, 0xFF2A2008, 0xFFFFE070, "stars")};

    public static Background background(String id) { for (Background b : BACKGROUNDS) if (b.id().equals(id)) return b; return BACKGROUNDS[0]; }
    public static boolean unlocked(Background b, int bestRank) { return bestRank >= b.rank(); }
    /** The best background a Rank has earned. */
    public static Background best(int rank) { Background r = BACKGROUNDS[0]; for (Background b : BACKGROUNDS) if (rank >= b.rank()) r = b; return r; }

    /** Everything a card shows. */
    public static final class Data {
        public String name = "", title = "", sub = "", faction = "", serial = "", key = "";
        public int factionColour = 0xFF8A8A8A, rank = 1;
        public float progress;
        public Background background = BACKGROUNDS[0];
        public java.util.function.Supplier<VoxModel> model;
        public final List<String[]> stats = new ArrayList<>();
        public Data stat(String label, String value) { stats.add(new String[]{label, value}); return this; }
    }

    public static Data of(Ctx c, Profile p) {
        Data d = new Data();
        d.name = p.name;
        d.title = p.prog.title();
        d.rank = p.prog.rank();
        d.progress = p.prog.rankProgress();
        d.sub = p.ironman ? "IRONMAN" : "ELEMENT LEADER";
        Alliance.Def a = Alliance.def(p.alliance);
        d.faction = a == null ? "UNALIGNED" : a.name().toUpperCase();
        d.factionColour = a == null ? 0xFF8A8A8A : a.colour();
        Background b = background(p.cardBackground);
        d.background = unlocked(b, p.prog.bestRank) ? b : BACKGROUNDS[0];
        d.serial = "ABS-" + String.format("%04d", Math.floorMod(p.seed ^ p.name.hashCode(), 10000)) + "-" + (p.slot + 1);
        ActorRenderer.Look look = ActorRenderer.playerLook(p, null);
        d.key = look.key;
        d.model = () -> c.ar.flatten(look);
        int human = 0, inf = p.stat("kills_infected");
        for (String f : absentialis.sim.ZoneState.FACTIONS) human += p.stat("kills_" + f);
        int raids = p.stat("raids"), deaths = p.stat("deaths");
        d.stat("Operations", String.valueOf(raids)).stat("Extractions", String.valueOf(p.stat("extracts")))
                .stat("Killed in action", String.valueOf(deaths)).stat("Survival", raids == 0 ? "-" : Math.round(100f * p.stat("extracts") / raids) + "%")
                .stat("Hostiles killed", String.valueOf(human)).stat("Infected killed", String.valueOf(inf))
                .stat("Squadmates lost", String.valueOf(p.stat("mates_lost"))).stat("Containers searched", String.valueOf(p.stat("containers")));
        return d;
    }

    public static Data of(Ctx c, Profile p, Roster.Mate m) {
        Data d = new Data();
        d.name = m.name;
        d.title = m.title();
        d.rank = m.level();
        d.progress = m.progress();
        d.sub = m.active ? (Roster.RED.equals(m.team) ? "RED TEAM" : "BLUE TEAM") : "RESERVE";
        Alliance.Def a = Alliance.def(p.alliance);
        d.faction = a == null ? "UNALIGNED" : a.name().toUpperCase();
        d.factionColour = a == null ? 0xFF8A8A8A : a.colour();
        d.background = best(m.level());
        d.serial = "ABS-" + String.format("%04d", Math.floorMod(p.seed * 31 + m.id * 977, 10000)) + "-S" + m.id;
        ActorRenderer.Look look = new ActorRenderer.Look();
        look.app = m.look;
        look.gear.vest = "soft";
        look.key = absentialis.character.CharBuilder.key(look.app, look.gear);
        d.key = look.key;
        d.model = () -> c.ar.flatten(look);
        absentialis.gameplay.items.ItemDef wd = absentialis.gameplay.items.Content.def(m.weapon);
        d.stat("Operations", String.valueOf(m.raids)).stat("Kills", String.valueOf(m.kills))
                .stat("Times down", String.valueOf(m.downs)).stat("Kills per operation", m.raids == 0 ? "-" : String.format("%.1f", m.kills / (float) m.raids))
                .stat("Level", m.level() + " / " + Roster.MAX_LEVEL).stat("Prestige", m.prestige() + " / " + Roster.MAX_PRESTIGE)
                .stat("Weapon", wd == null ? "?" : wd.name).stat("Experience", String.format("%,d", m.xp));
        return d;
    }

    /** Height of a card of a given width. */
    public static float height(float w) { return Math.round(w * 0.46f); }

    private static final java.util.Map<String, VoxModel> MODELS = new java.util.HashMap<>();

    /** Draws a card at (x, y), w wide. spin turns the figure. The same code draws the player and squadmates. */
    public static void draw(Ui ui, Ctx c, Data d, float x, float y, float w, float spin) {
        float h = height(w), k = w / 620f;          // every measure below is in card units at 620 wide
        Background bg = d.background;
        ui.shadow(x, y, w, h, 0x90);
        // background: a vertical blend of the two tones, then its pattern, then a vignette toward the edges
        int bands = 28;
        for (int i = 0; i < bands; i++) ui.b.rect(x, y + h * i / bands, w, h / bands + 1, Ui.mix(bg.top(), bg.bottom(), i / (float) (bands - 1)));
        ui.b.scissor((int) x, (int) y, (int) w, (int) h);
        pattern(ui, bg, x, y, w, h, k);
        ui.b.noScissor();
        ui.b.rect(x, y, w, 3 * k, Ui.alpha(bg.accent(), 0.9f));
        ui.b.rect(x, y + h - 22 * k, w, 22 * k, 0xC0080808);
        ui.b.outline(x, y, w, h, Math.max(1, 2 * k), Ui.mix(bg.accent(), 0xFF000000, 0.45f));
        // ---- the figure
        float fs = h - 54 * k, fx = x + 16 * k, fy = y + 18 * k;
        ui.b.rect(fx, fy, fs * 0.78f, fs, 0x90000000);
        ui.b.outline(fx, fy, fs * 0.78f, fs, 1, Ui.alpha(bg.accent(), 0.6f));
        if (d.model != null) {
            VoxModel m = MODELS.get(d.key);
            if (m == null) { if (MODELS.size() > 24) MODELS.clear(); m = d.model.get(); MODELS.put(d.key, m); }
            ui.b.scissor((int) fx, (int) fy, (int) (fs * 0.78f), (int) fs);
            c.icons.drawModel(ui.b, m, fx - fs * 0.11f, fy, fs, (float) Math.PI + spin, 0.14f);
            ui.b.noScissor();
        }
        // ---- identity
        float tx = fx + fs * 0.78f + 18 * k, tw = x + w - tx - 16 * k;
        float nameSize = absentialis.ui.Layout.fit(ui, d.name.toUpperCase(), tx, y + 16 * k, tw, 24 * k / ui.scale, 12, Ui.TXT_HI);
        float ty = y + 16 * k + absentialis.ui.Layout.lineHeight(ui, nameSize) + 2 * k;
        ui.text(d.title, tx, ty, 13 * k / ui.scale, bg.accent());
        ty += 20 * k;
        // faction chip and role
        float cw = ui.tw(d.faction, 10 * k / ui.scale) + 14 * k;
        ui.b.rect(tx, ty, cw, 17 * k, d.factionColour);
        ui.text(d.faction, tx + 7 * k, ty + 3 * k, 10 * k / ui.scale, 0xFFF4F0E4);
        ui.text(d.sub, tx + cw + 10 * k, ty + 3 * k, 10 * k / ui.scale, Ui.TXT_DIM);
        ty += 26 * k;
        // rank progress
        ui.b.rect(tx, ty, tw, 7 * k, 0xA0000000);
        ui.b.rect(tx, ty, tw * Math.max(0, Math.min(1, d.progress)), 7 * k, bg.accent());
        ui.textR(Math.round(d.progress * 100) + "% to next", tx + tw, ty + 9 * k, 9 * k / ui.scale, Ui.TXT_DIM);
        ty += 24 * k;
        // ---- stats: two columns
        float colW = tw / 2, rowH = 19 * k;
        for (int i = 0; i < d.stats.size(); i++) {
            String[] st = d.stats.get(i);
            float sx = tx + (i % 2) * colW, sy = ty + (i / 2) * rowH;
            if (sy + rowH > y + h - 24 * k) break;
            ui.text(st[0], sx, sy, 10 * k / ui.scale, Ui.TXT_DIM);
            ui.textR(st[1], sx + colW - 10 * k, sy, 11 * k / ui.scale, Ui.TXT_HI);
        }
        ui.text(d.serial, x + 16 * k, y + h - 17 * k, 9 * k / ui.scale, Ui.TXT_DIM);
        ui.textR(bg.name().toUpperCase() + "   " + absentialis.Version.TITLE, x + w - 16 * k, y + h - 17 * k, 9 * k / ui.scale, Ui.TXT_DIM);
    }

    /** The background's own texture: drawn from rectangles, no text and no images. */
    private static void pattern(Ui ui, Background bg, float x, float y, float w, float h, float k) {
        int a = Ui.alpha(bg.accent(), 0.10f), a2 = Ui.alpha(bg.accent(), 0.20f), dark = 0x30000000;
        switch (bg.pattern()) {
            case "topo" -> { for (int i = 0; i < 9; i++) { float r = (40 + i * 34) * k; ui.b.outline(x + w * 0.78f - r, y + h * 0.3f - r * 0.6f, r * 2, r * 1.2f, 1, a); } }
            case "panels" -> { for (float px = 0; px < w; px += 62 * k) ui.b.rect(x + px, y, 1, h, dark); for (float py = 0; py < h; py += 48 * k) ui.b.rect(x, y + py, w, 1, dark); for (float px = 31 * k; px < w; px += 62 * k) for (float py = 24 * k; py < h; py += 48 * k) ui.b.rect(x + px - k, y + py - k, 2 * k, 2 * k, a2); }
            case "rivets" -> { for (float px = 14 * k; px < w; px += 28 * k) { ui.b.rect(x + px, y + 9 * k, 3 * k, 3 * k, a2); ui.b.rect(x + px, y + h - 34 * k, 3 * k, 3 * k, a2); } for (int i = 0; i < 7; i++) ui.b.rect(x + w * (0.12f + i * 0.13f), y + h * (0.2f + (i * 37 % 50) / 100f), (20 + i * 9) * k, 2 * k, dark); }
            case "hazard" -> { for (float px = -h; px < w; px += 46 * k) for (int s = 0; s < 14; s++) ui.b.rect(x + px + s * 2 * k + (h - 40 * k) * 0, y + h - 40 * k + s * 1.2f * k, 22 * k, 1.2f * k + 1, a2); }
            case "stars" -> { for (int i = 0; i < 70; i++) { float sx = x + w * absentialis.engine.util.Rng.hash(i, 3, 7, 11), sy = y + h * 0.75f * absentialis.engine.util.Rng.hash(i, 5, 2, 23); float s = (absentialis.engine.util.Rng.hash(i, 1, 1, 5) < 0.2f ? 2 : 1) * Math.max(1, k); ui.b.rect(sx, sy, s, s, Ui.alpha(bg.accent(), 0.25f + 0.5f * absentialis.engine.util.Rng.hash(i, 9, 4, 31))); } }
            case "embers" -> { for (int i = 0; i < 44; i++) { float sx = x + w * absentialis.engine.util.Rng.hash(i, 2, 8, 13), f = absentialis.engine.util.Rng.hash(i, 6, 3, 29), sy = y + h * (1 - f * f); float s = (1 + 2 * (1 - f)) * Math.max(1, k); ui.b.rect(sx, sy, s, s, Ui.alpha(bg.accent(), 0.15f + 0.45f * (1 - f))); } }
            default -> { }
        }
    }
}
