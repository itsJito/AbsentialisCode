package absentialis.scene;

import absentialis.gameplay.Alliance;
import absentialis.persistence.Profile;
import absentialis.persistence.SaveSystem;
import absentialis.rivalry.Doctrine;
import absentialis.rivalry.RivalryEngine;
import absentialis.rivalry.RivalryState;
import absentialis.rivalry.RivalryWorld;
import absentialis.sim.Leaderboard;
import absentialis.ui.Layout;
import absentialis.ui.Ui;
import absentialis.world.District;
import java.util.ArrayList;
import java.util.List;

/**
 * The 0.6 hideout panels that are about the world rather than the kit: the alliance the survivor chooses once, the
 * LEADERBOARD and RIVALRIES tabs of the deployment screen, and the PROFILE tab with the survivor's card.
 * Each draws from the profile as it stands; nothing here keeps a copy of the state it shows.
 */
public final class OpsPanels {
    private final Ctx c;
    private float boardScroll, cardSpin;
    private String selectedGroup = "", mediateWith = "", intelAbout = "";
    private int boardFilter;
    private List<Leaderboard.Row> rows;
    private float rowsAge = 99;
    private final List<String> feedback = new ArrayList<>();

    public OpsPanels(Ctx c) { this.c = c; }

    private static int factionColour(String gameKey) {
        Alliance.Def d = Alliance.def(gameKey);
        return d != null ? d.colour() : "player".equals(gameKey) ? 0xFF4A90E2 : 0xFF8A8A8A;
    }

    // ================================================================== the alliance (asked once, after the profile is made)
    /** A modal the hideout shows until the survivor has chosen a side. Returns true once the choice is made. */
    public boolean allianceModal(Ui ui, Profile p) {
        ui.b.rect(0, 0, ui.w, ui.h, 0xE6000000);
        float w = Math.min(ui.s(1180), ui.w - ui.s(40)), h = Math.min(ui.s(640), ui.h - ui.s(40)), x = (ui.w - w) / 2, y = (ui.h - h) / 2, pad = ui.s(24);
        ui.shadow(x, y, w, h, 0xA0);
        ui.b.rect(x, y, w, h, 0xFF0E1011);
        ui.b.outline(x, y, w, h, 2, 0xFF8A6420);
        ui.b.rect(x + 2, y + 2, w - 4, ui.s(66), 0xFF16181B);
        ui.b.rect(x + 2, y + ui.s(66), w - 4, ui.s(2), Ui.AMBER);
        ui.text("DECLARE AN ALLEGIANCE", x + pad, y + ui.s(10), 26, Ui.TXT_HI);
        ui.text("You belong to no one: a third party to every quarrel in the Zone. This is only whose work you take and whose ground you start from. What each group makes of you after that is yours to earn - or lose.", x + pad, y + ui.s(42), 12, Ui.TXT_DIM);
        float top = y + ui.s(86), gap = ui.s(12), cw = (w - pad * 2 - gap * 3) / 4, ch = h - ui.s(86) - pad;
        boolean chose = false;
        for (int i = 0; i < Alliance.ALL.length; i++) {
            Alliance.Def d = Alliance.ALL[i];
            float cx = x + pad + i * (cw + gap);
            boolean hov = ui.hover(cx, top, cw, ch);
            float k = ui.ease("ally" + i, hov);
            ui.b.rect(cx, top, cw, ch, Ui.mix(0xFF14161A, 0xFF1E2126, k));
            ui.b.rect(cx, top, cw, ui.s(6), d.colour());
            ui.b.outline(cx, top, cw, ch, 1, hov ? d.colour() : 0xFF2E2A22);
            ui.b.scissor((int) cx, (int) top, (int) cw, (int) ch);
            float tx = cx + ui.s(16), tw = cw - ui.s(32), ty = top + ui.s(22);
            ui.text(d.name().toUpperCase(), tx, ty, 22, Ui.TXT_HI);
            ui.text(d.motto(), tx, ty + ui.s(30), 12, d.colour());
            ty += ui.s(58);
            ty += ui.wrap(d.blurb(), tx, ty, tw, 12, Ui.TXT) + ui.s(14);
            ui.text("HEADQUARTERS", tx, ty, 10, Ui.AMBER);
            ty += ui.s(16);
            for (District hq : Alliance.homes(d.key())) { ui.text(hq.display + (hq.def.headquarters.isEmpty() ? "" : "  -  " + hq.def.headquarters), tx, ty, 12, Ui.TXT); ty += ui.s(17); }
            ty += ui.s(8);
            ui.text("WORK", tx, ty, 10, Ui.AMBER);
            ty += ui.s(16) + ui.wrap(d.work(), tx, ty + ui.s(16), tw, 12, Ui.TXT) + ui.s(10);
            ui.b.noScissor();
            if (ui.button("allypick" + i, cx + ui.s(16), top + ch - ui.s(58), cw - ui.s(32), ui.s(42), "SIDE WITH THE " + d.name().toUpperCase(), "flag", true)) {
                Alliance.choose(p, d.key());
                SaveSystem.save(p);
                c.sfx("ui_deploy", 0.6f);
                chose = true;
            }
        }
        return chose;
    }

    // ================================================================== PROFILE tab
    public void profile(Ui ui, Profile p, float top) {
        cardSpin += ui.dt * 0.25f;
        float x = ui.s(24), h = ui.h - top - ui.s(24), w = ui.w - ui.s(48);
        float cy = ui.window("Profile  -  " + p.name, "star", x, top, w, h);
        float cw = Math.min(ui.s(760), w * 0.56f), cx = x + ui.s(20);
        ProfileCard.draw(ui, c, ProfileCard.of(c, p), cx, cy, cw, cardSpin);
        float by = cy + ProfileCard.height(cw) + ui.s(18);
        ui.text("CARD BACKGROUND", cx, by, 13, Ui.TXT_HI);
        ui.text("One is unlocked at each tier of Rank. Yours: " + ProfileCard.background(p.cardBackground).name(), cx + ui.s(170), by + ui.s(2), 11, Ui.TXT_DIM);
        by += ui.s(24);
        int cols = 5;
        float gw = (cw - ui.s(8) * (cols - 1)) / cols, gh = ui.s(54);
        for (int i = 0; i < ProfileCard.BACKGROUNDS.length; i++) {
            ProfileCard.Background b = ProfileCard.BACKGROUNDS[i];
            float gx = cx + (i % cols) * (gw + ui.s(8)), gy = by + (i / cols) * (gh + ui.s(8));
            boolean open = ProfileCard.unlocked(b, p.prog.bestRank), sel = b.id().equals(p.cardBackground), hov = ui.hover(gx, gy, gw, gh);
            for (int s = 0; s < 6; s++) ui.b.rect(gx, gy + gh * s / 6f, gw, gh / 6f + 1, Ui.alpha(Ui.mix(b.top(), b.bottom(), s / 5f), open ? 1 : 0.35f));
            ui.b.rect(gx, gy, gw, ui.s(3), Ui.alpha(b.accent(), open ? 1 : 0.3f));
            ui.b.outline(gx, gy, gw, gh, sel ? 2 : 1, sel ? Ui.AMBER : hov && open ? b.accent() : 0xFF2E2A22);
            Layout.fit(ui, b.name(), gx + ui.s(8), gy + ui.s(10), gw - ui.s(16), 12, 9, open ? Ui.TXT_HI : Ui.TXT_DIM);
            ui.text(open ? (sel ? "IN USE" : "Rank " + b.rank()) : "Unlocks at Rank " + b.rank(), gx + ui.s(8), gy + gh - ui.s(18), 10, open ? (sel ? Ui.AMBER : Ui.TXT_DIM) : Ui.RED);
            if (!open) ui.glyph("lock", gx + gw - ui.s(22), gy + ui.s(8), Math.max(1, ui.s(1)), 0xB0FFFFFF);
            if (open && hov && ui.click && !ui.consumed) { ui.consumed = true; p.cardBackground = b.id(); SaveSystem.save(p); c.sfx("ui_click", 0.5f); }
        }
        // ---- the record in full, beside the card
        float rx = cx + cw + ui.s(28), rw = x + w - rx - ui.s(20), ry = cy;
        Alliance.Def a = Alliance.def(p.alliance);
        ui.text("ALLIANCE", rx, ry, 12, Ui.AMBER);
        ry += ui.s(20);
        if (a != null) {
            ui.b.rect(rx, ry, ui.s(6), ui.s(40), a.colour());
            ui.text(a.name(), rx + ui.s(16), ry, 18, Ui.TXT_HI);
            ui.text(a.motto(), rx + ui.s(16), ry + ui.s(24), 11, Ui.TXT_DIM);
            ry += ui.s(50);
            StringBuilder dep = new StringBuilder();
            for (District d : District.CITY) if (Alliance.mayDeploy(p, d)) dep.append(dep.length() > 0 ? ", " : "").append(d.display);
            ry += ui.wrap("You can deploy from: " + (dep.length() == 0 ? "nowhere" : dep), rx, ry, rw, 12, Ui.TXT) + ui.s(14);
        } else { ui.text("Not chosen", rx, ry, 14, Ui.TXT_DIM); ry += ui.s(30); }
        ui.text("SERVICE RECORD", rx, ry, 12, Ui.AMBER);
        ry += ui.s(22);
        int human = 0;
        for (String f : absentialis.sim.ZoneState.FACTIONS) human += p.stat("kills_" + f);
        String[][] rec = {{"Rank", p.prog.title()}, {"Lifetime experience", String.format("%,d", p.prog.lifetimeXp)}, {"Coins", absentialis.Version.coins(p.scrip)}, {"Operations", String.valueOf(p.stat("raids"))},
                {"Extractions", String.valueOf(p.stat("extracts"))}, {"Killed in action", String.valueOf(p.stat("deaths"))}, {"Hostiles killed", String.valueOf(human)}, {"Infected killed", String.valueOf(p.stat("kills_infected"))},
                {"Map cells surveyed", String.valueOf(p.stat("cells"))}, {"Containers searched", String.valueOf(p.stat("containers"))}, {"Documents recovered", String.valueOf(p.stat("documents"))},
                {"Squad", p.squad.mates.size() + " on the roster, " + p.squad.fallen.size() + " lost"}, {"Maximum health", String.valueOf(absentialis.gameplay.CombatConfig.get().maxHealth(p.herbs))}};
        for (String[] r : rec) { if (ry > top + h - ui.s(26)) break; ui.text(r[0], rx, ry, 13, Ui.TXT); ui.textR(r[1], rx + rw, ry, 13, Ui.TXT_HI); ui.b.rect(rx, ry + ui.s(18), rw, 1, 0xFF22241F); ry += ui.s(23); }
        for (String f : absentialis.sim.ZoneState.FACTIONS) {
            if (ry > top + h - ui.s(26)) break;
            ui.text(Alliance.name(f) + " standing", rx, ry, 13, Ui.TXT);
            float v = p.rep(f);
            ui.textR(String.format("%+.0f", v), rx + rw, ry, 13, v < -10 ? Ui.RED : v > 20 ? Ui.GREEN : Ui.TXT_HI);
            ry += ui.s(21);
        }
    }

    // ================================================================== LEADERBOARD (deployment screen)
    private static final String[] FILTERS = {"EVERYONE", "MY ELEMENT", "LEADERS", "MILITARY", "BANDITS", "LONERS", "MERCENARIES"};

    public void leaderboard(Ui ui, Profile p, float x, float y, float w, float h) {
        rowsAge += ui.dt;
        if (rows == null || rowsAge > 2) { rows = Leaderboard.rows(p); rowsAge = 0; }
        int[] n = Leaderboard.counts(rows);
        ui.text("Everyone alive in the Zone, on one ladder. Rank is experience; the dead are not listed.", x, y, 11, Ui.TXT_DIM);
        ui.textR(rows.size() + " alive: " + n[0] + " in your element, " + n[1] + " leaders, " + n[2] + " others", x + w, y, 11, Ui.TXT_DIM);
        float fy = y + ui.s(20), fw = Math.min(ui.s(132), (w - ui.s(6) * (FILTERS.length - 1)) / FILTERS.length);
        for (int i = 0; i < FILTERS.length; i++) if (ui.tab("lbf" + i, x + i * (fw + ui.s(6)), fy, fw, ui.s(26), FILTERS[i], null, boardFilter == i) && boardFilter != i) { boardFilter = i; boardScroll = 0; }
        List<Leaderboard.Row> shown = new ArrayList<>();
        String[] fk = {null, null, null, "military", "raiders", "survivors", "mercenaries"};
        for (int i = 0; i < rows.size(); i++) {
            Leaderboard.Row r = rows.get(i);
            boolean mine = "you".equals(r.kind()) || "squad".equals(r.kind());
            if (boardFilter == 1 && !mine || boardFilter == 2 && !"leader".equals(r.kind()) || boardFilter >= 3 && (mine || !fk[boardFilter].equals(r.faction()))) continue;
            shown.add(r);
        }
        float hy = fy + ui.s(36), rh = ui.s(24), listY = hy + ui.s(22), listH = y + h - listY;
        float c0 = x + ui.s(8), c1 = x + ui.s(60), c2 = x + w * 0.36f, c3 = x + w * 0.58f, c4 = x + w * 0.70f, c5 = x + w * 0.77f;
        ui.b.rect(x, hy, w, ui.s(20), 0xFF16181B);
        ui.text("#", c0, hy + ui.s(4), 10, Ui.AMBER); ui.text("NAME", c1, hy + ui.s(4), 10, Ui.AMBER); ui.text("RANK", c2, hy + ui.s(4), 10, Ui.AMBER);
        ui.text("GROUP", c3, hy + ui.s(4), 10, Ui.AMBER); ui.text("KILLS", c4, hy + ui.s(4), 10, Ui.AMBER); ui.text("STANDING", c5, hy + ui.s(4), 10, Ui.AMBER);
        if (ui.hover(x, listY, w, listH)) boardScroll -= (float) c.in.scroll * rh * 3;
        boardScroll = Math.max(0, Math.min(Math.max(0, shown.size() * rh - listH), boardScroll));
        ui.b.scissor((int) x, (int) listY, (int) w, (int) listH);
        for (int i = 0; i < shown.size(); i++) {
            float ry = listY + i * rh - boardScroll;
            if (ry + rh < listY || ry > listY + listH) continue;
            Leaderboard.Row r = shown.get(i);
            boolean you = "you".equals(r.kind()), squad = "squad".equals(r.kind());
            ui.b.rect(x, ry, w, rh - 1, you ? 0xFF2A2416 : i % 2 == 0 ? 0xFF121416 : 0xFF0F1113);
            int fc = factionColour(r.faction());
            ui.b.rect(x, ry, ui.s(4), rh - 1, you ? Ui.AMBER : squad ? 0xFF4A90E2 : fc);
            int place = rows.indexOf(r) + 1;
            ui.text(String.valueOf(place), c0, ry + ui.s(5), 12, place <= 3 ? Ui.AMBER : Ui.TXT_DIM);
            Layout.fit(ui, r.name() + (you ? "  (you)" : ""), c1, ry + ui.s(5), c2 - c1 - ui.s(10), 13, 9, you ? Ui.TXT_HI : Ui.TXT);
            Layout.fit(ui, r.title(), c2, ry + ui.s(5), c3 - c2 - ui.s(10), 12, 9, Ui.TXT);
            ui.text(you || squad ? "Yours" : Alliance.name(r.faction()), c3, ry + ui.s(5), 12, fc == 0xFF8A8A8A ? Ui.TXT_DIM : Ui.mix(fc, 0xFFFFFFFF, 0.35f));
            ui.text(String.valueOf(r.kills()), c4, ry + ui.s(5), 12, r.kills() > 0 ? Ui.TXT_HI : Ui.TXT_DIM);
            Layout.fit(ui, r.detail(), c5, ry + ui.s(6), x + w - c5 - ui.s(8), 11, 8, Ui.TXT_DIM);
        }
        ui.b.noScissor();
        if (shown.isEmpty()) ui.textC("Nobody of that kind is alive.", x + w / 2, listY + ui.s(30), 13, Ui.TXT_DIM);
    }

    // ================================================================== RIVALRIES (deployment screen)
    private void say(RivalryEngine.Result r) { feedback.add(0, (r.ok() ? "" : "! ") + r.text()); while (feedback.size() > 4) feedback.remove(feedback.size() - 1); c.sfx(r.ok() ? "ui_click" : "ui_invalid", 0.5f); }

    private void meter(Ui ui, String label, float v, float x, float y, float w, int col, boolean signed) {
        ui.text(label, x, y, 10, Ui.TXT_DIM);
        float bx = x + ui.s(74), bw = w - ui.s(74) - ui.s(34), bh = ui.s(8);
        ui.b.rect(bx, y + ui.s(3), bw, bh, 0xFF1A1C1E);
        if (signed) { float mid = bx + bw / 2, len = bw / 2 * Math.min(1, Math.abs(v) / 100f); ui.b.rect(v >= 0 ? mid : mid - len, y + ui.s(3), len, bh, v >= 0 ? col : Ui.RED); ui.b.rect(mid, y + ui.s(1), 1, bh + ui.s(4), 0xFF5A5C56); }
        else ui.b.rect(bx, y + ui.s(3), bw * Math.min(1, Math.max(0, v) / 100f), bh, col);
        ui.textR(String.format(signed ? "%+.0f" : "%.0f", v), x + w, y, 11, Ui.TXT);
    }

    public void rivalries(Ui ui, Profile p, float x, float y, float w, float h) {
        RivalryEngine e = RivalryWorld.engine(p);
        RivalryEngine.Wallet wallet = RivalryWorld.wallet(p);
        List<RivalryState.Group> groups = e.s.active();
        if (e.s.group(selectedGroup) == null && !groups.isEmpty()) selectedGroup = groups.get(0).id;
        // ---- left: every group, how it stands with you, and what it is doing
        float lw = Math.min(ui.s(360), w * 0.36f), rh = Math.min(ui.s(58), (h - ui.s(4)) / Math.max(1, groups.size()));
        for (int i = 0; i < groups.size(); i++) {
            RivalryState.Group g = groups.get(i);
            RivalryState.Leader l = e.s.leaderOf(g);
            float ry = y + i * rh;
            boolean sel = g.id.equals(selectedGroup), hov = ui.hover(x, ry, lw, rh - ui.s(4));
            ui.b.rect(x, ry, lw, rh - ui.s(4), sel ? 0xFF2A2416 : Ui.mix(0xFF14161A, 0xFF1E2024, ui.ease("rg" + g.id, hov)));
            ui.b.rect(x, ry, ui.s(5), rh - ui.s(4), g.colour);
            if (sel) ui.b.outline(x, ry, lw, rh - ui.s(4), 1, 0xFF8A6420);
            float fav = g.playerRelation.favor;
            Doctrine.Status st = Doctrine.status(fav);
            int sc = fav <= -51 ? Ui.RED : fav <= -11 ? 0xFFE08A30 : fav < 20 ? Ui.TXT : fav < 50 ? 0xFFB8D048 : Ui.GREEN;
            Layout.fit(ui, g.name, x + ui.s(14), ry + ui.s(4), lw - ui.s(130), 13, 9, Ui.TXT_HI);
            ui.textR(e.treaty(g, "alliance") ? "ALLIED" : e.treaty(g, "truce") ? "TRUCE" : st.name().toUpperCase(), x + lw - ui.s(8), ry + ui.s(5), 10, e.treaty(g, null) ? Ui.AMBER : sc);
            if (rh >= ui.s(44)) Layout.fit(ui, Doctrine.display(g.faction) + "  -  " + (l == null ? "leaderless" : l.title + " " + l.name) + "  -  " + g.size + " strong", x + ui.s(14), ry + ui.s(21), lw - ui.s(22), 10, 8, Ui.TXT_DIM);
            float by = ry + rh - ui.s(13), bw = lw - ui.s(28), mid = x + ui.s(14) + bw / 2;
            ui.b.rect(x + ui.s(14), by, bw, ui.s(4), 0xFF1A1C1E);
            float len = bw / 2 * Math.min(1, Math.abs(fav) / 100f);
            ui.b.rect(fav >= 0 ? mid : mid - len, by, len, ui.s(4), sc);
            ui.b.rect(mid, by - ui.s(1), 1, ui.s(6), 0xFF5A5C56);
            if (hov && ui.click && !ui.consumed) { ui.consumed = true; selectedGroup = g.id; c.sfx("ui_tab", 0.4f); }
        }
        RivalryState.Group g = e.s.group(selectedGroup);
        if (g == null) return;
        RivalryState.Leader l = e.s.leaderOf(g);
        float dx = x + lw + ui.s(18), dw = x + w - dx, dy = y;
        ui.b.rect(dx - ui.s(9), y, 1, h, 0xFF2E2A22);
        // ---- header: the group and the one who runs it
        ui.b.rect(dx, dy, ui.s(6), ui.s(40), g.colour);
        ui.text(g.name, dx + ui.s(14), dy - ui.s(2), 20, Ui.TXT_HI);
        StringBuilder ground = new StringBuilder();
        for (String t : g.territoryIds) ground.append(ground.length() > 0 ? ", " : "").append(RivalryWorld.DISTRICTS.name(t));
        Layout.fit(ui, Doctrine.display(g.faction) + "  -  \"" + absentialis.engine.util.Json.str(Doctrine.faction(g.faction), "question", "") + "\"  -  holds " + ground + "  -  " + g.size + " strong, morale " + Math.round(g.morale * 100) + "%", dx + ui.s(14), dy + ui.s(24), dw - ui.s(16), 11, 8, Ui.TXT_DIM);
        dy += ui.s(50);
        float colW = (dw - ui.s(18)) / 2;
        // left column: the leader, relations
        float ly = dy;
        if (l != null) {
            ui.text((l.title + " " + l.name).trim().toUpperCase(), dx, ly, 14, Ui.TXT_HI);
            ly += ui.s(20);
            ly += ui.wrap(String.join(", ", l.traits) + (l.ambitions.isEmpty() ? "" : ". Wants " + l.ambitions.get(0)) + (l.injuries.isEmpty() ? "" : ". Carries " + String.join(", ", l.injuries)) + ". Met you " + l.encounters + (l.encounters == 1 ? " time." : " times."), dx, ly, colW, 11, Ui.TXT) + ui.s(4);
            ly += ui.wrap("\"" + e.line(l, g) + "\"", dx, ly, colW, 12, Ui.AMBER) + ui.s(10);
        }
        ui.text("HOW THE GROUP SEES YOU", dx, ly, 10, Ui.AMBER);
        ly += ui.s(16);
        RivalryState.Relation r = g.playerRelation;
        meter(ui, "Favor", r.favor, dx, ly, colW, Ui.GREEN, true); ly += ui.s(16);
        meter(ui, "Trust", r.trust, dx, ly, colW, 0xFF7AA0E0, true); ly += ui.s(16);
        meter(ui, "Respect", r.respect, dx, ly, colW, 0xFFE2B030, true); ly += ui.s(16);
        meter(ui, "Fear", r.fear, dx, ly, colW, 0xFFB080D0, false); ly += ui.s(16);
        meter(ui, "Hostility", r.hostility, dx, ly, colW, Ui.RED, false); ly += ui.s(16);
        meter(ui, "Debt to you", r.debt, dx, ly, colW, 0xFF7DBA5C, false); ly += ui.s(20);
        if (l != null) {
            ui.text("HOW " + l.name.toUpperCase().split(" ")[0] + " SEES YOU", dx, ly, 10, Ui.AMBER);
            ly += ui.s(16);
            meter(ui, "Trust", l.playerRelation.trust, dx, ly, colW, 0xFF7AA0E0, true); ly += ui.s(16);
            meter(ui, "Hostility", l.playerRelation.hostility, dx, ly, colW, Ui.RED, false); ly += ui.s(16);
            meter(ui, "Rivalry", e.rivalry(l) * 100, dx, ly, colW, 0xFFE08A30, false); ly += ui.s(20);
        }
        // their own quarrels
        ui.text("THEIR RIVALS", dx, ly, 10, Ui.AMBER);
        ly += ui.s(16);
        List<RivalryState.Group> others = new ArrayList<>(groups);
        others.remove(g);
        others.sort((a, b) -> Float.compare(e.rivalry(g, b), e.rivalry(g, a)));
        for (int i = 0; i < Math.min(3, others.size()) && ly < y + h - ui.s(14); i++) {
            RivalryState.Group o = others.get(i);
            float rv = e.rivalry(g, o);
            if (rv < 0.05f) break;
            ui.b.rect(dx, ly + ui.s(2), ui.s(4), ui.s(10), o.colour);
            Layout.fit(ui, o.name, dx + ui.s(10), ly, colW - ui.s(110), 11, 8, Ui.TXT);
            ui.b.rect(dx + colW - ui.s(96), ly + ui.s(4), ui.s(60), ui.s(6), 0xFF1A1C1E);
            ui.b.rect(dx + colW - ui.s(96), ly + ui.s(4), ui.s(60) * rv, ui.s(6), 0xFFE08A30);
            ui.textR(Math.round(rv * 100) + "%", dx + colW, ly, 10, Ui.TXT_DIM);
            ly += ui.s(16);
        }
        // right column: standing, treaty, what they have learned, what they are doing, what you can do
        float rx = dx + colW + ui.s(18), ry = dy;
        Doctrine.Status st = Doctrine.status(r.favor);
        ui.text(st.name().toUpperCase() + "  " + Math.round(r.favor), rx, ry, 14, Ui.TXT_HI);
        ry += ui.s(20) + ui.wrap(st.text(), rx, ry + ui.s(20), colW, 11, Ui.TXT_DIM) + ui.s(6);
        RivalryState.Treaty tr = e.s.treatyWith(g.id, null);
        if (tr != null) {
            ry += ui.wrap(("alliance".equals(tr.kind) ? absentialis.engine.util.Json.str(absentialis.engine.util.Json.obj(Doctrine.faction(g.faction), "alliance"), "name", "Alliance") : "Truce") + ": " + String.join(", ", tr.terms) + (tr.obligations.isEmpty() ? "" : ". You owe: " + String.join("; ", tr.obligations)) + (tr.tribute > 0 ? " (" + tr.tribute + " coins each review)" : ""), rx, ry, colW, 11, Ui.AMBER) + ui.s(6);
        } else {
            List<String> blockers = e.allianceBlockers(g);
            ry += ui.wrap(blockers.isEmpty() ? "An alliance can be negotiated now." : "Alliance needs: " + String.join("; ", blockers) + ".", rx, ry, colW, 11, blockers.isEmpty() ? Ui.GREEN : Ui.TXT_DIM) + ui.s(6);
        }
        if (!g.adaptations.isEmpty()) {
            StringBuilder ad = new StringBuilder();
            for (Object o : Doctrine.adaptations()) { @SuppressWarnings("unchecked") java.util.Map<String, Object> rule = (java.util.Map<String, Object>) o; if (g.adapted(absentialis.engine.util.Json.str(rule, "id", "")) > 0) ad.append(ad.length() > 0 ? ", " : "").append(absentialis.engine.util.Json.str(rule, "name", "")); }
            ry += ui.wrap("Learned from experience: " + ad + ".", rx, ry, colW, 11, 0xFFE08A30) + ui.s(6);
        }
        ui.text("LATELY", rx, ry, 10, Ui.AMBER);
        ry += ui.s(15);
        for (int i = 0; i < Math.min(3, g.history.size()); i++) ry += ui.wrap(g.history.get(i).replaceFirst("^t(\\d+) ", "Tick $1: "), rx, ry, colW, 10, Ui.TXT_DIM) + ui.s(2);
        ry += ui.s(6);
        // jobs
        for (RivalryState.Job j : new ArrayList<>(g.jobs)) {
            if (ry > y + h - ui.s(150)) break;
            ui.b.rect(rx, ry, colW, ui.s(38), 0xFF14161A);
            Layout.fit(ui, j.title + "  (" + j.have + "/" + j.need + ")", rx + ui.s(8), ry + ui.s(4), colW - ui.s(120), 12, 9, Ui.TXT_HI);
            ui.text("+" + j.payout + " cash", rx + ui.s(8), ry + ui.s(21), 10, Ui.GREEN);
            if ("open".equals(j.status)) { if (ui.button("rjob" + j.id, rx + colW - ui.s(104), ry + ui.s(5), ui.s(98), ui.s(28), "TAKE JOB", null, true)) say(e.acceptJob(g, j)); }
            else ui.textR(j.status.toUpperCase(), rx + colW - ui.s(8), ry + ui.s(12), 10, Ui.AMBER);
            if (ui.hover(rx, ry, colW, ui.s(38))) ui.tip(j.text);
            ry += ui.s(42);
        }
        // ---- what you can do: the same surface for every group, whatever its faction
        float ay = y + h - ui.s(104), bw = (dw - ui.s(8) * 3) / 4, bh = ui.s(30);
        String[][] acts = {{"TALK", "talk"}, {"SUPPLIES 400", "gift"}, {"BRIBE 900", "bribe"}, {"INTIMIDATE", "intimidate"}, {"TRUCE", "truce"}, {"ALLIANCE", "alliance"}, {"ASK FOR AID", "aid"}, {tr != null ? "BREAK AGREEMENT" : "INFORM ON RIVAL", tr != null ? "betray" : "intel"}};
        for (int i = 0; i < acts.length; i++) {
            float bx = dx + (i % 4) * (bw + ui.s(8)), byy = ay + (i / 4) * (bh + ui.s(6));
            if (!ui.button("ract" + i, bx, byy, bw, bh, acts[i][0], null, true)) continue;
            switch (acts[i][1]) {
                case "talk" -> say(e.talk(g));
                case "gift" -> say(e.gift(g, wallet));
                case "bribe" -> say(e.bribe(g, wallet));
                case "intimidate" -> say(e.intimidate(g, p.prog.rank()));
                case "truce" -> say(e.truce(g, wallet));
                case "alliance" -> say(e.alliance(g, wallet));
                case "aid" -> say(e.aid(g));
                case "betray" -> say(e.betray(g));
                default -> say(e.intel(g, others.isEmpty() ? null : others.get(0)));
            }
            SaveSystem.save(p);
        }
        float fy = y + h - ui.s(30);
        ui.b.rect(dx, fy - ui.s(4), dw, 1, 0xFF2E2A22);
        String last = !feedback.isEmpty() ? feedback.get(0) : e.s.notices.isEmpty() ? "Favor is earned and lost by what a group sees you do or hears of it." : e.s.notices.get(e.s.notices.size() - 1);
        Layout.fit(ui, last, dx, fy, dw, 12, 8, last.startsWith("!") ? Ui.RED : Ui.TXT);
    }
}
