package absentialis.ui;

import static org.lwjgl.opengl.GL11.*;

import absentialis.engine.render.Tex;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;
import org.lwjgl.system.MemoryUtil;

/**
 * Procedural pixel-art UI sprite sheet: 9-slice frames for panels/buttons/slots in every state,
 * glyph icons drawn as hand-authored pixel grids, and cursors. Sampled with nearest filtering only.
 */
public final class PixelArt {
    public static final int SIZE = 256;
    public final int[] px = new int[SIZE * SIZE];
    public final Map<String, int[]> rects = new HashMap<>(); // name -> {x, y, w, h}
    public int tex;
    private int cx, cy, rowH;

    // palette (worn military field kit: olive steel, bone text, signal amber)
    public static final int INK = Tex.rgb(14, 15, 14), STEEL_D = Tex.rgb(30, 33, 32), STEEL = Tex.rgb(44, 48, 46), STEEL_L = Tex.rgb(66, 72, 68),
            EDGE = Tex.rgb(96, 104, 96), BONE = Tex.rgb(214, 206, 184), AMBER = Tex.rgb(226, 160, 52), AMBER_D = Tex.rgb(150, 98, 30),
            RED = Tex.rgb(196, 56, 46), GREEN = Tex.rgb(104, 170, 84), BLUE = Tex.rgb(86, 140, 186);

    public void build() {
        frame("panel", STEEL, STEEL_L, STEEL_D, EDGE, true, 0);
        frame("panel_dark", STEEL_D, STEEL, INK, STEEL_L, true, 1);
        frame("btn", STEEL_L, EDGE, STEEL, Tex.rgb(120, 128, 118), false, 2);
        frame("btn_hover", Tex.rgb(84, 90, 80), Tex.rgb(140, 146, 130), STEEL_L, AMBER, false, 3);
        frame("btn_down", STEEL, STEEL_D, STEEL_L, AMBER_D, false, 4);
        frame("btn_off", STEEL_D, STEEL, STEEL_D, STEEL_L, false, 5);
        frame("slot", Tex.rgb(22, 24, 23), STEEL_D, Tex.rgb(36, 39, 37), STEEL, false, 6);
        frame("slot_hi", Tex.rgb(40, 44, 38), STEEL_L, STEEL, AMBER, false, 7);
        frame("tip", Tex.rgb(20, 20, 18), STEEL_D, INK, AMBER_D, true, 8);
        frame("tab", STEEL_D, STEEL, INK, STEEL_L, false, 9);
        frame("tab_on", STEEL_L, EDGE, STEEL, AMBER, false, 10);
        glyphs();
        upload();
    }

    private int[] alloc(String name, int w, int h) {
        if (cx + w > SIZE) { cx = 0; cy += rowH + 1; rowH = 0; }
        int[] r = {cx, cy, w, h};
        rects.put(name, r);
        cx += w + 1;
        rowH = Math.max(rowH, h);
        return r;
    }

    private void put(int[] r, int x, int y, int c) { if (x >= 0 && y >= 0 && x < r[2] && y < r[3]) px[(r[1] + y) * SIZE + r[0] + x] = c; }

    /** 16x16 frame, 5px borders: bevelled steel with rivets and an accent inner line. */
    private void frame(String name, int fill, int hi, int lo, int accent, boolean rivets, int seed) {
        int[] r = alloc(name, 16, 16);
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            float n = Tex.r(fill) > 0 ? (absentialis.engine.util.Rng.hash(x, y, seed, 7) - 0.5f) * 0.10f : 0;
            int c = Tex.shade(fill, 1 + n);
            if (x == 0 || y == 0 || x == 15 || y == 15) c = INK;
            else if (x == 1 || y == 1) c = hi;
            else if (x == 14 || y == 14) c = lo;
            else if ((x == 3 || y == 3 || x == 12 || y == 12) && x >= 3 && y >= 3 && x <= 12 && y <= 12) c = Tex.mix(fill, accent, 0.45f);
            put(r, x, y, c);
        }
        if (rivets) for (int[] p : new int[][]{{2, 2}, {13, 2}, {2, 13}, {13, 13}}) { put(r, p[0], p[1], EDGE); }
    }

    // ------------------------------------------------------------------ glyphs (12x12 hand-authored pixel grids)
    // . = clear, # = main colour, + = highlight, - = shadow, o = ink outline, r = red, a = amber, g = green
    private static final String[][] GLYPHS = {
            {"cursor", "o...........", "oo..........", "o+o.........", "o++o........", "o+++o.......", "o++++o......", "o+++++o.....", "o++++++o....", "o+++++ooo...", "o++o++o.....", "oo..o++o....", "o....oo....."},
            {"stat", "............", ".####.####..", ".#++#.#++#..", ".####.####..", "............", ".####.####..", ".#++#.#++#..", ".####.####..", "............", "..aaaaaaa...", "..a.....a...", "..aaaaaaa..."},
            {"inv", "............", "...######...", "..#------#..", ".##########.", ".#++++++++#.", ".#+######+#.", ".#++++++++#.", ".#++#aa#++#.", ".#++++++++#.", ".##########.", "............", "............"},
            {"map", "............", ".###.###.##.", ".#+#.#+#.#+.", ".#+###+###+.", ".#+#+#+#+#+.", ".#+#+#+r+#+.", ".#+#+#rrr#+.", ".#+#+#+r+#+.", ".#+#+#+#+#+.", ".##.###.###.", "............", "............"},
            {"bench", "............", "..##........", ".#++#.......", ".#+++#......", "..#+++#.....", "...#+++#....", "....#+++#...", ".....#+++#..", "......#++aa.", ".......#aaa.", "........aa..", "............"},
            {"contracts", "............", "..#######...", "..#+++++#...", "..#+###+#...", "..#+++++#...", "..#+###+#...", "..#+++++#...", "..#+##++#...", "..#+++++#aa.", "..#######aa.", ".........a..", "............"},
            {"heart", "............", "..rr...rr...", ".rrrr.rrrr..", ".rr+rrrrrr..", ".rrrrrrrrr..", ".rrrrrrrrr..", "..rrrrrrr...", "...rrrrr....", "....rrr.....", ".....r......", "............", "............"},
            {"bolt", "............", "......aa....", ".....aa.....", "....aa......", "...aaaaa....", ".....aa.....", "....aa......", "...aa.......", "..a.........", "............", "............", "............"},
            {"eye", "............", "............", "...######...", "..#++++++#..", ".#++####++#.", ".#++#oo#++#.", ".#++####++#.", "..#++++++#..", "...######...", "............", "............", "............"},
            {"bullet", "............", ".....+......", "....+#+.....", "....###.....", "....###.....", "....aaa.....", "....aaa.....", "....aaa.....", "....aaa.....", "....---.....", "............", "............"},
            {"clock", "............", "...#####....", "..#+++++#...", ".#+++#+++#..", ".#+++#+++#..", ".#+++##++#..", ".#+++++++#..", ".#+++++++#..", "..#+++++#...", "...#####....", "............", "............"},
            {"radio", "........#...", ".......#....", "......#.....", ".##########.", ".#--------#.", ".#-oo-a-a-#.", ".#-oo-----#.", ".#--------#.", ".##########.", "............", "............", "............"},
            {"skull", "............", "...#####....", "..#+++++#...", ".#+++++++#..", ".#+oo+oo+#..", ".#+oo+oo+#..", ".#+++#+++#..", "..#+++++#...", "...#+#+#....", "...#####....", "............", "............"},
            {"flag", "............", ".#aaaaaa....", ".#aaaaaaa...", ".#aaaaaa....", ".#aaaaaaa...", ".#..........", ".#..........", ".#..........", ".#..........", ".#..........", ".##.........", "............"},
            {"star", "............", ".....a......", ".....a......", "....aaa.....", "aaaaaaaaaaa.", ".aaaaaaaaa..", "..aaaaaaa...", "..aaa.aaa...", ".aa.....aa..", ".a.......a..", "............", "............"},
            {"lock", "............", "....###.....", "...#...#....", "...#...#....", "..#######...", "..#+++++#...", "..#++o++#...", "..#++o++#...", "..#+++++#...", "..#######...", "............", "............"},
            {"check", "............", "............", ".........g..", "........gg..", ".......gg...", ".g....gg....", ".gg..gg.....", "..gggg......", "...gg.......", "............", "............", "............"},
            {"cross", "............", "............", "..r.....r...", "...r...r....", "....r.r.....", ".....r......", "....r.r.....", "...r...r....", "..r.....r...", "............", "............", "............"},
            {"arrow", "............", "....#.......", "....##......", "....#+#.....", "########....", "#++++++#....", "########....", "....#+#.....", "....##......", "....#.......", "............", "............"},
            {"coin", "............", "...aaaaa....", "..a+++++a...", ".a++aaa++a..", ".a+a+++++a..", ".a++aaa++a..", ".a+++++a+a..", ".a++aaa++a..", "..a+++++a...", "...aaaaa....", "............", "............"},
            {"chevron", "............", "..a.....a...", "..aa...aa...", "...aa.aa....", "....aaa.....", "..a..a..a...", "..aa...aa...", "...aa.aa....", "....aaa.....", ".....a......", "............", "............"},
            {"token", "............", "....aaa.....", "...a+++a....", "..a+aaa+a...", ".a+a+a+a+a..", ".a+aa+aa+a..", ".a+a+a+a+a..", "..a+aaa+a...", "...a+++a....", "....aaa.....", "............", "............"},
            {"key", "............", "............", ".aaa........", "a+++a.......", "a+o+aaaaaaa.", "a+++a..a.a..", ".aaa...a.a..", "............", "............", "............", "............", "............"},
            {"doc", "............", "..######....", "..#++++##...", "..#+--+++#..", "..#++++++#..", "..#+----+#..", "..#++++++#..", "..#+----+#..", "..#++++++#..", "..########..", "............", "............"},
            {"handgun", "............", "............", ".##########.", ".#++++++-+#.", ".##########.", "..####+##...", "..###.#.#...", "..###..#....", "..#+#.......", "..###.......", "............", "............"},
            {"ammo", "............", "..+...+...+.", ".#+#.#+#.#+#", ".#+#.#+#.#+#", ".aaa.aaa.aaa", ".a+a.a+a.a+a", ".a+a.a+a.a+a", ".a+a.a+a.a+a", ".a+a.a+a.a+a", ".aaa.aaa.aaa", "............", "............"},
            {"herb", "............", "....g.......", "...ggg..g...", "..gg+gggg...", "...ggg+gg...", "....ggg.....", ".....#......", ".....#......", "....#.......", "............", "............", "............"},
            {"gem", "............", "...rrrrr....", "..r+++rrr...", ".r++rrrrrr..", ".rrrrrrrrr..", "..rrrrrrr...", "...rrrrr....", "....rrr.....", ".....r......", "............", "............", "............"},
            {"sort", "............", ".##.........", ".##..####...", ".....####...", ".##.........", ".##..######.", ".....######.", ".##.........", ".##..##.....", ".....##.....", "............", "............"},
            {"rotate", "............", "....####....", "...#....#...", "..#......#..", "..#......#..", "..#....aaaa.", "..#.....aa..", "...#....a...", "....####....", "............", "............", "............"},
            {"cog", "............", ".....#......", "..#.###.#...", "...#+++#....", ".##+#-#+##..", "...#+++#....", "..#.###.#...", ".....#......", "............", "............", "............", "............"},
            {"charm", "............", ".....#......", "....#.#.....", ".....#......", "....aaa.....", "...a+++a....", "...a+a+a....", "...a+++a....", "....aaa.....", "............", "............", "............"},
            {"crosshatch", "#...#...#...", ".#...#...#..", "..#...#...#.", "...#...#...#", "#...#...#...", ".#...#...#..", "..#...#...#.", "...#...#...#", "#...#...#...", ".#...#...#..", "..#...#...#.", "...#...#...#"},
            {"stamp", "............", "..aaaaaaa...", ".a.......a..", ".a.#####.a..", ".a.#+++#.a..", ".a.#+a+#.a..", ".a.#+++#.a..", ".a.#####.a..", ".a.......a..", "..aaaaaaa...", "............", "............"},
            {"search", "............", "...####.....", "..#++++#....", ".#++--++#...", ".#+-..-+#...", ".#+-..-+#...", ".#++--++#...", "..#++++##...", "...####.##..", "........##..", ".........##.", "............"},
            {"you", "............", ".....a......", "....aaa.....", "....aaa.....", "...aaaaa....", "...aaaaa....", "..aaaaaaa...", "..aa...aa...", ".a.......a..", "............", "............", "............"},
    };

    private void glyphs() {
        for (String[] g : GLYPHS) {
            int h = g.length - 1, w = g[1].length();
            int[] r = alloc(g[0], w, h);
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                char ch = x < g[y + 1].length() ? g[y + 1].charAt(x) : '.';
                int c = switch (ch) {
                    case '#' -> BONE; case '+' -> Tex.rgb(240, 236, 220); case '-' -> Tex.rgb(150, 144, 128); case 'o' -> INK;
                    case 'r' -> RED; case 'a' -> AMBER; case 'g' -> GREEN; default -> 0;
                };
                put(r, x, y, c);
            }
        }
        // drop shadow pass for glyphs (1px down-right, ink at 60%) so they read on any background
        for (String[] g : GLYPHS) {
            if (g[0].equals("crosshatch")) continue;
            int[] r = rects.get(g[0]);
            int[] copy = new int[r[2] * r[3]];
            for (int y = 0; y < r[3]; y++) for (int x = 0; x < r[2]; x++) copy[y * r[2] + x] = px[(r[1] + y) * SIZE + r[0] + x];
            for (int y = 0; y < r[3]; y++) for (int x = 0; x < r[2]; x++) {
                if (copy[y * r[2] + x] != 0) continue;
                boolean sh = x > 0 && y > 0 && copy[(y - 1) * r[2] + x - 1] != 0;
                if (sh) put(r, x, y, 0x99000000);
            }
        }
    }

    private void upload() {
        ByteBuffer b = MemoryUtil.memAlloc(SIZE * SIZE * 4);
        for (int c : px) b.put((byte) Tex.r(c)).put((byte) Tex.g(c)).put((byte) Tex.b(c)).put((byte) Tex.a(c));
        b.flip();
        tex = glGenTextures();
        glBindTexture(GL_TEXTURE_2D, tex);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, SIZE, SIZE, 0, GL_RGBA, GL_UNSIGNED_BYTE, b);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, org.lwjgl.opengl.GL12.GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, org.lwjgl.opengl.GL12.GL_CLAMP_TO_EDGE);
        MemoryUtil.memFree(b);
    }
}
