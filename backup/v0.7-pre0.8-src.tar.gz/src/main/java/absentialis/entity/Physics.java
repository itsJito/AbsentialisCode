package absentialis.entity;

import absentialis.world.Block;
import absentialis.world.World;

/**
 * Voxel collision for upright AABB actors: per-axis sweep against solid blocks, 1-block auto-step
 * when grounded (curbs, stairs), ladder climbing, and line-of-sight / ray queries.
 */
public final class Physics {
    private Physics() {}

    public static final float GRAVITY = 22f;
    /** Take-off speed of a standing jump: clears one block (7.2^2 / 2g = 1.18). Shared by the player and every agent. */
    public static final float JUMP = 7.2f;
    /**
     * 0.6: walking into a block no longer lifts a body onto it. Only stair blocks ({@link Block#STEP}) are climbed by
     * walking; anything else one block high has to be jumped, by the player and by agents alike. True restores 0.5.
     */
    public static boolean AUTO_STEP_ALL = false;

    /** True when every solid cell the body would meet at foot level is a stair tread (so walking carries it up). */
    public static boolean stairAt(World w, float x, float y, float z, float r) {
        if (AUTO_STEP_ALL) return true;
        int x0 = (int) Math.floor(x - r), x1 = (int) Math.floor(x + r - 1e-4f), z0 = (int) Math.floor(z - r), z1 = (int) Math.floor(z + r - 1e-4f), by = (int) Math.floor(y);
        boolean any = false;
        for (int bx = x0; bx <= x1; bx++) for (int bz = z0; bz <= z1; bz++) {
            if (!w.solid(bx, by, bz)) continue;
            if (!w.block(bx, by, bz).is(Block.STEP)) return false;
            any = true;
        }
        return any;
    }

    /** A one-block ledge that is not a stair stands in the way of a body moving along (dx, dz): it has to be jumped. */
    public static boolean ledgeAhead(World w, Actor a, float dx, float dz) {
        float l = (float) Math.sqrt(dx * dx + dz * dz);
        if (l < 1e-4f) return false;
        float nx = a.x + dx / l * (a.radius + 0.25f), nz = a.z + dz / l * (a.radius + 0.25f);
        if (boxFree(w, nx, a.y, nz, a.radius, a.height())) return false;
        return !stairAt(w, nx, a.y, nz, a.radius) && boxFree(w, nx, a.y + 1.01f, nz, a.radius, a.height()) && boxFree(w, a.x, a.y + 1.01f, a.z, a.radius, a.height());
    }

    public static boolean boxFree(World w, float x, float y, float z, float r, float h) {
        int x0 = (int) Math.floor(x - r), x1 = (int) Math.floor(x + r - 1e-4f);
        int y0 = (int) Math.floor(y), y1 = (int) Math.floor(y + h - 1e-4f);
        int z0 = (int) Math.floor(z - r), z1 = (int) Math.floor(z + r - 1e-4f);
        for (int bx = x0; bx <= x1; bx++) for (int by = y0; by <= y1; by++) for (int bz = z0; bz <= z1; bz++) if (w.solid(bx, by, bz)) return false;
        return true;
    }

    public static boolean inClimb(World w, float x, float y, float z) {
        // feet, waist and a little below the feet: the climb continues until the body has cleared the top rung,
        // so a ladder that ends at a roof edge delivers you onto the roof instead of dropping you back down it
        for (float dy : new float[]{-0.6f, 0f, 0.9f}) {
            Block b = w.block((int) Math.floor(x), (int) Math.floor(y + dy), (int) Math.floor(z));
            if (b != null && b.is(Block.CLIMB)) return true;
        }
        return false;
    }

    /**
     * Moves the actor by its velocity * dt with collision; updates onGround. Large steps are split
     * so no axis advances more than 0.4 blocks per sub-step (no tunnelling through 1-block floors
     * at terminal velocity or under coarse regional-tier ticks). Returns true if blocked horizontally.
     */
    public static boolean move(World w, Actor a, float dt) {
        float vmax = Math.max(Math.abs(a.vx), Math.max(Math.abs(a.vz), Math.abs(a.vy) + GRAVITY * dt));
        int n = Math.max(1, Math.min(64, (int) Math.ceil(vmax * dt / 0.4f)));
        boolean blocked = false;
        boolean ground = false;
        for (int i = 0; i < n; i++) { blocked |= step(w, a, dt / n); ground |= a.onGround; }
        a.onGround = ground && a.vy <= 0;
        return blocked;
    }

    private static boolean step(World w, Actor a, float dt) {
        float h = a.height(), r = a.radius;
        boolean blocked = false;
        // ladders: holding forward while inside a climbable column moves up
        boolean onLadder = inClimb(w, a.x, a.y, a.z);
        a.climbing = onLadder && a.wantClimb;
        if (a.climbing) {
            a.vy = a.climbDir * 3.2f;
            // going down stops at the floor instead of grinding into it
            if (a.climbDir < 0 && !boxFree(w, a.x, a.y - 0.1f, a.z, r, h)) a.vy = 0;
            a.vx *= 0.55f; a.vz *= 0.55f;
        } else if (onLadder && !a.onGround && a.vy <= 0) {
            a.vy = Math.max(a.vy - GRAVITY * dt, -1.4f);   // hands on the rails: a controlled slide, never a free fall
            a.fallSpeed = 0;
        } else a.vy -= GRAVITY * dt;
        a.vy = Math.max(a.vy, -40);
        // X
        float nx = a.x + a.vx * dt;
        if (boxFree(w, nx, a.y, a.z, r, h)) a.x = nx;
        else if (a.onGround && stairAt(w, nx, a.y, a.z, r) && boxFree(w, nx, a.y + 1.01f, a.z, r, h) && boxFree(w, a.x, a.y + 1.01f, a.z, r, h)) { a.y += 1.01f; a.x = nx; a.stepped += 1.01f; }
        else { blocked = true; a.vx = 0; }
        // Z
        float nz = a.z + a.vz * dt;
        if (boxFree(w, a.x, a.y, nz, r, h)) a.z = nz;
        else if (a.onGround && stairAt(w, a.x, a.y, nz, r) && boxFree(w, a.x, a.y + 1.01f, nz, r, h) && boxFree(w, a.x, a.y + 1.01f, a.z, r, h)) { a.y += 1.01f; a.z = nz; a.stepped += 1.01f; }
        else { blocked = true; a.vz = 0; }
        // Y
        float ny = a.y + a.vy * dt;
        a.onGround = false;
        if (boxFree(w, a.x, ny, a.z, r, h)) a.y = ny;
        else {
            if (a.vy < 0) {
                a.onGround = true;
                a.fallSpeed = -a.vy;
                a.y = (float) Math.floor(ny) + 1f;
                if (!boxFree(w, a.x, a.y, a.z, r, h)) a.y = (float) Math.ceil(ny);
            }
            a.vy = 0;
        }
        if (!boxFree(w, a.x, a.y, a.z, r, h)) depenetrate(w, a, r, h);
        return blocked;
    }

    /**
     * The body overlaps something solid (geometry changed round it: a door shut, a block was placed). 0.5 lifted it
     * 5 cm per step until it was free - which carried anyone standing in a closing doorway up through the lintel and
     * onto the floor above. Feet a little way into the floor are still lifted; anything else is pushed out sideways
     * to the nearest free spot, and a body that is truly boxed in stays where it is.
     */
    private static void depenetrate(World w, Actor a, float r, float h) {
        float frac = a.y - (float) Math.floor(a.y);
        if (frac > 0.7f && boxFree(w, a.x, (float) Math.ceil(a.y), a.z, r, h)) { a.y = (float) Math.ceil(a.y); return; }
        if (boxFree(w, a.x, a.y + 0.12f, a.z, r, h)) { a.y += 0.05f; return; }
        for (float d = 0.1f; d <= 1.01f; d += 0.1f) for (int k = 0; k < 8; k++) {
            float ox = OFFX[k] * d, oz = OFFZ[k] * d;
            if (boxFree(w, a.x + ox, a.y, a.z + oz, r, h)) { a.x += ox; a.z += oz; return; }
        }
    }

    private static final float[] OFFX = {1, -1, 0, 0, 0.7071f, 0.7071f, -0.7071f, -0.7071f}, OFFZ = {0, 0, 1, -1, 0.7071f, -0.7071f, 0.7071f, -0.7071f};

    /** True when no opaque block lies between the points (sight checks). */
    public static boolean los(World w, float ax, float ay, float az, float bx, float by, float bz) {
        float dx = bx - ax, dy = by - ay, dz = bz - az;
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 0.5f) return true;
        int steps = (int) (len * 2.5f);
        for (int i = 1; i < steps; i++) {
            float t = i / (float) steps;
            int x = (int) Math.floor(ax + dx * t), y = (int) Math.floor(ay + dy * t), z = (int) Math.floor(az + dz * t);
            Block b = w.block(x, y, z);
            if (b != null && b.opaque()) return false;
        }
        return true;
    }

    /**
     * Sight, as the AI's eyes use it (0.7). {@link #los} stops only at opaque blocks, which let people see through a
     * hedge as if it were air. Here anything that fills its cell and is not glass stops the line: walls, shut doors,
     * hedges, hay, sandbags. Tree leaves and tall grass do not stop it outright - they are counted by
     * {@link #foliage} and each one takes something off how much can be made out.
     */
    public static boolean sight(World w, float ax, float ay, float az, float bx, float by, float bz) {
        float dx = bx - ax, dy = by - ay, dz = bz - az;
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 0.5f) return true;
        int steps = (int) (len * 2.5f);
        int leaves = 0, lx = Integer.MIN_VALUE, ly = 0, lz = 0;
        for (int i = 1; i < steps; i++) {
            float t = i / (float) steps;
            int x = (int) Math.floor(ax + dx * t), y = (int) Math.floor(ay + dy * t), z = (int) Math.floor(az + dz * t);
            int id = w.get(x, y, z);
            if (id == 0) continue;
            Block b = Block.ALL[id];
            if (b.opaque()) return false;
            if (!b.solid() || b.mat == absentialis.world.Material.GLASS) continue;
            if (b.mat == absentialis.world.Material.FOLIAGE) {
                // canopy: a few cells of it and nothing can be made out through it
                if (x != lx || y != ly || z != lz) { lx = x; ly = y; lz = z; if (++leaves >= 4) return false; }
                continue;
            }
            if (b.is(Block.DOOR)) return false;
        }
        return true;
    }

    /** Cells of leaves, hedge or tall growth a line of sight passes through (each one hides a little more of what is behind it). */
    public static int foliage(World w, float ax, float ay, float az, float bx, float by, float bz) {
        float dx = bx - ax, dy = by - ay, dz = bz - az;
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        int steps = (int) (len * 2f), n = 0, lx = Integer.MIN_VALUE, ly = 0, lz = 0;
        for (int i = 1; i < steps; i++) {
            float t = i / (float) steps;
            int x = (int) Math.floor(ax + dx * t), y = (int) Math.floor(ay + dy * t), z = (int) Math.floor(az + dz * t);
            if (x == lx && y == ly && z == lz) continue;
            int id = w.get(x, y, z);
            if (id != 0 && Block.ALL[id].mat == absentialis.world.Material.FOLIAGE) { n++; lx = x; ly = y; lz = z; }
        }
        return n;
    }

    /** Fraction of the path that is clear (0..1) - used for sound occlusion. */
    public static float openness(World w, float ax, float ay, float az, float bx, float by, float bz) {
        float dx = bx - ax, dy = by - ay, dz = bz - az;
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        int steps = Math.max(2, (int) (len / 1.5f)), solid = 0;
        for (int i = 1; i < steps; i++) {
            float t = i / (float) steps;
            if (w.solid((int) Math.floor(ax + dx * t), (int) Math.floor(ay + dy * t), (int) Math.floor(az + dz * t))) solid++;
        }
        return 1f - Math.min(1f, solid / 6f);
    }

    /** Voxel ray cast: returns {x,y,z,face} of the first solid/interactive block within maxDist, or null. */
    public static int[] ray(World w, float ox, float oy, float oz, float dx, float dy, float dz, float maxDist, boolean interactOnly) {
        int x = (int) Math.floor(ox), y = (int) Math.floor(oy), z = (int) Math.floor(oz);
        int sx = dx > 0 ? 1 : -1, sy = dy > 0 ? 1 : -1, sz = dz > 0 ? 1 : -1;
        float tdx = Math.abs(1 / (dx == 0 ? 1e-6f : dx)), tdy = Math.abs(1 / (dy == 0 ? 1e-6f : dy)), tdz = Math.abs(1 / (dz == 0 ? 1e-6f : dz));
        float tmx = (dx > 0 ? (x + 1 - ox) : (ox - x)) * tdx, tmy = (dy > 0 ? (y + 1 - oy) : (oy - y)) * tdy, tmz = (dz > 0 ? (z + 1 - oz) : (oz - z)) * tdz;
        int face = -1;
        float t = 0;
        while (t <= maxDist) {
            int id = w.get(x, y, z);
            if (id != 0) {
                Block b = Block.ALL[id];
                if (interactOnly ? b.is(Block.INTERACT) || b.is(Block.CONTAINER) : b.solid()) return new int[]{x, y, z, face};
                if (interactOnly && b.opaque()) return null;
            }
            if (tmx < tmy && tmx < tmz) { x += sx; t = tmx; tmx += tdx; face = sx > 0 ? 1 : 0; }
            else if (tmy < tmz) { y += sy; t = tmy; tmy += tdy; face = sy > 0 ? 3 : 2; }
            else { z += sz; t = tmz; tmz += tdz; face = sz > 0 ? 5 : 4; }
        }
        return null;
    }
}
