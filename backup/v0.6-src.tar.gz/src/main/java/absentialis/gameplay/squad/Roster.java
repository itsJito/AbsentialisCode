package absentialis.gameplay.squad;

import absentialis.character.Appearance;
import absentialis.engine.util.Json;
import absentialis.engine.util.Rng;
import absentialis.gameplay.items.Content;
import absentialis.gameplay.items.ItemDef;
import absentialis.gameplay.progression.Progression;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The player's AI squad (v0.3). A profile starts with four customizable squadmates and unlocks five
 * more roster slots through Rank, nine in all; up to eight deploy on an operation, split between
 * Red Team and Blue Team (four each at most). Gold Team is everyone deployed. The player is the
 * Element Leader and is never counted as a squadmate.
 *
 * Every squadmate is persistent: their look, weapon and build, Level (1-50 over 1,265,500 XP) and
 * Prestige (0-10) are their own and are independent of the player's Rank and Prestige. A
 * squadmate's Prestige keeps Level 50 and everything they have - it is purely added on top.
 */
public final class Roster {
    public static final int START = 4, UNLOCKABLE = 5, MAX_ROSTER = START + UNLOCKABLE, MAX_ACTIVE = 8, TEAM_CAP = 4, MAX_LEVEL = 50, MAX_PRESTIGE = 10;
    public static final long XP_PER_CLIMB = Progression.CYCLE_XP;
    public static final String RED = "red", BLUE = "blue", GOLD = "gold";

    public static final class Mate {
        public long id;
        public String name = "Recruit";
        public Appearance look = Appearance.legacy(1, 0);
        /** Lifetime XP: the first 1,265,500 climb Level 1-50, every further 1,265,500 is one Prestige. */
        public long xp;
        public String weapon = "weapon.smg";
        public final List<String> build = new ArrayList<>();
        public String team = RED;
        public boolean active = true;
        public int kills, raids, downs;

        public int level() {
            long x = Math.min(xp, XP_PER_CLIMB);
            int r = 1;
            long acc = 0;
            while (r < MAX_LEVEL && acc + Progression.costOf(r) <= x) { acc += Progression.costOf(r); r++; }
            return r;
        }

        public int prestige() { return (int) Math.min(MAX_PRESTIGE, Math.max(0, (xp - XP_PER_CLIMB) / XP_PER_CLIMB)); }

        /** Progress toward the next Level, or toward the next Prestige once Level 50 is held. */
        public float progress() {
            if (xp >= XP_PER_CLIMB) return prestige() >= MAX_PRESTIGE ? 1 : ((xp - XP_PER_CLIMB) % XP_PER_CLIMB) / (float) XP_PER_CLIMB;
            int l = level();
            return (xp - Progression.xpToReach(l)) / (float) Progression.costOf(l);
        }

        public String title() { return (prestige() > 0 ? "P" + prestige() + " " : "") + Progression.rankName(level()) + " " + level(); }

        /** Experience shows: steadier aim, quicker reactions, a little more staying power. Never more damage per round. */
        public float skill() { return Math.min(1f, (level() - 1) / 49f * 0.8f + prestige() * 0.02f); }
        public float maxHp() { return 100 + level() + prestige() * 3; }

        public int addXp(long amount) {
            if (amount <= 0) return 0;
            int before = level() + prestige();
            xp = Math.min(XP_PER_CLIMB * (1 + MAX_PRESTIGE), xp + amount);
            return level() + prestige() - before;
        }
    }

    public final List<Mate> mates = new ArrayList<>();
    private long nextId = 1;

    private static final String[] FIRST = {"Anton", "Mila", "Dmitri", "Oksana", "Yuri", "Katya", "Pavel", "Irina", "Sergei", "Nadia", "Viktor", "Lena", "Taras", "Zoya", "Bohdan", "Vera"};
    private static final String[] CALL = {"Kestrel", "Brick", "Wren", "Lantern", "Moth", "Anvil", "Sable", "Rook", "Tally", "Ember", "Flint", "Harrow", "Vesper", "Quill", "Garnet", "Bishop"};
    private static final String[] STARTER_WEAPONS = {"weapon.smg", "weapon.pump12", "weapon.mosin", "weapon.smg", "weapon.tommy", "weapon.riot", "weapon.sr16", "weapon.akr", "weapon.striker"};

    /** Grows the roster to the number of slots the player has unlocked (never shrinks it). */
    public void ensure(int slots, long seed) {
        slots = Math.min(MAX_ROSTER, Math.max(START, slots));
        // 0.6: a slot comes with one squadmate, once. Whoever is lost in the Zone is not replaced by opening the
        // roster again - the place stays empty until someone is recruited into it.
        while (granted < slots && mates.size() < MAX_ROSTER) {
            int i = granted++;
            Rng r = new Rng(seed * 31 + i * 7919L);
            Mate m = new Mate();
            m.id = nextId++;
            m.look = Appearance.random(r);
            m.name = cleanName(absentialis.sim.Names.squad(r, m.look.female));
            m.weapon = STARTER_WEAPONS[i % STARTER_WEAPONS.length];
            m.team = teamSize(RED) <= teamSize(BLUE) ? RED : BLUE;
            m.active = activeCount() < MAX_ACTIVE && teamSize(m.team) < TEAM_CAP;
            mates.add(m);
        }
    }

    /** A fresh generated name (the RANDOM NAME button). */
    public String randomName(long salt) { return randomName(salt, false); }

    public String randomName(long salt, boolean female) { return absentialis.sim.Names.squad(new Rng(salt), female); }

    // ------------------------------------------------------------------ 0.6: loss and recruitment
    /** Squadmates this roster has ever been given by unlocking slots (never more than the slots unlocked). */
    public int granted;
    /** Recruits already hired, as "day:index" of the offer they answered. */
    public final java.util.Set<String> hired = new java.util.HashSet<>();

    /** Someone who did not come back: what the memorial keeps of them. */
    public record Fallen(String name, String title, int kills, int raids, int day, String cause) {}
    public final List<Fallen> fallen = new ArrayList<>();

    /** A candidate who can be hired into an empty place, and what they ask. */
    public record Offer(String key, Mate mate, int price) {}

    /** Places on the roster with nobody in them. */
    public int vacancies(int slots) { return Math.max(0, Math.min(MAX_ROSTER, Math.max(START, slots)) - mates.size()); }

    /**
     * Permadeath. The squadmate is struck off the roster with everything they were - level, prestige, kills, build -
     * and remembered on the memorial. Nothing of theirs returns.
     */
    public Fallen bury(Mate m, int day, String cause) {
        if (!mates.remove(m)) return null;
        Fallen f = new Fallen(m.name, m.title(), m.kills, m.raids, day, cause == null ? "" : cause);
        fallen.add(0, f);
        while (fallen.size() > 40) fallen.remove(fallen.size() - 1);
        return f;
    }

    /** Hiring price: a green recruit is cheap, experience is not (tunable). */
    public static int RECRUIT_BASE = 1800, RECRUIT_PER_LEVEL = 650;

    /**
     * Who is looking for work today. Three candidates, the same three for a given profile and day until one is
     * hired; their experience runs from none up to a little under half the Rank of whoever is hiring.
     */
    public List<Offer> offers(long seed, int day, int rank) {
        List<Offer> l = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            String key = day + ":" + i;
            if (hired.contains(key)) continue;
            Rng r = new Rng(seed * 131 + day * 7919L + i * 104729L);
            Mate m = new Mate();
            m.look = Appearance.random(r);
            m.name = cleanName(absentialis.sim.Names.squad(r, m.look.female));
            int lvl = 1 + r.nextInt(Math.max(1, Math.min(20, rank / 2)));
            m.xp = Progression.xpToReach(lvl);
            m.weapon = STARTER_WEAPONS[r.nextInt(STARTER_WEAPONS.length)];
            l.add(new Offer(key, m, RECRUIT_BASE + (lvl - 1) * RECRUIT_PER_LEVEL));
        }
        return l;
    }

    /** Takes a recruit on. Returns null when done, or why not. */
    public String hire(Offer o, int slots, long coins) {
        if (vacancies(slots) <= 0) return "No empty place on the roster";
        if (coins < o.price()) return "Not enough coins";
        Mate m = o.mate();
        m.id = nextId++;
        m.team = teamSize(RED) <= teamSize(BLUE) ? RED : BLUE;
        m.active = activeCount() < MAX_ACTIVE && teamSize(m.team) < TEAM_CAP;
        mates.add(m);
        hired.add(o.key());
        return null;
    }

    /**
     * A name as the player typed it, made safe to store and draw: printable characters only, runs of spaces
     * collapsed, trimmed, at most 20 characters. Anything else is theirs to choose - first names, callsigns,
     * numbers, punctuation. Returns "" when nothing printable is left (the caller keeps the old name).
     */
    public static String cleanName(String raw) {
        if (raw == null) return "";
        StringBuilder b = new StringBuilder();
        boolean space = false;
        for (int i = 0; i < raw.length(); i++) {
            char ch = raw.charAt(i);
            if (ch < 32 || ch == 127) continue;
            if (ch == ' ') { space = b.length() > 0; continue; }
            if (space) { b.append(' '); space = false; }
            b.append(ch);
            if (b.length() >= 20) break;
        }
        return b.toString().trim();
    }

    /** How the squad says a name aloud: the callsign in quotes when there is one, otherwise the first word. */
    public static String shortName(String name) {
        if (name == null || name.isEmpty()) return "you";
        int a = name.indexOf('"'), b = name.lastIndexOf('"');
        if (a >= 0 && b > a + 1) return name.substring(a + 1, b);
        int sp = name.indexOf(' ');
        return sp > 0 ? name.substring(0, sp) : name;
    }

    public List<Mate> active() { List<Mate> l = new ArrayList<>(); for (Mate m : mates) if (m.active) l.add(m); return l; }
    public int activeCount() { int n = 0; for (Mate m : mates) if (m.active) n++; return n; }
    /** Deployed members of a team; "gold" is the whole deployed element. */
    public List<Mate> team(String team) { List<Mate> l = new ArrayList<>(); for (Mate m : mates) if (m.active && (GOLD.equals(team) || m.team.equals(team))) l.add(m); return l; }
    public int teamSize(String team) { return team(team).size(); }
    public Mate byId(long id) { for (Mate m : mates) if (m.id == id) return m; return null; }

    /** Moves a squadmate to Red or Blue. Teams need not be equal, but neither holds more than four deployed soldiers. */
    public String assign(Mate m, String team) {
        if (!RED.equals(team) && !BLUE.equals(team)) return "Squadmates belong to Red or Blue; Gold is the whole element";
        if (m.team.equals(team)) return null;
        if (m.active && teamSize(team) >= TEAM_CAP) return (RED.equals(team) ? "Red" : "Blue") + " Team is full (" + TEAM_CAP + ")";
        m.team = team;
        return null;
    }

    public String setActive(Mate m, boolean on) {
        if (m.active == on) return null;
        if (on) {
            if (activeCount() >= MAX_ACTIVE) return "The element is full: " + MAX_ACTIVE + " squadmates plus you";
            if (teamSize(m.team) >= TEAM_CAP) { String other = RED.equals(m.team) ? BLUE : RED; if (teamSize(other) >= TEAM_CAP) return "Both teams are full"; m.team = other; }
        }
        m.active = on;
        return null;
    }

    /** Weapons a squadmate may be issued: any firearm the player has unlocked. */
    public static List<ItemDef> armoury(Progression p) {
        List<ItemDef> l = new ArrayList<>();
        for (String id : Progression.platforms()) { ItemDef d = Content.def(id); if (d.weapon != null && !d.weapon.melee() && (p == null || p.platformUnlocked(id))) l.add(d); }
        return l;
    }

    // ------------------------------------------------------------------ persistence (separate from player and weapon progression)
    public Map<String, Object> toJson() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("nextId", String.valueOf(nextId));
        List<Object> l = new ArrayList<>();
        for (Mate s : mates) {
            Map<String, Object> o = new LinkedHashMap<>();
            o.put("id", String.valueOf(s.id));
            o.put("name", s.name);
            o.put("look", s.look.toJson());
            o.put("xp", String.valueOf(s.xp));
            o.put("weapon", s.weapon);
            o.put("build", new ArrayList<Object>(s.build));
            o.put("team", s.team);
            o.put("active", s.active);
            o.put("kills", s.kills);
            o.put("raids", s.raids);
            o.put("downs", s.downs);
            l.add(o);
        }
        m.put("mates", l);
        m.put("granted", granted);
        m.put("hired", new ArrayList<Object>(hired));
        List<Object> fl = new ArrayList<>();
        for (Fallen f : fallen) {
            Map<String, Object> o = new LinkedHashMap<>();
            o.put("name", f.name()); o.put("title", f.title()); o.put("kills", f.kills()); o.put("raids", f.raids()); o.put("day", f.day()); o.put("cause", f.cause());
            fl.add(o);
        }
        m.put("fallen", fl);
        return m;
    }

    @SuppressWarnings("unchecked")
    public static Roster fromJson(Map<String, Object> m) {
        Roster r = new Roster();
        if (m == null) return r;
        r.nextId = Json.lng(m, "nextId", 1);
        for (Object o : Json.list(m, "mates")) {
            if (!(o instanceof Map)) continue;
            Map<String, Object> s = (Map<String, Object>) o;
            Mate t = new Mate();
            t.id = Json.lng(s, "id", r.mates.size() + 1);
            t.name = cleanName(Json.str(s, "name", "Recruit"));
            if (t.name.isEmpty()) t.name = "Recruit";
            t.look = Appearance.fromJson(Json.obj(s, "look"));
            t.xp = Json.lng(s, "xp", 0);
            t.weapon = Content.canon(Json.str(s, "weapon", "weapon.smg"));
            if (Content.def(t.weapon) == null || Content.def(t.weapon).weapon == null) t.weapon = "weapon.smg";
            t.build.addAll(Json.strList(s, "build"));
            t.team = BLUE.equals(Json.str(s, "team", RED)) ? BLUE : RED;
            t.active = Json.bool(s, "active", true);
            t.kills = Json.integer(s, "kills", 0);
            t.raids = Json.integer(s, "raids", 0);
            t.downs = Json.integer(s, "downs", 0);
            if (r.mates.size() < MAX_ROSTER) r.mates.add(t);
            r.nextId = Math.max(r.nextId, t.id + 1);
        }
        // a roster saved before 0.6 has no count: every place it had unlocked was full, so that is how many it was given
        r.granted = Json.integer(m, "granted", r.mates.size());
        r.hired.addAll(Json.strList(m, "hired"));
        for (Object o : Json.list(m, "fallen")) {
            if (!(o instanceof Map)) continue;
            Map<String, Object> s = (Map<String, Object>) o;
            r.fallen.add(new Fallen(Json.str(s, "name", "?"), Json.str(s, "title", ""), Json.integer(s, "kills", 0), Json.integer(s, "raids", 0), Json.integer(s, "day", 0), Json.str(s, "cause", "")));
        }
        return r;
    }
}
