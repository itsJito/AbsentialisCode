package absentialis.gameplay;

import absentialis.persistence.Profile;
import absentialis.rivalry.Doctrine;
import absentialis.rivalry.RivalryEngine;
import absentialis.rivalry.RivalryState;
import absentialis.rivalry.RivalryWorld;
import absentialis.world.District;

/**
 * The survivor's alliance (0.6): after creating a profile the player throws in with the Military, the Bandits, the
 * Loners or the Mercenaries. The choice is made once and is stored on the profile. It decides
 *
 *   WHERE they may deploy from - only ground their faction holds: its headquarters district, any district the
 *   faction has since taken (the strategic layer's controller of that district), or the ground of a group that has
 *   signed a formal alliance with them;
 *
 *   WHAT work they are offered - each faction's contract board is weighted toward its own trade
 *   (see {@link absentialis.gameplay.missions.Contracts#generate});
 *
 *   HOW the factions take them on sight to begin with - their own side accepts them, that side's enemies do not.
 *
 * Keys are the faction keys the whole game uses: military, raiders (the Bandits), survivors (the Loners), mercenaries.
 */
public final class Alliance {
    private Alliance() {}

    public record Def(String key, String name, String motto, String blurb, String work, int colour) {}

    public static final Def[] ALL = {
            new Def("military", "Military", "Hold the line.",
                    "The cordon garrison: checkpoints, patrols and the airfield. Disciplined, well supplied and answerable for every round. Bandits shoot at you on sight; the cordon lets you through.",
                    "Reconnaissance, intelligence recovery, bounties on bandits, clearing the infected off the approaches.", 0xFF5E7448),
            new Def("raiders", "Bandits", "Take what is there.",
                    "The crews of the rail yards and the gaol. Nobody gives you anything, so you take it. The military and the loners shoot first; the roads pay toll to your friends.",
                    "Hits on patrols and contractors, fuel and powder runs, getting loads out past the cordon.", 0xFF7E4A3C),
            new Def("survivors", "Loners", "Get everyone through.",
                    "The people who never left: families in cellars, scavengers, the odd doctor. Poor, careful and hard to find. Few enemies but the bandits - and nobody coming to help.",
                    "Supply runs for food and medicine, thinning the infected near the shelters, courier work.", 0xFF8A7A52),
            new Def("mercenaries", "Mercenaries", "Everything has a price.",
                    "Contractors guarding somebody's assets downtown and at the laboratory. The best kit in the Zone and no loyalty beyond the invoice. Bandits hate you; everyone else pays.",
                    "Paid eliminations, asset recovery, survey work. The pay is better and the standing it earns is thinner.", 0xFF5A6470)};

    public static Def def(String key) { for (Def d : ALL) if (d.key().equals(key)) return d; return null; }
    public static boolean chosen(Profile p) { return def(p.alliance) != null; }
    public static String name(String key) { Def d = def(key); return d == null ? "Unaligned" : d.name(); }

    /** The districts whose headquarters belong to a faction (the Bandits hold two). */
    public static java.util.List<District> homes(String key) {
        java.util.List<District> l = new java.util.ArrayList<>();
        for (District d : District.CITY) if (d.def.homeOf(key)) l.add(d);
        return l;
    }

    /** Why the player may deploy into a district, or null when they may not. A profile that has not chosen yet may go anywhere. */
    public static String deployReason(Profile p, District d) {
        if (!chosen(p)) return "unaligned";
        if (d.def.homeOf(p.alliance)) return name(p.alliance) + " headquarters";
        if (p.alliance.equals(p.zone.controller(d))) return "taken by the " + name(p.alliance);
        RivalryState s = p.rivalry;
        for (RivalryState.Treaty t : s.treaties.values()) {
            if (!t.active() || !"alliance".equals(t.kind)) continue;
            RivalryState.Group g = s.group(t.groupId);
            if (g != null && g.active && g.territoryIds.contains(d.name())) return "ground of your allies, " + g.name;
        }
        return null;
    }

    public static boolean mayDeploy(Profile p, District d) { return deployReason(p, d) != null; }

    /** What it would take to open a district the player cannot deploy into yet. */
    public static String howToOpen(Profile p, District d) {
        String holder = p.zone.controller(d);
        return "Held by " + (holder == null ? "nobody" : name(holder)) + ". Deploy here once the " + name(p.alliance) + " control it, or once a group that holds it signs an alliance with you.";
    }

    /**
     * Makes the choice. Standing with the chosen faction rises to where its people accept the player on sight, the
     * factions at war with it turn cold, and the faction's own groups start from a first impression in the player's
     * favor - an impression only: each group's favor is its own from then on.
     */
    public static void choose(Profile p, String key) {
        Def d = def(key);
        if (d == null) return;
        p.alliance = key;
        p.rep.put(key, Math.max(p.rep(key), 45f));
        for (String f : absentialis.sim.ZoneState.FACTIONS) {
            if (f.equals(key)) continue;
            boolean war = pair(key, f, "military", "raiders") || pair(key, f, "survivors", "raiders") || pair(key, f, "raiders", "mercenaries");
            if (war) p.rep.put(f, Math.min(p.rep(f), -30f));
        }
        RivalryEngine e = RivalryWorld.engine(p);
        String rf = Doctrine.ofGameKey(key);
        float share = Doctrine.world("firstImpressionShare", 0.25f);
        for (RivalryState.Group g : e.s.active()) {
            if (g.faction.equals(rf)) { g.playerRelation.favor = Math.max(g.playerRelation.favor, 100 * share); g.playerRelation.trust = Math.max(g.playerRelation.trust, 60 * share); }
            else if (pair(key, Doctrine.gameKey(g.faction), "military", "raiders") || pair(key, Doctrine.gameKey(g.faction), "survivors", "raiders") || pair(key, Doctrine.gameKey(g.faction), "raiders", "mercenaries")) {
                g.playerRelation.favor = Math.min(g.playerRelation.favor, -100 * share); g.playerRelation.hostility = Math.max(g.playerRelation.hostility, 30);
            }
        }
        if (rf != null) e.s.factionReputation.put(rf, Math.max(e.s.factionReputation.getOrDefault(rf, 0f), 25f));
        p.contracts.board.clear();
        p.contracts.refill(p.seed ^ p.stat("raids"), p.prog.rank(), key);
    }

    private static boolean pair(String a, String b, String p, String q) { return a.equals(p) && b.equals(q) || a.equals(q) && b.equals(p); }
}
