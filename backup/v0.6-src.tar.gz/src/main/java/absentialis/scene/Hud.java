package absentialis.scene;

import absentialis.gameplay.items.ItemInstance;
import absentialis.ui.Ui;
import java.util.ArrayList;
import java.util.List;

/**
 * In-raid HUD (addendum P1): minimal and contextual. Health / Stamina / Focus cores appear only
 * when they change; ammo only on fire or reload; the extraction timer sits top-centre and turns
 * amber at 10:00 and red at 3:00; hit feedback is directional with optional (scaled) shake;
 * captions describe sounds with a direction tag.
 */
public final class Hud {
    private final Ctx c;
    public float ammoShown = -99;
    private final List<Object[]> captions = new ArrayList<>(); // {text, until, color}
    private final List<Object[]> messages = new ArrayList<>();
    private float coreAlphaH, coreAlphaS, coreAlphaF, ammoAlpha;

    public Hud(Ctx c) { this.c = c; }

    public void message(String s, int col, float now) {
        messages.add(new Object[]{s, now + 5f, col});
        while (messages.size() > 5) messages.remove(0);
    }

    public void caption(String category, float bearingDeg, float loud, float now) {
        if (!c.settings.subtitles) return;
        String name = switch (category) {
            case "shot" -> "Gunfire"; case "shot_suppressed" -> "Suppressed shots"; case "explosion" -> "Explosion"; case "glass_break" -> "Glass breaking";
            case "groan" -> "Infected groan"; case "screech" -> "SCREECHER ALARM"; case "gurgle" -> "Fat infected swelling"; case "roar" -> "GIANT ROAR";
            case "shriek" -> "Fast infected shriek"; case "retch" -> "Fat infected retching"; case "splash" -> "Acid splash"; case "stomp" -> "Heavy footfalls";
            case "shout" -> "Shouting"; case "whistle" -> "Whistle"; case "radio_chatter" -> "Radio chatter";
            case "door_open", "door_close" -> "Door"; case "reload" -> "Reloading"; case "flare" -> "Flare"; case "alarm_clock" -> "Alarm clock ringing";
            case "impact" -> "Bullet impacts"; case "debris" -> "Debris"; case "melee" -> "Struggle"; case "search" -> "Rummaging"; case "bounce" -> "Clatter";
            default -> null;
        };
        if (name == null) return;
        String dir = bearing(bearingDeg);
        String dist = loud > 0.7f ? "close" : loud > 0.35f ? "near" : "distant";
        String text = "[" + name + " - " + dist + ", " + dir + "]";
        for (Object[] o : captions) if (o[0].equals(text)) { o[1] = now + 3f; return; }
        captions.add(new Object[]{text, now + 3f, category.equals("screech") || category.equals("roar") || category.equals("shriek") || category.equals("retch") || category.equals("stomp") ? Ui.RED : Ui.TXT});
        while (captions.size() > 4) captions.remove(0);
    }

    public static String bearing(float deg) {
        deg = ((deg % 360) + 360) % 360;
        if (deg < 30 || deg > 330) return "ahead";
        if (deg < 150) return deg < 60 ? "front-right" : deg < 120 ? "right" : "behind-right";
        if (deg < 210) return "behind";
        return deg > 300 ? "front-left" : deg > 240 ? "left" : "behind-left";
    }

    public void draw(Raid r, ItemInstance held, float reloadT, float reloadMax, String interact, boolean ads, float dt) {
        Ui ui = c.ui;
        float t = r.time;
        var s = r.body;
        // ---- cores (show on change, fade out after 3.5s)
        coreAlphaH = fade(coreAlphaH, t - s.healthChanged < 3.5f || r.player.hp < 35 || s.bleedLight || s.bleedHeavy, dt);
        coreAlphaS = fade(coreAlphaS, t - s.staminaChanged < 2.5f && s.stamina < 99, dt);
        coreAlphaF = fade(coreAlphaF, t - s.focusChanged < 2.5f && s.focus < 99, dt);
        float bx = ui.s(28), by = ui.h - ui.s(64);
        // health, armour, stamina, focus and ammunition are the status module's (scene.StatusHud, lower right);
        // what stays here are the conditions that need words: wounds, bleeding, hunger, radiation, the infection
        float sy = ui.h - ui.s(40);
        if (s.bleedHeavy || s.bleedLight || s.fracture) { ui.text(s.bleedHeavy ? "HEAVY BLEEDING" : s.bleedLight ? "BLEEDING" : "FRACTURE", bx, sy, 13, Ui.RED); sy -= ui.s(18); }
        if (s.exhausted > 0) { ui.text("WINDED", bx, sy, 13, Ui.AMBER); sy -= ui.s(18); }
        if (s.armInjury > 0.25f) { ui.text("ARM WOUNDED", bx, sy, 13, s.armInjury > 0.6f ? Ui.RED : Ui.AMBER); sy -= ui.s(18); }
        if (s.legInjury > 0.25f) { ui.text("LEG WOUNDED", bx, sy, 13, s.legInjury > 0.6f ? Ui.RED : Ui.AMBER); sy -= ui.s(18); }
        if (s.rad > 5) { ui.text(String.format("RAD %.0f", s.rad), bx, sy, 13, s.rad > 60 ? Ui.RED : Ui.AMBER); sy -= ui.s(18); }
        if (s.energy < 20) { ui.text("HUNGRY", bx, sy, 13, Ui.AMBER); sy -= ui.s(18); }
        if (s.hydration < 20) { ui.text("THIRSTY", bx, sy, 13, Ui.AMBER); sy -= ui.s(18); }
        if (s.infection > 0) {
            // the infection is never hidden: stage, how far along, and whether antibiotics are holding it
            String stage = InfectionSystem.stage(s.infection);
            int col = s.infection >= InfectionSystem.CRITICAL ? Ui.RED : s.infection >= InfectionSystem.FEVER ? 0xFFB8D048 : Ui.AMBER;
            boolean heldBack = t < s.suppressUntil;
            ui.text(stage + (heldBack ? "  (held)" : "") + "   -   Antiviral Medicine cures it", bx, sy, 13, col);
            ui.b.rect(bx, sy + ui.s(17), ui.s(128), ui.s(4), 0xFF1A1C1B);
            ui.b.rect(bx, sy + ui.s(17), ui.s(128) * Math.min(1, s.infection / 100f), ui.s(4), col);
        }

        // ---- ammunition is drawn by the status module; the 0.4 box is kept only as a fallback for screens without one
        boolean showAmmo = false;
        ammoAlpha = fade(ammoAlpha, showAmmo, dt);
        if (held != null && ammoAlpha > 0.01f && held.def().weapon != null && !held.def().weapon.melee()) {
            float ax = ui.w - ui.s(250), ay = ui.h - ui.s(78);
            int a = Math.round(ammoAlpha * 255);
            ui.b.rect(ax - ui.s(10), ay - ui.s(6), ui.s(238), ui.s(60), (a * 170 / 255) << 24 | 0x0E0F0E);
            ui.glyph("bullet", ax, ay + ui.s(6), Math.max(2, ui.s(2)), Ui.alpha(0xFFFFFFFF, ammoAlpha));
            String rounds = String.valueOf(held.loadedRounds());
            ui.text(rounds, ax + ui.s(34), ay, 30, Ui.alpha(held.loadedRounds() == 0 ? Ui.RED : Ui.TXT_HI, ammoAlpha));
            ui.text(held.fireModeName().toUpperCase(), ax + ui.s(110), ay + ui.s(4), 13, Ui.alpha(Ui.TXT_DIM, ammoAlpha));
            ui.text(held.def().name, ax + ui.s(110), ay + ui.s(22), 12, Ui.alpha(Ui.TXT, ammoAlpha));
            float cond = held.condition() / 100f;
            ui.b.rect(ax + ui.s(34), ay + ui.s(40), ui.s(180) * cond, ui.s(3), Ui.alpha(cond < 0.25f ? Ui.RED : cond < 0.5f ? Ui.AMBER : Ui.GREEN, ammoAlpha));
            if (held.jammed) ui.text("JAMMED - [R] CLEAR", ax, ay - ui.s(24), 15, Ui.RED);
            if (reloadT > 0) {
                float f = 1 - reloadT / Math.max(0.01f, reloadMax);
                ui.b.rect(ax + ui.s(34), ay - ui.s(8), ui.s(180), ui.s(4), 0x80000000);
                ui.b.rect(ax + ui.s(34), ay - ui.s(8), ui.s(180) * f, ui.s(4), 0xFFE2A034);
            }
        }

        // ---- extraction timer (top-centre)
        float rem = r.remaining();
        int col = rem <= 180 ? Ui.RED : rem <= 600 ? Ui.AMBER : Ui.TXT_HI;
        String ts = rem > 0 ? String.format("%02d:%02d", (int) rem / 60, (int) rem % 60) : String.format("CORDON +%02d:%02d", (int) -rem / 60, (int) -rem % 60);
        float tw = ui.tw(ts, 24);
        float pulse = rem <= 180 ? 0.6f + 0.4f * (float) Math.abs(Math.sin(t * 3)) : 1;
        ui.b.rect(ui.w / 2f - tw / 2 - ui.s(16), ui.s(10), tw + ui.s(32), ui.s(38), 0xA00E0F0E);
        ui.b.rect(ui.w / 2f - tw / 2 - ui.s(16), ui.s(46), tw + ui.s(32), ui.s(2), Ui.alpha(col, pulse));
        ui.textC(ts, ui.w / 2f, ui.s(15), 24, Ui.alpha(col, pulse));
        if (rem <= 600) ui.textC(rem <= 0 ? "ORDINARY EXITS CLOSED" : "EXTRACTION WINDOW CLOSING", ui.w / 2f, ui.s(52), 11, Ui.alpha(col, pulse));

        // ---- extraction progress
        if (r.extracting != null) {
            float f = r.extractProgress / 8f;
            float w = ui.s(320);
            ui.b.rect(ui.w / 2f - w / 2, ui.h * 0.62f, w, ui.s(10), 0xA0000000);
            ui.b.rect(ui.w / 2f - w / 2, ui.h * 0.62f, w * f, ui.s(10), 0xFF7DBA5C);
            ui.textC("EXTRACTING - " + r.extracting.exit.name.toUpperCase() + String.format("  %.0fs", Math.max(0, 8 - r.extractProgress)), ui.w / 2f, ui.h * 0.62f - ui.s(22), 15, Ui.GREEN);
        } else {
            Raid.ExitState here = r.exitAt(r.player.x, r.player.y, r.player.z);
            if (here != null) ui.textC(here.exit.name.toUpperCase() + " - " + here.requirement, ui.w / 2f, ui.h * 0.62f - ui.s(22), 14, Ui.RED);
        }

        // ---- directional hit feedback
        if (c.settings.hitDirection) for (float[] hm : r.hitMarkers) {
            float age = t - hm[1];
            float rel = hm[0] - r.player.yaw;
            float a = Math.max(0, 1 - age / 1.6f);
            float cx = ui.w / 2f, cy = ui.h / 2f, rad = ui.s(120);
            float R = (float) -Math.sin(rel), F = (float) Math.cos(rel); // attacker in player-local right/forward
            float px = cx + R * rad, py = cy - F * rad, tx = F, ty = R;  // arc tangent on screen
            ui.b.line(px - tx * ui.s(26), py - ty * ui.s(26), px + tx * ui.s(26), py + ty * ui.s(26), ui.s(5), Ui.alpha(0xFFD8483A, a));
        }
        if (r.player.hp < 30) ui.b.rect(0, 0, ui.w, ui.h, Ui.alpha(0x60800000, (30 - r.player.hp) / 30f * (0.6f + 0.4f * (float) Math.sin(t * 4))));

        // ---- crosshair (minimal dot, hidden while aiming)
        if (!ads && interact == null) ui.b.rect(ui.w / 2f - 1, ui.h / 2f - 1, 2, 2, 0xC0FFFFFF);
        if (interact != null) {
            ui.b.rect(ui.w / 2f - 2, ui.h / 2f - 2, 4, 4, 0xFFE2A034);
            ui.textC(interact, ui.w / 2f, ui.h / 2f + ui.s(18), 15, Ui.TXT_HI);
        }

        // ---- captions & messages
        float cy = ui.h - ui.s(150);
        for (int i = captions.size() - 1; i >= 0; i--) {
            Object[] o = captions.get(i);
            float left = (Float) o[1] - t;
            if (left <= 0) { captions.remove(i); continue; }
            String txt = (String) o[0];
            float w = ui.tw(txt, 15);
            ui.b.rect(ui.w / 2f - w / 2 - ui.s(8), cy - ui.s(3), w + ui.s(16), ui.s(22), Ui.alpha(0xB0000000, Math.min(1, left)));
            ui.textC(txt, ui.w / 2f, cy, 15, Ui.alpha((Integer) o[2], Math.min(1, left)));
            cy -= ui.s(26);
        }
        float my = ui.s(70);
        for (int i = messages.size() - 1; i >= 0; i--) {
            Object[] o = messages.get(i);
            float left = (Float) o[1] - t;
            if (left <= 0) { messages.remove(i); continue; }
            ui.text((String) o[0], ui.s(24), my, 14, Ui.alpha((Integer) o[2], Math.min(1, left)));
            my += ui.s(20);
        }
    }

    private static float fade(float a, boolean on, float dt) { return a + ((on ? 1 : 0) - a) * Math.min(1, dt / (on ? 0.12f : 0.6f)); }

    /** A core: glyph + 10 depleting pixel cells (deplete, not bars). */
    private void core(Ui ui, String glyph, float x, float y, float f, int col, float alpha, String status) {
        if (alpha < 0.01f) return;
        int g = Math.max(2, ui.s(2));
        ui.b.rect(x - ui.s(6), y - ui.s(6), ui.s(140), ui.s(38), Ui.alpha(0x900E0F0E, alpha));
        ui.glyph(glyph, x, y, g, Ui.alpha(0xFFFFFFFF, alpha));
        float cx = x + 12 * g + ui.s(8), cw = ui.s(8), gap = ui.s(2);
        for (int i = 0; i < 10; i++) {
            float fill = Math.max(0, Math.min(1, f * 10 - i));
            float px = cx + i * (cw + gap);
            ui.b.rect(px, y + ui.s(2), cw, ui.s(20), Ui.alpha(0xFF1A1C1B, alpha));
            if (fill > 0) {
                float h = ui.s(20) * fill;
                ui.b.rect(px, y + ui.s(2) + ui.s(20) - h, cw, h, Ui.alpha(col, alpha));
                ui.b.rect(px, y + ui.s(2) + ui.s(20) - h, cw, 1, Ui.alpha(0x60FFFFFF, alpha));
            }
        }
        if (status != null) ui.text(status, x, y - ui.s(20), 12, Ui.alpha(Ui.RED, alpha));
    }
}
