package absentialis.scene;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;

import absentialis.character.Animator;
import absentialis.character.Anims;
import absentialis.character.Pose;
import absentialis.character.Rig;
import absentialis.engine.Input;
import absentialis.engine.math.Mat4;
import absentialis.engine.render.WorldRenderer;
import absentialis.engine.voxel.VoxModel;
import absentialis.entity.Actor;
import absentialis.entity.Physics;
import absentialis.gameplay.inventory.Container;
import absentialis.gameplay.inventory.InventoryService;
import absentialis.gameplay.inventory.Loadout;
import absentialis.gameplay.items.ItemDef;
import absentialis.gameplay.items.ItemInstance;
import absentialis.gameplay.weapons.Gunsmith;
import absentialis.gameplay.weapons.WeaponService;
import absentialis.ui.InventoryUi;
import absentialis.ui.ItemModels;
import absentialis.ui.Ui;
import absentialis.world.Block;
import absentialis.world.District;
import absentialis.world.World;
import java.util.ArrayList;
import java.util.List;

/**
 * The raid as the player experiences it: input -> player body and weapon, camera, world and
 * model rendering, HUD and the in-raid overlays (inventory split view, weapon wheel, map,
 * pause). Simulation authority stays in {@link Raid}.
 */
public final class RaidScreen {
    private final Ctx c;
    public final Raid raid;
    private final Hud hud;
    private final WeaponWheel wheel;
    private final LoadoutPanel panel;
    private String heldSlot = "primary";
    // camera & feel
    private float bobAmt, lean, adsT, recoilPitch, recoilYaw, kick, switchT, shake, swayX, swayY, landDip, lastStepPhase, extractTick, stepGate;
    private ActorRenderer.Look playerLook;
    private final float[] eye = new float[3];
    private final Pose vmPose = new Pose(), vmBase = new Pose();
    /** Floor lookup for foot placement: the top of the first walkable block around the given height. */
    private final Animator.Ground ground = this::groundTop;

    private float groundTop(float x, float z, float y) {
        int ix = (int) Math.floor(x), iz = (int) Math.floor(z);
        for (int by = (int) Math.floor(y + 1.2f); by >= (int) Math.floor(y - 1.3f); by--) if (raid.world.solid(ix, by, iz) && !raid.world.solid(ix, by + 1, iz)) return by + 1;
        return Float.NaN;
    }
    public boolean thirdPerson;
    private final Mat4 proj = new Mat4(), view = new Mat4(), pv = new Mat4(), tmp = new Mat4();
    private float eyeX, eyeY, eyeZ, tpsDistance = 3.2f;
    // weapon timers
    private float fireTimer, reloadT, reloadMax, cycleT, lastShot = -9, lastRTime = -9, meleeT;
    private int shotIndex, burstLeft;
    private String reloadKind;
    private ItemInstance reloadMag;
    private boolean crouchToggle;
    // overlays
    public boolean invOpen, mapOpen, paused, done;
    private Container lootSide;
    private String lootTitle = "";
    private float inspectYaw, inspectPitch = 0.4f, mapZoom = 1;
    private final WorldRenderer.Env env = new WorldRenderer.Env();
    private absentialis.engine.audio.AudioEngine.Voice ambienceVoice;
    private String ambienceName;

    /** The 0.5 status interface: character module, squad column, killfeed, hit marker, speech bubbles. */
    public final StatusHud status;

    public RaidScreen(Ctx c, Raid raid) {
        this.c = c;
        this.raid = raid;
        hud = new Hud(c);
        status = new StatusHud(c, raid);
        xpFeed = new XpFeed(raid);
        wheel = new WeaponWheel(c);
        panel = new LoadoutPanel(c);
        panel.raid = raid;
        raid.listener = new Raid.Listener() {
            public void message(String text, int color) { hud.message(text, color, raid.time); }
            public void caption(String cat, float x, float z, float loud) {
                float ang = (float) Math.atan2(-(x - raid.player.x), -(z - raid.player.z)) - raid.player.yaw;
                hud.caption(cat, (float) Math.toDegrees(-ang), loud, raid.time);
                // gunfire the layered system rendered from its ShotFired event is not played a second time as a one-shot
                if (cat.startsWith("shot") && raid.time == gunHeardAt) return;
                playWorldSound(cat, x, z, loud);
            }
            public void voice(Actor a, String sample) {
                if (c.audio == null || !c.audio.available) return;
                // every speaker has their own pitch, so a squad sounds like several people
                float pitch = 0.82f + ((a.id * 37) % 40) / 100f + (a.infected() ? -0.2f : 0);
                c.audio.playAt(sample, a.x, a.y + 1.6f, a.z, 0.85f, 70, pitch, absentialis.engine.audio.AudioEngine.VOICE);
            }
            public void footstep(Actor a, String material, float speed) {
                if (c.audio == null || !c.audio.available) return;
                boolean giant = "tank".equals(a.archetype);
                float gain = Math.min(0.55f, 0.16f + speed * 0.06f) * (giant ? 0.3f : 1f) * (a.crouch ? 0.4f : 1f);
                c.audio.playAt(c.audio.step(material), a.x, a.y + 0.1f, a.z, gain, giant ? 60 : 30, (giant ? 0.6f : a.infected() ? 0.85f : 1f) * (0.92f + raid.rng.nextFloat() * 0.16f));
            }
        };
        acoustics = new WorldAcoustics(raid.world);
        raid.bus.on(absentialis.engine.events.Events.ShotFired.class, this::gunShot);
        if (c.audio != null) c.audio.guns.forget();
        raid.weaponMastery = (w, xp) -> c.profile.prog.addMastery(w, xp);
        raid.deathCam = 3.6f;    // the body ragdolls in the world ...
        raid.deathHold = true;   // ... and the raid waits there until the player chooses what happens next
        raid.gore.detail(c.settings.goreDetail);
        if (c.profile.loadout.slot("primary") == null) heldSlot = c.profile.loadout.slot("sidearm") != null ? "sidearm" : "melee";
        c.win.setCursorLocked(true);
        raid.player.weapon = held();
        if (raid.player.anim == null) raid.player.anim = new Animator();
        raid.player.anim.play("equip", 0.45f);
        if (held() != null) c.sfx(equipSound(held()), 0.5f);
        hud.message("Deployed at " + raid.insertion.name + " (" + raid.debrief.deployedIn.display + "). Find an exit before the window closes.", Ui.AMBER, 0);
        hud.message("[I] inventory  [Tab] weapon wheel  [M] map  [F] interact  [V] view  [~] console", Ui.TXT_DIM, 0);
    }

    private WorldAcoustics acoustics;
    /** Raid time of the last shot the gun bus rendered, and whether the player's last round was one of them. */
    private float gunHeardAt = -1, roomT;
    private boolean gunLocal;

    /** Level of the one-shot a weapon without a recorded profile fires (the crossbow): one number, used by the game and its gate. */
    public static float fallbackShotGain(absentialis.gameplay.items.ItemDef.Weapon w) { return "special".equals(w.family) ? 0.8f : 0.9f; }

    /** Every round fired in the raid - the player's and everyone else's - becomes a shot event on the gun bus. */
    private void gunShot(absentialis.engine.events.Events.ShotFired e) {
        if (c.audio == null || !c.audio.available) return;
        boolean local = e.shooterId() == raid.player.id;
        if (local) gunLocal = false;
        var a = c.audio;
        // the listener is where the camera's owner stands: the engine's copy is a frame old at most
        var ev = a.guns.shot(acoustics, e.weaponId(), e.shooterId(), e.rpm(), e.x(), e.y(), e.z(), e.dirX(), e.dirZ(), e.suppressed(), local, raid.player.x, raid.player.eyeY(), raid.player.z, raid.player.yaw);
        gunHeardAt = ev == null ? -1 : raid.time;
        if (ev == null) return;
        if (local) gunLocal = true;
    }

    private void playWorldSound(String cat, float x, float z, float loud) {
        if (c.audio == null || !c.audio.available) return;
        String s = switch (cat) {
            case "shot" -> loud < 0.3f ? "shot_distant" : "shot_rifle"; case "shot_suppressed" -> "shot_suppressed"; case "explosion" -> loud < 0.3f ? "explosion_far" : "explosion";
            case "bolt_release" -> "crossbow_shot"; case "glass_tinkle" -> "glass_tinkle";
            case "glass_break" -> "glass_break"; case "groan" -> "groan"; case "screech" -> "screech"; case "shriek" -> "shriek"; case "gurgle" -> "gurgle"; case "retch" -> "retch"; case "roar" -> "roar";
            case "splash" -> "splash"; case "stomp" -> "stomp"; case "shout" -> "shout"; case "whistle" -> "whistle"; case "radio_chatter" -> "radio"; case "search" -> "search";
            case "door_open" -> "door_open"; case "door_close" -> "door_close"; case "door_locked" -> "door_locked"; case "door_kick" -> "door_kick"; case "door_break" -> "door_break"; case "impact" -> "impact_concrete"; case "melee" -> "melee_hit"; case "alarm_clock" -> "beep";
            case "flare" -> "flare"; case "reload" -> "mag_in"; case "bounce" -> "bounce"; case "debris" -> "impact_wood";
            case "bite" -> "bite"; case "cough" -> "cough"; case "infected_turn" -> "infected_turn"; case "antiviral" -> "antiviral"; case "gore" -> "flesh_tear";
            case "slip" -> "slip"; case "fire_burst" -> "fire_burst"; case "flashbang" -> "explosion"; case "pin" -> "pin"; case "geiger" -> "geiger"; case "radio" -> "radio";
            case "bone" -> "bone_snap"; case "body_fall" -> "body_fall"; case "stagger" -> "stagger"; case "bullet_snap" -> "bullet_snap"; case "block" -> "melee_block"; case "grab" -> "grab";
            case "engine_start" -> "engine_start"; case "suspension" -> "suspension"; case "gear_shift" -> "gear_shift";
            case "car_crash" -> "car_crash"; case "car_bump" -> "car_bump"; case "tyre_burst" -> "tyre_burst"; case "car_door" -> "car_door"; case "car_horn" -> "car_horn";
            default -> null;
        };
        boolean voice = cat.equals("shout") || cat.equals("groan") || cat.equals("screech") || cat.equals("shriek") || cat.equals("roar") || cat.equals("retch") || cat.equals("gurgle") || cat.equals("radio_chatter") || cat.equals("whistle");
        if (s != null) c.audio.playAt(s, x, raid.player.y + 1, z, 0.9f, 300, voice ? 0.94f + raid.rng.nextFloat() * 0.12f : 1, voice ? absentialis.engine.audio.AudioEngine.VOICE : absentialis.engine.audio.AudioEngine.SFX);
    }

    private ItemInstance held() { return c.profile.loadout.slot(heldSlot); }
    private Loadout lo() { return c.profile.loadout; }
    /** Scripted visual verification: opens the barter panel with the nearest living person, brought to arm's length. */
    public void debugBarter() {
        Actor best = null;
        for (Actor a : raid.actors) if (!a.isPlayer && !a.dead && !a.infected() && !a.mate() && a.ragdoll == null && (best == null || a.dist(raid.player) < best.dist(raid.player))) best = a;
        if (best == null) return;
        best.hostileToPlayer = false;
        best.x = raid.player.x - (float) Math.sin(raid.player.yaw) * 1.6f; best.z = raid.player.z - (float) Math.cos(raid.player.yaw) * 1.6f; best.y = raid.player.y;
        trade.open(raid, lo(), best);
    }

    /** Barter with the people you meet, and passing kit to and from the squad (0.6). */
    public final BarterPanel trade = new BarterPanel();

    private boolean overlay() { return invOpen || mapOpen || paused || c.console.open || trade.open; }

    // ================================================================== update
    public void update(float dt) {
        Input in = c.in;
        if (raid.debrief.outcome != Raid.Debrief.Outcome.NONE) { done = true; return; }
        boolean consoleWas = c.console.open;
        if (in.keyPressed(GLFW_KEY_GRAVE_ACCENT)) c.console.toggle();
        if (c.console.input(in)) { c.win.setCursorLocked(false); if (!consoleWas) in.typed.clear(); raid.update(dt * 0.0f); return; }
        // overlays
        if (in.keyPressed(GLFW_KEY_ESCAPE)) {
            if (c.inv.drag != null) c.inv.drag = null;
            else if (trade.open) trade.close();
            else if (invOpen) closeInventory();
            else if (mapOpen) mapOpen = false;
            else paused = !paused;
        }
        if (trade.open && (trade.broken() || !paused && (in.pressed("interact") || in.pressed("inventory")))) { trade.close(); return; }
        if (!paused && in.pressed("inventory")) { if (invOpen) closeInventory(); else openInventory(null, ""); }
        if (!paused && !invOpen && in.pressed("map")) mapOpen = !mapOpen;
        boolean wheelKey = in.down("wheel") && !overlay();
        if (wheelKey && !wheel.open) wheel.openWheel();
        if (!wheelKey && wheel.open) { wheel.open = false; commitWheel(); }
        c.win.setCursorLocked(!invOpen && !paused && !mapOpen && !trade.open);
        if (paused) return;
        float simDt = wheel.open ? dt * 0.3f : dt; // SP slow-time while choosing
        boolean alive = !raid.player.dead;
        if (!alive) {
            if (!deathStarted) beginDeath();
            invOpen = false; mapOpen = false; wheel.open = false;
            // any key after the first moments skips ahead to the choice
            if (deadT > 2.2f && deadT < DEATH_MENU_AT && (in.lastKeyPressed >= 0 || in.pressed("fire"))) deadT = DEATH_MENU_AT;
            deadT += dt;
            if (deadT >= DEATH_MENU_AT) c.win.setCursorLocked(false);
        }
        if (wheel.open) wheel.update((float) in.dx, (float) in.dy);
        else if (!invOpen && !mapOpen && !trade.open && alive) look(in);
        boolean inCar = raid.vehicles.inside() || raid.vehicles.busy();
        if (inCar && alive && !invOpen && !mapOpen) { driveControls(in); squadKeys(in); }
        else if (!invOpen && !mapOpen && !trade.open && alive) { controls(in, simDt); squadKeys(in); }
        else { raid.player.vx *= 0.8f; raid.player.vz *= 0.8f; raid.vehicles.keys(false, false, false, false, true); }
        if (alive && !inCar) movePlayer(simDt);
        // the moments an opponent waits for: reloading, treating a wound, the recovery of a missed swing, a slip
        if (alive && (reloadT > 0 || raid.body.using != null || meleeT > 0.25f || raid.slipT > 0)) raid.playerVulnerableUntil = raid.time + 0.25f;
        raid.update(simDt);
        footfalls();
        music(dt);
        weaponTimers(simDt);
        useTimer(simDt);
        // extraction countdown: one tick per second, rising toward departure
        if (raid.extracting != null && raid.extractProgress > 0) {
            if ((int) raid.extractProgress != (int) extractTick) c.sfx("extract_tick", 0.5f, 0.8f + raid.extractProgress * 0.06f);
            extractTick = raid.extractProgress;
        } else extractTick = 0;
        if (invOpen && inspectArmed && c.inv.inspected != null) { inspectYaw += (float) in.dx * 0.01f; inspectPitch = Math.max(-1.2f, Math.min(1.2f, inspectPitch + (float) in.dy * 0.01f)); }
        if (mapOpen) mapZoom = Math.max(0.6f, Math.min(4f, mapZoom * (1 + (float) in.scroll * 0.12f)));
        // audio listener + ambience bed per district
        if (c.audio != null) {
            c.audio.lx = raid.player.x; c.audio.ly = raid.player.eyeY(); c.audio.lz = raid.player.z; c.audio.lyaw = raid.player.yaw;
            // the room the shared reverb models follows the listener, a few times a second
            roomT -= dt;
            if (roomT <= 0) { roomT = 0.2f; c.audio.guns.mixer.environment.listenerRoom(acoustics, raid.player.x, raid.player.eyeY(), raid.player.z); }
            String amb = "amb_" + (raid.player.y < World.GROUND - 3 ? "interior" : raid.profile.zone.weatherRain > 0.5f ? "rain" : ambienceFor(raid.world.district(raid.player.x, raid.player.z)));
            if (!amb.equals(ambienceName)) { if (ambienceVoice != null) ambienceVoice.fadeTo(0, 2); ambienceVoice = c.audio.loop(amb, 0.5f, true); ambienceName = amb; }
        }
    }

    /** At the wheel: the movement keys drive, [Space] is the handbrake, [F] gets out. Weapons stay down. */
    private void driveControls(Input in) {
        boolean ctl = !overlay() && raid.vehicles.driving != null;
        raid.vehicles.keys(ctl && in.down("forward"), ctl && in.down("back"), ctl && in.down("left"), ctl && in.down("right"), ctl && in.down("jump"));
        raid.playerAiming = false;
        adsT = 0;
        if (!ctl) return;
        if (in.pressed("view")) thirdPerson = !thirdPerson;
        if (in.pressed("interact")) { String r = raid.vehicles.exit(); if (r != null) { hud.message(r, Ui.AMBER, raid.time); c.sfx("ui_invalid", 0.4f); } else c.sfx("car_door_open", 0.5f); }
        if (in.pressed("flashlight")) { raid.vehicles.toggleLights(); c.sfx("ui_click", 0.3f); }
        if (in.keyPressed(GLFW_KEY_H)) raid.vehicles.horn();
        if (in.keyPressed(GLFW_KEY_J)) raid.vehicles.toggleSiren();
    }

    private void vehicleHud(Ui ui) {
        raid.vehicles.hud(ui);
        if (c.settings.vehicleDebug) raid.vehicles.debugText(ui);
    }

    private float deadT;
    /** Team the next order goes to: gold (everyone), red or blue. */
    public String squadSel = "gold";

    /** Where the leader is pointing: the first surface under the crosshair, or a spot ahead on the ground. */
    private float[] aimPoint() {
        Actor p = raid.player;
        float dx = (float) (-Math.sin(p.yaw) * Math.cos(p.pitch)), dy = (float) Math.sin(p.pitch), dz = (float) (-Math.cos(p.yaw) * Math.cos(p.pitch));
        int[] hit = Physics.ray(raid.world, eyeX, eyeY, eyeZ, dx, dy, dz, 70, false);
        if (hit != null) return new float[]{hit[0] + 0.5f - dx * 1.2f, hit[2] + 0.5f - dz * 1.2f};
        return new float[]{p.x + dx * 18, p.z + dz * 18};
    }

    /**
     * Squad command keys. [T] picks the team an order goes to (Gold = everyone deployed, Red, Blue). [F1] follow,
     * [F2] hold, [F3] move to the crosshair, [F4] sweep the crosshair. Hold [Left Ctrl] to queue the order
     * instead of issuing it; [F5] is Gold's Initiate, which releases every queued order at once. [F6] moves the
     * squadmate in front of you to the other team.
     */
    private void squadKeys(Input in) {
        if (raid.mates.isEmpty()) return;
        if (in.keyPressed(GLFW_KEY_T)) { squadSel = squadSel.equals("gold") ? "red" : squadSel.equals("red") ? "blue" : "gold"; c.sfx("ui_tab", 0.4f); hud.message("Commanding " + squadSel.toUpperCase() + " team (" + raid.team(squadSel).size() + ")", teamColor(squadSel), raid.time); }
        boolean queue = in.keyDown(GLFW_KEY_LEFT_CONTROL);
        String order = in.keyPressed(GLFW_KEY_F1) ? "follow" : in.keyPressed(GLFW_KEY_F2) ? "hold" : in.keyPressed(GLFW_KEY_F3) ? "move" : in.keyPressed(GLFW_KEY_F4) ? "sweep" : null;
        if (order != null) {
            float[] at = order.equals("move") || order.equals("sweep") ? aimPoint() : new float[]{Float.NaN, Float.NaN};
            int n = raid.squadOrder(squadSel, order, at[0], at[1], queue);
            hud.message(squadSel.toUpperCase() + ": " + order.toUpperCase() + (queue ? " queued - [F5] to initiate" : "") + (n == 0 ? " (nobody on that team)" : ""), teamColor(squadSel), raid.time);
            c.sfx("radio", 0.35f);
            raid.player.anim.play("interact", 0.5f);
        }
        if (in.keyPressed(GLFW_KEY_F5)) { int n = raid.initiate(); if (n == 0) hud.message("Nothing queued. Hold [Ctrl] with an order to queue it.", Ui.TXT_DIM, raid.time); else c.sfx("radio", 0.5f); }
        if (in.keyPressed(GLFW_KEY_F6)) {
            Actor p = raid.player, best = null;
            float fx = (float) -Math.sin(p.yaw), fz = (float) -Math.cos(p.yaw), bc = 0.9f;
            for (Actor m : raid.mates) { float dx = m.x - p.x, dz = m.z - p.z, d = (float) Math.sqrt(dx * dx + dz * dz); if (m.dead || d > 16 || d < 0.1f) continue; float cs = (dx * fx + dz * fz) / d; if (cs > bc) { bc = cs; best = m; } }
            hud.message(best == null ? "Look at a squadmate to move them between Red and Blue" : raid.reassign(best), best == null ? Ui.TXT_DIM : teamColor(best.team), raid.time);
        }
    }

    private static int teamColor(String t) { return t.equals("red") ? SquadPanel.RED_COL : t.equals("blue") ? SquadPanel.BLUE_COL : SquadPanel.GOLD_COL; }

    /** The element at a glance: who is alive, on which team, doing what, and what they have queued. */
    private void drawSquad(Ui ui) {
        if (raid.profile.squad.active().isEmpty()) return;
        float x = ui.s(24), y = ui.h * 0.34f, w = ui.s(216);
        String[] teams = {"gold", "red", "blue"};
        for (int i = 0; i < 3; i++) {
            boolean sel = teams[i].equals(squadSel);
            ui.b.rect(x + i * ui.s(72), y, ui.s(68), ui.s(18), sel ? Ui.alpha(teamColor(teams[i]), 0.85f) : 0x90101010);
            ui.textC(teams[i].toUpperCase() + " " + raid.team(teams[i]).size(), x + i * ui.s(72) + ui.s(34), y + ui.s(2), 11, sel ? 0xFF101010 : teamColor(teams[i]));
        }
        y += ui.s(22);
        for (Actor m : raid.mates) {
            ui.b.rect(x, y, w, ui.s(17), 0x80101010);
            ui.b.rect(x, y, ui.s(4), ui.s(17), teamColor(m.team));
            ui.text(m.name, x + ui.s(9), y + ui.s(1), 11, "engage".equals(m.state) ? Ui.RED : Ui.TXT);
            float hp = Math.max(0, m.hp / m.maxHp);
            ui.b.rect(x + ui.s(82), y + ui.s(6), ui.s(46), ui.s(5), 0xFF1A1C1B);
            ui.b.rect(x + ui.s(82), y + ui.s(6), ui.s(46) * hp, ui.s(5), hp < 0.35f ? Ui.RED : hp < 0.7f ? Ui.AMBER : Ui.GREEN);
            ui.text(("engage".equals(m.state) ? "FIGHTING" : m.sqOrder.toUpperCase()) + (m.qOrder != null ? " > " + m.qOrder.toUpperCase() : ""), x + ui.s(134), y + ui.s(1), 10, m.qOrder != null ? Ui.AMBER : Ui.TXT_DIM);
            y += ui.s(19);
        }
        int down = raid.profile.squad.active().size() - raid.mates.size();
        if (down > 0) { ui.text(down + " down", x + ui.s(9), y, 10, Ui.RED); y += ui.s(15); }
        ui.text("[T] team  [F1] follow  [F2] hold  [F3] move  [F4] sweep", x, y + ui.s(2), 9, Ui.TXT_DIM);
        ui.text("[Ctrl]+order queue  [F5] initiate  [F6] swap team", x, y + ui.s(14), 9, Ui.TXT_DIM);
    }

    private absentialis.engine.audio.AudioEngine.Voice tensionVoice;
    private float tension;

    /** Combat music: fades in while something hostile is actively engaging the player, out again afterwards. */
    private void music(float dt) {
        if (c.audio == null || !c.audio.available) return;
        if (tensionVoice == null) { tensionVoice = c.audio.loop("music_tension", 0f, absentialis.engine.audio.AudioEngine.MUSIC); }
        boolean hot = false;
        for (Actor a : raid.actors) if (!a.isPlayer && !a.dead && "engage".equals(a.state) && a.targetId == raid.player.id && a.distXZ(raid.player.x, raid.player.z) < 70) { hot = true; break; }
        tension += ((hot ? 0.6f : 0f) - tension) * Math.min(1, dt * (hot ? 1.2f : 0.25f));
        tensionVoice.setGain(tension);
    }

    private static String ambienceFor(District d) { return switch (d.ambience) { case "bells" -> "bells"; case "machines" -> "machines"; case "drone" -> "drone"; case "city" -> "city"; default -> "wind"; }; }

    public void stopAudio() {
        if (ambienceVoice != null) ambienceVoice.fadeTo(0, 1);
        if (tensionVoice != null) tensionVoice.fadeTo(0, 1);
        if (deathDrone != null) deathDrone.fadeTo(0, 1.5f);
        raid.fire.clear();
        raid.vehicles.stopAudio();
        if (c.audio != null) c.audio.duckTo(1f, 1f);
    }

    private void look(Input in) {
        Actor p = raid.player;
        float sens = c.settings.sensitivity * 0.01f * (adsT > 0.5f ? 1f / Math.max(1, zoom()) : 1);
        p.yaw -= (float) in.dx * sens;
        p.pitch = Math.max(-1.5f, Math.min(1.5f, p.pitch - (float) in.dy * sens));
    }

    private float zoom() { ItemInstance h = held(); return h == null ? 1 : h.zoom(); }

    private void controls(Input in, float dt) {
        Actor p = raid.player;
        if (in.pressed("view")) thirdPerson = !thirdPerson;
        if (in.pressed("flashlight")) {
            if (raid.lightSource(held()) == 0) { raid.playerFlashlight = false; hud.message("No flashlight: carry one in your case, or fit one to the weapon", Ui.RED, raid.time); }
            else { raid.playerFlashlight = !raid.playerFlashlight; c.sfx("ui_click", 0.35f); }
        }
        boolean down = p.downed();
        // 0.6: the slide. More than two seconds into a sprint, the crouch key drops the body onto its hip and it carries on
        // along the ground: fast, low, and committed to the direction it was going.
        if (in.pressed("crouch") && sprintHeld >= SLIDE_AFTER && p.onGround && p.slideT <= 0 && !down && !raid.noclip) startSlide(p);
        else if (c.settings.toggleCrouch) { if (in.pressed("crouch")) crouchToggle = !crouchToggle; }
        p.crouch = c.settings.toggleCrouch ? crouchToggle : in.down("crouch");
        if (p.slideT > 0) p.crouch = true;
        if (down) { p.crouch = false; crouchToggle = false; }
        if (p.crouch == false && !down && !Physics.boxFree(raid.world, p.x, p.y, p.z, p.radius, p.stand)) p.crouch = true;
        // on the ground only the sidearm can be worked
        if (down && !"sidearm".equals(heldSlot)) { if (lo().slot("sidearm") != null) switchTo("sidearm"); else { heldSlot = "none"; raid.player.weapon = null; } }
        if (!down && "none".equals(heldSlot)) { heldSlot = lo().slot("primary") != null ? "primary" : lo().slot("sidearm") != null ? "sidearm" : "melee"; raid.player.weapon = held(); }
        contextualCover(p, down);
        float tl = in.down("lean_left") ? -1 : in.down("lean_right") ? 1 : 0;
        lean += (tl - lean) * Math.min(1, dt * 10);
        // weapon selection
        if (!down) {
            if (in.pressed("primary")) switchTo("primary");
            if (in.pressed("sidearm")) switchTo("sidearm");
            if (in.pressed("melee")) switchTo("melee");
        }
        for (int k = 0; k < 4; k++) if (in.pressed("quick" + (k + 1))) { ItemInstance[] s = wheel.slots(lo()); if (s[4 + k] != null) useItem(s[4 + k]); }
        if (in.pressed("throw")) { ItemInstance[] s = wheel.slots(lo()); if (s[3] != null) throwIt(s[3]); }
        if (in.pressed("firemode")) { ItemInstance h = held(); if (h != null && h.def().weapon != null && h.def().weapon.modes.size() > 1) { h.fireMode = (h.fireMode + 1) % h.def().weapon.modes.size(); c.sfx("ui_click", 0.4f); hud.message("Fire mode: " + h.fireModeName().toUpperCase(), Ui.TXT, raid.time); } }
        if (in.pressed("reload")) reload();
        // a casualty in reach: holding [F] works on them, letting go leaves them where they are
        Actor patient = down ? null : raid.casualty.playerPatient();
        boolean working = patient != null && in.down("interact") && !p.sprinting;
        raid.casualty.playerRevive(working);
        if (working) { p.crouch = true; adsT = 0; raid.playerVulnerableUntil = raid.time + 0.3f; if (!p.anim.reviving) p.anim.reviving = true; }
        else if (p.anim.reviving && p.revivingId == 0) p.anim.reviving = false;
        if (in.pressed("interact") && patient == null && !down) interact();
        if (in.pressed("jump") && p.onGround && !p.crouch && !down && raid.body.stamina > 5) {
            p.vy = Physics.JUMP; raid.body.stamina -= 4; c.sfx("jump", 0.35f);
            if (p.anim != null && p.anim.action.isEmpty()) p.anim.play("jump", 0.5f);
        }
        // ADS
        boolean aim = c.settings.toggleAim ? (in.pressed("aim") ? adsT < 0.5f : adsT > 0.5f) : in.down("aim");
        ItemInstance h = held();
        boolean canAim = h != null && h.def().weapon != null && !h.def().weapon.melee() && reloadT <= 0 && !p.sprinting;
        float adsSpeed = h != null && h.def().weapon != null && !h.def().weapon.melee() ? 1f / Gunsmith.stats(h, 0).adsTime : 8;
        // ADS progress is linear in the weapon's own ADS time, so the transition takes exactly that long (coming
        // down is a little quicker); what is drawn follows the eased value, what is decided follows the plain one
        float adsTarget = aim && canAim ? 1 : 0, adsStep = dt * adsSpeed;
        adsT = adsT < adsTarget ? Math.min(adsTarget, adsT + adsStep) : Math.max(adsTarget, adsT - adsStep * 1.25f);
        adsK = adsT * adsT * (3 - 2 * adsT);
        raid.playerAiming = adsT > 0.6f;
        int expose = canAim ? Gunsmith.stats(h, 0).expose : 0;
        raid.playerLaser = expose == 1 || expose == 2 && adsT > 0.5f;
        fire(in, dt);
    }

    /**
     * Contextual cover for the player (brief 4.2). Crouched against something low, or pressed to the end of a wall
     * and leaning, the body settles onto the cover point there: it aligns with the surface, and what it does next
     * is real exposure - aiming over low cover stands the body up to shoot and drops it back when the sights come
     * down; a lean is only offered round an end the obstacle actually has.
     */
    private void contextualCover(Actor p, boolean down) {
        absentialis.gameplay.CombatConfig cfg = raid.combat;
        float fx = (float) -Math.sin(p.yaw), fz = (float) -Math.cos(p.yaw);
        float hs = (float) Math.sqrt(p.vx * p.vx + p.vz * p.vz);
        absentialis.world.CoverMap.Point cp = down || p.sprinting || !p.onGround || hs > cfg.coverMaxSpeed ? null : raid.world.cover.touching(p.x, p.y, p.z, fx, fz);
        boolean wantLean = Math.abs(lean) > 0.25f;
        boolean in = cp != null && (crouchHeld() || cp.height == absentialis.world.CoverMap.HIGH && wantLean && (lean < 0 ? cp.leanLeft : cp.leanRight));
        p.cover = in ? cp : null;
        p.coverAmt = in ? 1 : 0;
        if (!in) { p.lean = lean * 0.6f; coverPeek = false; return; }
        // a lean only where the obstacle ends on that side
        float side = lean < -0.25f && cp.leanLeft ? -1 : lean > 0.25f && cp.leanRight ? 1 : 0;
        // "left" is as seen facing the obstacle; the player may be turned, so express it in the body's own frame
        float lx = cp.leftX(), lz = cp.leftZ(), rx = (float) Math.cos(p.yaw), rz = (float) -Math.sin(p.yaw);
        p.lean = side == 0 ? 0 : (-(lx * rx + lz * rz) >= 0 ? 1 : -1) * side;
        // over the top: sights up means standing up, and the head and chest are then really above the cover
        coverPeek = cp.height == absentialis.world.CoverMap.LOW && adsT > 0.35f;
        if (coverPeek) p.crouch = false;
    }

    // ------------------------------------------------------------------ 0.6 movement: sprint, slide, third-person weight
    /** Seconds of sprint before a slide is on offer, how long a slide lasts, what it costs, and how it sheds speed (m/s per second). */
    public static final float SLIDE_AFTER = 2f, SLIDE_TIME = 0.95f, SLIDE_STAMINA = 6f, SLIDE_FRICTION = 5.2f, SLIDE_MIN_SPEED = 6.2f, SLIDE_END_SPEED = 2.4f;
    /** Third person: how quickly the body gathers speed, sheds it and changes direction (per second), and how fast it turns to face (radians per second). */
    public static final float TPS_ACCEL = 8.5f, TPS_DECEL = 7f, TPS_TURN_ACCEL = 10f, TPS_FACE_WALK = 9.5f, TPS_FACE_SPRINT = 6.5f, TPS_FACE_AIM = 14f;
    /** How long the current sprint has lasted, the sprint toggle's state, and the speed of a slide in progress. */
    public float sprintHeld;
    private boolean sprintLatch;
    private float slideSpeed;
    public int slides;

    private void startSlide(Actor p) {
        float hs = (float) Math.sqrt(p.vx * p.vx + p.vz * p.vz);
        if (hs < 3f) return;
        p.slideT = SLIDE_TIME;
        p.slideX = p.vx / hs; p.slideZ = p.vz / hs;
        slideSpeed = Math.max(hs * 1.12f, SLIDE_MIN_SPEED);
        raid.body.stamina = Math.max(0, raid.body.stamina - SLIDE_STAMINA);
        crouchToggle = true;                      // you come out of it on one knee
        sprintHeld = 0; sprintLatch = false;
        adsT = 0;
        slides++;
        c.sfx("slide", 0.5f);
        raid.emitSound(p.x, p.y, p.z, 14, "step", p.id, false);
    }

    /** Whether the light that is on comes from the weapon (else from the hand torch on the chest). */
    private boolean lightOnWeapon;
    /** How hard the last shot kicked (see Animator.kickOf): scales the view model's recoil and how long it lasts. */
    private float firePunch = 1;
    /** Experience shown as it is earned (0.6). */
    public XpFeed xpFeed;
    private boolean coverPeek;
    /** Eased ADS blend for everything visual (view model, field of view); {@link #adsT} stays the authority for rules. */
    private float adsK;
    private final java.util.Map<String, Float> sightCache = new java.util.HashMap<>();

    /**
     * Where this weapon's sight line is, measured from its own model: the highest point over the rear of the
     * receiver (the rear sight, or the optic mounted there). Aiming brings that line onto the view axis, so every
     * weapon - long, short, scoped - aligns by its own geometry instead of sharing one offset.
     */
    private float sightLine(ItemInstance h, VoxModel m, float s) {
        Float got = sightCache.get(h.visualKey());
        if (got != null) return got;
        int top = -1;
        for (int x = (int) (m.sx * 0.12f); x <= (int) (m.sx * 0.5f); x++) for (int z = 0; z < m.sz; z++) for (int y = m.sy - 1; y > top; y--) if (m.get(x, y, z) != 0) { top = y; break; }
        if (top < 0) top = m.sy - 1;
        // irons: the top of the rear sight sits just under the aim point; an optic is looked through, not over
        float v = -((top + 1) - 0.55f * m.sy) * s + (h.zoom() > 1 ? 1.4f * s : -0.003f);
        if (sightCache.size() > 256) sightCache.clear();
        sightCache.put(h.visualKey(), v);
        return v;
    }
    private boolean crouchHeld() { return c.settings.toggleCrouch ? crouchToggle : c.in.down("crouch"); }

    private void movePlayer(float dt) {
        Actor p = raid.player;
        Input in = c.in;
        boolean ctl = !overlay();
        float f = ctl ? (in.down("forward") ? 1 : 0) - (in.down("back") ? 1 : 0) : 0;
        float s = ctl ? (in.down("right") ? 1 : 0) - (in.down("left") ? 1 : 0) : 0;
        boolean moving = f != 0 || s != 0;
        absentialis.gameplay.CombatConfig cfg = raid.combat;
        int cond = cfg.condition(p.hp, p.maxHp).ordinal();
        boolean downed = p.downed();
        // sprint: held, or a toggle that lets go when you stop (Settings). First person runs where it looks; in third
        // person the body is sent by the keys and runs wherever it is sent.
        boolean sprintKey;
        if (c.settings.toggleSprint) { if (ctl && in.pressed("sprint")) sprintLatch = !sprintLatch; if (!moving) sprintLatch = false; sprintKey = sprintLatch; }
        else sprintKey = ctl && in.down("sprint");
        boolean sprintDir = thirdPerson ? moving : f > 0;
        p.sprinting = ctl && sprintKey && sprintDir && !p.crouch && p.slideT <= 0 && adsT < 0.3f && raid.body.canSprint() && cfg.sprint[cond] && !downed && p.revivingId == 0;
        sprintHeld = p.sprinting ? sprintHeld + dt : p.slideT > 0 ? 0 : Math.max(0, sprintHeld - dt * 6);
        ItemInstance h = held();
        boolean gun = h != null && h.def().weapon != null && !h.def().weapon.melee();
        float wMass = h == null || gun ? 0 : h.mass();
        float speed = raid.body.moveSpeed(p, p.sprinting, ctl && in.down("walk"), lo().mass(), c.profile.prog.carryCapacityKg(), wMass);
        if (gun) speed *= Gunsmith.stats(h, 0).mobility;
        speed *= 1 + lo().charm("speed");
        if (adsT > 0.5f) speed *= 0.6f;
        if (raid.body.using != null) speed *= 0.5f;
        if (raid.time < raid.grabUntil) speed *= 0.18f;      // held: you can turn and strike, not run
        // health condition: the limp is in the legs as well as the animation
        speed *= p.sprinting ? cfg.sprintSpeed[cond] : cfg.speed[cond];
        if (downed) speed = Math.min(speed, absentialis.entity.Survivor.WALK / 25f * cfg.crawlSpeed * 0.5f);
        if (p.revivingId != 0) speed = 0;
        if (raid.noclip) {
            float fx = (float) (-Math.sin(p.yaw) * Math.cos(p.pitch)), fy = (float) Math.sin(p.pitch), fz = (float) (-Math.cos(p.yaw) * Math.cos(p.pitch));
            float sp = (in.down("sprint") ? 40 : 14) * dt;
            p.x += (fx * f + (float) Math.cos(p.yaw) * s) * sp; p.y += fy * f * sp + (in.down("jump") ? sp : 0) - (in.down("crouch") ? sp : 0); p.z += (fz * f - (float) Math.sin(p.yaw) * s) * sp;
            p.vx = p.vy = p.vz = 0;
            return;
        }
        float fx = (float) -Math.sin(p.yaw), fz = (float) -Math.cos(p.yaw), rx = (float) Math.cos(p.yaw), rz = (float) -Math.sin(p.yaw);
        float tx = (fx * f + rx * s), tz = (fz * f + rz * s);
        float l = (float) Math.sqrt(tx * tx + tz * tz);
        if (l > 0) { tx = tx / l * speed; tz = tz / l * speed; }
        // wet blood has almost no grip: you keep sliding the way you were going
        // third person has weight: the body gathers speed, sheds it and comes about at different rates, none of them instant
        float ground = 14;
        if (thirdPerson) {
            float cur = (float) Math.sqrt(p.vx * p.vx + p.vz * p.vz), want = (float) Math.sqrt(tx * tx + tz * tz);
            ground = want < 0.1f ? TPS_DECEL : want > cur + 0.15f ? TPS_ACCEL : TPS_TURN_ACCEL;
        }
        float acc = (p.onGround ? ground : 3) * raid.gore.friction(p.x, p.y, p.z) * (raid.slipT > 0 ? 0.12f : 1);
        if (raid.slipT > 0) { landDip = Math.max(landDip, 0.2f); speed *= 0.4f; }
        if (p.slideT > 0) {
            // sliding: the ground takes the speed off; the keys can only nudge the line
            p.slideT -= dt;
            slideSpeed = Math.max(0, slideSpeed - SLIDE_FRICTION * dt);
            if (l > 0) { float nx = p.slideX + tx / Math.max(0.01f, speed) * dt * 1.2f, nz = p.slideZ + tz / Math.max(0.01f, speed) * dt * 1.2f, nl = (float) Math.sqrt(nx * nx + nz * nz); if (nl > 0.01f) { p.slideX = nx / nl; p.slideZ = nz / nl; } }
            p.vx = p.slideX * slideSpeed; p.vz = p.slideZ * slideSpeed;
            raid.playerVulnerableUntil = raid.time + 0.2f;
            if (slideSpeed < SLIDE_END_SPEED || !p.onGround && p.vy < -4) p.slideT = 0;
        } else {
            p.vx += (tx - p.vx) * Math.min(1, dt * acc);
            p.vz += (tz - p.vz) * Math.min(1, dt * acc);
        }
        // forward climbs (or descends when looking down the ladder), back always descends
        p.wantClimb = ctl && f != 0 && Physics.inClimb(raid.world, p.x, p.y, p.z);
        p.climbDir = f < 0 || p.pitch < -0.6f ? -1 : 1;
        boolean hitWall = Physics.move(raid.world, p, dt);
        if (p.slideT > 0 && hitWall) { p.slideT = 0; landDip = Math.max(landDip, 0.08f); }
        // third person: the body turns to face where it is going; aiming, firing, cover and anything done with the hands
        // turn it to face where the player is looking instead
        if (thirdPerson) {
            float hsNow = (float) Math.sqrt(p.vx * p.vx + p.vz * p.vz);
            boolean lock = adsT > 0.05f || raid.time - lastShot < 0.9f || p.cover != null || p.revivingId != 0 || downed || meleeT > 0 || raid.body.using != null || reloadT > 0 && hsNow < 0.5f;
            if (!p.faceSet) { p.faceYaw = p.yaw; p.faceSet = true; }
            float target = lock ? p.yaw : hsNow > 0.5f ? (float) Math.atan2(-p.vx, -p.vz) : p.faceYaw;
            p.faceYaw = absentialis.ai.Brain.turn(p.faceYaw, target, dt * (lock ? TPS_FACE_AIM : p.slideT > 0 ? 3f : p.sprinting ? TPS_FACE_SPRINT : TPS_FACE_WALK));
        } else p.faceSet = false;
        // fall damage
        if (p.onGround && p.fallSpeed > 13) { float dmg = (p.fallSpeed - 13) * 6; raid.damageActor(p, null, dmg, null, "legs", p.x, p.y, p.z); if (dmg > 20) raid.body.fracture = true; hud.message("Hard landing", Ui.RED, raid.time); }
        if (p.onGround && p.fallSpeed > 5) { landDip = Math.min(0.22f, p.fallSpeed * 0.012f); playStep(0.5f + Math.min(0.4f, p.fallSpeed * 0.03f), 0.85f); }
        p.fallSpeed = 0;
        p.stepped = 0;
        landDip = Math.max(0, landDip - dt * 0.9f);
        float hs = (float) Math.sqrt(p.vx * p.vx + p.vz * p.vz);
        bobAmt += ((p.onGround && moving ? Math.min(1, hs / 4f) : 0) - bobAmt) * Math.min(1, dt * 8);
    }

    /** Footstep material under the player: water when wading, otherwise the block's material. */
    private String stepMaterial() {
        Actor p = raid.player;
        Block in = raid.world.block((int) Math.floor(p.x), (int) Math.floor(p.y + 0.2f), (int) Math.floor(p.z));
        if (in != null && in.mat == absentialis.world.Material.WATER) return "water";
        Block under = raid.world.block((int) Math.floor(p.x), (int) Math.floor(p.y - 0.1f), (int) Math.floor(p.z));
        return WorldAcoustics.stepSurface(under);
    }

    private void playStep(float gain, float pitch) {
        String mat = stepMaterial();
        if (c.audio != null && !"none".equals(mat)) c.audio.play(c.audio.step(mat), gain, (raid.rng.nextFloat() - 0.5f) * 0.3f, pitch * (0.92f + raid.rng.nextFloat() * 0.16f));
    }

    /** One footstep per animated footfall (each half gait cycle): what you hear is what the legs do. */
    private void footfalls() {
        Actor p = raid.player;
        Animator an = p.anim;
        if (an == null) return;
        float ph = an.phase;
        boolean crossed = (lastStepPhase < 0.5f) != (ph < 0.5f);
        lastStepPhase = ph;
        stepGate -= c.ui.dt;
        if (!crossed || !p.onGround || an.speed < 0.5f || stepGate > 0 || p.climbing) return;
        stepGate = 0.14f;
        Block under = raid.world.block((int) Math.floor(p.x), (int) Math.floor(p.y - 0.1f), (int) Math.floor(p.z));
        boolean walk = c.in.down("walk");
        float radius = (p.crouch ? 2.5f : p.sprinting ? 20 : walk ? 4 : 9) * (under == null ? 1 : under.mat.noiseMul) * (1 + lo().charm("noise")) * (1 + Math.max(0, lo().mass() - c.profile.prog.carryCapacityKg()) * 0.02f);
        raid.emitSound(p.x, p.y, p.z, radius, "step", p.id, false);
        playStep(p.crouch ? 0.15f : p.sprinting ? 0.5f : walk ? 0.2f : 0.32f, 1f);
        // loose kit rattles when you run with a heavy pack
        if (p.sprinting && lo().mass() > 14 && raid.rng.chance(0.5)) c.sfx("gear_rattle", 0.12f);
    }

    // ------------------------------------------------------------------ weapons
    private void switchTo(String slot) {
        if (slot.equals(heldSlot) || lo().slot(slot) == null) return;
        heldSlot = slot;
        cancelReload();
        switchT = 0.45f;
        adsT = 0;
        c.sfx(equipSound(held()), 0.5f);
        raid.player.weapon = held();
        raid.player.anim.play("equip", 0.45f);
    }

    private static String equipSound(ItemInstance w) {
        if (w == null || w.def().weapon == null) return "zipper";
        return w.def().weapon.melee() ? "equip_melee" : "sidearm".equals(w.def().slot) ? "equip_pistol" : "equip_rifle";
    }

    private void cancelReload() {
        if (reloadT > 0 && raid.player.anim != null && raid.player.anim.action.startsWith("reload")) raid.player.anim.action = "";
        reloadT = 0; reloadKind = null; reloadMag = null;
    }

    private boolean reloadEmpty;
    private int reloadCue;
    private float stfT;

    /** Reload foley keyed to the animation: tactical and empty reloads sound as different as they look. */
    private void reloadFoley(float t) {
        if (reloadKind == null) return;
        float[] at; String[] snd;
        switch (reloadKind) {
            case "jam", "rack" -> { at = new float[]{0.42f, 0.60f}; snd = new String[]{"bolt_back", "bolt_release"}; }
            case "internal" -> { at = new float[]{0.80f}; snd = new String[]{"shell_in"}; }
            case "pumpfull" -> { at = new float[]{0.28f}; snd = new String[]{"pump"}; }
            default -> {
                if (reloadEmpty) { at = new float[]{0.16f, 0.26f, 0.64f, 0.80f, 0.88f}; snd = new String[]{"mag_out", "mag_drop", "mag_in", "bolt_back", "bolt_release"}; }
                else { at = new float[]{0.20f, 0.50f, 0.82f}; snd = new String[]{"mag_out", "pouch", "mag_in"}; }
            }
        }
        // each cue is a recorded handling sound of the weapon's family where one exists
        ItemInstance h = held();
        String fam = h == null || h.def().weapon == null ? "rifle" : handlingFamily(h.def().weapon);
        while (reloadCue < at.length && t >= at[reloadCue]) {
            String rec = c.audio == null ? null : c.audio.guns.cue(fam, snd[reloadCue]);
            if (rec != null) c.sfx("h_" + rec, 0.75f, 0.96f + raid.rng.nextFloat() * 0.08f); else c.sfx(snd[reloadCue], 0.6f);
            reloadCue++;
        }
    }

    private static String handlingFamily(ItemDef.Weapon w) {
        String f = w.family == null ? "" : w.family;
        return f.contains("pistol") || f.contains("handgun") || f.contains("sidearm") || f.contains("revolver") || f.contains("magnum") ? "pistol" : f.contains("shotgun") ? "shotgun" : "rifle";
    }

    private void fire(Input in, float dt) {
        ItemInstance h = held();
        raid.player.weapon = h;
        if (h == null || switchT > 0 || raid.body.using != null) return;
        if (raid.player.revivingId != 0 || raid.player.downed() && !"sidearm".equals(heldSlot)) return;
        ItemDef.Weapon w = h.def().weapon;
        if (w == null) return;
        boolean press = in.pressed("fire"), down = in.down("fire");
        if (w.melee()) { if (press && meleeT <= 0) melee(h); return; }
        if (reloadT > 0) {
            if (press && "internal".equals(reloadKind)) cancelReload(); // interrupt shell-by-shell loading
            return;
        }
        // sprint-to-fire: the weapon is down while you run and takes a moment to come back up
        if (raid.player.sprinting) { stfT = Gunsmith.stats(h, 0).sprintToFire; return; }
        if (stfT > 0) return;
        String mode = h.fireModeName();
        boolean want = switch (mode) { case "auto" -> down; case "burst" -> press || burstLeft > 0; default -> press; };
        if (!want || fireTimer > 0 || cycleT > 0) return;
        if (h.jammed) { if (press) { c.sfx("jam", 0.6f); hud.message("Weapon jammed - press [R] to clear", Ui.RED, raid.time); } burstLeft = 0; return; }
        if (!WeaponService.canFire(h)) {
            if (press) { c.sfx("dry_fire", 0.6f); hud.ammoShown = raid.time; }
            burstLeft = 0;
            return;
        }
        Gunsmith.Stats st = Gunsmith.stats(h, lo().charm("wear"));
        ItemDef ammo = WeaponService.fire(h, st, raid.environmentWear(), raid.rng);
        if (ammo == null) return;
        if (lo().charm("infinite_ammo") > 0) { h.rounds++; h.ammoId = ammo.id; }   // Cat Ears
        if ("burst".equals(mode)) burstLeft = burstLeft > 0 ? burstLeft - 1 : 2;
        Actor p = raid.player;
        float pitch = p.pitch + recoilPitch, yaw = p.yaw + recoilYaw;
        float dx = (float) (-Math.sin(yaw) * Math.cos(pitch)), dy = (float) Math.sin(pitch), dz = (float) (-Math.cos(yaw) * Math.cos(pitch));
        if (camThird && !p.dead) {
            // third person: the camera is over the shoulder, the muzzle is not. Find what the crosshair is on - the first
            // thing the camera's line meets beyond the body - and send the round from the head to that point.
            float s0 = tpsDistance * 0.9f + 0.4f, sx = camPX + dx * s0, sy = camPY + dy * s0, sz = camPZ + dz * s0, t = 240;
            int[] hb = Physics.ray(raid.world, sx, sy, sz, dx, dy, dz, t, false);
            if (hb != null) { float bx = hb[0] + 0.5f - sx, by = hb[1] + 0.5f - sy, bz = hb[2] + 0.5f - sz; t = Math.max(0.5f, (float) Math.sqrt(bx * bx + by * by + bz * bz) - 0.5f); }
            for (Actor a : raid.actors) { if (a.isPlayer || a.dead || Math.abs(a.x - p.x) > 250 || Math.abs(a.z - p.z) > 250) continue; float ta = a.intersect(sx, sy, sz, dx, dy, dz, t); if (ta >= 0 && ta < t) t = ta; }
            t = Math.max(t, 3f);
            float ax = sx + dx * t - eyeX, ay = sy + dy * t - eyeY, az = sz + dz * t - eyeZ, al = (float) Math.sqrt(ax * ax + ay * ay + az * az);
            if (al > 0.5f) { dx = ax / al; dy = ay / al; dz = az / al; }
        }
        boolean moving = Math.abs(p.vx) + Math.abs(p.vz) > 0.5f;
        float spread = st.dispersion * (0.35f + (1 - adsT) * 1.6f * st.hipMul) * (moving ? 1 + 0.6f / (adsT > 0.5f ? st.steady : 1) : 1) * (p.crouch ? 0.8f : 1) * (p.onGround ? 1 : 2.5f);
        // a hurt body holds a weapon worse; from the ground, worse again
        spread *= raid.combat.aimError[raid.combat.condition(p.hp, p.maxHp).ordinal()] * (p.downed() ? raid.combat.sidearmError : 1);
        if (p.cover != null && !coverPeek && Math.abs(p.lean) < 0.2f) spread *= 0.9f;      // braced on the cover
        raid.fireProjectiles(p, h, ammo, eyeX + dx * 0.4f, eyeY + dy * 0.4f, eyeZ + dz * 0.4f, dx, dy, dz, spread);
        raid.shotSignature(p, h, st, p.x, p.eyeY(), p.z);
        // recoil: per-platform pattern scaled by focus (recoil control) and ADS
        if (raid.time - lastShot > Gunsmith.recoveryTime(st) + 0.1f) shotIndex = 0;
        float[] k = Gunsmith.recoilKick(h.def(), shotIndex++);
        float mul = raid.body.recoilMul() * (adsT > 0.5f ? 0.75f : 1f) * (p.crouch ? 0.85f : 1f);
        p.pitch = Math.min(1.5f, p.pitch + (float) Math.toRadians(k[0] * 0.55f * mul));
        p.yaw -= (float) Math.toRadians(k[1] * 0.55f * mul);
        recoilPitch += (float) Math.toRadians(k[0] * 0.35f * mul);
        // 0.6: what the shot does to the hands depends on what was fired - the same kick for everything made a shotgun feel like a pistol
        firePunch = absentialis.character.Animator.kickOf(w.family, "bolt".equals(mode) || "pump".equals(mode));
        kick = Math.min(1, kick + 0.3f + w.recoilV * 0.05f + firePunch * 0.12f);
        shake = Math.max(shake, (firePunch - 1f) * 0.9f * c.settings.shake);
        raid.body.focus = Math.max(0, raid.body.focus - w.recoilV * 0.8f);
        raid.body.focusChanged = raid.time;
        lastShot = raid.time;
        fireTimer = 60f / st.rpm;
        if ("bolt".equals(mode) || "pump".equals(mode)) cycleT = 60f / st.rpm;
        raid.muzzleFlash = st.suppressed ? 0.3f : 1;
        p.anim.fire(firePunch);
        hud.ammoShown = raid.time;
        // the round was reported through ShotFired; only a weapon without a recorded profile falls back to its one-shot
        if (!gunLocal) {
            if (c.audio != null) c.audio.play(st.suppressed ? "shot_suppressed" : w.sound, fallbackShotGain(w), 0, 0.95f + raid.rng.nextFloat() * 0.1f);
            if ("bolt".equals(mode)) c.sfx("bolt", 0.5f);
            if ("pump".equals(mode)) c.sfx("pump", 0.5f);
        }
        if (h.jammed) { c.sfx("jam", 0.7f); hud.message("Jammed! (condition " + Math.round(h.condition()) + ") [R] to clear", Ui.RED, raid.time); }
        if (h.condition() < 25 && raid.rng.chance(0.05)) hud.message("Weapon is in critical condition - it needs a workbench", Ui.AMBER, raid.time);
    }

    private void melee(ItemInstance h) {
        meleeT = 60f / h.def().weapon.rpm;
        c.sfx("melee_swing", 0.6f);
        raid.player.anim.play("melee", Math.min(0.5f, meleeT));
        Actor p = raid.player;
        float fx = (float) -Math.sin(p.yaw), fz = (float) -Math.cos(p.yaw);
        Actor best = null; float bd = h.def().weapon.meleeRange + 0.4f;
        for (Actor a : raid.nearby(p.x, p.z, 4)) {
            if (a.isPlayer || a.dead) continue;
            float dx = a.x - p.x, dz = a.z - p.z, d = (float) Math.sqrt(dx * dx + dz * dz);
            if (d < bd && (dx * fx + dz * fz) / Math.max(0.01f, d) > 0.6f) { bd = d; best = a; }
        }
        if (best != null) {
            boolean sneak = !"engage".equals(best.state);
            float dmg = h.def().weapon.meleeDamage * (sneak ? 2.5f : 1) * (1 + lo().charm("melee"));
            // someone who sees it coming may block or step out of it
            float through = absentialis.ai.CloseCombat.defend(raid, best, p);
            wearBlade(h, 0.035f);
            if (through <= 0) { hud.message("They stepped out of it", Ui.TXT_DIM, raid.time); raid.emitSound(p.x, p.y, p.z, h.def().weapon.noise, "melee", p.id, false); return; }
            if (through < 1) hud.message("Blocked!", Ui.AMBER, raid.time);
            raid.meleeKind = "melee.knife".equals(h.defId) ? "blade" : "";
            raid.damageActor(best, p, dmg * through, null, sneak && best.infected() ? "head" : "torso", best.x, best.y + 1.4f, best.z);
            raid.meleeKind = "";
            if (best.id == raid.grabbedBy) raid.grabUntil = -99;
            c.sfx(through < 1 ? "melee_block" : "melee_hit", 0.7f);
            raid.emitSound(p.x, p.y, p.z, h.def().weapon.noise, "melee", p.id, false);
            return;
        }
        int[] hit = Physics.ray(raid.world, eyeX, eyeY, eyeZ, fx * (float) Math.cos(p.pitch), (float) Math.sin(p.pitch), fz * (float) Math.cos(p.pitch), 2.2f, false);
        if (hit != null) {
            Block hb = raid.world.block(hit[0], hit[1], hit[2]);
            // a knife opens crates; a crowbar opens most things
            float mul = "melee.crowbar".equals(h.defId) ? 2 : hb.is(Block.CONTAINER) && hb.mat == absentialis.world.Material.WOOD ? 1.4f : 0.5f;
            raid.damageBlock(hit[0], hit[1], hit[2], h.def().weapon.meleeDamage * mul, p.id);
            c.sfx("impact_wood", 0.5f);
            wearBlade(h, 0.02f);
        }
    }

    /** Knives have limited durability: every strike dulls the edge until it snaps. */
    private void wearBlade(ItemInstance h, float amount) {
        if (!"melee.knife".equals(h.defId)) return;
        h.durability -= amount;
        if (h.durability > 0) { if (h.durability < 0.2f && h.durability + amount >= 0.2f) hud.message("Your knife is about to break", Ui.AMBER, raid.time); return; }
        InventoryService.release(h);
        hud.message("Your knife broke", Ui.RED, raid.time);
        c.sfx("glass_break", 0.4f, 1.6f);
        for (String s : new String[]{"primary", "sidearm"}) if (lo().slot(s) != null) { heldSlot = s; break; }
        raid.player.weapon = held();
    }

    /** How long the rack after a full reload of a pump shotgun takes, and how many have been done (gates). */
    public static final float PUMP_TIME = 0.55f;
    public int pumpsAfterReload;

    private void reload() {
        ItemInstance h = held();
        if (h == null || h.def().weapon == null || h.def().weapon.melee() || reloadT > 0) return;
        ItemDef.Weapon w = h.def().weapon;
        if (h.jammed) { reloadKind = "jam"; reloadT = reloadMax = 1.2f; reloadCue = 0; raid.player.anim.play("clear_jam", 1.2f); return; }
        if (w.internal()) {
            if (h.rounds >= h.capacity()) return;
            ItemDef am = absentialis.gameplay.items.Content.ammoFor(w.caliber);
            if (findAmmo(w.caliber, null) == null) { hud.message("No " + (am == null ? w.caliber : am.name) + " in the case", Ui.RED, raid.time); c.sfx("ui_invalid", 0.4f); return; }
            float rt = Gunsmith.stats(h, 0).reloadTime;
            reloadCue = 0;
            hud.ammoShown = raid.time;
            if ("single".equals(w.reloadStyle)) {
                reloadKind = "internal"; reloadT = reloadMax = rt; reloadEmpty = h.rounds == 0;
                raid.player.anim.play("reload_shell", reloadMax);
            } else {
                // a round still in the weapon = quick tactical change; run dry = full reload with a rack
                reloadEmpty = h.rounds == 0;
                reloadKind = "magfill"; reloadT = reloadMax = rt * (reloadEmpty ? 1.15f : 0.85f);
                raid.player.anim.play(reloadEmpty ? "reload_empty" : "reload_tac", reloadMax);
            }
            return;
        }
        boolean speed = raid.time - lastRTime < 0.35f;
        lastRTime = raid.time;
        ItemInstance best = null;
        for (ItemInstance i : lo().caseGrid.items) if (i.def().magazine != null && i.def().magazine.magType.equals(w.magType) && i.rounds > 0 && (best == null || i.rounds > best.rounds)) best = i;
        if (best == null) {
            if (!h.chambered && h.mag != null && h.mag.rounds > 0) { reloadKind = "rack"; reloadT = reloadMax = 0.6f; reloadCue = 0; raid.player.anim.play("clear_jam", 0.6f); return; }
            hud.message("No loaded " + w.magType.toUpperCase() + " magazines - load one in the inventory", Ui.RED, raid.time);
            return;
        }
        if (h.mag != null && h.mag.rounds >= best.rounds && h.chambered) { hud.message("Current magazine is fuller", Ui.TXT_DIM, raid.time); return; }
        reloadMag = best;
        reloadKind = speed ? "speed" : "mag";
        reloadEmpty = !h.chambered;
        reloadCue = 0;
        reloadT = reloadMax = Gunsmith.stats(h, 0).reloadTime * (h.chambered ? 0.8f : 1.15f) * (speed ? 0.75f : 1);
        // bullets fired decide the animation: a round still chambered = tactical, run dry = full reload with a rack
        raid.player.anim.play(reloadEmpty ? "reload_empty" : "reload_tac", reloadMax);
        hud.ammoShown = raid.time;
        hud.message(h.chambered ? "Tactical reload (round kept in chamber)" + (speed ? " - dropping mag" : "") : "Empty reload - racking the action", Ui.TXT_DIM, raid.time);
    }

    private ItemInstance findAmmo(String caliber, String prefer) {
        ItemInstance best = null;
        for (ItemInstance i : lo().caseGrid.items) if (i.def().ammo != null && i.def().ammo.caliber.equals(caliber) && (prefer == null || prefer.equals(i.defId))) { best = i; break; }
        return best;
    }

    private void weaponTimers(float dt) {
        fireTimer -= dt; cycleT -= dt; switchT -= dt; meleeT -= dt; stfT -= dt;
        kick = Math.max(0, kick - dt * (6.6f - Math.min(2.6f, firePunch)));      // a heavy weapon takes longer to come back down
        recoilPitch *= Math.max(0, 1 - dt * 9);
        recoilYaw *= Math.max(0, 1 - dt * 9);
        if (reloadT <= 0) return;
        ItemInstance h = held();
        if (h == null) { cancelReload(); return; }
        reloadT -= dt;
        hud.ammoShown = raid.time;
        reloadFoley(1 - Math.max(0, reloadT) / Math.max(0.01f, reloadMax));
        if (reloadT > 0) return;
        switch (reloadKind) {
            case "jam" -> { WeaponService.clearJam(h); hud.message("Jam cleared", Ui.TXT, raid.time); }
            case "rack" -> WeaponService.chamberFromMag(h);
            case "internal" -> {
                ItemInstance ammo = findAmmo(h.def().weapon.caliber, null);
                if (ammo != null && WeaponService.loadOne(h, ammo)) {
                    if (h.rounds < h.capacity() && findAmmo(h.def().weapon.caliber, null) != null) { reloadT = reloadMax; reloadCue = 0; raid.player.anim.play("reload_shell", reloadMax); return; }
                }
                // 0.6: a pump gun loaded to the brim (or loaded from empty) is racked before it is ready - the fore-end
                // comes back and goes forward, and the weapon cannot fire until it has
                if ("pump".equals(h.fireModeName()) && (h.rounds >= h.capacity() || reloadEmpty) && h.rounds > 0) {
                    reloadKind = "pumpfull"; reloadT = reloadMax = PUMP_TIME; reloadCue = 0; reloadEmpty = false; pumpsAfterReload++;
                    raid.player.anim.play("pump", PUMP_TIME);
                    return;
                }
            }
            case "pumpfull" -> { }
            case "magfill" -> {
                List<ItemInstance> stacks = new ArrayList<>();
                for (ItemInstance i : lo().caseGrid.items) if (i.def().ammo != null) stacks.add(i);
                WeaponService.fill(h, stacks);
            }
            default -> {
                if (reloadMag != null && reloadMag.container == lo().caseGrid) {
                    WeaponService.Reload r = WeaponService.reloadMag(h, reloadMag, lo().caseGrid, 0, "speed".equals(reloadKind));
                    if (r.oldMag() != null) { raid.dropItem(r.oldMag(), raid.player.x, raid.player.y + 0.3f, raid.player.z); hud.message("Dropped magazine (" + r.oldMag().rounds + " rds) - it's on the ground", Ui.TXT_DIM, raid.time); }
                }
            }
        }
        cancelReload();
    }

    // ------------------------------------------------------------------ items
    private void useItem(ItemInstance it) {
        if (it.def().throwable != null) { throwIt(it); return; }
        if (it.def().weapon != null) { drawFromCase(it); return; }
        String r = panel.act(c.profile, it, "use", lo().caseGrid);
        if (r != null) hud.message(r, Ui.TXT, raid.time);
        if (raid.body.using != null) raid.player.anim.play("heal", Math.max(0.6f, raid.body.useTimer));
    }

    /** A weapon chosen from a quick slot or the wheel while it is still in the case: it takes its slot and comes to hand. */
    private void drawFromCase(ItemInstance it) {
        String slot = it.def().slot;
        if (slot == null || !(slot.equals("primary") || slot.equals("sidearm") || slot.equals("melee"))) { hud.message(it.def().name + " cannot be drawn", Ui.TXT_DIM, raid.time); return; }
        cancelReload();
        InventoryService.Result r = InventoryService.equip(it, lo(), slot);
        if (!r.ok()) { hud.message(r.msg(), Ui.RED, raid.time); return; }
        heldSlot = "";
        switchTo(slot);
    }

    private void useTimer(float dt) {
        if (raid.body.using == null) return;
        raid.body.useTimer -= dt;
        if (raid.body.useTimer > 0) return;
        ItemInstance it = panel.pendingUse;
        if (it != null && (it.container != null || it.slot != null)) {
            String r = raid.body.apply(raid.player, it.def());
            LoadoutPanel.consumeOne(it);
            c.sfx(it.def().food != null ? (it.def().food.hydration > it.def().food.energy ? "drink" : "eat") : it.def().medical.heal > 30 ? "injector" : "bandage", 0.6f);
            hud.message(it.def().name + ": " + r, Ui.GREEN, raid.time);
        }
        raid.body.using = null;
        panel.pendingUse = null;
    }

    private void throwIt(ItemInstance it) {
        Actor p = raid.player;
        float dx = (float) (-Math.sin(p.yaw) * Math.cos(p.pitch)), dy = (float) Math.sin(p.pitch), dz = (float) (-Math.cos(p.yaw) * Math.cos(p.pitch));
        ItemInstance one = it;
        InventoryService.consume(it, 1);
        ItemInstance hw = held();
        boolean launch = hw != null && hw.def().weapon != null && !hw.def().weapon.melee() && Gunsmith.stats(hw, 0).launcher && it.def().throwable != null && !"noise".equals(it.def().throwable.kind) && !"flare".equals(it.def().throwable.kind);
        if (launch) { raid.throwItem(one, dx, dy, dz, 2.3f, true); kick = 1; c.sfx("shot_shotgun", 0.5f, 0.6f); hud.message("Launched " + it.def().name, Ui.TXT_DIM, raid.time); raid.player.anim.fire(); return; }
        raid.throwItem(one, dx, dy, dz);
        raid.player.anim.play("throw", 0.6f);
        c.sfx("melee_swing", 0.4f);
        hud.message("Threw " + it.def().name, Ui.TXT_DIM, raid.time);
    }

    private void commitWheel() {
        int s = wheel.selected;
        if (s < 0) return;
        ItemInstance[] slots = wheel.slots(lo());
        if (slots[s] == null) return;
        switch (s) {
            case 0 -> switchTo("primary");
            case 1 -> switchTo("sidearm");
            case 2 -> switchTo("melee");
            case 3 -> throwIt(slots[3]);
            default -> useItem(slots[s]);
        }
    }

    /** What [F] would do right now (for the HUD prompt). */
    private String interactPrompt() {
        Actor p = raid.player;
        if (raid.extortion() != null) return "[F] Pay " + absentialis.Version.coins(Raid.EXTORT_PRICE) + "   -   or raise your weapon";
        String car = raid.vehicles.prompt();
        if (car != null && raid.nearestItem(p.x, p.y + 0.3f, p.z, 1.2f) == null) return car;
        if (raid.lonerInNeed(2.6f) != null) return "[F] Give a bandage";
        Actor bitten = raid.infection.patient(2.8f);
        if (bitten != null) return "[F] Give Antiviral Medicine to " + (bitten.name.isEmpty() ? "them" : absentialis.gameplay.squad.Roster.shortName(bitten.name)) + "  (" + InfectionSystem.stage(bitten.infection).toLowerCase() + ")";
        Raid.WorldItem wi = raid.nearestItem(p.x, p.y + 0.3f, p.z, 1.8f);
        if (wi != null) return "[F] Pick up " + wi.it.name();
        Actor patient = raid.casualty.playerPatient();
        if (patient != null) {
            String who = Raid.displayName(patient);
            return patient.vital == absentialis.entity.Vital.REVIVING ? "Reviving " + who + "  " + Math.round(raid.casualty.reviveFraction(patient) * 100) + "%  -  keep holding [F]"
                    : "[F] hold: revive " + who + "  (" + Math.max(0, (int) Math.ceil(patient.bleedLeft)) + "s)";
        }
        Actor corpse = raid.nearestCorpse(p.x, p.z, 1.8f);
        if (corpse != null) return "[F] Search " + corpse.corpse.label;
        Actor partner = raid.tradePartner(2.6f);
        if (partner != null && rayInteract() == null) return (partner.mate() ? "[F] Trade kit with " : "[F] Barter with ") + (partner.name == null || partner.name.isEmpty() ? Raid.displayName(partner) : absentialis.gameplay.squad.Roster.shortName(partner.name));
        int[] hit = rayInteract();
        if (hit != null) {
            Block b = raid.world.block(hit[0], hit[1], hit[2]);
            if (b.is(Block.DOOR)) {
                Doors.Door dr = raid.doors.at(hit[0], hit[1], hit[2]);
                if (dr == null) return null;
                return switch (raid.doors.state(dr)) { case LOCKED -> "Locked  -  [F] force it (loud)"; case OPEN -> "[F] Close door"; case DESTROYED -> null; default -> dr.latchBroken ? "[F] Push door" : "[F] Open door"; };
            }
            if (b.is(Block.CONTAINER)) return raid.isLocked(hit[0], hit[1], hit[2]) ? "[F] Unlock drawer (Small Key)" : "[F] Search " + b.name.replace('_', ' ');
            if (b.id == Block.TRANSFORMER) return "[F] Repair substation (2x Electrical Parts)";
            if (b.id == Block.BARRICADE) return "Barricade - break it with a crowbar or explosives";
        }
        return null;
    }

    private int[] rayInteract() {
        Actor p = raid.player;
        float dx = (float) (-Math.sin(p.yaw) * Math.cos(p.pitch)), dy = (float) Math.sin(p.pitch), dz = (float) (-Math.cos(p.yaw) * Math.cos(p.pitch));
        return Physics.ray(raid.world, eyeX, eyeY, eyeZ, dx, dy, dz, 3.0f, true);
    }

    /** [F]: the reach animation plays only when there is something in reach to act on. */
    private void interact() {
        if (tryInteract()) raid.player.anim.play("interact", 0.7f);
    }

    /** Performs whatever [F] means here. False when there was nothing to interact with (no animation, no sound). */
    private boolean tryInteract() {
        Actor p = raid.player;
        if (raid.extortion() != null) { String r = raid.payExtortion(); hud.message(r, r.startsWith("Paid") ? Ui.AMBER : Ui.RED, raid.time); c.sfx(r.startsWith("Paid") ? "ui_buy" : "ui_error", 0.5f); return true; }
        Actor needy = raid.lonerInNeed(2.6f);
        if (needy != null) { String r = raid.helpLoner(needy); hud.message(r, r.startsWith("You have") ? Ui.RED : Ui.GREEN, raid.time); c.sfx("bandage", 0.5f); return true; }
        Actor bitten = raid.infection.patient(2.8f);
        if (bitten != null) { String r = raid.infection.give(bitten); hud.message(r, r.startsWith("You have") ? Ui.RED : Ui.GREEN, raid.time); c.sfx(r.startsWith("You have") ? "ui_invalid" : "antiviral", 0.5f); return true; }
        Raid.WorldItem wi = raid.nearestItem(p.x, p.y + 0.3f, p.z, 1.8f);
        if (wi != null) {
            InventoryService.Result r = InventoryService.store(wi.it, lo());
            if (r.ok()) { raid.items.remove(wi); c.sfx("pickup", 0.5f); hud.message("Picked up " + wi.it.name(), Ui.TXT, raid.time); }
            else hud.message(r.msg(), Ui.RED, raid.time);
            return true;
        }
        Actor corpse = raid.nearestCorpse(p.x, p.z, 1.8f);
        if (corpse != null) { openInventory(corpse.corpse, corpse.corpse.label); return true; }
        Actor partner = raid.tradePartner(2.6f);
        if (partner != null && rayInteract() == null) { trade.open(raid, lo(), partner); cancelReload(); c.sfx("ui_click", 0.4f); return true; }
        int[] hit = rayInteract();
        if (hit == null || raid.vehicles.nearby() != null && !raid.world.block(hit[0], hit[1], hit[2]).is(Block.DOOR) && !raid.world.block(hit[0], hit[1], hit[2]).is(Block.CONTAINER)) {
            // nothing else in reach but a car: get in
            if (raid.vehicles.enter()) { cancelReload(); c.sfx("car_door_open", 0.5f); return true; }
            if (hit == null) return false;
        }
        Block b = raid.world.block(hit[0], hit[1], hit[2]);
        if (b.is(Block.DOOR)) {
            Doors.Door dr = raid.doors.at(hit[0], hit[1], hit[2]);
            if (dr == null) return false;
            if (raid.doors.use(dr, p) != null) {
                // locked: a boot against the latch - it takes a few, and everyone in earshot hears each one
                boolean gave = raid.doors.kick(dr, p);
                raid.playerVulnerableUntil = Math.max(raid.playerVulnerableUntil, raid.time + 0.5f);
                hud.message(gave ? "The latch gives" : "Locked - it holds", gave ? Ui.GREEN : Ui.AMBER, raid.time);
            }
            return true;
        }
        if (b.is(Block.CONTAINER) && raid.isLocked(hit[0], hit[1], hit[2]) && !raid.unlock(hit[0], hit[1], hit[2])) { hud.message("Locked. A Small Key opens it.", Ui.AMBER, raid.time); c.sfx("ui_invalid", 0.5f); return true; }
        if (b.is(Block.CONTAINER)) { Container box = raid.openContainer(hit[0], hit[1], hit[2]); openInventory(box, box.label); if (c.audio != null) c.audio.playAt("search", hit[0] + 0.5f, hit[1] + 0.5f, hit[2] + 0.5f, 0.6f, 20, 1); return true; }
        if (b.id == Block.TRANSFORMER) { hud.message(raid.repairSite(hit[0], hit[1], hit[2]), Ui.AMBER, raid.time); return true; }
        return false;
    }

    /** Automation: opens the nearest searchable container within r blocks. */
    public boolean debugOpenNearestContainer(int r) {
        Actor p = raid.player;
        int px = (int) p.x, py = (int) p.y, pz = (int) p.z;
        for (int d = 1; d <= r; d++) for (int x = px - d; x <= px + d; x++) for (int z = pz - d; z <= pz + d; z++) for (int y = py - 2; y <= py + 3; y++) {
            Block b = raid.world.block(x, y, z);
            if (b != null && b.is(Block.CONTAINER)) { Container box = raid.openContainer(x, y, z); openInventory(box, box.label); return true; }
        }
        return false;
    }

    private boolean inspectArmed, inspectWait;
    /** The open container held something when it was opened; once the last item leaves it, the search closes itself. */
    private boolean lootHadItems;
    private float lootEmptyT;

    /** Closes the search view a beat after the container or body has been emptied (never mid-drag). */
    private boolean wasInCar, viewBeforeCar;

    private void autoCloseLoot(float dt) {
        if (!invOpen || lootSide == null || !lootHadItems) return;
        if (!lootSide.items.isEmpty() || c.inv.drag != null) { lootEmptyT = 0; return; }
        lootEmptyT += dt;
        if (lootEmptyT < 0.22f) return;
        String what = lootSide.label == null || lootSide.label.isEmpty() ? "Container" : lootSide.label;
        closeInventory();
        c.sfx("zipper", 0.35f, 1.15f);
        hud.message(InventoryUi.cap(what) + " emptied", Ui.TXT_DIM, raid.time);
    }

    /** Seconds [F] has been down in the open menu, and how long a press may last and still count as a tap. */
    private float fHeld;
    private static final float F_TAP = 0.22f;

    private void openInventory(Container loot, String title) {
        invOpen = true;
        fHeld = 0;
        inspectArmed = false;
        inspectWait = true;
        c.inv.inspected = null;
        lootSide = loot;
        lootTitle = title;
        lootHadItems = loot != null && !loot.items.isEmpty();
        lootEmptyT = 0;
        c.inv.quickA = loot;
        c.inv.quickB = lo().caseGrid;
        c.inv.owner = lo();
        c.inv.allowDrop = true;
        c.inv.extraActions.clear();
        c.inv.extraActions.add("quick");
        c.inv.onAction = (it, act) -> { String r = panel.act(c.profile, it, act, lootSide); if (r != null) { c.inv.say(r, Ui.TXT); if (act.equals("use")) closeInventory(); } };
        c.sfx("zipper", 0.4f);
    }

    private void closeInventory() {
        invOpen = false;
        lootSide = null;
        lootHadItems = false;
        c.inv.drag = null;
        c.inv.menu.clear();
        raid.applyArmor();
        raid.player.weapon = held();
        if (held() == null) for (String s : new String[]{"primary", "sidearm", "melee"}) if (lo().slot(s) != null) { heldSlot = s; break; }
    }

    // ================================================================== render
    private final Mat4 invView = new Mat4();
    private float camYaw, camPitch;
    private boolean camThird;
    /** Third person: where the camera is, the point its boom hangs from (smoothed), the shoulder offset in use, and the framing offsets in play. */
    private float camPX, camPY, camPZ, tpsAX, tpsAY, tpsAZ, tpsShoulderNow, frameD, frameS, frameH, frameF;
    private boolean tpsTracking;
    /** Boom length with the sights up (metres). */
    public static final float TPS_AIM_DISTANCE = 1.45f;

    /**
     * Dynamic framing: what the body is doing changes where the camera wants to be - {distance, shoulder, height, field
     * of view} offsets from the standing frame, eased so the picture never jumps. A slide drops and widens it; working
     * on a casualty or lying wounded pulls it up and out; using something or working a door brings it in over the hands.
     */
    private void frame(Actor p, float dt) {
        String act = p.anim == null ? "" : p.anim.action;
        float d = 0, s = 0, h = 0, f = 0;
        if (p.downed()) { d = 0.9f; h = 0.55f; s = -0.25f; }
        else if (p.slideT > 0) { d = 0.5f; h = -0.45f; f = 3; }
        else if (p.revivingId != 0) { d = 0.9f; h = 0.35f; s = -0.2f; }
        else if (raid.body.using != null || "heal".equals(act)) { d = -0.7f; s = 0.10f; h = -0.05f; }
        else if ("interact".equals(act) || "car_enter".equals(act) || "car_exit".equals(act)) { d = -0.5f; s = 0.08f; }
        else if (act.startsWith("reload") || "pump".equals(act) || "clear_jam".equals(act)) { d = -0.3f; }
        else if ("melee".equals(act)) { d = 0.35f; f = 3; }
        else if (p.climbing) { d = 0.7f; h = 0.3f; s = -0.3f; }
        else if (p.sprinting) { d = 0.35f; h = -0.04f; }
        else if (p.cover != null) { d = -0.15f; s = 0.12f; h = p.crouch ? 0.05f : 0; }
        else if (p.crouch) { d = -0.2f; h = -0.1f; }
        float k = Math.min(1, dt * 4.5f);
        frameD += (d - frameD) * k; frameS += (s - frameS) * k; frameH += (h - frameH) * k; frameF += (f - frameF) * k;
    }

    public void render(float dt) {
        Actor p = raid.player;
        int W = c.win.width, H = c.win.height;
        glViewport(0, 0, W, H);
        // camera: first person rides the head bone of the animated body (gait, crouch, step-ups, landings)
        playerLook = ActorRenderer.playerLook(c.profile, playerLook);
        if (playerLook.gear.eyesClosed != raid.player.dead) { playerLook.gear.eyesClosed = raid.player.dead; playerLook.key = absentialis.character.CharBuilder.key(playerLook.app, playerLook.gear); }
        shake = Math.max(shake * Math.max(0, 1 - dt * 5), raid.damageShake * c.settings.shake);
        c.ar.eye(p, playerLook, p.pitch, eye);
        float rx = (float) Math.cos(p.yaw), rz = (float) -Math.sin(p.yaw);
        eyeX = eye[0] + rx * lean * 0.45f;
        eyeY = eye[1] - landDip;
        eyeZ = eye[2] + rz * lean * 0.45f;
        float yaw = p.yaw + (raid.rng.nextFloat() - 0.5f) * shake * 0.02f, pitch = p.pitch + (raid.rng.nextFloat() - 0.5f) * shake * 0.02f;
        boolean deathCam = p.dead && p.ragdoll != null;
        if (deathCam) {
            // you watch yourself fall: the camera leaves the head, looks back at the body from where the killing
            // blow came, then drifts slowly around it while the picture drains
            eyeX = p.ragdoll.x[absentialis.character.Ragdoll.PELVIS]; eyeY = p.ragdoll.y[absentialis.character.Ragdoll.PELVIS] + 0.5f; eyeZ = p.ragdoll.z[absentialis.character.Ragdoll.PELVIS];
            // turned: the camera stays with what you have become
            Actor husk = raid.infection.playerHusk;
            if (husk != null) { eyeX = husk.x; eyeY = husk.y + husk.height() * 0.7f; eyeZ = husk.z; }
            yaw = deathYaw + deadT * 0.16f; pitch = -0.36f - 0.1f * (float) Math.sin(deadT * 0.21f); lean = 0;
        }
        boolean driving = !p.dead && (raid.vehicles.driving != null || raid.vehicles.busy());
        if (raid.vehicles.driving != null && !p.dead && !this.thirdPerson) { raid.vehicles.eye(eye); eyeX = eye[0]; eyeY = eye[1]; eyeZ = eye[2]; }
        // behind the wheel the chase camera is the default; [V] still switches, and the old view returns on getting out
        boolean inCar = raid.vehicles.inside();
        if (inCar != wasInCar) { if (inCar) { viewBeforeCar = this.thirdPerson; this.thirdPerson = true; } else this.thirdPerson = viewBeforeCar; wasInCar = inCar; }
        raid.vehicles.cockpit = inCar && !this.thirdPerson && !deathCam;
        boolean thirdPerson = this.thirdPerson || deathCam;
        float cx = eyeX, cy = eyeY, cz = eyeZ;
        float fx = (float) (-Math.sin(yaw) * Math.cos(pitch)), fy = (float) Math.sin(pitch), fz = (float) (-Math.cos(yaw) * Math.cos(pitch));
        if (raid.vehicles.driving != null && !p.dead && this.thirdPerson) {
            // chase camera: behind and above the car, looking where the player looks
            float[] vp = raid.vehicles.driving.cameraAnchor();
            eyeX = vp[0]; eyeY = vp[1]; eyeZ = vp[2];
            cx = eyeX; cy = eyeY; cz = eyeZ;
        }
        if (thirdPerson) {
            // 0.6 third-person camera. On foot it sits behind the right shoulder on a boom the mouse swings freely; the
            // point it hangs from follows the head with a little lag (tracking), so steps and stops do not jolt the
            // picture; aiming draws it in to the shoulder; and what the body is doing reframes it (dynamic framing).
            boolean foot = !driving && !deathCam;
            float ax = eyeX, ay = eyeY, az = eyeZ;
            if (foot) {
                float sm = c.settings.tpsSmoothing, gap = (float) Math.sqrt((eyeX - tpsAX) * (eyeX - tpsAX) + (eyeY - tpsAY) * (eyeY - tpsAY) + (eyeZ - tpsAZ) * (eyeZ - tpsAZ));
                if (!tpsTracking || gap > 1.6f) { tpsAX = eyeX; tpsAY = eyeY; tpsAZ = eyeZ; tpsTracking = true; }
                float kxz = Math.min(1, dt * (30 - 20 * sm)), ky = Math.min(1, dt * (22 - 16 * sm));
                tpsAX += (eyeX - tpsAX) * kxz; tpsAZ += (eyeZ - tpsAZ) * kxz; tpsAY += (eyeY - tpsAY) * ky;
                ax = tpsAX; ay = tpsAY; az = tpsAZ;
                frame(p, dt);
            } else { tpsTracking = false; frameD = frameS = frameH = frameF = 0; }
            float d = deathCam ? 4.6f - 0.8f * Math.min(1, deadT / 9f) : driving ? 7.2f : Math.max(1.2f, (c.settings.tpsDistance + frameD) * (1 - adsK) + TPS_AIM_DISTANCE * adsK);
            float shoulder = driving ? 0 : Math.max(0, (c.settings.tpsShoulder + frameS) * (1 - 0.22f * adsK));
            float side = driving ? 0 : 0.25f;
            float bx = -fx + rx * side, by = -fy + (driving ? 0.3f : 0.08f), bz = -fz + rz * side, bl = (float) Math.sqrt(bx * bx + by * by + bz * bz);
            int[] hit = Physics.ray(raid.world, ax, ay, az, bx / bl, by / bl, bz / bl, d + 0.4f, false);
            if (hit != null) {
                float hx = hit[0] + 0.5f - ax, hy = hit[1] + 0.5f - ay, hz = hit[2] + 0.5f - az;
                d = Math.max(0.35f, Math.min(d, (float) Math.sqrt(hx * hx + hy * hy + hz * hz) - 0.95f));
            }
            // the shoulder offset gives way too, when there is a wall on that side
            if (shoulder > 0.05f && Physics.ray(raid.world, ax, ay, az, rx, 0, rz, shoulder + 0.35f, false) != null) shoulder *= 0.25f;
            tpsDistance += (d - tpsDistance) * Math.min(1, dt * (d < tpsDistance ? 30 : 6));
            tpsShoulderNow += (shoulder - tpsShoulderNow) * Math.min(1, dt * 10);
            float off = driving ? 0 : tpsShoulderNow * Math.min(1, tpsDistance / 1.5f);
            cx = ax - fx * tpsDistance + rx * off; cy = ay - fy * tpsDistance + (driving ? 0.9f : 0.2f - 0.08f * adsK + frameH); cz = az - fz * tpsDistance + rz * off;
        } else tpsTracking = false;
        camPX = cx; camPY = cy; camPZ = cz;
        camYaw = yaw; camPitch = pitch; camThird = thirdPerson;
        float fov = c.settings.fov / (1 + (zoom() - 1) * adsK) - adsK * 8 + (p.sprinting ? 4 : 0) + (p.slideT > 0 ? 5 : 0) + (thirdPerson ? frameF : 0) + (raid.vehicles.driving != null ? Math.min(8, raid.vehicles.driving.speed() * 0.25f) : 0);
        float aspect = W / (float) Math.max(1, H);
        proj.perspective((float) Math.toRadians(fov), aspect, 0.05f, 900f);
        view.identity().rotateZ(-lean * 0.08f).rotateX(-pitch).rotateY(-yaw).translate(-cx, -cy, -cz);
        pv.set(proj).mul(view);
        setupEnv(cx, cy, cz, fx, fy, fz);
        c.wr.scheduleDirty();
        c.wr.uploadResults(24);
        c.wr.viewDistance = 260;
        // the picture drains as you die: colour to black and white, grain rising, over the first seconds on the ground
        deathFx = p.dead ? Math.min(1, Math.max(0, (deadT - 0.6f) / 5.4f)) : Math.max(0, deathFx - dt * 2);
        boolean hands = !thirdPerson && !invOpen && !p.dead && !driving;
        if (c.hr != null) {
            var hr = c.hr;
            var f = hr.frame;
            f.view.set(view); f.proj.set(proj);
            f.vmProj.perspective((float) Math.toRadians(60), aspect, 0.01f, 10f);
            f.camX = cx; f.camY = cy; f.camZ = cz; f.fwdX = fx; f.fwdY = fy; f.fwdZ = fz;
            f.fovY = (float) Math.toRadians(fov); f.aspect = aspect; f.dt = dt; f.env = env; f.viewDistance = 260;
            f.death = deathFx * deathFx * (3 - 2 * deathFx);
            f.hurt = p.dead ? 0 : Math.max(Math.min(1, raid.damageShake * 1.4f), p.hp < 35 ? (35 - p.hp) / 35f * (0.75f + 0.25f * (float) Math.sin(raid.time * 4.5f)) : 0);
            f.infection = p.dead ? 0 : raid.body.infectionFx(raid.time);
            f.flash = raid.flashBlind > 0.01f ? Math.min(1, raid.flashBlind * 1.6f) : 0;
            c.settings.applyGraphics(hr, c.win);
            raid.fire.detail = c.settings.particleDetail;
            hr.scene.clear(); hr.viewmodel.clear(); hr.particles.clear(); hr.clearLights();
            c.mr.record(hr.scene);
            drawModels(dt);
            if (hands) { invView.invert(view); c.mr.record(hr.viewmodel, invView); drawViewmodel(fov, aspect); }
            c.mr.stop();
            sceneLights(hr, fx, fy, fz);
            raid.fire.submit(hr.particles);
            sparks(hr.particles);
            hr.render(c.wr, W, H);
        } else {
            glClearColor(env.fogR, env.fogG, env.fogB, 1);
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
            float[] f = {fx, fy, fz}, r = {(float) Math.cos(yaw), 0, (float) -Math.sin(yaw)};
            float[] up = {r[1] * fz - r[2] * fy, r[2] * fx - r[0] * fz, r[0] * fy - r[1] * fx};
            c.wr.renderSky(env, f, r, up, (float) Math.tan(Math.toRadians(fov / 2)), aspect);
            c.wr.render(pv, env);
            drawModels(dt);
            if (hands) drawViewmodel(fov, aspect);
        }
        raid.fire.audio(c.audio);
        raid.vehicles.audio(c.audio, dt);
        // 2D
        Ui ui = c.ui;
        ui.b.begin(W, H);
        ui.begin(dt, W, H);
        boolean deathMenu = p.dead && deadT >= DEATH_MENU_AT;
        ui.showCursor = invOpen || paused || mapOpen || c.console.open || deathMenu || trade.open;
        if (c.hr == null) {
            if (raid.muzzleFlash > 0.3f && !thirdPerson) ui.b.rect(0, 0, W, H, Ui.alpha(0x30FFD080, raid.muzzleFlash * 0.3f));
            if (raid.flashBlind > 0.01f) ui.b.rect(0, 0, W, H, Ui.alpha(0xFFFFFFFF, Math.min(1, raid.flashBlind * 1.6f)));
            if (p.dead) ui.b.rect(0, 0, W, H, Ui.alpha(0xFF000000, deathFx * 0.55f));   // no post chain here: a plain dim stands in for the drain
        }
        if (!invOpen && !mapOpen && !p.dead) {
            if (!p.dead) { status.nameTags(ui, pv, env.camX, env.camY, env.camZ); status.bubbles(ui, pv, env.camX, env.camY, env.camZ); }
            xpFeed.update();
            xpFeed.draw(ui);
            hud.draw(raid, held(), reloadT, reloadMax, driving ? null : interactPrompt(), adsT > 0.6f, dt);
            if (!p.dead) { status.module(ui, held(), reloadT, reloadMax, playerLook, hud.ammoShown); status.hitmarker(ui); }
            if (adsT > 0.6f && zoom() > 2) scopeOverlay(ui, W, H);
            else if (adsT > 0.35f && held() != null && held().attachments.get("optic") != null) dotOverlay(ui, W, H, held().attachments.get("optic").defId.endsWith("holo"), Math.min(1, (adsT - 0.35f) / 0.4f));
            if (raid.body.using != null) { ui.textC("Using " + raid.body.using.name + String.format("  %.1fs", raid.body.useTimer), W / 2f, H * 0.7f, 15, Ui.TXT_HI); }
            drawMinimap(ui);
            status.killfeed(ui, status.squad(ui, squadSel, new int[]{SquadPanel.GOLD_COL, SquadPanel.RED_COL, SquadPanel.BLUE_COL}));
            vehicleHud(ui);
            if (raid.aiDebug) aiDebug(ui);
        }
        wheel.draw(ui, lo(), dt);
        if (p.dead) drawDeath(ui);
        if (invOpen) drawInventory(ui, dt);
        if (trade.open) trade.draw(ui);
        if (mapOpen) drawMap(ui);
        if (paused) drawPause(ui);
        c.console.draw(ui, dt);
        if (c.settings.showFps) {
            ui.text(Math.round(1 / Math.max(1e-4f, dt)) + " fps  " + c.wr.drawnColumns + " cols  actors " + raid.actors.size() + "  fire " + raid.fire.particles() + "  " + absentialis.Version.SHORT, ui.s(8), H - ui.s(20), 12, Ui.TXT_DIM);
            if (c.hr != null) ui.text(c.hr.stats, ui.s(8), H - ui.s(36), 11, Ui.TXT_DIM);
        }
        ui.end();
        ui.b.end();
    }

    // ------------------------------------------------------------------ death sequence
    /** Seconds on the ground before the choice appears; any key after two seconds brings it up early. */
    private static final float DEATH_MENU_AT = 6.5f;
    private float deathFx, deathYaw;
    private boolean deathStarted;
    private absentialis.engine.audio.AudioEngine.Voice deathDrone;
    /** What the player chose once dead: "respawn", "menu" or "quit" (read by GameApp when the raid ends). */
    public String deathChoice;

    /** First frame of being dead: frame the camera on the killer's side of the body, start the sound of it. */
    private void beginDeath() {
        deathStarted = true;
        Actor p = raid.player, k = raid.actor(p.lastAttacker);
        // look across the body toward whoever did it; with nobody to blame, keep the way you were facing
        deathYaw = k != null && k != p ? (float) Math.atan2(-(k.x - p.x), -(k.z - p.z)) : p.yaw;
        invOpen = false; mapOpen = false; paused = false; wheel.open = false;
        c.inv.drag = null;
        c.sfx("death_sting", 0.9f);
        if (c.audio != null && c.audio.available) { deathDrone = c.audio.loop("death_drone", 0.9f, absentialis.engine.audio.AudioEngine.MUSIC); c.audio.duckTo(0.25f, 5f); }
        if (tensionVoice != null) tensionVoice.fadeTo(0, 2);
    }

    /** Resolves the death with the player's choice; the raid then ends on the next update. */
    public void chooseDeath(String choice) {
        if (deathChoice != null) return;
        deathChoice = choice;
        c.sfx("ui_confirm", 0.5f);
        raid.resolveDeath();
    }

    private void drawDeath(Ui ui) {
        float W = ui.w, H = ui.h;
        boolean ironman = c.profile.ironman;
        float k = Math.min(1, deadT / 1.4f);
        // letterbox bars close in as the colour leaves
        float bar = H * 0.085f * deathFx;
        ui.b.rect(0, 0, W, bar, 0xFF000000);
        ui.b.rect(0, H - bar, W, bar, 0xFF000000);
        Actor killer = raid.actor(raid.player.lastAttacker);
        String how = raid.deathReason().isEmpty() ? (killer != null && killer != raid.player ? "Killed by " + Raid.describe(killer) : "The Zone keeps what it kills") : raid.deathReason();
        boolean menu = deadT >= DEATH_MENU_AT;
        float ty = menu ? H * 0.20f : H * 0.36f;
        ui.textC("YOU DIED", W / 2f, ty, 56, Ui.alpha(0xFFD8D4CC, k));
        ui.textC(how, W / 2f, ty + ui.s(70), 15, Ui.alpha(Ui.TXT, k));
        ui.textC(String.format("%d:%02d in the Zone", (int) raid.time / 60, (int) raid.time % 60) + "   -   " + raid.debrief.deployedIn.display, W / 2f, ty + ui.s(94), 12, Ui.alpha(Ui.TXT_DIM, k));
        if (!menu) {
            if (deadT > 2.2f) ui.textC("press any key", W / 2f, H - bar - ui.s(34), 11, Ui.alpha(Ui.TXT_DIM, 0.5f + 0.4f * (float) Math.sin(deadT * 3)));
            return;
        }
        float a = Math.min(1, (deadT - DEATH_MENU_AT) / 0.6f);
        float bw = ui.s(340), bh = ui.s(48), bx = W / 2f - bw / 2, by = H * 0.50f;
        ui.b.rect(bx - ui.s(28), by - ui.s(56), bw + ui.s(56), (ironman ? 2 : 3) * (bh + ui.s(12)) + ui.s(118), Ui.alpha(0xD0080808, a));
        if (ironman) {
            ui.textC("IRONMAN", W / 2f, by - ui.s(42), 16, Ui.alpha(Ui.RED, a));
            ui.textC("One life. This survivor is gone and the profile is deleted.", W / 2f, by - ui.s(18), 12, Ui.alpha(Ui.TXT, a));
        } else {
            ui.textC("WHAT NOW?", W / 2f, by - ui.s(42), 16, Ui.alpha(Ui.TXT_HI, a));
            ui.textC("What you carried in is lost with the body. Secured treasures and the stash are safe.", W / 2f, by - ui.s(18), 12, Ui.alpha(Ui.TXT_DIM, a));
        }
        float y = by + ui.s(10);
        if (!ironman) { if (ui.button("d_respawn", bx, y, bw, bh, "RESPAWN AT THE HIDEOUT", "arrow", a > 0.6f)) chooseDeath("respawn"); y += bh + ui.s(12); }
        if (ui.button("d_menu", bx, y, bw, bh, "MAIN MENU", "inv", a > 0.6f)) chooseDeath("menu");
        y += bh + ui.s(12);
        if (ui.button("d_quit", bx, y, bw, bh, "QUIT TO DESKTOP", "cross", a > 0.6f)) chooseDeath("quit");
    }

    // ------------------------------------------------------------------ dynamic lights (hybrid renderer)
    private final java.util.List<float[]> lampScratch = new java.util.ArrayList<>();

    /** This frame's local lights, most important first: the renderer shadows and glows around the head of the list. */
    private void sceneLights(absentialis.engine.render.HybridRenderer hr, float fx, float fy, float fz) {
        Actor p = raid.player;
        final int SH = absentialis.engine.render.HybridRenderer.LIGHT_SHADOW, SPOT = absentialis.engine.render.HybridRenderer.LIGHT_SPOT, STATIC = absentialis.engine.render.HybridRenderer.LIGHT_STATIC;
        // the beam starts where the flashlight is: at the muzzle when it is on the gun, at the chest when it is the hand torch
        // clipped to the rig (a little lower, a little to the left, and it does not follow the sights up and down as closely)
        if (env.flashlight > 0 && !p.dead) {
            if (lightOnWeapon) hr.addLight(eyeX + fx * 0.45f, eyeY - 0.10f, eyeZ + fz * 0.45f, 40, 11.5f, 10.8f, 9.4f, SH | SPOT, fx, fy, fz, 0.86f);
            else { float rx = (float) Math.cos(p.yaw), rz = (float) -Math.sin(p.yaw); hr.addLight(eyeX + fx * 0.2f - rx * 0.14f, eyeY - 0.38f, eyeZ + fz * 0.2f - rz * 0.14f, 34, 10.4f, 9.6f, 8.0f, SH | SPOT, fx, fy * 0.85f, fz, 0.84f); }
        }
        if (raid.muzzleFlash > 0.05f) hr.addPoint(env.flashX, env.flashY, env.flashZ, 11, 22 * raid.muzzleFlash, 15 * raid.muzzleFlash, 7 * raid.muzzleFlash, SH);
        raid.fire.lights(hr);
        raid.vehicles.lights(hr);
        for (Actor a : raid.actors) {
            if (a.isPlayer || a.dead || a.distXZ(env.camX, env.camZ) > 70) continue;
            float tx = (float) -Math.sin(a.yaw), tz = (float) -Math.cos(a.yaw), hy = a.y + a.height() * 0.72f;
            if (a.light) hr.addLight(a.x + tx * 0.42f, hy, a.z + tz * 0.42f, 20, 7.5f, 6.4f, 4.6f, SH | SPOT, tx, -0.12f, tz, 0.80f);
            if (raid.time < a.flashUntil && raid.time > a.flashUntil - 0.07f) hr.addPoint(a.x + tx * 0.9f, hy + 0.1f, a.z + tz * 0.9f, 9, 16, 11, 5, 0);
        }
        // explosions and other glowing debris light what is around them for as long as they last
        int glow = 0;
        for (Raid.Effect e : raid.effects) {
            if (!e.glow || e.size < 0.16f || glow >= 6) continue;
            float k = Math.min(1, e.life / e.max * 2);
            hr.addPoint(e.x, e.y, e.z, 7, ((e.color >> 16) & 255) / 255f * 9 * k, ((e.color >> 8) & 255) / 255f * 9 * k, (e.color & 255) / 255f * 9 * k, 0);
            glow++;
        }
        // powered lamps near the camera, nearest first (the rest of the city's lamps reach the frame through the probes)
        lampScratch.clear();
        for (absentialis.world.MapData.Point lp : raid.world.map.lampsOnPower) {
            float dx = lp.x + 0.5f - env.camX, dz = lp.z + 0.5f - env.camZ, d2 = dx * dx + dz * dz;
            if (d2 > 66 * 66 || raid.world.get(lp.x, lp.y, lp.z) != Block.LAMP) continue;
            lampScratch.add(new float[]{lp.x + 0.5f, lp.y + 0.35f, lp.z + 0.5f, d2});
        }
        lampScratch.sort((a, b) -> Float.compare(a[3], b[3]));
        for (int i = 0; i < Math.min(72, lampScratch.size()); i++) { float[] l = lampScratch.get(i); hr.addPoint(l[0], l[1], l[2], 14, 5.6f, 4.5f, 3.0f, STATIC | SH); }
    }

    /** Tracer sparks and muzzle glow as real emitters of light in the particle pass. */
    private void sparks(absentialis.engine.render.ParticleBatch pb) {
        if (raid.muzzleFlash > 0.2f && !camThird && !raid.player.dead) pb.add(env.flashX, env.flashY - 0.05f, env.flashZ, 0.22f * raid.muzzleFlash, 9f, 6f, 2.6f, 0.9f, 0, absentialis.engine.render.ParticleBatch.GLOW, 0, raid.time);
        for (Actor a : raid.actors) {
            if (a.isPlayer || a.dead || !(raid.time < a.flashUntil && raid.time > a.flashUntil - 0.06f)) continue;
            float tx = (float) -Math.sin(a.yaw), tz = (float) -Math.cos(a.yaw);
            pb.add(a.x + tx * 0.95f, a.y + a.height() * 0.74f, a.z + tz * 0.95f, 0.3f, 10f, 6.5f, 2.6f, 0.9f, 0, absentialis.engine.render.ParticleBatch.GLOW, 0, a.id);
        }
    }

    /** Where the fog bank is complete this frame, in metres: nothing past it is visible, to the player or to anybody else. */
    public float fogEnd = 165f;

    private void setupEnv(float cx, float cy, float cz, float fx, float fy, float fz) {
        District d = raid.world.district(cx, cz);
        float day = raid.daylight();
        env.daylight = day;
        env.time = raid.time;
        env.rain = raid.profile.zone.weatherRain > 0.5f ? (raid.profile.zone.weatherRain - 0.5f) * 2 : 0;
        float out = World.outsideDistance(cx, cz);
        float dens = d.fogDensity * (1 + env.rain * 0.8f) * (1 + Math.min(1.5f, out / 60f));
        absentialis.gameplay.CombatConfig fc = absentialis.gameplay.CombatConfig.get();
        env.fogDensity = dens / 230f * fc.fogHaze;
        float near = (1 - (1 - fc.fogNight) * (1 - day)) * (1 - (1 - fc.fogRain) * env.rain);
        env.fogWallStart = fc.fogStart * near; env.fogWallEnd = fogEnd = Math.min(fc.fogEnd * near, 236f);
        env.fogSkyHorizon = 1f; env.fogSkyZenith = fc.fogSky;
        float nightK = 0.12f + 0.88f * day;
        env.fogR = d.fogR * nightK; env.fogG = d.fogG * nightK; env.fogB = d.fogB * nightK;
        if (cy < World.GROUND - 3) { env.fogDensity = 1 / 45f; env.fogR = 0.04f; env.fogG = 0.05f; env.fogB = 0.04f; }
        env.skyR = 0.85f + 0.15f * day; env.skyG = 0.9f; env.skyB = 1f;
        env.tintR = d.tintR; env.tintG = d.tintG; env.tintB = d.tintB;
        double h = raid.profile.zone.hour + raid.time / 60.0 * 0.5;
        double sa = (h % 24 - 6) / 12.0 * Math.PI;
        env.sunX = (float) Math.cos(sa) * 0.8f; env.sunY = (float) Math.sin(sa); env.sunZ = 0.35f;
        env.camX = cx; env.camY = cy; env.camZ = cz; env.dirX = fx; env.dirY = fy; env.dirZ = fz;
        ItemInstance hw = held();
        int lightFrom = raid.lightSource(held());
        if (lightFrom == 0) raid.playerFlashlight = false;        // dropped, traded away or left on the other gun
        env.flashlight = raid.playerFlashlight ? 1 : 0;
        lightOnWeapon = lightFrom == 2;
        env.flashR = raid.muzzleFlash; env.flashX = eyeX + fx; env.flashY = eyeY; env.flashZ = eyeZ + fz;
    }

    private void drawModels(float dt) {
        var mr = c.mr;
        mr.begin(pv, env);
        float day = raid.daylight();
        for (Actor a : raid.actors) {
            if (a.distXZ(env.camX, env.camZ) > 150) continue;
            a.hurtFlash = Math.max(0, a.hurtFlash - dt);
            float light = ActorRenderer.lightAt(raid.world, a.x, a.y, a.z, day);
            if (a.isPlayer && raid.vehicles.driving != null && !a.dead && !thirdPerson) continue;   // at the wheel in first person: the cabin is what you see
            if (a.isPlayer) {
                if (a.dead) { if (a.ragdoll != null && !raid.infection.playerRisen()) c.ar.draw(a, playerLook, light, 0, null, 0, false); continue; }
                if (thirdPerson) {
                    c.ar.alpha = Math.max(0.25f, Math.min(1, (tpsDistance - 0.6f) / 1.4f));
                    c.ar.draw(a, playerLook, light, a.pitch, ground, 0, false);
                    c.ar.alpha = 1;
                } else {
                    // true first-person body: the same rig and gait, minus the head and the arms the viewmodel draws
                    mr.flags = absentialis.engine.render.DrawList.NO_SHADOW;
                    c.ar.draw(a, playerLook, light, a.pitch, ground, ActorRenderer.FP_HIDE, true);
                    // ... while the shadow on the ground is the whole of you, head and arms included
                    mr.flags = absentialis.engine.render.DrawList.SHADOW_ONLY;
                    if (mr.recording()) c.ar.draw(a, playerLook, light, a.pitch, ground, 0, false);
                    mr.flags = 0;
                }
                continue;
            }
            ActorRenderer.Look look = ActorRenderer.lookFor(a);
            // agents look where they believe their target is
            float pitch = 0;
            if (!a.dead && "engage".equals(a.state)) { float dd = a.distXZ(a.memX, a.memZ); pitch = (float) Math.atan2(a.memY + 1.2f - a.eyeY(), Math.max(1, dd)); }
            c.ar.draw(a, look, light, pitch, a.distXZ(env.camX, env.camZ) < 40 ? ground : null, 0, false);
            if (a.dead) continue;
            if (a.light) {
                // a carried torch: a warm beam ahead of the bearer - you can see a night sentry coming, and so can they
                float tx = (float) -Math.sin(a.yaw), tz = (float) -Math.cos(a.yaw), hy = a.y + a.height() * 0.72f;
                if (c.hr == null) mr.beam(a.x + tx * 0.4f, hy, a.z + tz * 0.4f, a.x + tx * 9, hy - 1.1f, a.z + tz * 9, 0.22f, 0x18FFE8B0, 1);
                tmp.identity().translate(a.x + tx * 0.42f, hy, a.z + tz * 0.42f).scale(0.09f, 0.09f, 0.09f).translate(0, -0.5f, 0);
                mr.cube(tmp, 0xFFFFF0C0, 1, 1);
            }
            // telegraphs are visual too (accessibility: never audio-only)
            float top = a.y + a.height();
            if (raid.telegraphing(a, "swell")) { float k = 0.9f + 0.25f * (float) Math.sin(raid.time * 30); tmp.identity().translate(a.x, a.y + 1.0f, a.z).scale(k, k, k).translate(0, -0.5f, 0); mr.cube(tmp, 0x70A0D040, 1, 1); }
            if (raid.telegraphing(a, "retch")) { tmp.identity().translate(a.x, top + 0.05f, a.z).scale(0.3f, 0.3f, 0.3f).translate(0, -0.5f, 0); mr.cube(tmp, 0xE0B4E040, 1, 1); }
            if (raid.telegraphing(a, "screech") || raid.telegraphing(a, "shriek")) { tmp.identity().translate(a.x, top + 0.3f, a.z).scale(0.25f, 0.25f, 0.25f); mr.cube(tmp, 0xFFFF3020, 1, 1); }
            if (raid.telegraphing(a, "throw")) { tmp.identity().translate(a.x + (float) Math.cos(a.yaw) * 0.9f, top + 0.5f, a.z - (float) Math.sin(a.yaw) * 0.9f).scale(0.7f, 0.6f, 0.7f).translate(0, -0.5f, 0); mr.cube(tmp, 0xFF8A8478, 0.9f, 0); tmp.identity().translate(a.x, top + 1.4f, a.z).scale(0.3f, 0.3f, 0.3f); mr.cube(tmp, 0xFFFF7020, 1, 1); }
            if (raid.telegraphing(a, "charge")) { for (int k = 0; k < 3; k++) { tmp.identity().translate(a.x + (float) Math.sin(raid.time * 9 + k * 2) * 0.8f, a.y + 0.1f + k * 0.12f, a.z + (float) Math.cos(raid.time * 7 + k * 2) * 0.8f).scale(0.25f, 0.25f, 0.25f); mr.cube(tmp, 0xB0A09880, 0.9f, 0); } tmp.identity().translate(a.x, top + 0.4f, a.z).scale(0.3f, 0.3f, 0.3f); mr.cube(tmp, 0xFFFF3020, 1, 1); }
        }
        // ---- vehicles
        mr.material(); mr.flags = 0;
        raid.vehicles.draw(mr, env.camX, env.camZ, pos -> ActorRenderer.lightAt(raid.world, pos[0], pos[1] + 0.5f, pos[2], day));
        raid.doors.draw(mr, tmp, env.camX, env.camZ, pos -> ActorRenderer.lightAt(raid.world, pos[0], pos[1], pos[2], day));
        if (c.settings.vehicleDebug) raid.vehicles.debugDraw(mr, tmp);
        // ---- blood and severed parts (scene.Gore)
        Gore gore = raid.gore;
        for (Gore.Pool pl : gore.pools) {
            if (Math.abs(pl.x - env.camX) > 46 || Math.abs(pl.z - env.camZ) > 46) continue;
            float rad = pl.radius();
            if (rad < 0.05f) continue;
            float pl2 = ActorRenderer.lightAt(raid.world, pl.x, pl.y, pl.z, day);
            int col = Ui.alpha(Ui.mix(pl.color, 0xFF2A0C0A, 1 - pl.wet), 0.92f);
            mr.material(0.12f + (1 - pl.wet) * 0.6f, 0);
            mr.flags = absentialis.engine.render.DrawList.NO_SHADOW;
            col |= 0xFF000000;   // opaque in the deferred path: it is a surface, lit and reflective, not an overlay
            tmp.identity().translate(pl.x, pl.y + 0.012f, pl.z).rotateY(pl.id * 0.7f).scale(rad * 1.25f, 0.02f, rad * 1.25f).translate(0, 0, 0);
            mr.cube(tmp, col, pl2 + pl.wet * 0.15f, 0);
            for (int k = 0; k < 8; k++) {
                if (pl.r[k] < 0.12f) continue;
                float ang = k * 0.7854f, lr = pl.r[k];
                tmp.identity().translate(pl.x + (float) Math.cos(ang) * lr * 0.55f, pl.y + 0.014f, pl.z + (float) Math.sin(ang) * lr * 0.55f).rotateY(-ang).scale(lr * 0.95f, 0.018f, Math.max(0.12f, lr * 0.6f));
                mr.cube(tmp, col, pl2 + pl.wet * 0.15f, 0);
            }
        }
        mr.material(0.45f, 0);
        for (Gore.Stain st : gore.stains) {
            if (Math.abs(st.x - env.camX) > 40 || Math.abs(st.z - env.camZ) > 40) continue;
            tmp.identity().translate(st.x, st.y, st.z).scale(st.axis == 0 ? 0.02f : st.size, st.size * 1.3f, st.axis == 2 ? 0.02f : st.size).translate(0, -0.5f, 0);
            mr.cube(tmp, st.color, ActorRenderer.lightAt(raid.world, st.x, st.y, st.z, day), 0);
        }
        for (float[] dr : gore.drops) {
            float sz = 0.035f + dr[6] * 0.5f;
            tmp.identity().translate(dr[0], dr[1], dr[2]).scale(sz, sz * 1.6f, sz).translate(0, -0.5f, 0);
            mr.cube(tmp, dr[7] > 0 ? Gore.INFECTED_BLOOD : 0xFFA01814, 0.8f, 0);
        }
        mr.material(); mr.flags = 0;
        // detached parts: each region the piece carries, drawn from its own voxels in the pose it had when it came away
        c.ar.wounds.pump();
        for (absentialis.anatomy.DismembermentSystem.Piece pc : gore.dismember.pieces) {
            float[] pcc = pc.centre();
            if (Math.abs(pcc[0] - env.camX) > 70 || Math.abs(pcc[2] - env.camZ) > 70) continue;
            float pl = ActorRenderer.lightAt(raid.world, pcc[0], pcc[1], pcc[2], day);
            for (int g = 0; g < Rig.GROUPS; g++) {
                absentialis.anatomy.VoxelBody.Chunk ch = pc.body.chunks[g];
                if (ch == null || ch.empty() || pc.rel[g] == null) continue;
                tmp.set(pc.xform).mul(pc.rel[g]);
                mr.draw(c.ar.wounds.mesh("pc:" + pc.id + "#" + g, ch), tmp, pl, 0xFFFFFFFF, 0);
            }
        }
        // fragments knocked out of bodies
        mr.flags = absentialis.engine.render.DrawList.NO_SHADOW;
        for (Gore.Debris db : gore.debris) {
            if (Math.abs(db.x - env.camX) > 40 || Math.abs(db.z - env.camZ) > 40) continue;
            tmp.identity().translate(db.x, db.y, db.z).rotateY(db.spin).scale(db.size, db.size, db.size).translate(0, -0.5f, 0);
            mr.cube(tmp, db.life < 1 ? Ui.alpha(db.color, db.life) : db.color, 0.8f, 0);
        }
        mr.flags = 0;
        for (Raid.WorldItem w : raid.items) {
            VoxModel m = ItemModels.of(w.it);
            float s = 1 / 40f;
            tmp.identity().translate(w.x, w.y + 0.05f + (float) Math.sin(raid.time * 2 + w.x) * 0.03f, w.z).rotateY(raid.time * 0.6f + w.z).scale(s, s, s);
            mr.draw(mr.mesh("w:" + w.it.visualKey(), m, 1), tmp, ActorRenderer.lightAt(raid.world, w.x, w.y, w.z, day) + 0.15f, 0xFFFFFFFF, 0.15f);
        }
        if (raid.playerLaser && !raid.player.dead) {
            // the beam everyone else can see: from the weapon to the first thing it touches
            Actor pl = raid.player;
            float lx = (float) (-Math.sin(pl.yaw) * Math.cos(pl.pitch)), ly = (float) Math.sin(pl.pitch), lz = (float) (-Math.cos(pl.yaw) * Math.cos(pl.pitch));
            int[] lh = Physics.ray(raid.world, eyeX, eyeY, eyeZ, lx, ly, lz, 40, false);
            float ll = lh == null ? 40 : (float) Math.sqrt((lh[0] + 0.5f - eyeX) * (lh[0] + 0.5f - eyeX) + (lh[1] + 0.5f - eyeY) * (lh[1] + 0.5f - eyeY) + (lh[2] + 0.5f - eyeZ) * (lh[2] + 0.5f - eyeZ));
            float rx2 = (float) Math.cos(pl.yaw) * 0.12f, rz2 = (float) -Math.sin(pl.yaw) * 0.12f;
            mr.beam(eyeX + rx2 + lx * 0.5f, eyeY - 0.12f + ly * 0.5f, eyeZ + rz2 + lz * 0.5f, eyeX + lx * ll, eyeY + ly * ll, eyeZ + lz * ll, 0.012f, 0xC040FF50, 1);
        }
        for (Raid.Thrown t : raid.thrown) {
            float sz = t.debris ? 0.55f : 0.12f;
            tmp.identity().translate(t.x, t.y, t.z).rotateY(raid.time * 5).rotateX(raid.time * 7).scale(sz, sz, sz).translate(0, -0.5f, 0);
            mr.cube(tmp, t.debris ? 0xFF8A8478 : 0xFF4A5030, 0.8f, 0);
        }
        for (Raid.Projectile pr : raid.projectiles) {
            if (!pr.tracer && pr.owner == raid.player.id) continue;
            mr.beam(pr.px, pr.py, pr.pz, pr.x, pr.y, pr.z, pr.tracer ? 0.04f : 0.015f, pr.tracer ? 0xFFFFC060 : 0x80FFF0C0, 1);
        }
        for (Raid.Effect e : raid.effects) {
            tmp.identity().translate(e.x, e.y, e.z).scale(e.size, e.size, e.size).translate(0, -0.5f, 0);
            mr.cube(tmp, Ui.alpha(e.color, Math.min(1, e.life / e.max * 2)), e.glow ? 1 : 0.7f, e.glow ? 1 : 0);
        }
        // hazard zones: a stippled pool so the edge of the danger is readable
        if (c.hr == null) raid.fire.drawLegacy(mr, tmp);
        for (Raid.Zone z : raid.zones) {
            if (z.kind.equals("fire")) continue;   // real flames mark it (scene.FireSystem)
            int col = z.kind.equals("contam") ? 0x508CA83A : 0x70B4D040;
            for (int k = 0; k < 14; k++) {
                float ang = k * 2.4f + z.x, rad = z.radius * (float) Math.sqrt((k + 0.5f) / 14f);
                tmp.identity().translate(z.x + (float) Math.sin(ang) * rad, z.y + 0.02f, z.z + (float) Math.cos(ang) * rad).scale(0.9f, 0.04f, 0.9f).translate(0, 0, 0);
                mr.cube(tmp, col, 1, 0.6f);
            }
        }
        // smoke columns over places where the strategic tier resolved a fight
        for (float[] sm : raid.smoke) {
            if (raid.player.distXZ(sm[0], sm[2]) > 220) continue;
            for (int k = 0; k < 10; k++) {
                float t = (raid.time * 0.25f + k / 10f) % 1f, sz = 0.5f + t * 2.2f;
                tmp.identity().translate(sm[0] + (float) Math.sin(t * 5 + k) * t * 2.5f, sm[1] + t * 26, sm[2] + t * 4).scale(sz, sz, sz).translate(0, -0.5f, 0);
                mr.cube(tmp, Ui.alpha(0xFF2A2826, (1 - t) * 0.55f), 0.5f, 0);
            }
        }
        if (raid.noiseDebug) for (Raid.Sound s : raid.sounds) {
            float age = raid.time - s.time(), rad = s.radius() * Math.min(1, age * 3);
            for (int k = 0; k < 24; k++) {
                double a0 = k * Math.PI * 2 / 24, a1 = (k + 1) * Math.PI * 2 / 24;
                mr.beam(s.x() + (float) Math.sin(a0) * rad, s.y(), s.z() + (float) Math.cos(a0) * rad, s.x() + (float) Math.sin(a1) * rad, s.y(), s.z() + (float) Math.cos(a1) * rad, 0.06f, Ui.alpha(0xFF40C0FF, 1 - age / 4), 1);
            }
        }
        // extraction beacons: visible signal columns at eligible exits nearby
        for (Raid.ExitState s : raid.exits) {
            if (!s.eligible) continue;
            float d = raid.player.distXZ(s.exit.x, s.exit.z);
            if (d > 120 || !c.profile.discovered(s.exit.x / 8, s.exit.z / 8)) continue;
            tmp.identity().translate(s.exit.x + 0.5f, s.exit.y, s.exit.z + 0.5f).scale(0.15f, 18f, 0.15f);
            mr.cube(tmp, 0x5050FF70, 1, 1);
        }
        mr.end();
    }

    // ------------------------------------------------------------------ first-person viewmodel
    /** Viewmodel space is a miniature of the world in front of the camera: this is one character voxel there. */
    private static final float VM_VOX = Rig.VOX * 40f / 88f;
    private final Mat4 vmWeapon = new Mat4(), vmBone = new Mat4();
    private final float[] vt = new float[3], ve = new float[3];

    /**
     * Weapon and both arms. The weapon follows the same action clips as the third-person body
     * (tactical reload, empty reload with a rack, shell loading, jam clearing), so a reload looks
     * different depending on whether a round is still chambered. Sway lags the mouse and scales
     * with the weapon's mass; the arms are the player's own sleeves and gloves, solved onto the grips.
     */
    private void drawViewmodel(float fov, float aspect) {
        ItemInstance h = held();
        if (h == null) return;
        Actor p = raid.player;
        Animator an = p.anim;
        if (!c.mr.recording()) glClear(GL_DEPTH_BUFFER_BIT);
        Mat4 vp = new Mat4().perspective((float) Math.toRadians(60), aspect, 0.01f, 10f);
        WorldRenderer.Env e = new WorldRenderer.Env();
        e.fogDensity = 0; e.camX = 0; e.camY = 0; e.camZ = 0;
        c.mr.begin(vp, e);
        VoxModel m = ItemModels.of(h);
        boolean melee = h.def().weapon != null && h.def().weapon.melee();
        boolean pistol = !melee && "sidearm".equals(h.def().slot);
        float s = 1 / 88f;
        // weight: heavier weapons lag further behind the look, drift more at rest and settle slower
        float mass = Math.max(0.4f, h.mass()), heft = 0.6f + mass * 0.16f;
        float dt = c.ui.dt;
        float lagX = overlay() ? 0 : (float) -c.in.dx * 0.00045f * heft, lagY = overlay() ? 0 : (float) c.in.dy * 0.00045f * heft;
        swayX += (Math.max(-0.05f, Math.min(0.05f, lagX)) - swayX) * Math.min(1, dt * (14f / heft));
        swayY += (Math.max(-0.05f, Math.min(0.05f, lagY)) - swayY) * Math.min(1, dt * (14f / heft));
        float tired = 1 + (1 - raid.body.stamina / 100f) * 1.5f;
        // through the sights the weapon is held to the eye: lag, drift and gait bob are almost entirely taken out,
        // leaving the breath - what moves the point of aim is recoil and the shooter's condition, not the walk cycle
        float ak = adsK, hip = 1 - ak, loose = 1 - ak * 0.92f;
        float breath = 1 + (1 - raid.body.focus / 100f) * 0.8f + raid.combat.animation[raid.combat.condition(p.hp, p.maxHp).ordinal()] * 1.2f;
        float idleX = (float) Math.sin(raid.time * 0.9f) * 0.0022f * heft * tired * (hip + ak * 0.10f * breath), idleY = (float) Math.sin(raid.time * 1.3f + 1) * 0.0018f * heft * tired * (hip + ak * 0.14f * breath);
        // gait bob straight from the animated footfalls
        float ph = an.phase * 6.2832f, walk = bobAmt * (1 - ak * 0.95f);
        float bobX = (float) Math.sin(ph) * 0.010f * walk, bobY = -Math.abs((float) Math.cos(ph)) * 0.008f * walk;
        // action clip (weapon channel) relative to the shouldered pose
        float aw = 0;
        Anims.get("wpn_aim").sample(0, vmBase);
        vmPose.set(vmBase);
        if (!an.action.isEmpty() && Anims.get(an.action).drivesWeapon && !Anims.get(an.action).additive && !an.action.equals("equip")) {
            Anims.get(an.action).sample(an.actionTime / an.actionDur, vmPose);
            aw = Math.max(0, Math.min(1, Math.min(an.actionTime / Animator.BLEND, (an.actionDur - an.actionTime) / Animator.BLEND)));
        }
        float dxp = (vmPose.wpn[0] - vmBase.wpn[0]) * aw, dyp = (vmPose.wpn[1] - vmBase.wpn[1]) * aw, dzp = (vmPose.wpn[2] - vmBase.wpn[2]) * aw;
        float dpitch = (vmPose.wpn[3] - vmBase.wpn[3]) * aw, dyaw = (vmPose.wpn[4] - vmBase.wpn[4]) * aw, droll = (vmPose.wpn[5] - vmBase.wpn[5]) * aw;
        float sw = Math.max(0, switchT) / 0.45f;
        float sight = melee ? -0.06f : sightLine(h, m, s);
        float ax = 0.13f * hip + swayX * loose + idleX + bobX + dxp * VM_VOX;
        float ay = -0.13f * hip + sight * ak + swayY * loose + idleY + bobY + dyp * VM_VOX - sw * sw * 0.32f - landDip * 0.4f * hip;
        float az = -0.34f + ak * 0.045f + kick * (0.03f + 0.022f * firePunch) + dzp * VM_VOX;
        float sprintLower = p.sprinting ? 1 : 0;
        vmWeapon.identity().translate(ax, ay - sprintLower * 0.05f, az)
                .rotateY(dyaw + hip * 0.06f - swayX * 2.5f * loose + sprintLower * 0.5f + sw * 0.4f)
                .rotateX(kick * (0.05f + 0.035f * firePunch - ak * 0.03f) + dpitch * 0.8f + swayY * 2.5f * loose - sw * 0.9f - sprintLower * 0.25f)
                .rotateZ(droll * 0.7f - swayX * 3f * loose + lean * -0.12f * hip);
        Mat4 mm = new Mat4().set(vmWeapon).rotateY((float) Math.PI / 2).scale(s, s, s).translate(m.sx * 0.22f, -m.sy * 0.55f, 0);
        if (melee) mm.rotateZ(meleeT > 0 ? -1.2f * meleeT : 0);
        float light = Math.max(0.25f, ActorRenderer.lightAt(raid.world, p.x, p.y, p.z, raid.daylight())) + raid.muzzleFlash * 0.4f;
        c.mr.material(0.46f, 0.55f);
        c.mr.draw(c.mr.mesh("w:" + h.visualKey(), m, 1), mm, light, 0xFFFFFFFF, 0);
        c.mr.material();

        // hands: firing grip, and the support hand on the fore-end or wherever the clip sends it
        float gz = -0.06f * m.sx * s, gy = -0.17f * m.sy * s;
        vmWeapon.transformPoint(0.004f, gy - 0.012f, gz + 0.01f, vt);
        if (melee) vmWeapon.transformPoint(0, -0.5f * m.sy * s, 0.30f * m.sx * s, vt);
        arm(playerLook, true, vt[0], vt[1], vt[2], 0.17f, -0.30f, -0.06f, light);
        if (!melee) {
            float sep = pistol ? 0.012f : 0.34f * m.sx * s;
            float lx = vmPose.lhOnWeapon > 0.5f ? vmPose.wpn[6] * aw : 0, ly = vmPose.lhOnWeapon > 0.5f ? vmPose.wpn[7] * aw : 0, lz = vmPose.lhOnWeapon > 0.5f ? vmPose.wpn[8] * aw : 0;
            vmWeapon.transformPoint((pistol ? -0.012f : 0) + lx * VM_VOX, gy + (pistol ? -0.012f : 0.006f) + ly * VM_VOX, gz - sep + lz * VM_VOX, vt);
            if (aw > 0 && vmPose.lhOnWeapon < 0.5f) {
                // free hand (interact / heal): an eye-space reach instead of a grip
                float k = aw;
                vt[0] += (vmPose.wpn[6] * VM_VOX * 1.6f - 0.02f - vt[0]) * k; vt[1] += (-0.20f + (vmPose.wpn[7] + 6) * VM_VOX - vt[1]) * k; vt[2] += (-0.30f + vmPose.wpn[8] * VM_VOX * 0.6f - vt[2]) * k;
            }
            arm(playerLook, false, vt[0], vt[1], vt[2], -0.12f, -0.32f, -0.14f, light);
            // the fresh magazine travels in the support hand from the pouch to the well
            if (reloadT > 0 && reloadMag != null && ("mag".equals(reloadKind) || "speed".equals(reloadKind))) {
                float t = 1 - reloadT / Math.max(0.01f, reloadMax), t0 = reloadEmpty ? 0.40f : 0.52f, t1 = reloadEmpty ? 0.66f : 0.84f;
                if (t > t0 && t < t1) {
                    VoxModel mg = ItemModels.of(reloadMag);
                    vmBone.identity().translate(vt[0], vt[1] + 0.01f, vt[2]).rotateY((float) Math.PI / 2 + dyaw).rotateZ(-0.2f).scale(s, s, s).translate(0, -mg.sy * 0.2f, 0);
                    c.mr.draw(c.mr.mesh("w:" + reloadMag.visualKey(), mg, 1), vmBone, light, 0xFFFFFFFF, 0);
                }
            }
        }
        if (raid.muzzleFlash > 0.2f && h.def().weapon != null && !melee) {
            float[] mz = new float[3];
            mm.transformPoint(m.sx / 2f + 1, m.sy * 0.6f, 0, mz);
            float fs = 0.05f * raid.muzzleFlash;
            Mat4 fm = new Mat4().translate(mz[0], mz[1] - fs / 2, mz[2]).scale(fs, fs, fs);
            c.mr.cube(fm, 0xB0FFD070, 1, 1);
        }
        c.mr.end();
    }

    /** One viewmodel arm: forearm and hand run from an off-screen elbow to the hand target, upper arm behind it. */
    private void arm(ActorRenderer.Look look, boolean right, float tx, float ty, float tz, float ex, float ey, float ez, float light) {
        float ux = tx - ex, uy = ty - ey, uz = tz - ez, ul = (float) Math.sqrt(ux * ux + uy * uy + uz * uz);
        if (ul < 1e-4f) return;
        ux /= ul; uy /= ul; uz /= ul;
        float k = VM_VOX, fore = 7 * k;
        // forearm pivot (elbow) sits a forearm-and-hand behind the target
        float px = tx - ux * fore, py = ty - uy * fore, pz = tz - uz * fore;
        int up = right ? Rig.R_UPPER_ARM : Rig.L_UPPER_ARM;
        Rig.aimBone(vmBone, px, py, pz, ux, uy, uz, k);
        c.ar.drawPart(look, up + 1, vmBone, light);
        Rig.aimBone(vmBone, px + ux * 5 * k, py + uy * 5 * k, pz + uz * 5 * k, ux, uy, uz, k);
        c.ar.drawPart(look, up + 2, vmBone, light);
        // upper arm from an off-screen shoulder down to the elbow
        float sx = right ? 0.24f : -0.22f, sy = -0.46f, sz = 0.10f;
        float wx = px - sx, wy = py - sy, wz = pz - sz, wl = (float) Math.sqrt(wx * wx + wy * wy + wz * wz);
        wx /= wl; wy /= wl; wz /= wl;
        Rig.aimBone(vmBone, px - wx * 5 * k, py - wy * 5 * k, pz - wz * 5 * k, wx, wy, wz, k);
        c.ar.drawPart(look, up, vmBone, light);
    }

    /**
     * The picture through a magnified scope: the tube's shadow round a clear circle, a fine crosshair that thickens
     * toward the edge (the eye finds the centre by following the bars in), range marks on the lower limb, and no
     * dot over the point of aim - only where the hairs would cross.
     */
    private void scopeOverlay(Ui ui, int W, int H) {
        float r = Math.min(W, H) * 0.44f;
        float cx = W / 2f, cy = H / 2f;
        ui.b.rect(0, 0, cx - r, H, 0xFF000000); ui.b.rect(cx + r, 0, W - cx - r, H, 0xFF000000);
        ui.b.rect(cx - r, 0, 2 * r, cy - r, 0xFF000000); ui.b.rect(cx - r, cy + r, 2 * r, H - cy - r, 0xFF000000);
        // the round edge of the tube: the corners of the square are filled in, row by row
        int rows = (int) r, step = Math.max(1, ui.s(2));
        for (int y = -rows; y < rows; y += step) {
            float half = (float) Math.sqrt(Math.max(0, r * r - (y + step * 0.5f) * (y + step * 0.5f)));
            ui.b.rect(cx - r, cy + y, r - half, step, 0xFF000000); ui.b.rect(cx + half, cy + y, r - half, step, 0xFF000000);
            float soft = r * 0.06f;
            ui.b.rect(cx - half, cy + y, soft, step, 0x70000000); ui.b.rect(cx + half - soft, cy + y, soft, step, 0x70000000);
        }
        float gap = r * 0.035f, thin = Math.max(1, ui.s(1)), thick = Math.max(2, ui.s(3)), inner = r * 0.42f;
        ui.b.rect(cx - inner, cy - thin / 2, inner - gap, thin, 0xE0000000); ui.b.rect(cx + gap, cy - thin / 2, inner - gap, thin, 0xE0000000);
        ui.b.rect(cx - thin / 2, cy - inner, thin, inner - gap, 0xE0000000); ui.b.rect(cx - thin / 2, cy + gap, thin, inner - gap, 0xE0000000);
        ui.b.rect(cx - r, cy - thick / 2, r - inner, thick, 0xF0000000); ui.b.rect(cx + inner, cy - thick / 2, r - inner, thick, 0xF0000000);
        ui.b.rect(cx - thick / 2, cy + inner, thick, r - inner, 0xF0000000);
        for (int k = 1; k <= 3; k++) { float my = cy + gap + (inner - gap) * k / 4f, mw = r * (0.05f - k * 0.008f); ui.b.rect(cx - mw, my, mw * 2, thin, 0xE0000000); }
    }

    /**
     * Looking through a red dot or a holographic sight: the dot (or ring and dot) the sight projects, at the point of
     * aim. It is small, bright and sits on the target without hiding it; the weapon's own sight window frames it.
     */
    private void dotOverlay(Ui ui, int W, int H, boolean holo, float k) {
        float cx = W / 2f, cy = H / 2f;
        int red = Ui.alpha(0xFFFF3A28, k), glow = Ui.alpha(0xFFFF3A28, k * 0.22f);
        float d = Math.max(2, ui.s(3));
        ui.b.rect(cx - d * 1.5f, cy - d * 1.5f, d * 3, d * 3, glow);
        ui.b.rect(cx - d / 2, cy - d / 2, d, d, red);
        if (!holo) return;
        float rr = ui.s(26), t = Math.max(1, ui.s(2));
        for (int i = 0; i < 48; i++) {
            if (i % 12 == 0) continue;                              // four breaks in the ring, at the quarters
            double a = i / 48.0 * Math.PI * 2;
            ui.b.rect(cx + (float) Math.cos(a) * rr - t / 2, cy + (float) Math.sin(a) * rr - t / 2, t, t, red);
        }
        for (int q = 0; q < 4; q++) { float ax = q == 0 ? 1 : q == 2 ? -1 : 0, ay = q == 1 ? 1 : q == 3 ? -1 : 0; ui.b.rect(cx + ax * (rr + ui.s(5)) - (ax != 0 ? ui.s(4) : t / 2), cy + ay * (rr + ui.s(5)) - (ay != 0 ? ui.s(4) : t / 2), ax != 0 ? ui.s(8) : t, ay != 0 ? ui.s(8) : t, red); }
    }

    private void drawMinimap(Ui ui) {
        float s = ui.s(180), x = ui.w - s - ui.s(18), y = ui.s(18);
        ui.nine("panel_dark", x - ui.s(6), y - ui.s(6), s + ui.s(12), s + ui.s(12), 0xE0FFFFFF);
        float span = 120;
        c.map.draw(ui, c.profile, x, y, s, s, raid.player.x - span / 2, raid.player.z - span / 2, span, raid.exits, raid.player.x, raid.player.z, raid.player.yaw, false);
        status.minimapContacts(ui, x, y, s, raid.player.x - span / 2, raid.player.z - span / 2, span);
        District d = raid.world.district(raid.player.x, raid.player.z);
        ui.textR(d.display.toUpperCase(), x + s, y + s + ui.s(10), 12, Ui.TXT);
        float out = raid.world.exposure(raid.player.x, raid.player.z);
        if (out > 0) ui.textR("RADIATION ZONE", x + s, y + s + ui.s(28), 12, Ui.RED);
        // the clock runs: schedules, staffing and what the dark hides all follow it
        double hr = raid.hour() % 24;
        ui.text(String.format("%02d:%02d  %s", (int) hr, (int) (hr * 60) % 60, raid.night() ? "NIGHT" : raid.daylight() < 0.95f ? (hr < 12 ? "DAWN" : "DUSK") : "DAY"), x, y + s + ui.s(10), 12, raid.night() ? Ui.BLUE : Ui.TXT);
        if (Block.trunk(raid.world.get((int) Math.floor(raid.player.x), World.GROUND - 1, (int) Math.floor(raid.player.z))) || Block.trunk(raid.world.get((int) Math.floor(raid.player.x) + 2, World.GROUND - 1, (int) Math.floor(raid.player.z))) || Block.trunk(raid.world.get((int) Math.floor(raid.player.x), World.GROUND - 1, (int) Math.floor(raid.player.z) + 2)))
            ui.textR("RING ROAD - follow the double line to any district", x + s, y + s + ui.s(46), 11, Ui.AMBER);
    }

    private void drawMap(Ui ui) {
        ui.b.rect(0, 0, ui.w, ui.h, 0xD0080807);
        float s = Math.min(ui.w, ui.h) - ui.s(120), x = (ui.w - s) / 2, y = ui.s(70);
        ui.window("Field Map  -  " + raid.profile.zone.day + "d " + String.format("%02d:00", (int) (raid.profile.zone.hour + raid.time / 120) % 24), "map", x - ui.s(12), y - ui.s(56), s + ui.s(24), s + ui.s(70));
        float span = World.W / mapZoom;
        float cx = Math.max(span / 2, Math.min(World.W - span / 2, raid.player.x)), cz = Math.max(span / 2, Math.min(World.D - span / 2, raid.player.z));
        c.map.draw(ui, c.profile, x, y, s, s, cx - span / 2, cz - span / 2, span, raid.exits, raid.player.x, raid.player.z, raid.player.yaw, true);
        c.map.legend(ui, c.profile, x + s + ui.s(30), y);
        float ly = y + ui.s(220);
        ui.text("EXITS", x + s + ui.s(30), ly, 14, Ui.TXT_HI);
        for (Raid.ExitState e : raid.exits) {
            ly += ui.s(34);
            if (ly > ui.h - ui.s(40)) break;
            ui.text(e.exit.name, x + s + ui.s(30), ly, 13, e.eligible ? Ui.GREEN : Ui.TXT_DIM);
            ui.text(e.requirement, x + s + ui.s(30), ly + ui.s(15), 10, Ui.TXT_DIM);
        }
        ui.text("[Scroll] zoom   [M] close", x, y + s + ui.s(8), 12, Ui.TXT_DIM);
    }

    private void drawInventory(Ui ui, float dt) {
        ui.b.rect(0, 0, ui.w, ui.h, 0xC8060706);
        var inv = c.inv;
        inv.begin(36);
        float pad = ui.s(24);
        inv.fit(ui.h - ui.s(48) - ui.s(40) - ui.s(44) - ui.s(150), lo().caseGrid.h + (lo().packGrid() == null ? 0 : lo().packGrid().h + 2));
        float rightW = panel.width(lo());
        float leftW = lootSide != null ? Math.max(lootSide.w * inv.cell + ui.s(24), ui.s(300)) : ui.s(300);
        float inspW = ui.s(300);
        float total = leftW + rightW + inspW + pad * 4;
        float x0 = Math.max(pad, (ui.w - total) / 2);
        float top = ui.s(48);
        // left: container / corpse / ground
        float lh = ui.h - top - ui.s(40);
        float cy = ui.window(lootSide != null ? "Searching" : "Nearby", "search", x0, top, leftW + pad, lh);
        if (lootSide != null) inv.grid(lootSide, x0 + ui.s(16), cy + ui.s(30), lootSide.label);
        else ui.wrap("Nothing open. Search containers, bodies or pick items up with [F]. Shift+click moves items between sides.", x0 + ui.s(16), cy + ui.s(8), leftW - ui.s(8), 13, Ui.TXT_DIM);
        // right: loadout (gear, charms, case, tabs)
        float rx = x0 + leftW + pad * 2;
        float ry = ui.window("Survivor  -  " + c.profile.name, "inv", rx, top, rightW + pad, lh);
        panel.draw(c.profile, rx + ui.s(12), ry, rightW, lh - (ry - top) - ui.s(20), lootSide);
        // right: the character status panel, with the inspected item beneath it
        float ix = rx + rightW + pad * 2;
        float sh = Math.min(Math.round(lh * 0.64f), ui.s(540));
        status.statusPanel(ui, new absentialis.ui.Layout.Box(ix, top, inspW, sh), held(), playerLook);
        inv.inspectPanel(ix, top + sh + ui.s(10), inspW, lh - sh - ui.s(10));
        ui.text("[F]/[I]/[Esc] close   [R] rotate   [Shift+Click] transfer   [RMB] actions   [Z] sort case   hold [F] over an item to inspect", x0, ui.h - ui.s(30), 12, Ui.TXT_DIM);
        if (c.in.pressed("sort")) { InventoryService.Result r = InventoryService.autoSort(lo().caseGrid); inv.say(r.ok() ? "Case sorted" : r.msg(), r.ok() ? Ui.GREEN : Ui.RED); }
        inv.end();
        // 0.6: the key that opened the menu closes it. A tap of [F] (the interact binding) shuts the menu, as Escape does;
        // holding it past the tap time over an item is the full-screen inspect it always was. The press that opened the
        // menu is ignored until the key has been let go once.
        boolean fDown = c.in.down("interact");
        boolean shut = false;
        if (!fDown) {
            if (!inspectWait && !inspectArmed && fHeld > 0 && fHeld < F_TAP) shut = true;
            inspectWait = false; inspectArmed = false; fHeld = 0;
        } else if (!inspectWait) {
            fHeld += dt;
            if (!inspectArmed && fHeld >= F_TAP && inv.hover != null) { inspectArmed = true; inv.inspected = inv.hover; }
        }
        if (inspectArmed) inv.fullInspect(inspectYaw + inv.spin * 0.2f, inspectPitch);
        autoCloseLoot(dt);
        if (shut && invOpen) closeInventory();
    }

    private void drawPause(Ui ui) {
        ui.b.rect(0, 0, ui.w, ui.h, 0xB0000000);
        float w = ui.s(360), h = ui.s(330), x = (ui.w - w) / 2, y = (ui.h - h) / 2;
        float cy = ui.window("Paused", "cog", x, y, w, h);
        float bw = w - ui.s(48), bh = ui.s(44);
        if (ui.button("p_resume", x + ui.s(24), cy + ui.s(6), bw, bh, "RESUME", "arrow", true)) paused = false;
        if (ui.button("p_settings", x + ui.s(24), cy + ui.s(58), bw, bh, "SETTINGS", "cog", true)) pauseAction = "settings";
        if (ui.button("p_abandon", x + ui.s(24), cy + ui.s(110), bw, bh, "ABANDON RAID (MIA)", "skull", true)) { raid.debrief.outcome = Raid.Debrief.Outcome.MIA; raid.debrief.reason = "Abandoned the operation"; paused = false; }
        if (ui.button("p_quit", x + ui.s(24), cy + ui.s(162), bw, bh, "QUIT TO DESKTOP", "cross", true)) pauseAction = "quit";
        ui.text("Quitting mid-raid counts as missing in action.", x + ui.s(24), cy + ui.s(222), 12, Ui.TXT_DIM);
    }

    public String pauseAction;

    private void aiDebug(Ui ui) {
        float[] o = new float[3];
        for (Actor a : raid.actors) {
            if (a.isPlayer || a.dead || a.distXZ(raid.player.x, raid.player.z) > 80) continue;
            float w = pv.project(a.x, a.y + a.height() + 0.4f, a.z, o);
            if (w <= 0) continue;
            float sx = (o[0] * 0.5f + 0.5f) * ui.w, sy = (1 - (o[1] * 0.5f + 0.5f)) * ui.h;
            int col = "engage".equals(a.state) ? Ui.RED : "investigate".equals(a.state) || "search".equals(a.state) ? Ui.AMBER : Ui.GREEN;
            ui.textC(a.faction + "/" + a.archetype + " " + a.state + (a.hostileToPlayer ? " H" : "") + String.format(" aw%.1f T%d", a.awareness, a.tier), sx, sy, 11, col);
            if (!a.infected()) ui.textC(absentialis.ai.Tactics.describe(a) + (a.memConfirmed ? "  seen" : "  hearsay") + String.format(" %.0fs  err %.0fm", raid.time - a.memTime, a.memErr) + (a.anat == null ? "" : "  " + AIInjuryAdapter.describe(a)), sx, sy + ui.s(12), 10, Ui.TXT_DIM);
        }
        ui.text("AI tiers: active " + raid.actors.stream().filter(a -> !a.dead && a.tier == 0).count() + "  regional " + raid.actors.stream().filter(a -> !a.dead && a.tier == 1).count() + "  population " + raid.populationTotal(), ui.s(8), ui.s(110), 12, Ui.AMBER);
    }
}
