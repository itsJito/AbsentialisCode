# Changelog

Newest first. Each version lists what changed for the player; file names are given where they help find the work.
What was verified for 0.6, and how, is in `docs/V0.6_IMPLEMENTATION.md`.

## Version 0.6

### World and buildings
- The map, its districts and its roads are unchanged. **Buildings were rebuilt**: a late-Soviet street - panel
  blocks with balconies, sand-lime and red brick, dark plinths, concrete entrance canopies, windows two panes tall.
- **Stairs fixed.** Every flight has a fourth tread level with the floor it reaches and clear head room over every
  tread (0.5 stopped one rise short and left the slab over the first step).
- Two-cell entrances are **double doors**: one object, two leaves.
- Interiors are **furnished densely** (about half of every room's wall is taken), storage stands two tiers high,
  corridors have the two-tone painted wall, and every room has its light fitting, lit or dead.
- **Textures redrawn at 64 x 64** (were 32 x 32): masonry, panels, plaster, roofing, floors, carpets, ceilings.
  Windows are a casement round a pane. No redrawn texture carries lettering; torn wallpaper and the ringed lamp
  are gone.
- **Fog bank**: the world dissolves from 48 m and is gone by 165 m, inside the draw distance, so nothing is drawn
  at its edge. Nearer at night and in rain. Nobody sees or shoots through it either (`content/combat.json`).
- A broken window leaves **physical shards**, thrown the way the round was going.

### Movement and camera
- **No auto-jump**, for the player or anyone else: a block in the way is jumped, stairs are walked.
- **Third person rebuilt**: right-shoulder camera with free look, smooth tracking, aim zoom, and framing that
  follows what the body is doing; movement relative to the camera in every direction; the body turns to its
  travel; weighted acceleration and turning; a **slide** from crouching after two seconds of sprint. Sprint can be
  held or toggled; distance, shoulder and smoothing are settings.
- Characters **do not pass through each other**. Bodies push doors open; a door rests against someone standing in it.
- Fixed: a door could push you up a floor. Fixed: A steered the car right.

### Combat
- **Sydney Engine** (`sydney/*`, `content/sydney.json`): the passive ragdoll became an active one. A hit body is
  given to physics with the momentum of the blow where it landed; sensors read its balance, virtual muscles
  (bounded PD torques) work to keep it up, and the solver decides. It sways, catches itself with a step, or goes
  down reaching for the ground, lies there, and gets up under its own strength - or is left to crawl if a leg is
  gone. People put a hand to the wound; the infected take more to put down and do not. The player's character is
  given to it only by death. Console: `sydney on|off|stats`.
- **Shotguns** hit much harder; a close-range head shot takes the head off. **Handguns never do.**
- A pump shotgun is **racked after a full reload** before it will fire.
- Firing has weight by weapon: a handgun snaps, a shotgun or a magnum rocks the upper body and settles more slowly.
- **Optics help**: the red dot and the holographic sight are open windows with a projected reticle; scopes have a
  proper sight picture.
- **Gun audio** levelled by measurement: no firearm is quiet, shotguns are the heaviest report, the crossbow has
  its own sound. The industrial hum and static are gone.
- Fixed: crash when drawing a weapon from the Tab wheel. Fixed: the AI could not use ladders.

### People
- **Male or female** bodies (narrower arms, trunk and head; six more hairstyles). Generated names are American
  and match the body.
- **Name tags** over heads in the colour the minimap gives them; squadmates' are always shown.
- The dead **close their eyes**. The infected **eat human corpses**, which waste away and are finally gone.
- AI sight uses three lines to a body (half hidden is half as noticeable), registers the edge of its vision more
  slowly, and looks along the ground until alerted; a floor between muffles sound; the alerted hear further.
- **Barter** with anyone not hostile - goods for goods, on terms set by what their group thinks of you - and pass
  kit freely to and from **squadmates** ([F], facing them).
- **Squadmate permadeath**: a squadmate who dies is gone, with rank and record; replacements are recruited and
  paid for.

### Vehicles
- The driver's door is a **real door** on the door engine: it opens to let you in, shuts behind you, takes damage
  on its hinge and its latch, and can be shot off - after which there is no door to open.
- Getting in and out have their own animations. **Squadmates ride along** (up to three) and get out when you do.

### Items and interface
- The **flashlight is an object**: carry one in the case (one is issued to every profile) or fit the Mounted
  Flashlight to any firearm from the first day. [L], rebindable.
- Herbs are the colour they are called; **Green + Red + Yellow** is a new mixture and shows all three.
- **Six ammunition models**, one per calibre. Shop tabs: a handgun for Weapons, cartridges for Ammo.
- **XP bar** with the percentage to the next Rank, and a line for every award as it is earned.
- **Profile card** with ten backgrounds unlocked by Rank; squadmates have the same card.
- [F] closes the loot menu. Dev console: `money`, `vehicle`.

### The Zone
- **Alliance**, chosen once after creating a profile (Military, Bandits, Loners, Mercenaries): it decides where
  you can deploy from and what work you are offered.
- **Population** sliders before profile creation, overall and per group.
- **Leaderboard** tab on the deployment screen: everyone alive, ranked. Every NPC has a Rank.
- **Group Rivalry System** (`rivalry/*`, `content/rivalry.json`): groups and their leaders remember what you do
  and what they hear of it, adapt to it and act on it; a Rivalries tab shows where you stand and what you can do.
- Fixed: extraction points on the city wall read as Wilderness and irradiated you.

### Project
- Version 0.6 in one place (`absentialis.Version`); save format 6 with migration from 5 (nothing is lost: a
  flashlight is issued, generated squad names are redrawn, typed names are kept).
- 483 quality gates (89 new for 0.6).

## Version 0.5

### World
- Rewrote city generation as a twelve-stage, data-driven pipeline (`content/districts.json`,
  `content/buildings.json`): district layout by terrain suitability, protected road network, lots, landmark
  compounds, room-graph interiors, furnishing, validation with repair or rejection, and a generation report.
- Six environments: Residential, Industrial, Governmental, Downtown, Outskirts, Wilderness. Each developed district
  has exactly two landmark compounds and one faction headquarters.
- Every room of every building is reachable from the street; buildings that cannot be made so are repaired or removed.
- Fixed: the perimeter trench; glass-like towers outside the boundary; floating dead-tree canopies; canopies
  blocking road cells.
- Cover points generated from world geometry, per chunk, invalidated when blocks change.
- Debug layers as PNGs (`ABS_GENDUMP`): plan, footprints, rooms, navigation, invalid cells, materials, cover.

### Combat and characters
- Tactical AI: utility-scored intents (hold, peek, suppress, advance, relocate, withdraw) over a squad blackboard;
  cover selection from the cover map; leaning and pop-up fire; chokepoint awareness; rescue of downed allies.
- Casualty state machine ACTIVE -> DOWNED -> REVIVING -> ACTIVE (or DEAD): 20 s bleed-out, 4 s revive,
  interruptible. Infected are never downed. Fatal regions and catastrophic damage always kill.
- Fixed: the player's body vanished on death.
- Four health conditions with configurable thresholds (`content/combat.json`) affecting speed, sprint, aim and
  animation.
- Cover for the player in first and third person; cover and injury animation layers.
- Physical doors: hinge swing, regional damage, latch and hinge failure, debris, navigation updates, AI door use.
- Aim-down-sights aligned from each weapon model's own sight line, with eased blending.
- Yellow Herbs raise maximum health permanently (saved with the profile, kept through prestige).

### Interface
- Status module (lower right): portrait, health arc that lengthens with maximum health, loaded and reserve ammunition.
- Squad status column and killfeed on the left; one line per confirmed death, none for incapacitation.
- Hit marker from confirmed events only: white hit, yellow incapacitation, red kill.
- Minimap contacts coloured by relation (blue squad with facing, green friendly, yellow neutral, red hostile).
- World-space speech bubbles driven by the existing dialogue.
- Resolution-independent layout helpers; fixed the Insertion Point text overflow in the hideout.

### Audio
- Layered gun audio (`engine/audio/gun`): per-weapon profiles, sample-accurate shot scheduling, transient / body /
  tail / distant / mechanical layers, voice budgets, occlusion, early reflections, one shared late reverb,
  compressor and limiter. Player and NPC fire use the same path.
- Recorded assets with documented licences (`ATTRIBUTION.md`, `docs/audio/weapon_asset_manifest.md`), a reproducible
  pipeline (`gradlew prepareAudio`), originals preserved in `tools/audio/originals/`.
- Recorded footsteps for nine surfaces, with variation. Reload cues play recorded handling sounds on the reload
  animation's clock. Door latch, kick and break sounds.

### Project
- Version 0.5 in one place (`absentialis.Version`); save format 5 with migration from 4.
- 394 quality gates (81 new for 0.5).

## Version 0.4

### Fixed
- **No audio.** The Windows Volume Mixer entry for the Java runtime was at 0%. The game now checks its own mixer
  session at start-up and restores it (`engine/audio/WinAudioSession`), shows the device and mixer level, and has
  a test-sound button with live meters. The mixer thread survives a device fault.
- **Crash** in the blood system (`ConcurrentModificationException`): the gore, projectile, thrown and zone loops no
  longer change a list while walking it.
- [F] only plays the interact animation when something was interacted with.
- Weapon icons are fitted to the model and drawn side-on, so every gun fills the tile it occupies.
- A container closes itself a moment after the last item is taken.

### Changed
- **Infection** (`scene/InfectionSystem`): bites can break the skin; BITTEN > FEVER > SICK > CRITICAL with
  symptoms; Antiviral Medicine cures it at any stage. Untreated, the player dies and rises; NPCs turn in the body
  they had.
- **Death**: third-person view of the body as the picture drains, then RESPAWN / MAIN MENU / QUIT. Ironman makes
  death permanent.
- **Lighting** (`engine/render/HybridRenderer`): OpenGL 4.5 deferred PBR in HDR - cascaded sun shadows, tiled light
  culling, shadowed local lights, irradiance probes, GTAO, reflections, volumetric fog, TAA, bloom, auto-exposure.
  Four presets; falls back to the 0.3 renderer without GL 4.5 (`ABS_LEGACY_GL=1`).
- **Damage** (`anatomy/*`, `scene/Gore`): bodies are layered voxels; hits remove what they pass through; wounds
  persist; a limb comes away when what joins it fails.
- **Enemy AI** (`ai/Tactics`, `ai/SquadMind`, `ai/CloseCombat`): awareness from sight and sound only, memory that
  goes stale, squads that share information, roles, scored cover and flanks, suppression, coordinated search,
  close combat.
- **Vehicles** (`vehicle/*`): four-wheel rigid-body simulation at 50 Hz; eight vehicles in `content/vehicles.json`;
  bought in the shop, one per operation, at most four in an operation.
- **Deployment**: a one-page Operation Briefing.
- **Squad**: every squadmate can be renamed.
- **Fire** is a particle system with light, heat, rain and sound (`scene/FireSystem`); the fire voxel is gone.

### Added
- Version numbers on the title screen, hideout, HUD footer and saves.
